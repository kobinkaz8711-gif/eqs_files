export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      budget_articles: {
        Row: {
          code: string
          created_at: string
          id: string
          is_fallback: boolean
          kind: Database["public"]["Enums"]["budget_article_kind"]
          name: string
          scope: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          is_fallback?: boolean
          kind: Database["public"]["Enums"]["budget_article_kind"]
          name: string
          scope?: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          is_fallback?: boolean
          kind?: Database["public"]["Enums"]["budget_article_kind"]
          name?: string
          scope?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      checklist_items: {
        Row: {
          created_at: string
          critical: boolean
          depends_on_item_id: string | null
          hint: string | null
          id: string
          label: string
          required: boolean
          section_id: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          critical?: boolean
          depends_on_item_id?: string | null
          hint?: string | null
          id?: string
          label: string
          required?: boolean
          section_id: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          critical?: boolean
          depends_on_item_id?: string | null
          hint?: string | null
          id?: string
          label?: string
          required?: boolean
          section_id?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "checklist_items_depends_on_item_id_fkey"
            columns: ["depends_on_item_id"]
            isOneToOne: false
            referencedRelation: "checklist_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "checklist_items_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "checklist_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      checklist_sections: {
        Row: {
          created_at: string
          id: string
          sort_order: number
          template_id: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          sort_order?: number
          template_id: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          sort_order?: number
          template_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "checklist_sections_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "checklist_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      checklist_templates: {
        Row: {
          created_at: string
          id: string
          name: string
          transport_type_code: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          transport_type_code: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          transport_type_code?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "checklist_templates_transport_type_code_fkey"
            columns: ["transport_type_code"]
            isOneToOne: true
            referencedRelation: "transport_types"
            referencedColumns: ["code"]
          },
        ]
      }
      container_extractor_api_keys: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          key_value: string
          label: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          key_value: string
          label?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          key_value?: string
          label?: string | null
        }
        Relationships: []
      }
      cost_charge_type_mapping: {
        Row: {
          article_id: string
          created_at: string
          finance_article_id: string | null
          id: string
          source_code: string
          source_type: string
          updated_at: string
        }
        Insert: {
          article_id: string
          created_at?: string
          finance_article_id?: string | null
          id?: string
          source_code: string
          source_type: string
          updated_at?: string
        }
        Update: {
          article_id?: string
          created_at?: string
          finance_article_id?: string | null
          id?: string
          source_code?: string
          source_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "cost_charge_type_mapping_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "budget_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cost_charge_type_mapping_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["article_id"]
          },
          {
            foreignKeyName: "cost_charge_type_mapping_finance_article_id_fkey"
            columns: ["finance_article_id"]
            isOneToOne: false
            referencedRelation: "budget_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cost_charge_type_mapping_finance_article_id_fkey"
            columns: ["finance_article_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["article_id"]
          },
        ]
      }
      departments: {
        Row: {
          code: string | null
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          code?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          code?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      email_templates: {
        Row: {
          body: string
          created_at: string
          id: string
          kind: Database["public"]["Enums"]["email_template_kind"]
          subject: string
          transport_type_code: string | null
          updated_at: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          kind: Database["public"]["Enums"]["email_template_kind"]
          subject: string
          transport_type_code?: string | null
          updated_at?: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          kind?: Database["public"]["Enums"]["email_template_kind"]
          subject?: string
          transport_type_code?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "email_templates_transport_type_code_fkey"
            columns: ["transport_type_code"]
            isOneToOne: false
            referencedRelation: "transport_types"
            referencedColumns: ["code"]
          },
        ]
      }
      eqs_booking_exports: {
        Row: {
          acknowledged_at: string | null
          created_at: string
          created_by: string | null
          eqs_booking_id: string | null
          error: string | null
          file_id: string
          file_number: string
          filename: string
          id: string
          payload: Json | null
          payload_path: string
          response_filename: string | null
          response_path: string | null
          sent_at: string | null
          status: string
        }
        Insert: {
          acknowledged_at?: string | null
          created_at?: string
          created_by?: string | null
          eqs_booking_id?: string | null
          error?: string | null
          file_id: string
          file_number: string
          filename: string
          id?: string
          payload?: Json | null
          payload_path: string
          response_filename?: string | null
          response_path?: string | null
          sent_at?: string | null
          status?: string
        }
        Update: {
          acknowledged_at?: string | null
          created_at?: string
          created_by?: string | null
          eqs_booking_id?: string | null
          error?: string | null
          file_id?: string
          file_number?: string
          filename?: string
          id?: string
          payload?: Json | null
          payload_path?: string
          response_filename?: string | null
          response_path?: string | null
          sent_at?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "eqs_booking_exports_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "eqs_booking_exports_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      eqs_equipment_type_map: {
        Row: {
          iso_code: string
          label: string
          updated_at: string
        }
        Insert: {
          iso_code: string
          label: string
          updated_at?: string
        }
        Update: {
          iso_code?: string
          label?: string
          updated_at?: string
        }
        Relationships: []
      }
      eqs_ext_bookings: {
        Row: {
          accno: string | null
          booking_no: string
          do_locn: string | null
          extracted_at: string | null
          locn_pod: string | null
          locn_pol: string | null
          received_at: string | null
          refresh_run_id: string | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
          vessel: string | null
          voyage: string | null
        }
        Insert: {
          accno?: string | null
          booking_no: string
          do_locn?: string | null
          extracted_at?: string | null
          locn_pod?: string | null
          locn_pol?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          vessel?: string | null
          voyage?: string | null
        }
        Update: {
          accno?: string | null
          booking_no?: string
          do_locn?: string | null
          extracted_at?: string | null
          locn_pod?: string | null
          locn_pol?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          vessel?: string | null
          voyage?: string | null
        }
        Relationships: []
      }
      eqs_ext_container_buyers_5y: {
        Row: {
          accno: string
          country_code: string | null
          country_name: string | null
          customer_name: string | null
          extracted_at: string | null
          first_sale_date: string | null
          last_sale_date: string | null
          last_sale_invoice_no: string | null
          received_at: string | null
          refresh_run_id: string | null
          sale_count: number | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
        }
        Insert: {
          accno: string
          country_code?: string | null
          country_name?: string | null
          customer_name?: string | null
          extracted_at?: string | null
          first_sale_date?: string | null
          last_sale_date?: string | null
          last_sale_invoice_no?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          sale_count?: number | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
        }
        Update: {
          accno?: string
          country_code?: string | null
          country_name?: string | null
          customer_name?: string | null
          extracted_at?: string | null
          first_sale_date?: string | null
          last_sale_date?: string | null
          last_sale_invoice_no?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          sale_count?: number | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
        }
        Relationships: []
      }
      eqs_ext_container_lessees_5y: {
        Row: {
          accno: string
          booking_count: number | null
          country_code: string | null
          country_name: string | null
          customer_name: string | null
          extracted_at: string | null
          first_booking_date: string | null
          last_booking_date: string | null
          last_booking_no: string | null
          received_at: string | null
          refresh_run_id: string | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
        }
        Insert: {
          accno: string
          booking_count?: number | null
          country_code?: string | null
          country_name?: string | null
          customer_name?: string | null
          extracted_at?: string | null
          first_booking_date?: string | null
          last_booking_date?: string | null
          last_booking_no?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
        }
        Update: {
          accno?: string
          booking_count?: number | null
          country_code?: string | null
          country_name?: string | null
          customer_name?: string | null
          extracted_at?: string | null
          first_booking_date?: string | null
          last_booking_date?: string | null
          last_booking_no?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
        }
        Relationships: []
      }
      eqs_ext_cost_charge_types: {
        Row: {
          created_at_source: string | null
          extracted_at: string | null
          is_active: boolean
          received_at: string | null
          refresh_run_id: string | null
          source_code: string
          source_key: string | null
          source_name: string | null
          source_system: string | null
          source_table: string | null
          source_type: string
          updated_at_source: string | null
        }
        Insert: {
          created_at_source?: string | null
          extracted_at?: string | null
          is_active?: boolean
          received_at?: string | null
          refresh_run_id?: string | null
          source_code: string
          source_key?: string | null
          source_name?: string | null
          source_system?: string | null
          source_table?: string | null
          source_type: string
          updated_at_source?: string | null
        }
        Update: {
          created_at_source?: string | null
          extracted_at?: string | null
          is_active?: boolean
          received_at?: string | null
          refresh_run_id?: string | null
          source_code?: string
          source_key?: string | null
          source_name?: string | null
          source_system?: string | null
          source_table?: string | null
          source_type?: string
          updated_at_source?: string | null
        }
        Relationships: []
      }
      eqs_ext_finance_lines: {
        Row: {
          accno: string | null
          amount: number | null
          booking_no: string | null
          credit_note_no: string | null
          currency: string | null
          dte_acct: string | null
          ext_source_id: string | null
          extracted_at: string | null
          finance_direction: string | null
          finance_type: string | null
          id: string
          invoice_date: string | null
          invoice_no: string | null
          original_inv_no: string | null
          party_accname: string | null
          party_accno: string | null
          party_contact: string | null
          party_role: string | null
          received_at: string | null
          refresh_run_id: string | null
          source_area: string | null
          source_code: string | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
          source_type: string | null
          unit_no: string | null
        }
        Insert: {
          accno?: string | null
          amount?: number | null
          booking_no?: string | null
          credit_note_no?: string | null
          currency?: string | null
          dte_acct?: string | null
          ext_source_id?: string | null
          extracted_at?: string | null
          finance_direction?: string | null
          finance_type?: string | null
          id?: string
          invoice_date?: string | null
          invoice_no?: string | null
          original_inv_no?: string | null
          party_accname?: string | null
          party_accno?: string | null
          party_contact?: string | null
          party_role?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          source_area?: string | null
          source_code?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          source_type?: string | null
          unit_no?: string | null
        }
        Update: {
          accno?: string | null
          amount?: number | null
          booking_no?: string | null
          credit_note_no?: string | null
          currency?: string | null
          dte_acct?: string | null
          ext_source_id?: string | null
          extracted_at?: string | null
          finance_direction?: string | null
          finance_type?: string | null
          id?: string
          invoice_date?: string | null
          invoice_no?: string | null
          original_inv_no?: string | null
          party_accname?: string | null
          party_accno?: string | null
          party_contact?: string | null
          party_role?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          source_area?: string | null
          source_code?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          source_type?: string | null
          unit_no?: string | null
        }
        Relationships: []
      }
      eqs_ext_finance_totals: {
        Row: {
          created_at: string
          currency: string | null
          document_date: string | null
          document_no: string
          document_type: string | null
          ext_source_id: string
          extracted_at: string | null
          id: string
          line_count: number | null
          original_document_no: string | null
          party_accno: string | null
          party_name: string | null
          party_role: string | null
          posting_date: string | null
          received_at: string | null
          refresh_run_id: string | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
          total_amount_base: number | null
          total_amount_local: number | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          currency?: string | null
          document_date?: string | null
          document_no: string
          document_type?: string | null
          ext_source_id: string
          extracted_at?: string | null
          id?: string
          line_count?: number | null
          original_document_no?: string | null
          party_accno?: string | null
          party_name?: string | null
          party_role?: string | null
          posting_date?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          total_amount_base?: number | null
          total_amount_local?: number | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          currency?: string | null
          document_date?: string | null
          document_no?: string
          document_type?: string | null
          ext_source_id?: string
          extracted_at?: string | null
          id?: string
          line_count?: number | null
          original_document_no?: string | null
          party_accno?: string | null
          party_name?: string | null
          party_role?: string | null
          posting_date?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          total_amount_base?: number | null
          total_amount_local?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      eqs_ext_locations_subregions: {
        Row: {
          country_code: string | null
          country_name: string | null
          created_at_source: string | null
          extracted_at: string | null
          is_active: boolean
          locn_desc: string | null
          locn_id: string
          received_at: string | null
          refresh_run_id: string | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
          subregion_desc: string | null
          subregion_id: string | null
          updated_at_source: string | null
        }
        Insert: {
          country_code?: string | null
          country_name?: string | null
          created_at_source?: string | null
          extracted_at?: string | null
          is_active?: boolean
          locn_desc?: string | null
          locn_id: string
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          subregion_desc?: string | null
          subregion_id?: string | null
          updated_at_source?: string | null
        }
        Update: {
          country_code?: string | null
          country_name?: string | null
          created_at_source?: string | null
          extracted_at?: string | null
          is_active?: boolean
          locn_desc?: string | null
          locn_id?: string
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          subregion_desc?: string | null
          subregion_id?: string | null
          updated_at_source?: string | null
        }
        Relationships: []
      }
      eqs_ext_recent_units: {
        Row: {
          accno: string | null
          booking_no: string
          charge1_amount: number | null
          charge1_code: string | null
          charge1_currency: string | null
          charge1_name: string | null
          charge2_amount: number | null
          charge2_code: string | null
          charge2_currency: string | null
          charge2_name: string | null
          charge3_amount: number | null
          charge3_code: string | null
          charge3_currency: string | null
          charge3_name: string | null
          charge4_amount: number | null
          charge4_code: string | null
          charge4_currency: string | null
          charge4_name: string | null
          cost1_amount: number | null
          cost1_code: string | null
          cost1_currency: string | null
          cost1_name: string | null
          cost1_supplier_accno: string | null
          cost2_amount: number | null
          cost2_code: string | null
          cost2_currency: string | null
          cost2_name: string | null
          cost2_supplier_accno: string | null
          customer: string | null
          daily_rate: number | null
          department: string | null
          do_locn: string | null
          extracted_at: string | null
          fc_customer: string | null
          free_min_days: number | null
          grade: string | null
          internal_ref: string | null
          lessee_order: string | null
          locn_pod: string | null
          locn_pol: string | null
          onhire_date: string | null
          received_at: string | null
          refresh_run_id: string | null
          repl_value: number | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
          unit_no: string
        }
        Insert: {
          accno?: string | null
          booking_no: string
          charge1_amount?: number | null
          charge1_code?: string | null
          charge1_currency?: string | null
          charge1_name?: string | null
          charge2_amount?: number | null
          charge2_code?: string | null
          charge2_currency?: string | null
          charge2_name?: string | null
          charge3_amount?: number | null
          charge3_code?: string | null
          charge3_currency?: string | null
          charge3_name?: string | null
          charge4_amount?: number | null
          charge4_code?: string | null
          charge4_currency?: string | null
          charge4_name?: string | null
          cost1_amount?: number | null
          cost1_code?: string | null
          cost1_currency?: string | null
          cost1_name?: string | null
          cost1_supplier_accno?: string | null
          cost2_amount?: number | null
          cost2_code?: string | null
          cost2_currency?: string | null
          cost2_name?: string | null
          cost2_supplier_accno?: string | null
          customer?: string | null
          daily_rate?: number | null
          department?: string | null
          do_locn?: string | null
          extracted_at?: string | null
          fc_customer?: string | null
          free_min_days?: number | null
          grade?: string | null
          internal_ref?: string | null
          lessee_order?: string | null
          locn_pod?: string | null
          locn_pol?: string | null
          onhire_date?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          repl_value?: number | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          unit_no: string
        }
        Update: {
          accno?: string | null
          booking_no?: string
          charge1_amount?: number | null
          charge1_code?: string | null
          charge1_currency?: string | null
          charge1_name?: string | null
          charge2_amount?: number | null
          charge2_code?: string | null
          charge2_currency?: string | null
          charge2_name?: string | null
          charge3_amount?: number | null
          charge3_code?: string | null
          charge3_currency?: string | null
          charge3_name?: string | null
          charge4_amount?: number | null
          charge4_code?: string | null
          charge4_currency?: string | null
          charge4_name?: string | null
          cost1_amount?: number | null
          cost1_code?: string | null
          cost1_currency?: string | null
          cost1_name?: string | null
          cost1_supplier_accno?: string | null
          cost2_amount?: number | null
          cost2_code?: string | null
          cost2_currency?: string | null
          cost2_name?: string | null
          cost2_supplier_accno?: string | null
          customer?: string | null
          daily_rate?: number | null
          department?: string | null
          do_locn?: string | null
          extracted_at?: string | null
          fc_customer?: string | null
          free_min_days?: number | null
          grade?: string | null
          internal_ref?: string | null
          lessee_order?: string | null
          locn_pod?: string | null
          locn_pol?: string | null
          onhire_date?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          repl_value?: number | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          unit_no?: string
        }
        Relationships: []
      }
      eqs_ext_refresh_runs: {
        Row: {
          finished_at: string | null
          notes: string | null
          refresh_run_id: string
          rows_loaded: number | null
          started_at: string
          status: string | null
        }
        Insert: {
          finished_at?: string | null
          notes?: string | null
          refresh_run_id: string
          rows_loaded?: number | null
          started_at?: string
          status?: string | null
        }
        Update: {
          finished_at?: string | null
          notes?: string | null
          refresh_run_id?: string
          rows_loaded?: number | null
          started_at?: string
          status?: string | null
        }
        Relationships: []
      }
      eqs_ext_rt_charges: {
        Row: {
          accno: string | null
          amount: number | null
          charge_code: string | null
          charge_date: string | null
          currency: string | null
          extracted_at: string | null
          id: string
          received_at: string | null
          refresh_run_id: string | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
          unit_no: string | null
        }
        Insert: {
          accno?: string | null
          amount?: number | null
          charge_code?: string | null
          charge_date?: string | null
          currency?: string | null
          extracted_at?: string | null
          id?: string
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          unit_no?: string | null
        }
        Update: {
          accno?: string | null
          amount?: number | null
          charge_code?: string | null
          charge_date?: string | null
          currency?: string | null
          extracted_at?: string | null
          id?: string
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          unit_no?: string | null
        }
        Relationships: []
      }
      eqs_ext_sales: {
        Row: {
          amount: number | null
          amount_base: number | null
          buyer_accno: string | null
          buyer_name: string | null
          created_at: string
          currency: string | null
          depot_code: string | null
          dte_acct: string | null
          ext_source_id: string
          extracted_at: string | null
          id: string
          invoice_date: string | null
          invoice_no: string | null
          original_inv_no: string | null
          received_at: string | null
          refresh_run_id: string | null
          sale_direction: string | null
          sale_locn: string | null
          sale_subregion: string | null
          sales_person: string | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
          unit_iso: string | null
          unit_no: string
          updated_at: string
        }
        Insert: {
          amount?: number | null
          amount_base?: number | null
          buyer_accno?: string | null
          buyer_name?: string | null
          created_at?: string
          currency?: string | null
          depot_code?: string | null
          dte_acct?: string | null
          ext_source_id: string
          extracted_at?: string | null
          id?: string
          invoice_date?: string | null
          invoice_no?: string | null
          original_inv_no?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          sale_direction?: string | null
          sale_locn?: string | null
          sale_subregion?: string | null
          sales_person?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          unit_iso?: string | null
          unit_no: string
          updated_at?: string
        }
        Update: {
          amount?: number | null
          amount_base?: number | null
          buyer_accno?: string | null
          buyer_name?: string | null
          created_at?: string
          currency?: string | null
          depot_code?: string | null
          dte_acct?: string | null
          ext_source_id?: string
          extracted_at?: string | null
          id?: string
          invoice_date?: string | null
          invoice_no?: string | null
          original_inv_no?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          sale_direction?: string | null
          sale_locn?: string | null
          sale_subregion?: string | null
          sales_person?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          unit_iso?: string | null
          unit_no?: string
          updated_at?: string
        }
        Relationships: []
      }
      eqs_ext_unit_history: {
        Row: {
          accno: string | null
          booking_no: string | null
          event_code: string | null
          event_date: string | null
          event_type: string | null
          extracted_at: string | null
          id: string
          locn_id: string | null
          received_at: string | null
          refresh_run_id: string | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
          unit_no: string
        }
        Insert: {
          accno?: string | null
          booking_no?: string | null
          event_code?: string | null
          event_date?: string | null
          event_type?: string | null
          extracted_at?: string | null
          id?: string
          locn_id?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          unit_no: string
        }
        Update: {
          accno?: string | null
          booking_no?: string | null
          event_code?: string | null
          event_date?: string | null
          event_type?: string | null
          extracted_at?: string | null
          id?: string
          locn_id?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          unit_no?: string
        }
        Relationships: []
      }
      eqs_ext_unit_refresh_status: {
        Row: {
          is_stale: boolean
          last_refresh_at: string | null
          last_refresh_run_id: string | null
          unit_no: string
        }
        Insert: {
          is_stale?: boolean
          last_refresh_at?: string | null
          last_refresh_run_id?: string | null
          unit_no: string
        }
        Update: {
          is_stale?: boolean
          last_refresh_at?: string | null
          last_refresh_run_id?: string | null
          unit_no?: string
        }
        Relationships: []
      }
      eqs_ext_units: {
        Row: {
          amt_ppb: number | null
          amt_ppl: number | null
          extracted_at: string | null
          grade: string | null
          iso_code: string | null
          owner_code: string | null
          received_at: string | null
          refresh_run_id: string | null
          sale_amt_b: number | null
          source_key: string | null
          source_system: string | null
          source_table: string | null
          status: string | null
          unit_no: string
          year_built: number | null
        }
        Insert: {
          amt_ppb?: number | null
          amt_ppl?: number | null
          extracted_at?: string | null
          grade?: string | null
          iso_code?: string | null
          owner_code?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          sale_amt_b?: number | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          status?: string | null
          unit_no: string
          year_built?: number | null
        }
        Update: {
          amt_ppb?: number | null
          amt_ppl?: number | null
          extracted_at?: string | null
          grade?: string | null
          iso_code?: string | null
          owner_code?: string | null
          received_at?: string | null
          refresh_run_id?: string | null
          sale_amt_b?: number | null
          source_key?: string | null
          source_system?: string | null
          source_table?: string | null
          status?: string | null
          unit_no?: string
          year_built?: number | null
        }
        Relationships: []
      }
      eqs_sftp_settings: {
        Row: {
          enabled: boolean
          errors_remote_path: string | null
          host: string | null
          id: number
          incomplete_remote_path: string | null
          outbox_remote_path: string | null
          poll_interval_seconds: number
          port: number
          processed_remote_path: string | null
          updated_at: string
          use_tls: boolean
          username: string | null
        }
        Insert: {
          enabled?: boolean
          errors_remote_path?: string | null
          host?: string | null
          id?: number
          incomplete_remote_path?: string | null
          outbox_remote_path?: string | null
          poll_interval_seconds?: number
          port?: number
          processed_remote_path?: string | null
          updated_at?: string
          use_tls?: boolean
          username?: string | null
        }
        Update: {
          enabled?: boolean
          errors_remote_path?: string | null
          host?: string | null
          id?: number
          incomplete_remote_path?: string | null
          outbox_remote_path?: string | null
          poll_interval_seconds?: number
          port?: number
          processed_remote_path?: string | null
          updated_at?: string
          use_tls?: boolean
          username?: string | null
        }
        Relationships: []
      }
      equipment_grades: {
        Row: {
          code: string
          created_at: string
          is_active: boolean
          label: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          is_active?: boolean
          label: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          is_active?: boolean
          label?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      feature_flags: {
        Row: {
          code: string
          enabled: boolean
          updated_at: string
        }
        Insert: {
          code: string
          enabled?: boolean
          updated_at?: string
        }
        Update: {
          code?: string
          enabled?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      file_audit_log: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          details: Json | null
          file_id: string | null
          id: string
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          details?: Json | null
          file_id?: string | null
          id?: string
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          details?: Json | null
          file_id?: string | null
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "file_audit_log_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_audit_log_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      file_booking_assignment_history: {
        Row: {
          acted_at: string
          acted_by: string | null
          action: string
          booking_no: string
          file_id: string
          id: string
        }
        Insert: {
          acted_at?: string
          acted_by?: string | null
          action: string
          booking_no: string
          file_id: string
          id?: string
        }
        Update: {
          acted_at?: string
          acted_by?: string | null
          action?: string
          booking_no?: string
          file_id?: string
          id?: string
        }
        Relationships: []
      }
      file_booking_assignments: {
        Row: {
          assigned_at: string
          assigned_by: string | null
          booking_no: string
          file_id: string
          id: string
          is_active: boolean
          notes: string | null
          source: string
          unlinked_at: string | null
          unlinked_by: string | null
        }
        Insert: {
          assigned_at?: string
          assigned_by?: string | null
          booking_no: string
          file_id: string
          id?: string
          is_active?: boolean
          notes?: string | null
          source?: string
          unlinked_at?: string | null
          unlinked_by?: string | null
        }
        Update: {
          assigned_at?: string
          assigned_by?: string | null
          booking_no?: string
          file_id?: string
          id?: string
          is_active?: boolean
          notes?: string | null
          source?: string
          unlinked_at?: string | null
          unlinked_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "file_booking_assignments_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_booking_assignments_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      file_budget_fact_lines: {
        Row: {
          amount: number
          article_id: string
          created_at: string
          currency: string
          file_id: string
          id: string
          source_finance_line_id: string | null
          unit_no: string | null
        }
        Insert: {
          amount?: number
          article_id: string
          created_at?: string
          currency: string
          file_id: string
          id?: string
          source_finance_line_id?: string | null
          unit_no?: string | null
        }
        Update: {
          amount?: number
          article_id?: string
          created_at?: string
          currency?: string
          file_id?: string
          id?: string
          source_finance_line_id?: string | null
          unit_no?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "file_budget_fact_lines_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "budget_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_budget_fact_lines_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["article_id"]
          },
          {
            foreignKeyName: "file_budget_fact_lines_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_budget_fact_lines_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      file_budget_plan_lines: {
        Row: {
          amount_eur: number | null
          amount_per_unit: number
          amount_usd: number | null
          article_id: string
          container_type: string | null
          created_at: string
          currency: string
          file_id: string
          id: string
          notes: string | null
          planned_qty: number
          source_type: string
          total_amount: number | null
          updated_at: string
        }
        Insert: {
          amount_eur?: number | null
          amount_per_unit?: number
          amount_usd?: number | null
          article_id: string
          container_type?: string | null
          created_at?: string
          currency: string
          file_id: string
          id?: string
          notes?: string | null
          planned_qty?: number
          source_type?: string
          total_amount?: number | null
          updated_at?: string
        }
        Update: {
          amount_eur?: number | null
          amount_per_unit?: number
          amount_usd?: number | null
          article_id?: string
          container_type?: string | null
          created_at?: string
          currency?: string
          file_id?: string
          id?: string
          notes?: string | null
          planned_qty?: number
          source_type?: string
          total_amount?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "file_budget_plan_lines_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "budget_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_budget_plan_lines_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["article_id"]
          },
          {
            foreignKeyName: "file_budget_plan_lines_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_budget_plan_lines_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      file_container_types: {
        Row: {
          charge1_amount: number | null
          charge1_code: string | null
          charge2_amount: number | null
          charge2_code: string | null
          charge3_amount: number | null
          charge3_code: string | null
          charge4_amount: number | null
          charge4_code: string | null
          container_type: string
          cost1_amount: number | null
          cost1_code: string | null
          cost1_currency: string | null
          cost1_supplier_accno: string | null
          cost2_amount: number | null
          cost2_code: string | null
          cost2_currency: string | null
          cost2_supplier_accno: string | null
          created_at: string
          daily_rate: number | null
          file_id: string
          free_min_days: number | null
          grade: string | null
          id: string
          planned_qty: number
          repl_value: number | null
        }
        Insert: {
          charge1_amount?: number | null
          charge1_code?: string | null
          charge2_amount?: number | null
          charge2_code?: string | null
          charge3_amount?: number | null
          charge3_code?: string | null
          charge4_amount?: number | null
          charge4_code?: string | null
          container_type: string
          cost1_amount?: number | null
          cost1_code?: string | null
          cost1_currency?: string | null
          cost1_supplier_accno?: string | null
          cost2_amount?: number | null
          cost2_code?: string | null
          cost2_currency?: string | null
          cost2_supplier_accno?: string | null
          created_at?: string
          daily_rate?: number | null
          file_id: string
          free_min_days?: number | null
          grade?: string | null
          id?: string
          planned_qty: number
          repl_value?: number | null
        }
        Update: {
          charge1_amount?: number | null
          charge1_code?: string | null
          charge2_amount?: number | null
          charge2_code?: string | null
          charge3_amount?: number | null
          charge3_code?: string | null
          charge4_amount?: number | null
          charge4_code?: string | null
          container_type?: string
          cost1_amount?: number | null
          cost1_code?: string | null
          cost1_currency?: string | null
          cost1_supplier_accno?: string | null
          cost2_amount?: number | null
          cost2_code?: string | null
          cost2_currency?: string | null
          cost2_supplier_accno?: string | null
          created_at?: string
          daily_rate?: number | null
          file_id?: string
          free_min_days?: number | null
          grade?: string | null
          id?: string
          planned_qty?: number
          repl_value?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "file_container_types_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_container_types_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
          {
            foreignKeyName: "file_container_types_grade_fkey"
            columns: ["grade"]
            isOneToOne: false
            referencedRelation: "equipment_grades"
            referencedColumns: ["code"]
          },
        ]
      }
      file_finance_lines: {
        Row: {
          amount: number | null
          article_id: string | null
          created_at: string
          currency: string | null
          dte_acct: string | null
          file_id: string
          id: string
          invoice_date: string | null
          invoice_no: string | null
          is_unmapped: boolean
          source_code: string | null
          source_finance_id: string | null
          source_type: string | null
          unit_no: string | null
        }
        Insert: {
          amount?: number | null
          article_id?: string | null
          created_at?: string
          currency?: string | null
          dte_acct?: string | null
          file_id: string
          id?: string
          invoice_date?: string | null
          invoice_no?: string | null
          is_unmapped?: boolean
          source_code?: string | null
          source_finance_id?: string | null
          source_type?: string | null
          unit_no?: string | null
        }
        Update: {
          amount?: number | null
          article_id?: string | null
          created_at?: string
          currency?: string | null
          dte_acct?: string | null
          file_id?: string
          id?: string
          invoice_date?: string | null
          invoice_no?: string | null
          is_unmapped?: boolean
          source_code?: string | null
          source_finance_id?: string | null
          source_type?: string | null
          unit_no?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "file_finance_lines_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "budget_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_finance_lines_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["article_id"]
          },
          {
            foreignKeyName: "file_finance_lines_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_finance_lines_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      file_rt_billing_rules: {
        Row: {
          config: Json
          created_at: string
          file_id: string
          id: string
          rule_code: string
        }
        Insert: {
          config?: Json
          created_at?: string
          file_id: string
          id?: string
          rule_code: string
        }
        Update: {
          config?: Json
          created_at?: string
          file_id?: string
          id?: string
          rule_code?: string
        }
        Relationships: [
          {
            foreignKeyName: "file_rt_billing_rules_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_rt_billing_rules_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      file_rt_charges: {
        Row: {
          amount: number | null
          charge_code: string | null
          charge_date: string | null
          created_at: string
          currency: string | null
          file_id: string
          id: string
          source_rt_id: string | null
          unit_no: string | null
        }
        Insert: {
          amount?: number | null
          charge_code?: string | null
          charge_date?: string | null
          created_at?: string
          currency?: string | null
          file_id: string
          id?: string
          source_rt_id?: string | null
          unit_no?: string | null
        }
        Update: {
          amount?: number | null
          charge_code?: string | null
          charge_date?: string | null
          created_at?: string
          currency?: string | null
          file_id?: string
          id?: string
          source_rt_id?: string | null
          unit_no?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "file_rt_charges_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_rt_charges_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      file_snapshot_lines: {
        Row: {
          bucket: string
          created_at: string
          id: string
          payload: Json
          snapshot_id: string
        }
        Insert: {
          bucket: string
          created_at?: string
          id?: string
          payload: Json
          snapshot_id: string
        }
        Update: {
          bucket?: string
          created_at?: string
          id?: string
          payload?: Json
          snapshot_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "file_snapshot_lines_snapshot_id_fkey"
            columns: ["snapshot_id"]
            isOneToOne: false
            referencedRelation: "file_snapshots"
            referencedColumns: ["id"]
          },
        ]
      }
      file_snapshots: {
        Row: {
          created_at: string
          created_by: string | null
          file_id: string
          id: string
          reason: string
          status_at_snapshot: Database["public"]["Enums"]["file_status"] | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          file_id: string
          id?: string
          reason: string
          status_at_snapshot?: Database["public"]["Enums"]["file_status"] | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          file_id?: string
          id?: string
          reason?: string
          status_at_snapshot?: Database["public"]["Enums"]["file_status"] | null
        }
        Relationships: [
          {
            foreignKeyName: "file_snapshots_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_snapshots_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      file_status_history: {
        Row: {
          changed_at: string
          changed_by: string | null
          file_id: string
          from_status: Database["public"]["Enums"]["file_status"] | null
          id: string
          notes: string | null
          to_status: Database["public"]["Enums"]["file_status"]
        }
        Insert: {
          changed_at?: string
          changed_by?: string | null
          file_id: string
          from_status?: Database["public"]["Enums"]["file_status"] | null
          id?: string
          notes?: string | null
          to_status: Database["public"]["Enums"]["file_status"]
        }
        Update: {
          changed_at?: string
          changed_by?: string | null
          file_id?: string
          from_status?: Database["public"]["Enums"]["file_status"] | null
          id?: string
          notes?: string | null
          to_status?: Database["public"]["Enums"]["file_status"]
        }
        Relationships: [
          {
            foreignKeyName: "file_status_history_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_status_history_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      file_unit_assignment_history: {
        Row: {
          acted_at: string
          acted_by: string | null
          action: string
          file_id: string
          id: string
          unit_no: string
        }
        Insert: {
          acted_at?: string
          acted_by?: string | null
          action: string
          file_id: string
          id?: string
          unit_no: string
        }
        Update: {
          acted_at?: string
          acted_by?: string | null
          action?: string
          file_id?: string
          id?: string
          unit_no?: string
        }
        Relationships: []
      }
      file_unit_assignments: {
        Row: {
          assigned_at: string
          assigned_by: string | null
          booking_no: string | null
          effective_date_from: string | null
          effective_date_to: string | null
          effective_from_source: string | null
          effective_to_source: string | null
          file_id: string
          grade: string | null
          id: string
          is_active: boolean
          locn_pod: string | null
          locn_pol: string | null
          onhire_date: string | null
          unit_no: string
          unit_type: string | null
          unlinked_at: string | null
        }
        Insert: {
          assigned_at?: string
          assigned_by?: string | null
          booking_no?: string | null
          effective_date_from?: string | null
          effective_date_to?: string | null
          effective_from_source?: string | null
          effective_to_source?: string | null
          file_id: string
          grade?: string | null
          id?: string
          is_active?: boolean
          locn_pod?: string | null
          locn_pol?: string | null
          onhire_date?: string | null
          unit_no: string
          unit_type?: string | null
          unlinked_at?: string | null
        }
        Update: {
          assigned_at?: string
          assigned_by?: string | null
          booking_no?: string | null
          effective_date_from?: string | null
          effective_date_to?: string | null
          effective_from_source?: string | null
          effective_to_source?: string | null
          file_id?: string
          grade?: string | null
          id?: string
          is_active?: boolean
          locn_pod?: string | null
          locn_pol?: string | null
          onhire_date?: string | null
          unit_no?: string
          unit_type?: string | null
          unlinked_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "file_unit_assignments_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_unit_assignments_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      file_warnings: {
        Row: {
          code: string
          created_at: string
          file_id: string
          id: string
          is_resolved: boolean
          message: string | null
          severity: string
        }
        Insert: {
          code: string
          created_at?: string
          file_id: string
          id?: string
          is_resolved?: boolean
          message?: string | null
          severity?: string
        }
        Update: {
          code?: string
          created_at?: string
          file_id?: string
          id?: string
          is_resolved?: boolean
          message?: string | null
          severity?: string
        }
        Relationships: [
          {
            foreignKeyName: "file_warnings_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_warnings_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
      files: {
        Row: {
          budget_unlocked: boolean
          business_date: string | null
          cl_date: string | null
          closed_at: string | null
          cn_date: string | null
          created_at: string
          created_by: string | null
          customer_accno: string | null
          customer_name: string | null
          department_id: string
          dest_country_code: string | null
          dest_locn: string | null
          dest_subregion: string | null
          direction: Database["public"]["Enums"]["file_direction"] | null
          eqs_booking_error: string | null
          eqs_booking_id: string | null
          eqs_booking_received_at: string | null
          eqs_booking_sent_at: string | null
          eqs_booking_state: string | null
          file_number: string | null
          fx_rate_eur_usd: number | null
          id: string
          lessee_order: string | null
          notes: string | null
          op_date: string | null
          opened_at: string | null
          origin_country_code: string | null
          origin_locn: string | null
          origin_subregion: string | null
          planned_arrival_date: string | null
          planned_departure_date: string | null
          rcl_date: string | null
          rp_date: string | null
          sales_manager_id: string | null
          sales_person_id: string | null
          status: Database["public"]["Enums"]["file_status"]
          updated_at: string
        }
        Insert: {
          budget_unlocked?: boolean
          business_date?: string | null
          cl_date?: string | null
          closed_at?: string | null
          cn_date?: string | null
          created_at?: string
          created_by?: string | null
          customer_accno?: string | null
          customer_name?: string | null
          department_id: string
          dest_country_code?: string | null
          dest_locn?: string | null
          dest_subregion?: string | null
          direction?: Database["public"]["Enums"]["file_direction"] | null
          eqs_booking_error?: string | null
          eqs_booking_id?: string | null
          eqs_booking_received_at?: string | null
          eqs_booking_sent_at?: string | null
          eqs_booking_state?: string | null
          file_number?: string | null
          fx_rate_eur_usd?: number | null
          id?: string
          lessee_order?: string | null
          notes?: string | null
          op_date?: string | null
          opened_at?: string | null
          origin_country_code?: string | null
          origin_locn?: string | null
          origin_subregion?: string | null
          planned_arrival_date?: string | null
          planned_departure_date?: string | null
          rcl_date?: string | null
          rp_date?: string | null
          sales_manager_id?: string | null
          sales_person_id?: string | null
          status?: Database["public"]["Enums"]["file_status"]
          updated_at?: string
        }
        Update: {
          budget_unlocked?: boolean
          business_date?: string | null
          cl_date?: string | null
          closed_at?: string | null
          cn_date?: string | null
          created_at?: string
          created_by?: string | null
          customer_accno?: string | null
          customer_name?: string | null
          department_id?: string
          dest_country_code?: string | null
          dest_locn?: string | null
          dest_subregion?: string | null
          direction?: Database["public"]["Enums"]["file_direction"] | null
          eqs_booking_error?: string | null
          eqs_booking_id?: string | null
          eqs_booking_received_at?: string | null
          eqs_booking_sent_at?: string | null
          eqs_booking_state?: string | null
          file_number?: string | null
          fx_rate_eur_usd?: number | null
          id?: string
          lessee_order?: string | null
          notes?: string | null
          op_date?: string | null
          opened_at?: string | null
          origin_country_code?: string | null
          origin_locn?: string | null
          origin_subregion?: string | null
          planned_arrival_date?: string | null
          planned_departure_date?: string | null
          rcl_date?: string | null
          rp_date?: string | null
          sales_manager_id?: string | null
          sales_person_id?: string | null
          status?: Database["public"]["Enums"]["file_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "files_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "files_sales_manager_id_fkey"
            columns: ["sales_manager_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "files_sales_person_id_fkey"
            columns: ["sales_person_id"]
            isOneToOne: false
            referencedRelation: "sales_persons"
            referencedColumns: ["id"]
          },
        ]
      }
      module_departments: {
        Row: {
          created_at: string
          department_id: string
          module_id: string
        }
        Insert: {
          created_at?: string
          department_id: string
          module_id: string
        }
        Update: {
          created_at?: string
          department_id?: string
          module_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "module_departments_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "module_departments_module_id_fkey"
            columns: ["module_id"]
            isOneToOne: false
            referencedRelation: "modules"
            referencedColumns: ["id"]
          },
        ]
      }
      modules: {
        Row: {
          code: string
          created_at: string
          description: string | null
          icon: string | null
          id: string
          is_active: boolean
          name: string
          route: string | null
          sort_order: number
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          route?: string | null
          sort_order?: number
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          route?: string | null
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      permissions: {
        Row: {
          code: string
          created_at: string
          description: string | null
          id: string
        }
        Insert: {
          code: string
          created_at?: string
          description?: string | null
          id?: string
        }
        Update: {
          code?: string
          created_at?: string
          description?: string | null
          id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          department_id: string | null
          email: string
          full_name: string | null
          id: string
          is_active: boolean
          position: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          department_id?: string | null
          email: string
          full_name?: string | null
          id: string
          is_active?: boolean
          position?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          department_id?: string | null
          email?: string
          full_name?: string | null
          id?: string
          is_active?: boolean
          position?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      reporting_period_control: {
        Row: {
          current_closed_date: string | null
          id: boolean
          updated_at: string
        }
        Insert: {
          current_closed_date?: string | null
          id?: boolean
          updated_at?: string
        }
        Update: {
          current_closed_date?: string | null
          id?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      role_permissions: {
        Row: {
          created_at: string
          permission_id: string
          role_id: string
        }
        Insert: {
          created_at?: string
          permission_id: string
          role_id: string
        }
        Update: {
          created_at?: string
          permission_id?: string
          role_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "role_permissions_permission_id_fkey"
            columns: ["permission_id"]
            isOneToOne: false
            referencedRelation: "permissions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "role_permissions_role_id_fkey"
            columns: ["role_id"]
            isOneToOne: false
            referencedRelation: "roles"
            referencedColumns: ["id"]
          },
        ]
      }
      roles: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_system: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_system?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_system?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      sales_finance_article_map: {
        Row: {
          created_at: string
          finance_article_id: string
          sales_article_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          finance_article_id: string
          sales_article_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          finance_article_id?: string
          sales_article_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sales_finance_article_map_finance_article_id_fkey"
            columns: ["finance_article_id"]
            isOneToOne: false
            referencedRelation: "budget_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_finance_article_map_finance_article_id_fkey"
            columns: ["finance_article_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["article_id"]
          },
          {
            foreignKeyName: "sales_finance_article_map_sales_article_id_fkey"
            columns: ["sales_article_id"]
            isOneToOne: true
            referencedRelation: "budget_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_finance_article_map_sales_article_id_fkey"
            columns: ["sales_article_id"]
            isOneToOne: true
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["article_id"]
          },
        ]
      }
      sales_persons: {
        Row: {
          created_at: string
          department_id: string | null
          full_name: string
          id: string
          is_active: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          department_id?: string | null
          full_name: string
          id?: string
          is_active?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          department_id?: string | null
          full_name?: string
          id?: string
          is_active?: boolean
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sales_persons_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      transport_types: {
        Row: {
          code: string
          created_at: string
          is_active: boolean
          label: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          is_active?: boolean
          label: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          is_active?: boolean
          label?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          role_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          role_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          role_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_role_id_fkey"
            columns: ["role_id"]
            isOneToOne: false
            referencedRelation: "roles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      container_extractor_api_keys_public: {
        Row: {
          created_at: string | null
          id: string | null
          key_length: number | null
          label: string | null
          last4: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string | null
          key_length?: never
          label?: string | null
          last4?: never
        }
        Update: {
          created_at?: string | null
          id?: string | null
          key_length?: never
          label?: string | null
          last4?: never
        }
        Relationships: []
      }
      vw_file_budget_summary: {
        Row: {
          article_code: string | null
          article_id: string | null
          article_name: string | null
          fact_eur: number | null
          fact_usd: number | null
          file_id: string | null
          kind: Database["public"]["Enums"]["budget_article_kind"] | null
          plan_eur: number | null
          plan_eur_converted: number | null
          plan_usd: number | null
          plan_usd_converted: number | null
          sort_order: number | null
        }
        Relationships: []
      }
      vw_file_finance_current: {
        Row: {
          amount: number | null
          currency: string | null
          dte_acct: string | null
          file_id: string | null
          finance_id: string | null
          invoice_date: string | null
          invoice_no: string | null
          source_code: string | null
          source_type: string | null
          unit_no: string | null
        }
        Relationships: [
          {
            foreignKeyName: "file_unit_assignments_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "file_unit_assignments_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "vw_file_budget_summary"
            referencedColumns: ["file_id"]
          },
        ]
      }
    }
    Functions: {
      fn_assign_booking: {
        Args: { p_booking_no: string; p_file_id: string; p_source?: string }
        Returns: string
      }
      fn_assign_unit: {
        Args: { p_file_id: string; p_unit_no: string }
        Returns: string
      }
      fn_assign_unit_with_check: {
        Args: { p_booking_no?: string; p_file_id: string; p_unit_no: string }
        Returns: string
      }
      fn_cancel_file:
        | { Args: { p_file_id: string; p_reason?: string }; Returns: undefined }
        | {
            Args: {
              p_file_id: string
              p_reason?: string
              p_status_date?: string
            }
            Returns: undefined
          }
      fn_change_file_department: {
        Args: { p_file_id: string; p_new_department_id: string }
        Returns: string
      }
      fn_close_file:
        | { Args: { p_file_id: string; p_notes?: string }; Returns: string }
        | {
            Args: {
              p_file_id: string
              p_notes?: string
              p_status_date?: string
            }
            Returns: string
          }
      fn_confirm_rp:
        | { Args: { p_file_id: string; p_notes?: string }; Returns: string }
        | {
            Args: {
              p_file_id: string
              p_notes?: string
              p_status_date?: string
            }
            Returns: string
          }
      fn_create_file: {
        Args: {
          p_customer_accno?: string
          p_customer_name?: string
          p_department_id: string
          p_dest_locn?: string
          p_dest_subregion?: string
          p_direction?: Database["public"]["Enums"]["file_direction"]
          p_notes?: string
          p_origin_locn?: string
          p_origin_subregion?: string
          p_planned_arrival_date?: string
          p_planned_departure_date?: string
        }
        Returns: string
      }
      fn_create_status_snapshot: {
        Args: { p_file_id: string; p_reason: string }
        Returns: string
      }
      fn_open_file:
        | { Args: { p_file_id: string }; Returns: undefined }
        | {
            Args: { p_file_id: string; p_status_date?: string }
            Returns: undefined
          }
      fn_refresh_file_finance_lines: {
        Args: { p_file_id: string }
        Returns: number
      }
      fn_refresh_file_from_ext: { Args: { p_file_id: string }; Returns: Json }
      fn_revert_file_status: {
        Args: { p_file_id: string; p_notes?: string }
        Returns: Database["public"]["Enums"]["file_status"]
      }
      fn_set_file_status_dates: {
        Args: {
          p_cl?: string
          p_cn?: string
          p_file_id: string
          p_op?: string
          p_rcl?: string
          p_rp?: string
        }
        Returns: undefined
      }
      fn_set_ready_for_cl:
        | { Args: { p_file_id: string; p_notes?: string }; Returns: string }
        | {
            Args: {
              p_file_id: string
              p_notes?: string
              p_status_date?: string
            }
            Returns: string
          }
      fn_sync_booking_units: {
        Args: { p_booking_no: string; p_file_id: string }
        Returns: number
      }
      fn_unlink_booking: { Args: { p_assignment_id: string }; Returns: number }
      fn_unlink_unit: { Args: { p_assignment_id: string }; Returns: undefined }
      has_permission: {
        Args: { _code: string; _user_id: string }
        Returns: boolean
      }
      has_role: { Args: { _name: string; _user_id: string }; Returns: boolean }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      user_has_module_access: {
        Args: { _module_code: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      budget_article_kind: "COST" | "REVENUE"
      email_template_kind: "ok" | "missing"
      file_direction: "EXPORT" | "IMPORT" | "TRIANGLE"
      file_status: "DR" | "OP" | "RP" | "RCL" | "CL" | "CN"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      budget_article_kind: ["COST", "REVENUE"],
      email_template_kind: ["ok", "missing"],
      file_direction: ["EXPORT", "IMPORT", "TRIANGLE"],
      file_status: ["DR", "OP", "RP", "RCL", "CL", "CN"],
    },
  },
} as const
