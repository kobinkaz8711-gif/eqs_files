import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { AuthProvider } from "@/hooks/useAuth";
import { I18nProvider } from "@/i18n/i18n";
import { Toaster } from "@/components/ui/sonner";

function getLocale(): "ru" | "en" {
  if (typeof window === "undefined") return "ru";
  try {
    const v = window.localStorage.getItem("locale");
    return v === "en" ? "en" : "ru";
  } catch {
    return "ru";
  }
}

import appCss from "../styles.css?url";

function NotFoundComponent() {
  const ru = getLocale() === "ru";
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">
          {ru ? "Страница не найдена" : "Page not found"}
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          {ru
            ? "Запрошенная страница не существует или была перемещена."
            : "The requested page doesn't exist or has been moved."}
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            {ru ? "На главную" : "Home"}
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  const ru = getLocale() === "ru";

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          {ru ? "Не удалось загрузить страницу" : "Failed to load page"}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {ru
            ? "Что-то пошло не так. Попробуйте обновить или вернуться на главную."
            : "Something went wrong. Try reloading or return home."}
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            {ru ? "Повторить" : "Retry"}
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            {ru ? "На главную" : "Home"}
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "CMS" },
      {
        name: "description",
        content:
          "Ultra-fast чек-лист для отдела логистики: проставьте галочки — получите готовое письмо для менеджера.",
      },
      { property: "og:title", content: "CMS" },
      { property: "og:type", content: "website" },
      { name: "twitter:title", content: "CMS" },
      { name: "description", content: "CMS" },
      { property: "og:description", content: "CMS" },
      { name: "twitter:description", content: "CMS" },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/cKdMVlFLObVFAWr4suT1hElei1j2/social-images/social-1780047649048-registracionnaya_bukva_r_iz_samokleyashhejsya_tkani_bainbridge_sl250bur_250_mm_sinyaya.webp" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/cKdMVlFLObVFAWr4suT1hElei1j2/social-images/social-1780047649048-registracionnaya_bukva_r_iz_samokleyashhejsya_tkani_bainbridge_sl250bur_250_mm_sinyaya.webp" },
      { name: "twitter:card", content: "summary_large_image" },
    ],


    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Lora:wght@500;600;700&family=JetBrains+Mono:wght@500&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <I18nProvider>
        <AuthProvider>
          <Outlet />
          <Toaster position="bottom-right" />
        </AuthProvider>
      </I18nProvider>
    </QueryClientProvider>
  );
}
