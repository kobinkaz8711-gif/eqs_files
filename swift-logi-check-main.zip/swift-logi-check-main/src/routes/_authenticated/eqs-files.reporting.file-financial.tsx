import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Download, Play } from "lucide-react";
import { useMemo, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import * as XLSX from "xlsx";
import { getFileFinancialReport } from "@/lib/files.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

export const Route = createFileRoute(
  "/_authenticated/eqs-files/reporting/file-financial",
)({
  head: () => ({ meta: [{ title: "File financial report" }] }),
  component: FileFinancialReport,
});

const STATUS_LABEL: Record<string, string> = {
  DR: "Draft",
  OP: "Open",
  RP: "Reporting",
  RCL: "Reconcile",
  CL: "Closed",
  CN: "Cancelled",
};

const CONTROL_DATE_OPTIONS: { value: string; label: string }[] = [
  { value: "OP", label: "OP date" },
  { value: "RP", label: "RP date" },
  { value: "RCL", label: "R4CL date" },
  { value: "CL", label: "CL date" },
  { value: "CN", label: "CN date" },
];


type Row = {
  file_id: string;
  file_number: string | null;
  status: string;
  customer: string | null;
  department_id: string | null;
  department: string | null;
  sales_manager_id: string | null;
  sales_manager: string | null;
  creation_date: string | null;
  op_date: string | null;
  rp_date: string | null;
  total_units: number;
  revenue_budget: number;
  cost_budget: number;
  revenue_finance: number;
  cost_finance: number;
  revenue_diff: number;
  cost_diff: number;
  gpm_budget: number;
  gpm_finance: number;
};

function today(): string {
  return new Date().toISOString().slice(0, 10);
}
function startOfYear(): string {
  return `${new Date().getFullYear()}-01-01`;
}


type NumCol = { key: keyof Row; label: string };

const BASE_COLS: NumCol[] = [
  { key: "revenue_budget", label: "Rev (ActBudg)" },
  { key: "revenue_finance", label: "Rev (finance)" },
  { key: "cost_budget", label: "Cost (ActBudg)" },
  { key: "cost_finance", label: "Cost (finance)" },
];
const DIFF_COLS: NumCol[] = [
  { key: "revenue_diff", label: "Rev (fin−ActBudg)" },
  { key: "cost_diff", label: "Cost (fin−ActBudg)" },
];
const GPM_COLS: NumCol[] = [
  { key: "gpm_budget", label: "GPM (ActBudg)" },
  { key: "gpm_finance", label: "GPM (finance)" },
];

const fmt = (n: number) =>
  n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function FileFinancialReport() {
  const runFn = useServerFn(getFileFinancialReport);
  const [status, setStatus] = useState<string>("OP");
  const [dateFrom, setDateFrom] = useState<string>(startOfYear());
  const [dateTo, setDateTo] = useState<string>(today());
  const [currentStatus, setCurrentStatus] = useState<string>("ALL");
  const [includeCancelled, setIncludeCancelled] = useState<boolean>(false);
  const [addAccruals, setAddAccruals] = useState<boolean>(false);
  const [showDiff, setShowDiff] = useState<boolean>(false);

  const [rows, setRows] = useState<Row[]>([]);

  const numCols: NumCol[] = useMemo(
    () => [...BASE_COLS, ...(showDiff ? DIFF_COLS : []), ...GPM_COLS],
    [showDiff],
  );

  const runMut = useMutation({
    mutationFn: () =>
      runFn({
        data: {
          status: status as any,
          date_from: dateFrom,
          date_to: dateTo,
          current_status: currentStatus === "ALL" ? null : (currentStatus as any),
          include_cancelled: includeCancelled,
          add_accruals: addAccruals,
        },
      }),
    onSuccess: (r: any) => {
      const list = (r?.rows ?? []) as Row[];
      setRows(list);
      if (list.length === 0) toast.message("No files match the selected status / period");
      else toast.success(`Loaded ${list.length} file(s)`);
    },
    onError: (e: any) => {
      console.error("getFileFinancialReport failed", e);
      toast.error(e?.message ?? "Failed to build report");
    },
  });

  // Client filters
  const [fDept, setFDept] = useState<string>("ALL");
  const [fMgr, setFMgr] = useState<string>("ALL");
  const [fStatus, setFStatus] = useState<string>("ALL");
  const [fNum, setFNum] = useState<string>("");

  const deptOptions = useMemo(() => {
    const m = new Map<string, string>();
    for (const r of rows) if (r.department) m.set(r.department, r.department);
    return Array.from(m.values()).sort();
  }, [rows]);
  const mgrOptions = useMemo(() => {
    const m = new Map<string, string>();
    for (const r of rows) if (r.sales_manager) m.set(r.sales_manager, r.sales_manager);
    return Array.from(m.values()).sort();
  }, [rows]);
  const statusOptions = useMemo(() => {
    const s = new Set<string>();
    for (const r of rows) s.add(r.status);
    return Array.from(s).sort();
  }, [rows]);

  const filtered = useMemo(() => {
    const q = fNum.trim().toLowerCase();
    return rows.filter((r) => {
      if (fDept !== "ALL" && r.department !== fDept) return false;
      if (fMgr !== "ALL" && r.sales_manager !== fMgr) return false;
      if (fStatus !== "ALL" && r.status !== fStatus) return false;
      if (q && !(r.file_number ?? "").toLowerCase().includes(q)) return false;
      return true;
    });
  }, [rows, fDept, fMgr, fStatus, fNum]);

  const totals = useMemo(() => {
    const t: Record<string, number> = {};
    for (const c of numCols) t[c.key] = 0;
    let units = 0;
    for (const r of filtered) {
      units += r.total_units ?? 0;
      for (const c of numCols) t[c.key] += Number(r[c.key] ?? 0);
    }
    return { nums: t, units };
  }, [filtered, numCols]);

  const exportXlsx = () => {
    const header = [
      "Sales manager",
      "Department",
      "Customer",
      "File #",
      "Total units",
      "Status",
      "RP date",
      "OP date",
      ...numCols.map((c) => c.label),
    ];
    const totalRow = [
      "TOTAL",
      "",
      "",
      "",
      totals.units,
      "",
      "",
      "",
      ...numCols.map((c) => Number(totals.nums[c.key].toFixed(2))),
    ];
    const body = filtered.map((r) => [
      r.sales_manager ?? "",
      r.department ?? "",
      r.customer ?? "",
      r.file_number ?? "",
      r.total_units ?? 0,
      STATUS_LABEL[r.status] ?? r.status,
      r.rp_date ?? "",
      r.op_date ?? "",
      ...numCols.map((c) => Number(Number(r[c.key] ?? 0).toFixed(2))),
    ]);
    const sheet = XLSX.utils.aoa_to_sheet([
      [`File financial report — status ${STATUS_LABEL[status] ?? status} · ${dateFrom} → ${dateTo}`],
      [],
      header,
      totalRow,
      ...body,
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, sheet, "File financial");
    XLSX.writeFile(wb, `file-financial-${status}-${dateFrom}_${dateTo}.xlsx`);
  };

  return (
    <div className="max-w-[1400px] mx-auto px-4 py-6">
      <Button variant="ghost" size="sm" asChild className="mb-3">
        <Link to="/eqs-files/reporting">
          <ArrowLeft className="size-4 mr-1" /> Reporting
        </Link>
      </Button>
      <h1 className="text-2xl font-semibold tracking-tight mb-1">File financial report</h1>
      <p className="text-sm text-muted-foreground mb-5">
        Forecast (ActBudg) vs Finance fact. Отбор: выбранный статус был установлен в указанный период.
      </p>

      {/* Run params */}
      <div className="mb-5 p-4 rounded-xl border border-border bg-card space-y-3">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <Label className="text-xs">Control date</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CONTROL_DATE_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">From</Label>
            <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-[160px]" />
          </div>
          <div>
            <Label className="text-xs">To</Label>
            <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-[160px]" />
          </div>
          <div>
            <Label className="text-xs">Current status</Label>
            <Select value={currentStatus} onValueChange={setCurrentStatus}>
              <SelectTrigger className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All</SelectItem>
                {Object.entries(STATUS_LABEL).map(([k, v]) => (
                  <SelectItem key={k} value={k}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button onClick={() => runMut.mutate()} disabled={runMut.isPending}>
            <Play className="size-4 mr-1" /> {runMut.isPending ? "Running…" : "Run"}
          </Button>
          <div className="ml-auto text-sm text-muted-foreground">
            {rows.length > 0 && `${filtered.length} / ${rows.length} files`}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-4">
          {status !== "CN" && (
            <label className="flex items-center gap-2 text-xs select-none">
              <input
                type="checkbox"
                checked={includeCancelled}
                onChange={(e) => setIncludeCancelled(e.target.checked)}
                className="size-4"
              />
              Include cancelled
            </label>
          )}
          <label className="flex items-center gap-2 text-xs select-none">
            <input
              type="checkbox"
              checked={addAccruals}
              onChange={(e) => setAddAccruals(e.target.checked)}
              className="size-4"
            />
            Add accruals to finance
          </label>
          <label className="flex items-center gap-2 text-xs select-none">
            <input
              type="checkbox"
              checked={showDiff}
              onChange={(e) => setShowDiff(e.target.checked)}
              className="size-4"
            />
            Show diff fin−ActBudg
          </label>
        </div>
      </div>


      {runMut.isError && (
        <div className="mb-3 rounded-md border border-destructive/40 bg-destructive/5 text-destructive text-sm px-3 py-2">
          {(runMut.error as any)?.message ?? "Failed to build report"}
        </div>
      )}

      {runMut.isSuccess && rows.length === 0 && (
        <div className="mb-3 rounded-md border border-border bg-muted/30 text-sm px-4 py-6 text-center text-muted-foreground">
          No files found for status <b>{STATUS_LABEL[status] ?? status}</b> in {dateFrom} → {dateTo}.
        </div>
      )}

      {rows.length > 0 && (
        <>
          {/* Filters */}
          <div className="flex flex-wrap gap-3 mb-3">
            <Select value={fDept} onValueChange={setFDept}>
              <SelectTrigger className="w-[200px]"><SelectValue placeholder="Department" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All departments</SelectItem>
                {deptOptions.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={fMgr} onValueChange={setFMgr}>
              <SelectTrigger className="w-[220px]"><SelectValue placeholder="Sales manager" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All managers</SelectItem>
                {mgrOptions.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={fStatus} onValueChange={setFStatus}>
              <SelectTrigger className="w-[160px]"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All statuses</SelectItem>
                {statusOptions.map((s) => <SelectItem key={s} value={s}>{STATUS_LABEL[s] ?? s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Input
              placeholder="File #"
              value={fNum}
              onChange={(e) => setFNum(e.target.value)}
              className="w-[180px]"
            />
            <Button variant="outline" onClick={exportXlsx} disabled={filtered.length === 0} className="ml-auto">
              <Download className="size-4 mr-1" /> Export to Excel
            </Button>
          </div>


          {/* Table */}
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 text-muted-foreground">
                  <tr>
                    <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap w-[120px]">Sales manager</th>
                    <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap w-[120px]">Dept.</th>
                    <th className="text-left font-medium px-2 py-1.5 w-[160px]">Customer</th>
                    <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">File #</th>
                    <th className="text-right font-medium px-2 py-1.5 whitespace-nowrap">Units</th>
                    <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">Status</th>
                    <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">OP date</th>
                    <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">RP date</th>
                    {numCols.map((c) => (
                      <th key={c.key} className="text-right font-medium px-2 py-1.5 whitespace-nowrap">{c.label}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {/* Totals row */}
                  <tr className="bg-muted/40 font-semibold border-t border-border">
                    <td className="px-2 py-1.5 whitespace-nowrap">TOTAL</td>
                    <td className="px-2 py-1.5"></td>
                    <td className="px-2 py-1.5"></td>
                    <td className="px-2 py-1.5"></td>
                    <td className="px-2 py-1.5 text-right font-mono">{totals.units}</td>
                    <td className="px-2 py-1.5"></td>
                    <td className="px-2 py-1.5"></td>
                    <td className="px-2 py-1.5"></td>
                    {numCols.map((c) => {
                      const v = totals.nums[c.key] ?? 0;
                      return (
                        <td
                          key={c.key}
                          className={`px-2 py-1.5 text-right font-mono tabular-nums ${v < 0 ? "text-red-600" : ""}`}
                        >
                          {fmt(v)}
                        </td>
                      );
                    })}
                  </tr>
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={8 + numCols.length} className="p-6 text-center text-muted-foreground">
                        No rows match the filters.
                      </td>
                    </tr>
                  )}
                  {filtered.map((r) => (
                    <tr key={r.file_id} className="border-t border-border hover:bg-muted/30">
                    <td className="px-2 py-1 whitespace-nowrap">{r.sales_manager ?? "—"}</td>
                    <td className="px-2 py-1 whitespace-nowrap w-[120px]">{r.department ?? "—"}</td>
                    <td className="px-2 py-1 min-w-[160px] max-w-[234px] truncate">{r.customer ?? "—"}</td>
                    <td className="px-2 py-1 font-mono whitespace-nowrap">
                      <Link
                        to="/eqs-files/$id"
                        params={{ id: r.file_id }}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        {r.file_number ?? "—"}
                      </Link>
                    </td>
                    <td className="px-2 py-1 text-right font-mono">{r.total_units}</td>
                    <td className="px-2 py-1 whitespace-nowrap">
                      <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                        {STATUS_LABEL[r.status] ?? r.status}
                      </Badge>
                    </td>
                    <td className="px-2 py-1 font-mono whitespace-nowrap">{r.op_date ?? "—"}</td>
                    <td className="px-2 py-1 font-mono whitespace-nowrap">{r.rp_date ?? "—"}</td>
                      {numCols.map((c) => {
                        const v = Number(r[c.key] ?? 0);
                        return (
                          <td
                            key={c.key}
                            className={`px-2 py-1 text-right font-mono tabular-nums ${v < 0 ? "text-red-600" : ""}`}
                          >
                            {fmt(v)}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {rows.length === 0 && !runMut.isPending && (
        <div className="text-center text-muted-foreground py-12 border border-dashed border-border rounded-xl">
          Выберите параметры и нажмите Run.
        </div>
      )}
    </div>
  );
}
