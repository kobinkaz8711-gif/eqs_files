import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { ArrowLeft, Download, Play, Search, ChevronRight, ChevronDown } from "lucide-react";
import { Fragment, useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import * as XLSX from "xlsx";
import {
  getFinancialResultAdjustment,
  getFinancialAdjustmentDrilldown,
} from "@/lib/files.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

export const Route = createFileRoute(
  "/_authenticated/eqs-files/reporting/financial-adjustment",
)({
  head: () => ({ meta: [{ title: "Financial result adjustment" }] }),
  component: FinancialAdjustmentReport,
  errorComponent: ({ error, reset }) => {
    const router = useRouter();
    return (
      <div className="p-6">
        <p className="text-sm text-destructive mb-2">{(error as any)?.message ?? "Error"}</p>
        <Button size="sm" onClick={() => { reset(); router.invalidate(); }}>Retry</Button>
      </div>
    );
  },
  notFoundComponent: () => <div className="p-6 text-sm">Not found</div>,
});

const STATUS_LABEL: Record<string, string> = {
  DR: "Draft",
  OP: "Open",
  RP: "Reporting",
  RCL: "Reconcile",
  CL: "Closed",
  CN: "Cancelled",
};

const CONTROL_DATE_OPTIONS = [
  { value: "OP", label: "OP date" },
  { value: "RP", label: "RP date" },
  { value: "RCL", label: "R4CL date" },
  { value: "CL", label: "CL date" },
  { value: "CN", label: "CN date" },
];

type Row = {
  file_status: string | null;
  finance_article_id: string | null;
  finance_article_kind: "REVENUE" | "COST" | null;
  finance_article_name: string | null;
  charge_source_type: string | null;
  charge_source_code: string | null;
  charge_type_name: string | null;
  revenue_budget: number;
  cost_budget: number;
  revenue_finance: number;
  cost_finance: number;
  gpm_budget: number;
  gpm_finance: number;
};

const NUM_COLS: { key: keyof Row; label: string }[] = [
  { key: "revenue_budget", label: "Rev (ActBudg)" },
  { key: "revenue_finance", label: "Rev (finance)" },
  { key: "cost_budget", label: "Cost (ActBudg)" },
  { key: "cost_finance", label: "Cost (finance)" },
  { key: "gpm_budget", label: "GPM (ActBudg)" },
  { key: "gpm_finance", label: "GPM (finance)" },
];

const fmt = (n: number) =>
  n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const GPM_KEYS = new Set<string>(["gpm_budget", "gpm_finance"]);
const isZero = (n: number) => Math.abs(n) < 0.005;
const fmtOrBlank = (n: number) => (isZero(n) ? "" : fmt(n));

const today = () => new Date().toISOString().slice(0, 10);
const startOfYear = () => `${new Date().getFullYear()}-01-01`;

function FinancialAdjustmentReport() {
  const runFn = useServerFn(getFinancialResultAdjustment);
  const drillFn = useServerFn(getFinancialAdjustmentDrilldown);
  const [status, setStatus] = useState("OP");
  const [dateFrom, setDateFrom] = useState(startOfYear());
  const [dateTo, setDateTo] = useState(today());
  const [currentStatus, setCurrentStatus] = useState("ALL");
  const [includeCancelled, setIncludeCancelled] = useState(false);
  const [addAccruals, setAddAccruals] = useState(false);
  const [breakdown, setBreakdown] = useState<"ARTICLE" | "CHARGE_TYPE">("ARTICLE");
  const [groupByStatus, setGroupByStatus] = useState(false);
  const [search, setSearch] = useState("");
  const [rows, setRows] = useState<Row[]>([]);
  const [drillMode, setDrillMode] = useState(false);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const filtersKey = JSON.stringify({
    status, dateFrom, dateTo, currentStatus, includeCancelled, addAccruals,
    breakdown, groupByStatus,
  });

  const runMut = useMutation({
    mutationFn: () =>
      runFn({
        data: {
          status: status as any,
          date_from: dateFrom,
          date_to: dateTo,
          current_status: currentStatus === "ALL" ? null : (currentStatus as any),
          include_cancelled: includeCancelled,
          add_accruals: addAccruals,
          breakdown,
          group_by_status: groupByStatus,
        },
      }),
    onSuccess: (r: any) => {
      const list = (r?.rows ?? []) as Row[];
      setRows(list);
      setExpanded(new Set());
      if (list.length === 0) toast.message("No data for selected filters");
      else toast.success(`Loaded ${list.length} row(s)`);
    },
    onError: (e: any) => {
      toast.error(e?.message ?? "Failed to build report");
    },
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((r) =>
      (r.finance_article_name ?? "").toLowerCase().includes(q) ||
      (r.charge_type_name ?? "").toLowerCase().includes(q) ||
      (r.charge_source_code ?? "").toLowerCase().includes(q),
    );
  }, [rows, search]);

  const groups = useMemo(() => {
    if (!groupByStatus) return [{ status: null as string | null, rows: filtered }];
    const m = new Map<string, Row[]>();
    for (const r of filtered) {
      const k = r.file_status ?? "—";
      const arr = m.get(k) ?? [];
      arr.push(r);
      m.set(k, arr);
    }
    return Array.from(m.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([status, rows]) => ({ status, rows }));
  }, [filtered, groupByStatus]);

  const sumRows = (rs: Row[]) => {
    const t: Record<string, number> = {};
    for (const c of NUM_COLS) t[c.key as string] = 0;
    for (const r of rs) for (const c of NUM_COLS) t[c.key as string] += Number(r[c.key] ?? 0);
    return t;
  };

  const grandTotals = useMemo(() => sumRows(filtered), [filtered]);

  const rowKey = (r: Row): string =>
    [
      r.file_status ?? "",
      r.finance_article_id ?? "",
      r.charge_source_type ?? "",
      r.charge_source_code ?? "",
    ].join("|");

  const toggleExpand = (k: string) => {
    setExpanded((prev) => {
      const n = new Set(prev);
      if (n.has(k)) n.delete(k);
      else n.add(k);
      return n;
    });
  };

  const exportXlsx = () => {
    const header = [
      ...(groupByStatus ? ["File status"] : []),
      "Finance budget kind",
      "Finance budget name",
      ...(breakdown === "CHARGE_TYPE" ? ["Cost/charge type"] : []),
      ...NUM_COLS.map((c) => c.label),
    ];
    const body: any[][] = [];
    const numCell = (v: number) => (isZero(v) ? "" : Number(v.toFixed(2)));
    body.push([
      ...(groupByStatus ? [""] : []),
      "TOTAL", "",
      ...(breakdown === "CHARGE_TYPE" ? [""] : []),
      ...NUM_COLS.map((c) => numCell(grandTotals[c.key as string] ?? 0)),
    ]);
    for (const g of groups) {
      if (groupByStatus) {
        const t = sumRows(g.rows);
        body.push([
          STATUS_LABEL[g.status ?? ""] ?? g.status ?? "—",
          "Subtotal", "",
          ...(breakdown === "CHARGE_TYPE" ? [""] : []),
          ...NUM_COLS.map((c) => numCell(t[c.key as string] ?? 0)),
        ]);
      }
      for (const r of g.rows) {
        body.push([
          ...(groupByStatus ? [STATUS_LABEL[g.status ?? ""] ?? g.status ?? "—"] : []),
          r.finance_article_kind ?? "—",
          r.finance_article_name ?? "— Unmapped —",
          ...(breakdown === "CHARGE_TYPE"
            ? [(r.charge_type_name ?? (`${r.charge_source_type ?? ""} ${r.charge_source_code ?? ""}`.trim())) || "—"]
            : []),
          ...NUM_COLS.map((c) =>
            GPM_KEYS.has(c.key as string) ? "" : numCell(Number(r[c.key] ?? 0)),
          ),
        ]);
      }
    }
    const sheet = XLSX.utils.aoa_to_sheet([
      [`Financial result adjustment — ${STATUS_LABEL[status] ?? status} · ${dateFrom} → ${dateTo}`],
      [],
      header,
      ...body,
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, sheet, "Adjustment");
    XLSX.writeFile(wb, `fin-adjustment-${status}-${dateFrom}_${dateTo}.xlsx`);
  };

  const dimColCount =
    (drillMode ? 1 : 0) + 1 /* kind */ + 1 /* name */ + (breakdown === "CHARGE_TYPE" ? 1 : 0);

  return (
    <div className="max-w-[1400px] mx-auto px-4 py-6">
      <Button variant="ghost" size="sm" asChild className="mb-3">
        <Link to="/eqs-files/reporting">
          <ArrowLeft className="size-4 mr-1" /> Reporting
        </Link>
      </Button>
      <h1 className="text-2xl font-semibold tracking-tight mb-1">Financial result adjustment</h1>
      <p className="text-sm text-muted-foreground mb-5">
        Та же логика, что и File financial report, но в разрезе статей бюджета / cost·charge types.
      </p>

      <div className="mb-5 p-4 rounded-xl border border-border bg-card space-y-3">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <Label className="text-xs">Control date</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                {CONTROL_DATE_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">From</Label>
            <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-[160px]" />
          </div>
          <div>
            <Label className="text-xs">To</Label>
            <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-[160px]" />
          </div>
          <div>
            <Label className="text-xs">Current status</Label>
            <Select value={currentStatus} onValueChange={setCurrentStatus}>
              <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All</SelectItem>
                {Object.entries(STATUS_LABEL).map(([k, v]) => (
                  <SelectItem key={k} value={k}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Breakdown</Label>
            <Select value={breakdown} onValueChange={(v) => setBreakdown(v as any)}>
              <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ARTICLE">Per article</SelectItem>
                <SelectItem value="CHARGE_TYPE">Per cost·charge type</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={() => runMut.mutate()} disabled={runMut.isPending}>
            <Play className="size-4 mr-1" /> {runMut.isPending ? "Running…" : "Run"}
          </Button>
          <div className="ml-auto text-sm text-muted-foreground">
            {rows.length > 0 && `${filtered.length} / ${rows.length} rows`}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-4">
          {status !== "CN" && (
            <label className="flex items-center gap-2 text-xs select-none">
              <input type="checkbox" checked={includeCancelled} onChange={(e) => setIncludeCancelled(e.target.checked)} className="size-4" />
              Include cancelled
            </label>
          )}
          <label className="flex items-center gap-2 text-xs select-none">
            <input type="checkbox" checked={addAccruals} onChange={(e) => setAddAccruals(e.target.checked)} className="size-4" />
            Add accruals to finance
          </label>
          <label className="flex items-center gap-2 text-xs select-none">
            <input type="checkbox" checked={groupByStatus} onChange={(e) => setGroupByStatus(e.target.checked)} className="size-4" />
            Group by file status
          </label>
        </div>
      </div>

      {runMut.isError && (
        <div className="mb-3 rounded-md border border-destructive/40 bg-destructive/5 text-destructive text-sm px-3 py-2">
          {(runMut.error as any)?.message ?? "Failed to build report"}
        </div>
      )}

      {rows.length > 0 && (
        <>
          <div className="flex flex-wrap gap-3 mb-3 items-center">
            <Input
              placeholder="Search article / charge type"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-[260px]"
            />
            <div className="ml-auto flex items-center gap-2">
              <Button
                variant={drillMode ? "default" : "outline"}
                onClick={() => { setDrillMode((v) => !v); setExpanded(new Set()); }}
                title="Show details per row"
              >
                <Search className="size-4 mr-1" /> Drill-down{drillMode ? " on" : ""}
              </Button>
              <Button variant="outline" onClick={exportXlsx} disabled={filtered.length === 0}>
                <Download className="size-4 mr-1" /> Export to Excel
              </Button>
            </div>
          </div>

          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 text-muted-foreground">
                  <tr>
                    {drillMode && <th className="w-6 px-2 py-1.5"></th>}
                    <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">Kind</th>
                    <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">Finance budget name</th>
                    {breakdown === "CHARGE_TYPE" && (
                      <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">Cost/charge type</th>
                    )}
                    {NUM_COLS.map((c) => (
                      <th key={c.key as string} className="text-right font-medium px-2 py-1.5 whitespace-nowrap">{c.label}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr className="bg-muted/40 font-semibold border-t border-border">
                    {drillMode && <td></td>}
                    <td className="px-2 py-1.5">TOTAL</td>
                    <td className="px-2 py-1.5"></td>
                    {breakdown === "CHARGE_TYPE" && <td className="px-2 py-1.5"></td>}
                    {NUM_COLS.map((c) => {
                      const v = grandTotals[c.key as string] ?? 0;
                      return (
                        <td key={c.key as string} className={`px-2 py-1.5 text-right font-mono tabular-nums ${v < 0 ? "text-red-600" : ""}`}>
                          {fmtOrBlank(v)}
                        </td>
                      );
                    })}
                  </tr>
                  {groups.map((g, gi) => {
                    const sub = groupByStatus ? sumRows(g.rows) : null;
                    return (
                      <Fragment key={`g-${gi}`}>
                        {groupByStatus && (
                          <tr key={`h-${gi}`} className="bg-muted/30 border-t border-border">
                            <td colSpan={dimColCount} className="px-2 py-1.5 font-semibold">
                              {STATUS_LABEL[g.status ?? ""] ?? g.status ?? "—"}
                            </td>
                            {NUM_COLS.map((c) => {
                              const v = sub?.[c.key as string] ?? 0;
                              return (
                                <td key={c.key as string} className={`px-2 py-1.5 text-right font-mono tabular-nums font-semibold ${v < 0 ? "text-red-600" : ""}`}>
                                  {fmtOrBlank(v)}
                                </td>
                              );
                            })}
                          </tr>
                        )}
                        {g.rows.map((r, ri) => {
                          const k = rowKey(r);
                          const isOpen = expanded.has(k);
                          return (
                            <Fragment key={`r-${gi}-${ri}`}>
                              <tr
                                className={`border-t border-border hover:bg-muted/30 ${drillMode ? "cursor-pointer" : ""}`}
                                onClick={drillMode ? () => toggleExpand(k) : undefined}
                              >
                                {drillMode && (
                                  <td className="px-2 py-1 text-muted-foreground">
                                    {isOpen ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />}
                                  </td>
                                )}
                                <td className="px-2 py-1 whitespace-nowrap">{r.finance_article_kind ?? "—"}</td>
                                <td className="px-2 py-1">{r.finance_article_name ?? "— Unmapped —"}</td>
                                {breakdown === "CHARGE_TYPE" && (
                                  <td className="px-2 py-1">
                                    {(r.charge_type_name ??
                                      (`${r.charge_source_type ?? ""} ${r.charge_source_code ?? ""}`.trim())) ||
                                      "—"}
                                  </td>
                                )}
                                {NUM_COLS.map((c) => {
                                  const isGpm = GPM_KEYS.has(c.key as string);
                                  const v = Number(r[c.key] ?? 0);
                                  return (
                                    <td key={c.key as string} className={`px-2 py-1 text-right font-mono tabular-nums ${!isGpm && v < 0 ? "text-red-600" : ""}`}>
                                      {isGpm ? "" : fmtOrBlank(v)}
                                    </td>
                                  );
                                })}
                              </tr>
                              {drillMode && isOpen && (
                                <DrillDownRow
                                  colSpan={dimColCount + NUM_COLS.length}
                                  row={r}
                                  filtersKey={filtersKey}
                                  drillFn={drillFn}
                                  status={status}
                                  dateFrom={dateFrom}
                                  dateTo={dateTo}
                                  currentStatus={currentStatus}
                                  includeCancelled={includeCancelled}
                                  addAccruals={addAccruals}
                                  breakdown={breakdown}
                                  groupByStatus={groupByStatus}
                                />
                              )}
                            </Fragment>
                          );
                        })}
                      </Fragment>
                    );
                  })}
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={dimColCount + NUM_COLS.length} className="p-6 text-center text-muted-foreground">
                        No rows match the filters.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

const COLUMN_LABELS: Record<string, string> = {
  rev_b: "Rev (ActBudg)",
  rev_f: "Rev (finance)",
  cost_b: "Cost (ActBudg)",
  cost_f: "Cost (finance)",
};
const COLUMN_ORDER = ["rev_b", "rev_f", "cost_b", "cost_f"] as const;

function DrillDownRow({
  colSpan, row, filtersKey, drillFn,
  status, dateFrom, dateTo, currentStatus, includeCancelled, addAccruals, breakdown, groupByStatus,
}: {
  colSpan: number;
  row: Row;
  filtersKey: string;
  drillFn: ReturnType<typeof useServerFn<typeof getFinancialAdjustmentDrilldown>>;
  status: string;
  dateFrom: string;
  dateTo: string;
  currentStatus: string;
  includeCancelled: boolean;
  addAccruals: boolean;
  breakdown: "ARTICLE" | "CHARGE_TYPE";
  groupByStatus: boolean;
}) {
  const q = useQuery({
    queryKey: ["fin-adj-drill", filtersKey, row.file_status, row.finance_article_id, row.charge_source_type, row.charge_source_code],
    queryFn: () =>
      drillFn({
        data: {
          status: status as any,
          date_from: dateFrom,
          date_to: dateTo,
          current_status: currentStatus === "ALL" ? null : (currentStatus as any),
          include_cancelled: includeCancelled,
          add_accruals: addAccruals,
          breakdown,
          group_by_status: groupByStatus,
          key_file_status: groupByStatus ? row.file_status : null,
          key_finance_article_id: row.finance_article_id,
          key_charge_source_type: row.charge_source_type,
          key_charge_source_code: row.charge_source_code,
        },
      }),
  });

  const detail = (q.data?.rows ?? []) as any[];

  // Group by column → file
  type ColBucket = {
    col: string;
    total: number;
    files: Map<string, { file_id: string; file_number: string; file_status: string; total: number; rows: any[] }>;
  };
  const byCol = useMemo(() => {
    const m = new Map<string, ColBucket>();
    for (const d of detail) {
      const cols = (d.contributes ?? []) as string[];
      for (const c of cols) {
        let b = m.get(c);
        if (!b) { b = { col: c, total: 0, files: new Map() }; m.set(c, b); }
        b.total += Number(d.amount_usd ?? 0);
        const fk = d.file_id;
        let f = b.files.get(fk);
        if (!f) {
          f = { file_id: d.file_id, file_number: d.file_number, file_status: d.file_status, total: 0, rows: [] };
          b.files.set(fk, f);
        }
        f.total += Number(d.amount_usd ?? 0);
        f.rows.push(d);
      }
    }
    return COLUMN_ORDER
      .filter((c) => m.has(c) && Math.abs(m.get(c)!.total) >= 0.005)
      .map((c) => m.get(c)!);
  }, [detail]);

  const [openCols, setOpenCols] = useState<Set<string>>(new Set());
  const [openFiles, setOpenFiles] = useState<Set<string>>(new Set());

  const toggleCol = (c: string) => setOpenCols((p) => {
    const n = new Set(p); n.has(c) ? n.delete(c) : n.add(c); return n;
  });
  const toggleFile = (k: string) => setOpenFiles((p) => {
    const n = new Set(p); n.has(k) ? n.delete(k) : n.add(k); return n;
  });

  return (
    <tr className="bg-muted/10">
      <td colSpan={colSpan} className="p-0">
        <div className="p-3 border-t border-dashed border-border">
          {q.isLoading && <div className="text-xs text-muted-foreground">Loading details…</div>}
          {q.isError && <div className="text-xs text-destructive">{(q.error as any)?.message ?? "Error"}</div>}
          {q.isSuccess && byCol.length === 0 && (
            <div className="text-xs text-muted-foreground">No detail rows.</div>
          )}
          {q.isSuccess && byCol.length > 0 && (
            <div className="space-y-1">
              {byCol.map((b) => {
                const colOpen = openCols.has(b.col);
                const files = Array.from(b.files.values()).sort(
                  (a, z) => (a.file_number ?? "").localeCompare(z.file_number ?? ""),
                );
                return (
                  <div key={b.col} className="rounded border border-border bg-background">
                    <button
                      type="button"
                      onClick={() => toggleCol(b.col)}
                      className="w-full flex items-center gap-2 px-2 py-1.5 text-xs hover:bg-muted/40"
                    >
                      {colOpen ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />}
                      <span className="font-semibold">{COLUMN_LABELS[b.col]}</span>
                      <span className="text-muted-foreground">· {files.length} file(s)</span>
                      <span className={`ml-auto font-mono tabular-nums ${b.total < 0 ? "text-red-600" : ""}`}>
                        {fmt(b.total)}
                      </span>
                    </button>
                    {colOpen && (
                      <div className="px-2 pb-2 space-y-1">
                        {files.map((f) => {
                          const fk = `${b.col}::${f.file_id}`;
                          const fOpen = openFiles.has(fk);
                          return (
                            <div key={fk} className="rounded border border-border/60">
                              <div className="w-full flex items-center gap-2 px-2 py-1 text-[11px] hover:bg-muted/40">
                                <button
                                  type="button"
                                  onClick={() => toggleFile(fk)}
                                  className="flex items-center"
                                  aria-label={fOpen ? "Collapse" : "Expand"}
                                >
                                  {fOpen ? <ChevronDown className="size-3" /> : <ChevronRight className="size-3" />}
                                </button>
                                <Link
                                  to="/eqs-files/$id"
                                  params={{ id: f.file_id }}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="font-mono text-primary hover:underline"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  {f.file_number}
                                </Link>
                                <span className="text-muted-foreground">[{STATUS_LABEL[f.file_status] ?? f.file_status}]</span>
                                <button
                                  type="button"
                                  onClick={() => toggleFile(fk)}
                                  className="flex-1 text-left text-muted-foreground"
                                >
                                  · {f.rows.length} row(s)
                                </button>
                                <span className={`ml-auto font-mono tabular-nums ${f.total < 0 ? "text-red-600" : ""}`}>
                                  {fmt(f.total)}
                                </span>
                              </div>
                              {fOpen && (
                                <div className="overflow-x-auto">
                                  <table className="w-full text-[11px]">
                                    <thead className="text-muted-foreground bg-muted/20">
                                      <tr>
                                        <th className="text-left font-medium px-2 py-1">Contributes to</th>
                                        <th className="text-left font-medium px-2 py-1">Third-party</th>
                                        <th className="text-left font-medium px-2 py-1">Unit</th>
                                        <th className="text-left font-medium px-2 py-1">Cont.</th>
                                        <th className="text-left font-medium px-2 py-1">Source</th>
                                        <th className="text-left font-medium px-2 py-1">Charge type</th>
                                        <th className="text-left font-medium px-2 py-1">Doc #</th>
                                        <th className="text-left font-medium px-2 py-1">Doc date</th>
                                        <th className="text-right font-medium px-2 py-1">Amount</th>
                                        <th className="text-left font-medium px-2 py-1">Cur</th>
                                        <th className="text-right font-medium px-2 py-1">Amount (USD)</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {f.rows.map((d: any, i: number) => (
                                        <tr key={i} className="border-t border-border/60">
                                          <td className="px-2 py-1">{COLUMN_LABELS[b.col]}</td>
                                          <td className="px-2 py-1">{d.third_party ?? "—"}</td>
                                          <td className="px-2 py-1 font-mono">{d.unit_no ?? "—"}</td>
                                          <td className="px-2 py-1">{d.container_type ?? "—"}</td>
                                          <td className="px-2 py-1">
                                            <span className="inline-block px-1.5 py-0.5 rounded bg-muted text-[10px]">
                                              {d.source}
                                            </span>
                                          </td>
                                          <td className="px-2 py-1">{d.charge_type_label ?? "—"}</td>
                                          <td className="px-2 py-1">{d.doc_no ?? "—"}</td>
                                          <td className="px-2 py-1">{d.doc_date ? String(d.doc_date).slice(0, 10) : "—"}</td>
                                          <td className={`px-2 py-1 text-right font-mono tabular-nums ${Number(d.amount) < 0 ? "text-red-600" : ""}`}>
                                            {fmt(Number(d.amount ?? 0))}
                                          </td>
                                          <td className="px-2 py-1">{d.currency}</td>
                                          <td className={`px-2 py-1 text-right font-mono tabular-nums ${Number(d.amount_usd) < 0 ? "text-red-600" : ""}`}>
                                            {fmt(Number(d.amount_usd ?? 0))}
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </td>
    </tr>
  );
}

