import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/eqs-files/reporting")({
  head: () => ({ meta: [{ title: "EQS Files — Reporting" }] }),
  component: ReportingLayout,
});

function ReportingLayout() {
  return <Outlet />;
}
