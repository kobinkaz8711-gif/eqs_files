import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import JSZip from "jszip";
import {
  Upload, CheckCircle2, AlertTriangle, Download, FileText, Search, ArrowUpDown,
  Boxes, Container, Sparkles, Loader2, Package, RotateCcw, Inbox, Keyboard,
  ChevronRight, FileSpreadsheet, Settings2,
} from "lucide-react";
import { useInvoiceStore, type ProcessingStep } from "@/lib/invoice/store";
import type { BillingRow } from "@/lib/invoice/parse";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { InvoicePdfPreview } from "@/components/InvoicePdfPreview";
import { useT } from "@/i18n/i18n";

export const Route = createFileRoute("/_authenticated/invoice-generator")({
  component: InvoiceApp,
  head: () => ({
    meta: [
      { title: "Invoice Generator — MAXX Services" },
      { name: "description", content: "Generate Invoice and Credit Note PDFs from container billing exports." },
    ],
  }),
});

const fmtMoney = (n: number, c = "USD") =>
  `${n < 0 ? "-" : ""}${Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${c}`;

const categoryBadge: Record<BillingRow["category"], { label: string; cls: string }> = {
  "provision-4": { label: "Provision 4", cls: "bg-[color:var(--color-info)]/12 text-[color:var(--color-info)] border-[color:var(--color-info)]/25" },
  "provision-6": { label: "Provision 6", cls: "bg-violet-500/12 text-violet-700 border-violet-500/25 dark:text-violet-300" },
  "free": { label: "Free Days", cls: "bg-[color:var(--color-success)]/12 text-[color:var(--color-success)] border-[color:var(--color-success)]/25" },
  "additional": { label: "Additional", cls: "bg-amber-500/12 text-amber-700 border-amber-500/25 dark:text-amber-300" },
  "other": { label: "Other", cls: "bg-muted text-muted-foreground border-border" },
};

const kindBadge: Record<BillingRow["kind"], { label: string; cls: string }> = {
  invoice: { label: "Invoice", cls: "bg-[color:var(--color-success)]/15 text-[color:var(--color-success)] border-[color:var(--color-success)]/30" },
  credit: { label: "Credit Note", cls: "bg-[color:var(--color-destructive)]/15 text-[color:var(--color-destructive)] border-[color:var(--color-destructive)]/30" },
  skip: { label: "Skipped", cls: "bg-muted text-muted-foreground border-border" },
};

function InvoiceApp() {
  const store = useInvoiceStore();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const onPick = () => fileInputRef.current?.click();
  const onFile = useCallback((f: File | null | undefined) => {
    if (f) void store.ingestFile(f);
  }, [store]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key.toLowerCase() === "u") onPick();
      if (e.key.toLowerCase() === "i" && store.invoiceDoc) downloadBlob(store.invoiceDoc.blob, `${store.invoiceDoc.meta.number}.pdf`);
      if (e.key.toLowerCase() === "c" && store.creditDoc) downloadBlob(store.creditDoc.blob, `${store.creditDoc.meta.number}.pdf`);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [store.invoiceDoc, store.creditDoc]);

  return (
    <div className="text-foreground">
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv,.xls,.xlsx"
        className="hidden"
        onChange={(e) => onFile(e.target.files?.[0])}
      />
      <main className="mx-auto max-w-[1480px] px-6 py-8 lg:px-10">
        <div className="grid grid-cols-1 gap-8 xl:grid-cols-[1fr_320px]">
          <div className="space-y-8 min-w-0">
            <Hero onPick={onPick} onFile={onFile} />
            <AnimatePresence>
              {store.status !== "idle" && (
                <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                  <Timeline />
                </motion.div>
              )}
            </AnimatePresence>
            {store.status === "ready" && (
              <>
                <KpiAndPreview />
                <DocumentPreview />
              </>
            )}
          </div>
          <Sidebar onPick={onPick} />
        </div>
      </main>
    </div>
  );
}

function Hero({ onPick, onFile }: { onPick: () => void; onFile: (f: File | null) => void }) {
  const t = useT();
  const status = useInvoiceStore((s) => s.status);
  const step = useInvoiceStore((s) => s.step);
  const fileName = useInvoiceStore((s) => s.fileName);
  const error = useInvoiceStore((s) => s.error);
  const [drag, setDrag] = useState(false);

  return (
    <section className="space-y-6">
      {/* Title + settings */}
      <div className="flex items-center justify-between gap-4">
        <h1 className="text-3xl lg:text-4xl font-semibold tracking-tight text-foreground leading-tight">
          {t("inv.title1")}{" "}
          <span className="bg-gradient-to-r from-primary to-info bg-clip-text text-transparent">
            {t("inv.title2")}
          </span>
        </h1>
        <Link to="/settings/invoice-generator">
          <Button variant="outline" size="sm">
            <Settings2 className="mr-2 h-3.5 w-3.5" />
            {t("inv.moduleSettings")}
          </Button>
        </Link>
      </div>

      {/* Upload */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => { e.preventDefault(); setDrag(false); onFile(e.dataTransfer.files?.[0] ?? null); }}
        onClick={onPick}
        className={cn(
          "relative cursor-pointer rounded-2xl border-2 border-dashed bg-card p-5 transition-all overflow-hidden",
          drag
            ? "border-primary bg-primary/[0.03] shadow-[0_0_0_4px_rgba(49,73,130,0.08)]"
            : "border-border hover:border-border-strong",
          status === "processing" && "border-[color:var(--color-info)]",
          status === "ready" && "border-[color:var(--color-success)]",
          status === "error" && "border-[color:var(--color-destructive)]",
        )}
      >
        <div className="flex flex-row items-center gap-4">
          <motion.div
            animate={drag ? { scale: 1.08, rotate: -3 } : { scale: 1, rotate: 0 }}
            className={cn(
              "rounded-xl grid place-items-center shrink-0 size-10",
              status === "ready" ? "bg-[color:var(--color-success)]/15 text-[color:var(--color-success)]"
                : status === "error" ? "bg-[color:var(--color-destructive)]/15 text-[color:var(--color-destructive)]"
                : status === "processing" ? "bg-[color:var(--color-info)]/15 text-[color:var(--color-info)]"
                : drag ? "bg-primary text-primary-foreground"
                : "bg-primary/10 text-primary",
            )}
          >
            {status === "processing" ? <Loader2 className="size-5 animate-spin" />
              : status === "ready" ? <CheckCircle2 className="size-5" />
              : status === "error" ? <AlertTriangle className="size-5" />
              : <Upload className="size-5" />}
          </motion.div>
          <div className="min-w-0 flex-1">
            <div className="font-semibold text-foreground text-base truncate">
              {status === "processing" ? t("inv.processing", step ?? "") :
               status === "ready" ? t("inv.ready") :
               status === "error" ? t("inv.error") :
               drag ? t("inv.dropActive") :
               t("inv.dropIdle")}
            </div>
            <div className="text-sm text-muted-foreground mt-0.5 truncate">
              {fileName ? fileName : t("inv.dropHint")}
            </div>
            {error && <div className="mt-1 text-xs text-[color:var(--color-destructive)]">{error}</div>}
          </div>
          <Button onClick={(e) => { e.stopPropagation(); onPick(); }} className="shrink-0">
            <Upload className="mr-2 h-3.5 w-3.5" />
            {t("inv.pickFile")}
          </Button>
        </div>
      </div>
    </section>
  );
}

const STEP_KEYS: ProcessingStep[] = ["uploaded", "parsing", "validating", "grouping", "generating", "ready"];
const STEP_TKEY: Record<ProcessingStep, "inv.step.uploaded" | "inv.step.parsing" | "inv.step.validating" | "inv.step.grouping" | "inv.step.generating" | "inv.step.ready"> = {
  uploaded: "inv.step.uploaded",
  parsing: "inv.step.parsing",
  validating: "inv.step.validating",
  grouping: "inv.step.grouping",
  generating: "inv.step.generating",
  ready: "inv.step.ready",
};

function Timeline() {
  const t = useT();
  const step = useInvoiceStore((s) => s.step);
  const status = useInvoiceStore((s) => s.status);
  const activeIdx = step ? STEP_KEYS.indexOf(step) : -1;
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-center justify-between gap-4 overflow-x-auto">
        {STEP_KEYS.map((key, i) => {
          const done = i < activeIdx || status === "ready";
          const active = i === activeIdx && status !== "ready";
          return (
            <div key={key} className="flex flex-1 min-w-[140px] items-center gap-2">
              <div className={cn(
                "flex h-7 w-7 shrink-0 items-center justify-center rounded-full border text-[11px] font-semibold",
                done ? "bg-[color:var(--color-success)] border-[color:var(--color-success)] text-white" :
                active ? "bg-[color:var(--color-info)] border-[color:var(--color-info)] text-white" :
                "border-border bg-surface text-muted-foreground",
              )}>
                {done ? <CheckCircle2 className="h-3.5 w-3.5" /> : active ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : i + 1}
              </div>
              <div className="text-xs leading-tight">
                <div className={cn("font-medium", (done || active) ? "text-foreground" : "text-muted-foreground")}>{t(STEP_TKEY[key])}</div>
              </div>
              {i < STEP_KEYS.length - 1 && <div className="hidden md:block h-px flex-1 bg-border" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function KpiAndPreview() {
  const t = useT();
  const rows = useInvoiceStore((s) => s.rows);
  const invoiceRows = useInvoiceStore((s) => s.invoiceRows);
  const creditRows = useInvoiceStore((s) => s.creditRows);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "invoice" | "credit">("all");
  const [sortKey, setSortKey] = useState<keyof BillingRow>("container");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  const invoiceTotal = useMemo(() => invoiceRows.reduce((s, r) => s + r.total, 0), [invoiceRows]);
  const creditTotal = useMemo(() => creditRows.reduce((s, r) => s + r.total, 0), [creditRows]);
  const currency = rows[0]?.currency ?? "USD";

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let r = rows;
    if (filter !== "all") r = r.filter((x) => x.kind === filter);
    if (q) r = r.filter((x) =>
      [x.container, x.bookingId, x.custOrder, x.chargeDescription, x.clientRef]
        .some((v) => v.toLowerCase().includes(q)),
    );
    r = [...r].sort((a, b) => {
      const va = a[sortKey]; const vb = b[sortKey];
      if (typeof va === "number" && typeof vb === "number") return sortDir === "asc" ? va - vb : vb - va;
      return sortDir === "asc" ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
    });
    return r;
  }, [rows, query, filter, sortKey, sortDir]);

  const toggleSort = (k: keyof BillingRow) => {
    if (k === sortKey) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(k); setSortDir("asc"); }
  };

  const kindLabel: Record<BillingRow["kind"], string> = {
    invoice: t("inv.kind.invoice"),
    credit: t("inv.kind.credit"),
    skip: t("inv.kind.skip"),
  };

  return (
    <section className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <KpiCard label={t("inv.kpi.invoiceTotal")} value={fmtMoney(invoiceTotal, currency)} accent="success" icon={<FileText className="h-4 w-4" />} />
        <KpiCard label={t("inv.kpi.creditTotal")} value={`-${fmtMoney(Math.abs(creditTotal), currency)}`} accent="destructive" icon={<RotateCcw className="h-4 w-4" />} />
        <KpiCard label={t("inv.kpi.rows")} value={`${rows.length}`} sub={`${invoiceRows.length} inv · ${creditRows.length} cr`} icon={<Package className="h-4 w-4" />} />
      </div>

      <div className="rounded-xl border border-border bg-card">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border p-3">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold">{t("inv.parsedRows")}</h3>
            <span className="text-xs text-muted-foreground">{filtered.length} / {rows.length}</span>
          </div>
          <div className="flex flex-1 items-center justify-end gap-2 min-w-[260px]">
            <div className="relative max-w-xs flex-1">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("inv.search")} className="h-8 pl-8 text-xs" />
            </div>
            <div className="flex rounded-md border border-border bg-surface p-0.5 text-xs">
              {(["all", "invoice", "credit"] as const).map((k) => (
                <button key={k} onClick={() => setFilter(k)}
                  className={cn("rounded px-2.5 py-1 capitalize transition-colors", filter === k ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}>
                  {k}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="max-h-[460px] overflow-auto">
          <table className="w-full text-xs">
            <thead className="sticky top-0 z-10 bg-[color:var(--color-surface-2)]/95 backdrop-blur">
              <tr className="text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                <Th onClick={() => toggleSort("container")} active={sortKey === "container"} dir={sortDir}>{t("inv.col.container")}</Th>
                <Th onClick={() => toggleSort("category")} active={sortKey === "category"} dir={sortDir}>{t("inv.col.charge")}</Th>
                <Th onClick={() => toggleSort("bookingId")} active={sortKey === "bookingId"} dir={sortDir}>{t("inv.col.internalRef")}</Th>
                <Th onClick={() => toggleSort("custOrder")} active={sortKey === "custOrder"} dir={sortDir}>{t("inv.col.booking")}</Th>
                <Th onClick={() => toggleSort("kind")} active={sortKey === "kind"} dir={sortDir}>{t("inv.col.kind")}</Th>
                <Th onClick={() => toggleSort("total")} active={sortKey === "total"} dir={sortDir} className="text-right">{t("inv.col.amount")}</Th>
              </tr>
            </thead>
            <tbody>
              {filtered.slice(0, 400).map((r, i) => {
                const kind = kindBadge[r.kind];
                return (
                  <tr key={r.id} className={cn("border-t border-border/60 hover:bg-accent/40 transition-colors", i % 2 === 0 && "bg-surface/30")}>
                    <td className="px-3 py-2 font-mono font-medium">{r.container || "—"}</td>
                    <td className="px-3 py-2 font-mono">{r.charge || "—"}</td>
                    <td className="px-3 py-2 font-mono text-muted-foreground">{r.bookingId}</td>
                    <td className="px-3 py-2 text-muted-foreground">{r.custOrder}</td>
                    <td className="px-3 py-2"><Badge variant="outline" className={cn("font-normal", kind.cls)}>{kindLabel[r.kind]}</Badge></td>
                    <td className={cn("px-3 py-2 text-right font-mono tabular-nums",
                      r.kind === "credit" && "text-[color:var(--color-destructive)]",
                      r.kind === "invoice" && "text-foreground",
                    )}>{fmtMoney(r.total, r.currency)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length > 400 && (
            <div className="border-t border-border p-3 text-center text-[11px] text-muted-foreground">
              {t("inv.shownFirst", 400, filtered.length)}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function Th({ children, onClick, active, dir, className }: { children: React.ReactNode; onClick: () => void; active: boolean; dir: "asc" | "desc"; className?: string }) {
  return (
    <th className={cn("px-3 py-2 font-medium", className)}>
      <button onClick={onClick} className={cn("inline-flex items-center gap-1 hover:text-foreground transition-colors", active && "text-foreground")}>
        {children}
        <ArrowUpDown className={cn("h-3 w-3 opacity-50", active && "opacity-100", active && dir === "desc" && "rotate-180")} />
      </button>
    </th>
  );
}

function parseDmy(s: string): Date | undefined {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(s.trim());
  if (!m) return undefined;
  const d = new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
  return isNaN(d.getTime()) ? undefined : d;
}
function formatDmy(d: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
}

function DateInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [open, setOpen] = useState(false);
  const selected = parseDmy(value);
  return (
    <div className="flex items-center gap-1">
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="DD/MM/YYYY"
        className="h-8 text-xs"
      />
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button type="button" variant="outline" size="icon" className="h-8 w-8 shrink-0">
            <CalendarIcon className="h-3.5 w-3.5" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="end">
          <Calendar
            mode="single"
            selected={selected}
            onSelect={(d) => {
              if (d) {
                onChange(formatDmy(d));
                setOpen(false);
              }
            }}
            initialFocus
            className={cn("p-3 pointer-events-auto")}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}

function KpiCard({ label, value, sub, icon, accent }: { label: string; value: string; sub?: string; icon: React.ReactNode; accent?: "success" | "destructive" }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-4">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>{label}</span>
        <span className={cn(
          "flex h-6 w-6 items-center justify-center rounded-md",
          accent === "success" ? "bg-[color:var(--color-success)]/15 text-[color:var(--color-success)]" :
          accent === "destructive" ? "bg-[color:var(--color-destructive)]/15 text-[color:var(--color-destructive)]" :
          "bg-secondary text-foreground",
        )}>{icon}</span>
      </div>
      <div className="mt-3 text-2xl font-semibold tracking-tight tabular-nums">{value}</div>
      {sub && <div className="mt-1 text-[11px] text-muted-foreground">{sub}</div>}
    </div>
  );
}

function DocumentPreview() {
  const t = useT();
  const invoice = useInvoiceStore((s) => s.invoiceDoc);
  const credit = useInvoiceStore((s) => s.creditDoc);
  const remarks = useInvoiceStore((s) => s.remarks);
  const setRemarks = useInvoiceStore((s) => s.setRemarks);
  const overrides = useInvoiceStore((s) => s.overrides);
  const setOverride = useInvoiceStore((s) => s.setOverride);
  const regenerate = useInvoiceStore((s) => s.regenerate);
  const regenerating = useInvoiceStore((s) => s.regenerating);
  return (
    <section className="space-y-3">
      <div className="rounded-xl border border-border bg-card p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-semibold">{t("inv.docParams")}</h3>
            <p className="text-xs text-muted-foreground">{t("inv.docParamsHint")}</p>
          </div>
          <Button size="sm" onClick={() => void regenerate()} disabled={regenerating}>
            {regenerating ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="mr-1.5 h-3.5 w-3.5" />}
            {t("inv.regenerate")}
          </Button>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <FieldLite label={t("inv.field.date")}>
            <DateInput value={overrides.date} onChange={(v) => setOverride("date", v)} />
          </FieldLite>
          <FieldLite label={t("inv.field.dueDate")}>
            <DateInput value={overrides.dueDate} onChange={(v) => setOverride("dueDate", v)} />
          </FieldLite>
          <FieldLite label={t("inv.field.printed")}>
            <DateInput value={overrides.printed} onChange={(v) => setOverride("printed", v)} />
          </FieldLite>
          <FieldLite label={t("inv.field.taxRef")}>
            <Input value={overrides.taxRef} onChange={(e) => setOverride("taxRef", e.target.value)} className="h-8 text-xs" />
          </FieldLite>
        </div>
        <FieldLite label={t("inv.field.remarks")}>
          <textarea
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            rows={2}
            className="w-full resize-y rounded-md border border-border bg-background px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-ring"
          />
        </FieldLite>
      </div>
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">{t("inv.preview.title")}</h3>
          <p className="text-xs text-muted-foreground">{t("inv.preview.hint")}</p>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <PdfPanel title="Invoice" doc={invoice} accent="success" />
        <PdfPanel title="Credit Note" doc={credit} accent="destructive" />
      </div>
    </section>
  );
}

function FieldLite({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <label className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}


function PdfPanel({ title, doc, accent }: { title: string; doc: ReturnType<typeof useInvoiceStore.getState>["invoiceDoc"]; accent: "success" | "destructive" }) {
  const t = useT();
  if (!doc) {
    return (
      <div className="flex h-[560px] flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card text-center">
        <FileText className="mb-2 h-8 w-8 text-muted-foreground" />
        <div className="text-sm font-medium">{t("inv.noRowsFor", title)}</div>
        <div className="mt-1 text-xs text-muted-foreground">{t("inv.nothingToGen")}</div>
      </div>
    );
  }
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <div className="flex items-center justify-between border-b border-border bg-[color:var(--color-surface-2)]/60 px-4 py-3">
        <div className="flex items-center gap-3">
          <span className={cn(
            "flex h-7 w-7 items-center justify-center rounded-md",
            accent === "success" ? "bg-[color:var(--color-success)]/15 text-[color:var(--color-success)]" : "bg-[color:var(--color-destructive)]/15 text-[color:var(--color-destructive)]",
          )}>
            <FileText className="h-4 w-4" />
          </span>
          <div className="leading-tight">
            <div className="text-sm font-semibold">{title}</div>
            <div className="text-[11px] text-muted-foreground font-mono">{doc.meta.number} · {doc.meta.date}</div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right leading-tight">
            <div className="text-sm font-semibold tabular-nums">{accent === "destructive" ? `-${fmtMoney(Math.abs(doc.meta.total), doc.meta.currency)}` : fmtMoney(doc.meta.total, doc.meta.currency)}</div>
            <div className="text-[11px] text-muted-foreground">{t("inv.linesCount", doc.meta.lineCount)}</div>
          </div>
          <Button size="sm" variant="outline" onClick={() => downloadBlob(doc.blob, `${doc.meta.number}.pdf`)}>
            <Download className="mr-1.5 h-3.5 w-3.5" /> PDF
          </Button>
        </div>
      </div>
      <div className="bg-[color:var(--color-surface-2)] p-4">
        <div className="mx-auto max-w-[640px] rounded-md shadow-lg ring-1 ring-black/5 overflow-hidden">
          <InvoicePdfPreview bytes={doc.bytes} title={title} />
        </div>
      </div>
    </div>
  );
}


function Sidebar({ onPick }: { onPick: () => void }) {
  const t = useT();
  const s = useInvoiceStore();
  const downloadZip = async () => {
    if (!s.invoiceDoc && !s.creditDoc) return;
    const zip = new JSZip();
    if (s.invoiceDoc) zip.file(`${s.invoiceDoc.meta.number}.pdf`, s.invoiceDoc.bytes);
    if (s.creditDoc) zip.file(`${s.creditDoc.meta.number}.pdf`, s.creditDoc.bytes);
    const blob = await zip.generateAsync({ type: "blob" });
    downloadBlob(blob, `documents-${s.invoiceDoc?.meta.number ?? "export"}.zip`);
  };

  return (
    <aside className="space-y-4 xl:sticky xl:top-[88px] h-fit">

      <div className="rounded-xl border border-border bg-card p-4">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{t("inv.sidebar.status")}</div>
        <div className="mt-3 space-y-2 text-sm">
          <Row label={t("inv.sidebar.file")} value={s.fileName ?? "—"} mono />
          <Row label={t("inv.sidebar.size")} value={s.fileSize ? `${(s.fileSize / 1024).toFixed(1)} KB` : "—"} />
          <Row label={t("inv.sidebar.rows")} value={String(s.rows.length)} />
          <Row label={t("inv.sidebar.invoice")} value={String(s.invoiceRows.length)} />
          <Row label={t("inv.sidebar.credit")} value={String(s.creditRows.length)} />
          <Row label={t("inv.sidebar.validation")} value={
            s.status === "ready" ? (s.warnings.length ? t("inv.sidebar.warn", s.warnings.length) : t("inv.sidebar.ok")) : "—"
          } accent={s.status === "ready" ? (s.warnings.length ? "warning" : "success") : undefined} />
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-4">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3">{t("inv.sidebar.export")}</div>
        <div className="space-y-2">
          <Button className="w-full justify-start" disabled={!s.invoiceDoc} onClick={() => s.invoiceDoc && downloadBlob(s.invoiceDoc.blob, `${s.invoiceDoc.meta.number}.pdf`)}>
            <Download className="mr-2 h-3.5 w-3.5" /> {t("inv.sidebar.dlInvoice")}
          </Button>
          <Button variant="outline" className="w-full justify-start" disabled={!s.creditDoc} onClick={() => s.creditDoc && downloadBlob(s.creditDoc.blob, `${s.creditDoc.meta.number}.pdf`)}>
            <Download className="mr-2 h-3.5 w-3.5" /> {t("inv.sidebar.dlCredit")}
          </Button>
          <Button variant="secondary" className="w-full justify-start" disabled={!s.invoiceDoc && !s.creditDoc} onClick={downloadZip}>
            <Download className="mr-2 h-3.5 w-3.5" /> {t("inv.sidebar.dlZip")}
          </Button>
          <Button variant="ghost" className="w-full justify-start text-muted-foreground" onClick={s.reset} disabled={s.status === "idle"}>
            <RotateCcw className="mr-2 h-3.5 w-3.5" /> {t("inv.sidebar.reset")}
          </Button>
        </div>
      </div>

      {s.warnings.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-1.5">
            <AlertTriangle className="h-3 w-3 text-[color:var(--color-warning)]" /> {t("inv.sidebar.warnings")}
          </div>
          <ul className="space-y-2 text-xs">
            {s.warnings.slice(0, 6).map((w, i) => (
              <li key={i} className="flex items-start gap-2 rounded-md bg-surface px-2 py-2">
                <span className={cn("mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full",
                  w.level === "warning" ? "bg-[color:var(--color-warning)]" : "bg-[color:var(--color-info)]")} />
                <span>{w.message}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="rounded-xl border border-border bg-card p-4">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-1.5">
          <Inbox className="h-3 w-3" /> {t("inv.sidebar.recent")}
        </div>
        {s.recent.length === 0 ? (
          <div className="text-xs text-muted-foreground">{t("inv.sidebar.noRecent")}</div>
        ) : (
          <ul className="space-y-1.5 text-xs">
            {s.recent.map((r, i) => (
              <li key={i} className="flex items-center justify-between rounded-md px-2 py-1.5 hover:bg-accent/50">
                <div className="flex items-center gap-2 truncate">
                  <FileSpreadsheet className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                  <span className="truncate font-mono">{r.name}</span>
                </div>
                <span className="text-muted-foreground shrink-0 ml-2">{r.rows}</span>
              </li>
            ))}
          </ul>
        )}
        <Button variant="ghost" size="sm" className="mt-2 w-full justify-between text-xs" onClick={onPick}>
          {t("inv.sidebar.newUpload")} <ChevronRight className="h-3.5 w-3.5" />
        </Button>
      </div>

    </aside>
  );
}

function Row({ label, value, mono, accent }: { label: string; value: string; mono?: boolean; accent?: "success" | "warning" }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={cn(
        "truncate text-right text-xs max-w-[180px]",
        mono && "font-mono",
        accent === "success" && "text-[color:var(--color-success)] font-medium",
        accent === "warning" && "text-[color:var(--color-warning)] font-medium",
      )}>{value}</span>
    </div>
  );
}

function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name; document.body.appendChild(a); a.click();
  a.remove(); setTimeout(() => URL.revokeObjectURL(url), 500);
}
