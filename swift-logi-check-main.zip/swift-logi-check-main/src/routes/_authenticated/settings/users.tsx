import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  Loader2,
  
  KeyRound,
  Power,
  Search,
  ShieldCheck,
  Copy,
  Eye,
  EyeOff,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import {
  createUser,
  listUsers,
  sendPasswordReset,
  setUserRoles,
  updateUser,
  type UserListItem,
} from "@/lib/users.functions";
import { listRoles } from "@/lib/roles.functions";
import { listDepartments } from "@/lib/departments.functions";

export const Route = createFileRoute("/_authenticated/settings/users")({
  head: () => ({ meta: [{ title: "Пользователи — Logis" }] }),
  component: UsersPage,
});

function UsersPage() {
  const { hasPermission } = useAuth();
  const canManage = hasPermission("users.manage");
  const queryClient = useQueryClient();

  const list = useServerFn(listUsers);
  const rolesFn = useServerFn(listRoles);

  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"all" | "active" | "inactive">("all");
  const [roleId, setRoleId] = useState<string>("all");
  const [inviteOpen, setInviteOpen] = useState(false);
  const [rolesUser, setRolesUser] = useState<UserListItem | null>(null);

  const usersQ = useQuery({
    queryKey: ["users", { search, status, roleId }],
    queryFn: () =>
      list({
        data: {
          search: search || undefined,
          status,
          roleId: roleId === "all" ? undefined : roleId,
        },
      }),
  });

  const rolesQ = useQuery({ queryKey: ["roles"], queryFn: () => rolesFn() });
  const departmentsFn = useServerFn(listDepartments);
  const departmentsQ = useQuery({
    queryKey: ["departments"],
    queryFn: () => departmentsFn(),
  });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["users"] });

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 lg:py-14">
      <header className="mb-8 flex items-end justify-between gap-6 flex-wrap">
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-primary mb-3">
            Команда
          </p>
          <h1 className="text-4xl font-semibold tracking-tight leading-[1.05]">
            Пользователи
          </h1>
          <p className="text-muted-foreground mt-2 max-w-[58ch]">
            Управление сотрудниками, приглашение новых, изменение ролей.
          </p>
        </div>
        {canManage ? (
          <Button onClick={() => setInviteOpen(true)}>
            Создать пользователя
          </Button>
        ) : null}
      </header>

      <div className="flex flex-wrap gap-3 mb-5">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Поиск по имени, email или отделу"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={status} onValueChange={(v: typeof status) => setStatus(v)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все статусы</SelectItem>
            <SelectItem value="active">Активные</SelectItem>
            <SelectItem value="inactive">Деактивированные</SelectItem>
          </SelectContent>
        </Select>
        <Select value={roleId} onValueChange={setRoleId}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Все роли" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все роли</SelectItem>
            {rolesQ.data?.items.map((r) => (
              <SelectItem key={r.id} value={r.id}>
                {r.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Сотрудник</TableHead>
              <TableHead>Роли</TableHead>
              <TableHead>Отдел</TableHead>
              <TableHead>Статус</TableHead>
              <TableHead className="text-right">Действия</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {usersQ.isLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={5}>
                    <Skeleton className="h-8 w-full" />
                  </TableCell>
                </TableRow>
              ))
            ) : usersQ.data?.items.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-12">
                  Сотрудники не найдены
                </TableCell>
              </TableRow>
            ) : (
              usersQ.data?.items.map((u) => (
                <UserRow
                  key={u.id}
                  user={u}
                  canManage={canManage}
                  onChangeRoles={() => setRolesUser(u)}
                  onRefresh={refresh}
                />
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {canManage ? (
        <>
          <CreateDialog
            open={inviteOpen}
            onOpenChange={setInviteOpen}
            roles={rolesQ.data?.items ?? []}
            departments={departmentsQ.data?.items ?? []}
            onCreated={refresh}
          />
          <RolesDialog
            user={rolesUser}
            onClose={() => setRolesUser(null)}
            roles={rolesQ.data?.items ?? []}
            onSaved={refresh}
          />
        </>
      ) : null}
    </div>
  );
}

function UserRow({
  user,
  canManage,
  onChangeRoles,
  onRefresh,
}: {
  user: UserListItem;
  canManage: boolean;
  onChangeRoles: () => void;
  onRefresh: () => void;
}) {
  const updateFn = useServerFn(updateUser);
  const resetFn = useServerFn(sendPasswordReset);

  const toggleActive = useMutation({
    mutationFn: () => updateFn({ data: { id: user.id, is_active: !user.is_active } }),
    onSuccess: () => {
      toast.success(user.is_active ? "Сотрудник деактивирован" : "Сотрудник активирован");
      onRefresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const reset = useMutation({
    mutationFn: () => resetFn({ data: { email: user.email } }),
    onSuccess: () => toast.success("Письмо для сброса отправлено"),
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <TableRow>
      <TableCell>
        <div className="flex flex-col">
          <span className="font-medium">{user.full_name || user.email}</span>
          <span className="text-xs text-muted-foreground">{user.email}</span>
        </div>
      </TableCell>
      <TableCell>
        <div className="flex flex-wrap gap-1">
          {user.roles.length ? (
            user.roles.map((r) => (
              <Badge key={r.id} variant="secondary">
                {r.name}
              </Badge>
            ))
          ) : (
            <span className="text-xs text-muted-foreground">—</span>
          )}
        </div>
      </TableCell>
      <TableCell className="text-sm text-muted-foreground">
        {user.department?.name || "—"}
      </TableCell>
      <TableCell>
        {user.is_active ? (
          <Badge className="bg-emerald-500/10 text-emerald-700 hover:bg-emerald-500/10 dark:text-emerald-400">
            Активен
          </Badge>
        ) : (
          <Badge variant="secondary">Деактивирован</Badge>
        )}
      </TableCell>
      <TableCell className="text-right">
        {canManage ? (
          <div className="flex justify-end gap-1">
            <Button size="sm" variant="ghost" onClick={onChangeRoles} title="Сменить роли">
              <ShieldCheck className="size-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => reset.mutate()}
              disabled={reset.isPending}
              title="Сбросить пароль"
            >
              <KeyRound className="size-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => toggleActive.mutate()}
              disabled={toggleActive.isPending}
              title={user.is_active ? "Деактивировать" : "Активировать"}
            >
              <Power className="size-4" />
            </Button>
          </div>
        ) : null}
      </TableCell>
    </TableRow>
  );
}

function generatePassword(len = 14): string {
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const lower = "abcdefghijkmnpqrstuvwxyz";
  const nums = "23456789";
  const sym = "!@#$%^&*-_";
  const all = upper + lower + nums + sym;
  const pick = (s: string) => s[Math.floor(Math.random() * s.length)];
  const required = [pick(upper), pick(lower), pick(nums), pick(sym)];
  const rest = Array.from({ length: len - required.length }, () => pick(all));
  return [...required, ...rest].sort(() => Math.random() - 0.5).join("");
}

function CreateDialog({
  open,
  onOpenChange,
  roles,
  departments,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  roles: { id: string; name: string }[];
  departments: { id: string; name: string; is_active: boolean }[];
  onCreated: () => void;
}) {
  const create = useServerFn(createUser);
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [position, setPosition] = useState("");
  const [departmentId, setDepartmentId] = useState<string>("none");
  const [password, setPassword] = useState(() => generatePassword());
  const [showPwd, setShowPwd] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);

  const reset = () => {
    setEmail("");
    setFullName("");
    setPosition("");
    setDepartmentId("none");
    setPassword(generatePassword());
    setSelected([]);
    setShowPwd(false);
  };

  const copyCreds = async () => {
    await navigator.clipboard.writeText(`Email: ${email}\nПароль: ${password}`);
    toast.success("Учётные данные скопированы");
  };

  const m = useMutation({
    mutationFn: () =>
      create({
        data: {
          email,
          password,
          full_name: fullName,
          position: position || undefined,
          department_id: departmentId === "none" ? null : departmentId,
          role_ids: selected,
        },
      }),
    onSuccess: async () => {
      await navigator.clipboard.writeText(`Email: ${email}\nПароль: ${password}`).catch(() => {});
      toast.success("Пользователь создан", {
        description: `Логин: ${email} · Пароль скопирован в буфер обмена`,
        duration: 8000,
      });
      onCreated();
      onOpenChange(false);
      reset();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v);
        if (!v) reset();
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Создать пользователя</DialogTitle>
          <DialogDescription>
            Учётные данные нужно будет передать сотруднику лично.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Email</Label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@company.com"
            />
          </div>
          <div className="space-y-1.5">
            <Label>ФИО</Label>
            <Input value={fullName} onChange={(e) => setFullName(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Должность</Label>
              <Input value={position} onChange={(e) => setPosition(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Отдел</Label>
              <Select value={departmentId} onValueChange={setDepartmentId}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— не указан —</SelectItem>
                  {departments
                    .filter((d) => d.is_active)
                    .map((d) => (
                      <SelectItem key={d.id} value={d.id}>
                        {d.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Пароль</Label>
            <div className="flex gap-1.5">
              <Input
                type={showPwd ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="font-mono"
              />
              <Button
                type="button"
                size="icon"
                variant="outline"
                onClick={() => setShowPwd((v) => !v)}
                title={showPwd ? "Скрыть" : "Показать"}
              >
                {showPwd ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </Button>
              <Button
                type="button"
                size="icon"
                variant="outline"
                onClick={() => setPassword(generatePassword())}
                title="Сгенерировать"
              >
                <RefreshCw className="size-4" />
              </Button>
              <Button
                type="button"
                size="icon"
                variant="outline"
                onClick={copyCreds}
                title="Скопировать email и пароль"
                disabled={!email || !password}
              >
                <Copy className="size-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Минимум 8 символов. После создания пароль скопируется автоматически.
            </p>
          </div>
          <div className="space-y-1.5">
            <Label>Роли</Label>
            <div className="border border-border rounded-md p-3 space-y-2 max-h-44 overflow-y-auto">
              {roles.map((r) => (
                <label key={r.id} className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox
                    checked={selected.includes(r.id)}
                    onCheckedChange={(v) =>
                      setSelected((prev) =>
                        v ? [...prev, r.id] : prev.filter((id) => id !== r.id),
                      )
                    }
                  />
                  {r.name}
                </label>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Отмена
          </Button>
          <Button
            onClick={() => m.mutate()}
            disabled={m.isPending || !email || !fullName || password.length < 8}
          >
            {m.isPending ? <Loader2 className="size-4 animate-spin" /> : "Создать"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function RolesDialog({
  user,
  onClose,
  roles,
  onSaved,
}: {
  user: UserListItem | null;
  onClose: () => void;
  roles: { id: string; name: string }[];
  onSaved: () => void;
}) {
  const setRoles = useServerFn(setUserRoles);
  const [selected, setSelected] = useState<string[]>([]);

  useMemo(() => {
    if (user) setSelected(user.roles.map((r) => r.id));
  }, [user]);

  const m = useMutation({
    mutationFn: () =>
      setRoles({ data: { user_id: user!.id, role_ids: selected } }),
    onSuccess: () => {
      toast.success("Роли обновлены");
      onSaved();
      onClose();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={!!user} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Роли сотрудника</DialogTitle>
          <DialogDescription>{user?.email}</DialogDescription>
        </DialogHeader>
        <div className="border border-border rounded-md p-3 space-y-2">
          {roles.map((r) => (
            <label key={r.id} className="flex items-center gap-2 text-sm cursor-pointer">
              <Checkbox
                checked={selected.includes(r.id)}
                onCheckedChange={(v) =>
                  setSelected((prev) =>
                    v ? [...prev, r.id] : prev.filter((id) => id !== r.id),
                  )
                }
              />
              {r.name}
            </label>
          ))}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Отмена
          </Button>
          <Button onClick={() => m.mutate()} disabled={m.isPending}>
            {m.isPending ? <Loader2 className="size-4 animate-spin" /> : "Сохранить"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
