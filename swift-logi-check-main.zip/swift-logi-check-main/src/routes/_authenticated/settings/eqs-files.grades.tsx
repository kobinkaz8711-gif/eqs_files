import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { listGrades, upsertGrade, deleteGrade } from "@/lib/grades.functions";

export const Route = createFileRoute("/_authenticated/settings/eqs-files/grades")({
  head: () => ({ meta: [{ title: "EQS Equipment Grades" }] }),
  component: GradesPage,
});

function GradesPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listGrades);
  const upsertFn = useServerFn(upsertGrade);
  const deleteFn = useServerFn(deleteGrade);

  const q = useQuery({ queryKey: ["equipment-grades"], queryFn: () => listFn() });

  const [newCode, setNewCode] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [newSort, setNewSort] = useState<number>(0);

  const addMut = useMutation({
    mutationFn: () =>
      upsertFn({
        data: {
          code: newCode,
          label: newLabel || newCode,
          sort_order: newSort,
          is_active: true,
        },
      }),
    onSuccess: () => {
      toast.success("Saved");
      setNewCode("");
      setNewLabel("");
      setNewSort(0);
      qc.invalidateQueries({ queryKey: ["equipment-grades"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Error"),
  });

  const toggleMut = useMutation({
    mutationFn: (row: { code: string; label: string; sort_order: number; is_active: boolean }) =>
      upsertFn({ data: row }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["equipment-grades"] }),
    onError: (e: any) => toast.error(e?.message ?? "Error"),
  });

  const delMut = useMutation({
    mutationFn: (code: string) => deleteFn({ data: { code } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["equipment-grades"] }),
    onError: (e: any) => toast.error(e?.message ?? "Error"),
  });

  return (
    <div className="max-w-3xl mx-auto px-6 py-8">
      <Button variant="ghost" size="sm" asChild className="mb-4">
        <Link to="/settings/eqs-files">
          <ArrowLeft className="size-4 mr-1" /> EQS Files Settings
        </Link>
      </Button>
      <h1 className="text-2xl font-semibold mb-1">Equipment Grades</h1>
      <p className="text-sm text-muted-foreground mb-6">
        Справочник грейдов (состояния) контейнеров. Используется в строках типов
        контейнеров файла и при выгрузке в EQS.
      </p>

      <div className="flex gap-2 mb-4 items-end">
        <div className="flex flex-col">
          <span className="text-xs text-muted-foreground mb-1">Code</span>
          <Input
            placeholder="e.g. CW"
            value={newCode}
            onChange={(e) => setNewCode(e.target.value)}
            className="w-32"
          />
        </div>
        <div className="flex flex-col flex-1">
          <span className="text-xs text-muted-foreground mb-1">Label</span>
          <Input
            placeholder="Label"
            value={newLabel}
            onChange={(e) => setNewLabel(e.target.value)}
          />
        </div>
        <div className="flex flex-col">
          <span className="text-xs text-muted-foreground mb-1">Sort</span>
          <Input
            type="number"
            value={newSort}
            onChange={(e) => setNewSort(parseInt(e.target.value || "0", 10))}
            className="w-20"
          />
        </div>
        <Button onClick={() => addMut.mutate()} disabled={!newCode || addMut.isPending}>
          <Plus className="size-4 mr-1" /> Add / Update
        </Button>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/30">
            <tr>
              <th className="text-left p-2 w-[160px]">Code</th>
              <th className="text-left p-2">Label</th>
              <th className="text-left p-2 w-[80px]">Sort</th>
              <th className="text-left p-2 w-[100px]">Active</th>
              <th className="w-12"></th>
            </tr>
          </thead>
          <tbody>
            {(q.data?.items ?? []).map((row: any) => (
              <tr key={row.code} className="border-t">
                <td className="p-2 font-mono">{row.code}</td>
                <td className="p-2">{row.label}</td>
                <td className="p-2 text-muted-foreground">{row.sort_order}</td>
                <td className="p-2">
                  <Switch
                    checked={!!row.is_active}
                    onCheckedChange={(v) =>
                      toggleMut.mutate({
                        code: row.code,
                        label: row.label,
                        sort_order: row.sort_order ?? 0,
                        is_active: v,
                      })
                    }
                  />
                </td>
                <td className="p-2 text-right">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      if (confirm(`Delete grade ${row.code}?`)) delMut.mutate(row.code);
                    }}
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </td>
              </tr>
            ))}
            {q.data?.items.length === 0 && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-muted-foreground">
                  Справочник пуст
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
