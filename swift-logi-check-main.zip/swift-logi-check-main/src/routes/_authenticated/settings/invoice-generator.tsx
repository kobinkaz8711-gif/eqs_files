import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Save, RotateCcw, Building2, FileText, Receipt, ImageIcon, Trash2, BookOpen, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  useInvoiceSettings,
  DEFAULT_CHARGE_MAP,
  type InvoiceSettings,
  type ChargeMapEntry,
  type ChargeReplacement,
} from "@/lib/invoice/settings";

export const Route = createFileRoute("/_authenticated/settings/invoice-generator")({
  head: () => ({ meta: [{ title: "Invoice Generator — Settings" }] }),
  component: InvoiceGeneratorSettings,
});

function InvoiceGeneratorSettings() {
  const { settings, save, reset } = useInvoiceSettings();
  const [draft, setDraft] = useState<InvoiceSettings>(settings);
  useEffect(() => {
    setDraft(settings);
  }, [settings]);

  const update = <K extends keyof InvoiceSettings>(key: K, value: InvoiceSettings[K]) =>
    setDraft((d) => ({ ...d, [key]: value }));

  const updateCompany = <K extends keyof InvoiceSettings["company"]>(
    key: K,
    value: InvoiceSettings["company"][K],
  ) => setDraft((d) => ({ ...d, company: { ...d.company, [key]: value } }));

  const updateBillTo = <K extends keyof InvoiceSettings["billTo"]>(
    key: K,
    value: InvoiceSettings["billTo"][K],
  ) => setDraft((d) => ({ ...d, billTo: { ...d.billTo, [key]: value } }));

  const onSave = () => {
    save(draft);
    toast.success("Настройки сохранены");
  };

  const onReset = () => {
    reset();
    toast.success("Сброшено к значениям по умолчанию");
    setTimeout(() => window.location.reload(), 200);
  };

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <Link
        to="/invoice-generator"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6"
      >
        <ArrowLeft className="size-4" />
        Назад к Invoice Generator
      </Link>

      <h1 className="text-3xl font-semibold tracking-tight mb-2">Настройки модуля</h1>
      <p className="text-muted-foreground mb-8">
        Реквизиты компании, плательщика и параметры документов. Сохраняется локально в браузере.
      </p>

      {/* Company */}
      <section className="rounded-2xl border border-border bg-card p-6 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Building2 className="size-4 text-primary" />
          <h2 className="font-semibold">Реквизиты компании</h2>
        </div>
        <div className="space-y-3">
          <Field label="Название">
            <Input value={draft.company.name} onChange={(e) => updateCompany("name", e.target.value)} />
          </Field>
          <Field label="Подзаголовок">
            <Input value={draft.company.sub} onChange={(e) => updateCompany("sub", e.target.value)} />
          </Field>
          <Field label="Адрес (по одной строке)">
            <Textarea
              rows={4}
              value={draft.company.lines.join("\n")}
              onChange={(e) => updateCompany("lines", e.target.value.split("\n"))}
            />
          </Field>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Field label="Телефон">
              <Input value={draft.company.tel} onChange={(e) => updateCompany("tel", e.target.value)} />
            </Field>
            <Field label="Email">
              <Input value={draft.company.email} onChange={(e) => updateCompany("email", e.target.value)} />
            </Field>
          </div>
          <Field label="Tax Reg">
            <Input value={draft.company.tax} onChange={(e) => updateCompany("tax", e.target.value)} />
          </Field>
        </div>
      </section>

      {/* Logo */}
      <section className="rounded-2xl border border-border bg-card p-6 mb-6">
        <div className="flex items-center gap-2 mb-1">
          <ImageIcon className="size-4 text-primary" />
          <h2 className="font-semibold">Логотип</h2>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          PNG или JPEG. Будет показан в правом верхнем углу PDF. Рекомендуется до 600&times;240 px.
        </p>
        <div className="flex items-start gap-4">
          <div className="flex h-20 w-40 items-center justify-center rounded-lg border border-border bg-muted/40 overflow-hidden">
            {draft.logoDataUrl ? (
              <img src={draft.logoDataUrl} alt="Logo" className="max-h-full max-w-full object-contain" />
            ) : (
              <span className="text-xs text-muted-foreground">Нет логотипа</span>
            )}
          </div>
          <div className="flex-1 space-y-2">
            <Input
              type="file"
              accept="image/png,image/jpeg"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                if (f.size > 1_500_000) {
                  toast.error("Файл слишком большой (макс. 1.5 MB)");
                  return;
                }
                const reader = new FileReader();
                reader.onload = () => update("logoDataUrl", String(reader.result));
                reader.readAsDataURL(f);
              }}
            />
            {draft.logoDataUrl && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => update("logoDataUrl", undefined)}
              >
                <Trash2 className="mr-2 size-3.5" /> Удалить логотип
              </Button>
            )}
          </div>
        </div>
      </section>


      {/* Bill To */}
      <section className="rounded-2xl border border-border bg-card p-6 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Receipt className="size-4 text-primary" />
          <h2 className="font-semibold">Плательщик (Bill To)</h2>
        </div>
        <div className="space-y-3">
          <Field label="Название">
            <Input value={draft.billTo.name} onChange={(e) => updateBillTo("name", e.target.value)} />
          </Field>
          <Field label="Адрес (по одной строке)">
            <Textarea
              rows={4}
              value={draft.billTo.lines.join("\n")}
              onChange={(e) => updateBillTo("lines", e.target.value.split("\n"))}
            />
          </Field>
        </div>
      </section>

      {/* Document */}
      <section className="rounded-2xl border border-border bg-card p-6 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <FileText className="size-4 text-primary" />
          <h2 className="font-semibold">Параметры документа</h2>
        </div>
        <div className="space-y-3">
          <Field label="Примечание / Remarks">
            <Textarea
              rows={2}
              value={draft.remarks}
              onChange={(e) => update("remarks", e.target.value)}
            />
          </Field>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Field label="VAT, %">
              <Input
                type="number"
                step="0.01"
                value={draft.vatPercent}
                onChange={(e) => update("vatPercent", Number(e.target.value) || 0)}
              />
            </Field>
            <Field label="Срок оплаты, дней">
              <Input
                type="number"
                value={draft.dueDays}
                onChange={(e) => update("dueDays", Number(e.target.value) || 0)}
              />
            </Field>
            <Field label="Account (по умолчанию)">
              <Input value={draft.account} onChange={(e) => update("account", e.target.value)} />
            </Field>
          </div>
          <Field label="Internal Contact">
            <Input
              value={draft.internalContact}
              onChange={(e) => update("internalContact", e.target.value)}
            />
          </Field>
          <Field label="Tax Ref (по умолчанию)">
            <Input value={draft.taxRef} onChange={(e) => update("taxRef", e.target.value)} />
          </Field>
        </div>
      </section>


      {/* Charge nomenclature */}
      <section className="rounded-2xl border border-border bg-card p-6 mb-6">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <BookOpen className="size-4 text-primary" />
            <h2 className="font-semibold">Справочник номенклатуры (Charge)</h2>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => update("chargeMap", [...DEFAULT_CHARGE_MAP])}
            >
              <RotateCcw className="mr-2 size-3.5" /> Загрузить значения по умолчанию
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() =>
                update("chargeMap", [...draft.chargeMap, { code: "", name: "" }])
              }
            >
              <Plus className="mr-2 size-3.5" /> Добавить
            </Button>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          Код из колонки Charge сопоставляется с названием — оно подставляется в описание строки PDF.
        </p>
        <div className="space-y-2 max-h-[420px] overflow-auto pr-2">
          <div className="grid grid-cols-[120px_1fr_auto] gap-2 text-xs text-muted-foreground px-1">
            <div>Код</div>
            <div>Название</div>
            <div></div>
          </div>
          {draft.chargeMap.map((entry, i) => (
            <div key={i} className="grid grid-cols-[120px_1fr_auto] gap-2">
              <Input
                value={entry.code}
                onChange={(e) => {
                  const next = [...draft.chargeMap];
                  next[i] = { ...next[i], code: e.target.value };
                  update("chargeMap", next);
                }}
                placeholder="CODE"
              />
              <Input
                value={entry.name}
                onChange={(e) => {
                  const next = [...draft.chargeMap];
                  next[i] = { ...next[i], name: e.target.value };
                  update("chargeMap", next);
                }}
                placeholder="Описание"
              />
              <Button
                size="icon"
                variant="ghost"
                onClick={() => {
                  const next = draft.chargeMap.filter((_: ChargeMapEntry, idx: number) => idx !== i);
                  update("chargeMap", next);
                }}
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
          ))}
        </div>
      </section>

      {/* Charge replacements */}
      <section className="rounded-2xl border border-border bg-card p-6 mb-6">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <BookOpen className="size-4 text-primary" />
            <h2 className="font-semibold">Замена кодов в документах</h2>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() =>
              update("chargeReplacements", [
                ...(draft.chargeReplacements ?? []),
                { from: "", to: "" },
              ])
            }
          >
            <Plus className="mr-2 size-3.5" /> Добавить
          </Button>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          При генерации PDF код из колонки Charge заменяется на новый код. Например: RENT → REN2. Справочник номенклатуры остаётся без изменений.
        </p>
        <div className="space-y-2 max-h-[320px] overflow-auto pr-2">
          <div className="grid grid-cols-[1fr_1fr_auto] gap-2 text-xs text-muted-foreground px-1">
            <div>Исходный код</div>
            <div>Новый код</div>
            <div></div>
          </div>
          {(draft.chargeReplacements ?? []).map((entry, i) => (
            <div key={i} className="grid grid-cols-[1fr_1fr_auto] gap-2">
              <Input
                value={entry.from}
                onChange={(e) => {
                  const next = [...(draft.chargeReplacements ?? [])];
                  next[i] = { ...next[i], from: e.target.value };
                  update("chargeReplacements", next);
                }}
                placeholder="RENT"
              />
              <Input
                value={entry.to}
                onChange={(e) => {
                  const next = [...(draft.chargeReplacements ?? [])];
                  next[i] = { ...next[i], to: e.target.value };
                  update("chargeReplacements", next);
                }}
                placeholder="REN2"
              />
              <Button
                size="icon"
                variant="ghost"
                onClick={() => {
                  const next = (draft.chargeReplacements ?? []).filter(
                    (_: ChargeReplacement, idx: number) => idx !== i,
                  );
                  update("chargeReplacements", next);
                }}
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
          ))}
        </div>
      </section>


      <div className="flex items-center gap-2">
        <Button onClick={onSave}>
          <Save className="mr-2 size-4" /> Сохранить
        </Button>
        <Button variant="outline" onClick={onReset}>
          <RotateCcw className="mr-2 size-4" /> Сбросить по умолчанию
        </Button>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
