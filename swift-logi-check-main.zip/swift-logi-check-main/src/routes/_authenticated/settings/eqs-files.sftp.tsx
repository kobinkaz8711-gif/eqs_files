import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ArrowLeft, Download, RefreshCw, Play, FolderOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import {
  getEqsSftpSettings,
  saveEqsSftpSettings,
  listRecentEqsExports,
  getEqsExportDownloadUrl,
  probeEqsFtp,
  runEqsRelayNow,
} from "@/lib/eqs-booking.functions";


export const Route = createFileRoute("/_authenticated/settings/eqs-files/sftp")({
  head: () => ({ meta: [{ title: "EQS FTP Settings" }] }),
  component: SftpSettingsPage,
});

function SftpSettingsPage() {
  const qc = useQueryClient();
  const fetchFn = useServerFn(getEqsSftpSettings);
  const saveFn = useServerFn(saveEqsSftpSettings);

  const q = useQuery({ queryKey: ["eqs-sftp-settings"], queryFn: () => fetchFn() });

  const [form, setForm] = useState({
    host: "",
    port: 21,
    username: "",
    outbox_remote_path: "",
    processed_remote_path: "",
    errors_remote_path: "",
    incomplete_remote_path: "",
    enabled: false,
    use_tls: false,
    poll_interval_seconds: 30,
  });

  useEffect(() => {
    if (q.data) {
      setForm({
        host: q.data.host ?? "",
        port: q.data.port ?? 21,
        username: q.data.username ?? "",
        outbox_remote_path: q.data.outbox_remote_path ?? "",
        processed_remote_path: q.data.processed_remote_path ?? "",
        errors_remote_path: q.data.errors_remote_path ?? "",
        incomplete_remote_path: (q.data as any).incomplete_remote_path ?? "",
        enabled: q.data.enabled ?? false,
        use_tls: (q.data as any).use_tls ?? false,
        poll_interval_seconds: q.data.poll_interval_seconds ?? 30,
      });
    }
  }, [q.data]);

  const saveMut = useMutation({
    mutationFn: () => saveFn({ data: form }),
    onSuccess: () => {
      toast.success("SFTP settings saved");
      qc.invalidateQueries({ queryKey: ["eqs-sftp-settings"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Save failed"),
  });

  return (
    <div className="max-w-3xl mx-auto px-6 py-8">
      <Button variant="ghost" size="sm" asChild className="mb-4">
        <Link to="/settings/eqs-files">
          <ArrowLeft className="size-4 mr-1" /> EQS Files Settings
        </Link>
      </Button>
      <h1 className="text-2xl font-semibold mb-1">FTP Settings (EQS)</h1>
      <p className="text-sm text-muted-foreground mb-6">
        Параметры подключения к FTP-серверу EQS. Пароль хранится в секретах под именем{" "}
        <code className="text-xs bg-muted px-1 rounded">EQS_SFTP_PASSWORD</code>.
      </p>

      <div className="space-y-4 bg-card border rounded-lg p-5">
        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2">
            <Label>Host</Label>
            <Input value={form.host} onChange={(e) => setForm({ ...form, host: e.target.value })} />
          </div>
          <div>
            <Label>Port</Label>
            <Input
              type="number"
              value={form.port}
              onChange={(e) => setForm({ ...form, port: Number(e.target.value) || 21 })}
            />
          </div>
        </div>
        <div>
          <Label>Username</Label>
          <Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
        </div>
        <div>
          <Label>Outbox (исходящие, мы пишем сюда)</Label>
          <Input
            value={form.outbox_remote_path}
            onChange={(e) => setForm({ ...form, outbox_remote_path: e.target.value })}
            placeholder="/eqs/inbox"
          />
        </div>
        <div>
          <Label>Processed (успех, EQS пишет сюда)</Label>
          <Input
            value={form.processed_remote_path}
            onChange={(e) => setForm({ ...form, processed_remote_path: e.target.value })}
            placeholder="/eqs/processed"
          />
        </div>
        <div>
          <Label>Errors (ошибки, EQS пишет сюда)</Label>
          <Input
            value={form.errors_remote_path}
            onChange={(e) => setForm({ ...form, errors_remote_path: e.target.value })}
            placeholder="/eqs/errors"
          />
        </div>
        <div>
          <Label>Incomplete (букинги созданы, но не полностью заполнены)</Label>
          <Input
            value={form.incomplete_remote_path}
            onChange={(e) => setForm({ ...form, incomplete_remote_path: e.target.value })}
            placeholder="EQS/incomplete"
          />
        </div>
        <div className="grid grid-cols-2 gap-3 items-end">
          <div>
            <Label>Poll interval (sec) — для UI</Label>
            <Input
              type="number"
              value={form.poll_interval_seconds}
              onChange={(e) =>
                setForm({ ...form, poll_interval_seconds: Number(e.target.value) || 30 })
              }
            />
          </div>
          <div className="flex items-center gap-3 pb-2">
            <Switch
              checked={form.enabled}
              onCheckedChange={(v) => setForm({ ...form, enabled: v })}
            />
            <Label>Enabled (включить релей)</Label>
          </div>
        </div>
        <div className="flex items-center gap-3 pt-1">
          <Switch
            checked={form.use_tls}
            onCheckedChange={(v) => setForm({ ...form, use_tls: v })}
          />
          <Label>Use TLS (FTPS, explicit)</Label>
        </div>
        <div className="pt-2">
          <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>
            {saveMut.isPending ? "Saving…" : "Save"}
          </Button>
        </div>
      </div>

      <FtpProbeSection />
      <ExportsTable />
    </div>
  );
}

function FtpProbeSection() {
  const probeFn = useServerFn(probeEqsFtp);
  const runFn = useServerFn(runEqsRelayNow);
  const [data, setData] = useState<any>(null);

  const probeMut = useMutation({
    mutationFn: () => probeFn({ data: undefined as any }),
    onSuccess: (r: any) => setData(r.data ?? r),
    onError: (e: any) => toast.error(e?.message ?? "Probe failed"),
  });
  const runMut = useMutation({
    mutationFn: () => runFn({ data: undefined as any }),
    onSuccess: (r: any) => {
      toast.success(`Uploaded ${r?.data?.uploaded ?? 0}, processed ${r?.data?.processed ?? 0}`);
      probeMut.mutate();
    },
    onError: (e: any) => toast.error(e?.message ?? "Run failed"),
  });

  return (
    <div className="mt-8 bg-card border rounded-lg p-5">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <FolderOpen className="size-5" /> FTP содержимое
        </h2>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => runMut.mutate()} disabled={runMut.isPending}>
            <Play className="size-4 mr-1" />
            {runMut.isPending ? "Run…" : "Запустить сейчас"}
          </Button>
          <Button size="sm" variant="outline" onClick={() => probeMut.mutate()} disabled={probeMut.isPending}>
            <RefreshCw className={`size-4 mr-1 ${probeMut.isPending ? "animate-spin" : ""}`} />
            Обновить
          </Button>
        </div>
      </div>
      {!data && (
        <p className="text-sm text-muted-foreground">Нажмите «Обновить», чтобы увидеть, что сейчас лежит на FTP.</p>
      )}
      {data?.folders && (
        <div className="space-y-4">
          {Object.entries(data.folders).map(([key, val]: any) => (
            <div key={key}>
              <div className="text-sm font-medium mb-1">
                {key}{" "}
                <span className="text-muted-foreground font-normal">({val?.path ?? "—"})</span>
              </div>
              {val?.error && <div className="text-xs text-destructive">{val.error}</div>}
              {val?.lines && (
                <pre className="text-xs bg-muted/50 rounded p-2 overflow-x-auto whitespace-pre">
                  {val.lines.join("\n")}
                </pre>
              )}
            </div>
          ))}
        </div>
      )}
      {data?.error && <div className="text-sm text-destructive">{data.error}</div>}
    </div>
  );
}

function ExportsTable() {
  const listFn = useServerFn(listRecentEqsExports);
  const dlFn = useServerFn(getEqsExportDownloadUrl);
  const q = useQuery({ queryKey: ["eqs-recent-exports"], queryFn: () => listFn({ data: undefined as any }) });

  async function open(bucket: "eqs-outbox" | "eqs-inbox", path: string) {
    try {
      const r: any = await dlFn({ data: { bucket, path } });
      window.open(r.url, "_blank", "noopener");
    } catch (e: any) {
      toast.error(e?.message ?? "Download failed");
    }
  }

  return (
    <div className="mt-8 bg-card border rounded-lg p-5">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold">Последние выгрузки</h2>
        <Button size="sm" variant="outline" onClick={() => q.refetch()}>
          <RefreshCw className="size-4 mr-1" /> Обновить
        </Button>
      </div>
      {q.isLoading && <div className="text-sm text-muted-foreground">Loading…</div>}
      {q.data?.items?.length === 0 && (
        <div className="text-sm text-muted-foreground">Пока нет выгрузок.</div>
      )}
      {!!q.data?.items?.length && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-muted-foreground border-b">
                <th className="py-2 pr-3">File</th>
                <th className="py-2 pr-3">Filename</th>
                <th className="py-2 pr-3">Status</th>
                <th className="py-2 pr-3">Created</th>
                <th className="py-2 pr-3">Sent</th>
                <th className="py-2 pr-3">Booking ID</th>
                <th className="py-2 pr-3 text-right">Файлы</th>
              </tr>
            </thead>
            <tbody>
              {q.data!.items.map((it: any) => (
                <tr key={it.id} className="border-b last:border-0">
                  <td className="py-2 pr-3 font-mono text-xs">{it.file_number}</td>
                  <td className="py-2 pr-3 font-mono text-xs">{it.filename}</td>
                  <td className="py-2 pr-3">
                    <span className={`px-1.5 py-0.5 rounded text-xs ${
                      it.status === "acknowledged" ? "bg-green-500/15 text-green-700 dark:text-green-400"
                        : it.status === "incomplete" ? "bg-amber-500/15 text-amber-700 dark:text-amber-400"
                        : it.status === "sent" ? "bg-blue-500/15 text-blue-700 dark:text-blue-400"
                        : it.status === "failed" ? "bg-red-500/15 text-red-700 dark:text-red-400"
                        : "bg-muted text-muted-foreground"
                    }`}>{it.status}</span>
                  </td>
                  <td className="py-2 pr-3 text-xs whitespace-nowrap">{fmt(it.created_at)}</td>
                  <td className="py-2 pr-3 text-xs whitespace-nowrap">{fmt(it.sent_at)}</td>
                  <td className="py-2 pr-3 font-mono text-xs">{it.eqs_booking_id ?? "—"}</td>
                  <td className="py-2 pr-3 text-right">
                    <div className="flex gap-2 justify-end">
                      {it.payload_path && (
                        <Button size="sm" variant="ghost" onClick={() => open("eqs-outbox", it.payload_path)}>
                          <Download className="size-3.5 mr-1" /> отправлен
                        </Button>
                      )}
                      {it.response_path && (
                        <Button size="sm" variant="ghost" onClick={() => open("eqs-inbox", it.response_path)}>
                          <Download className="size-3.5 mr-1" /> ответ
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function fmt(ts: string | null | undefined) {
  if (!ts) return "—";
  const d = new Date(ts);
  return d.toLocaleString();
}
