import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/settings/eqs-files/rt-billing")({
  head: () => ({ meta: [{ title: "RT Billing Rules" }] }),
  component: () => <Stub title="RT Billing Rules" />,
});

function Stub({ title }: { title: string }) {
  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <Button variant="ghost" size="sm" asChild className="mb-4">
        <Link to="/settings/eqs-files">
          <ArrowLeft className="size-4 mr-1" /> EQS Files
        </Link>
      </Button>
      <h1 className="text-2xl font-semibold tracking-tight mb-2">{title}</h1>
      <p className="text-muted-foreground">Coming soon.</p>
    </div>
  );
}
