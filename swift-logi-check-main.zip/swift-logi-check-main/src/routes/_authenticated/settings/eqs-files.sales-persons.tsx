import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { ArrowLeft, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAuth } from "@/hooks/useAuth";
import {
  listSalesPersons,
  createSalesPerson,
  updateSalesPerson,
  deleteSalesPerson,
} from "@/lib/salesPersons.functions";
import { listDepartments } from "@/lib/departments.functions";

export const Route = createFileRoute("/_authenticated/settings/eqs-files/sales-persons")({
  head: () => ({ meta: [{ title: "Sales Persons — EQS Files" }] }),
  component: SalesPersonsPage,
});

const UNASSIGNED = "__none__";

function SalesPersonsPage() {
  const { hasPermission, me } = useAuth();
  if (me && !hasPermission("admin.full")) {
    throw redirect({ to: "/forbidden" });
  }

  const qc = useQueryClient();
  const listFn = useServerFn(listSalesPersons);
  const createFn = useServerFn(createSalesPerson);
  const updateFn = useServerFn(updateSalesPerson);
  const deleteFn = useServerFn(deleteSalesPerson);
  const listDeptsFn = useServerFn(listDepartments);

  const q = useQuery({ queryKey: ["sales-persons"], queryFn: () => listFn() });
  const deptsQ = useQuery({ queryKey: ["departments"], queryFn: () => listDeptsFn() });
  const items = (q.data?.items ?? []) as any[];
  const depts = (deptsQ.data?.items ?? []) as any[];

  const invalidate = () => qc.invalidateQueries({ queryKey: ["sales-persons"] });

  const [name, setName] = useState("");
  const [deptId, setDeptId] = useState<string>(UNASSIGNED);

  const create = useMutation({
    mutationFn: () =>
      createFn({
        data: {
          full_name: name.trim(),
          department_id: deptId === UNASSIGNED ? null : deptId,
        },
      }),
    onSuccess: () => {
      invalidate();
      setName("");
      setDeptId(UNASSIGNED);
      toast.success("Sales person added");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const update = useMutation({
    mutationFn: (input: { id: string; patch: Record<string, unknown> }) =>
      updateFn({ data: { id: input.id, ...input.patch } }),
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      invalidate();
      toast.success("Sales person removed");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="text-foreground">
      <div className="border-b border-border bg-card">
        <div className="max-w-[1200px] mx-auto px-6 py-3">
          <Link to="/settings/eqs-files" className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1">
            <ArrowLeft className="size-3" /> EQS Files
          </Link>
          <h1 className="text-base font-semibold tracking-tight mt-1">Sales Persons</h1>
        </div>
      </div>

      <main className="max-w-[1200px] mx-auto px-6 py-6 space-y-6">
        <div className="bg-card border border-border rounded-md p-4">
          <h2 className="text-sm font-semibold mb-3">Добавить менеджера</h2>
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1 min-w-[260px] flex-1">
              <Label htmlFor="sp-name" className="text-xs">ФИО</Label>
              <Input
                id="sp-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Например: Ivan Petrov"
              />
            </div>
            <div className="space-y-1 min-w-[200px]">
              <Label className="text-xs">Отдел</Label>
              <Select value={deptId} onValueChange={setDeptId}>
                <SelectTrigger>
                  <SelectValue placeholder="Без отдела" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={UNASSIGNED}>— Без отдела —</SelectItem>
                  {depts.map((d) => (
                    <SelectItem key={d.id} value={d.id}>
                      {d.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={() => {
                if (!name.trim()) {
                  toast.error("Введите ФИО");
                  return;
                }
                create.mutate();
              }}
              disabled={create.isPending}
            >
              Добавить
            </Button>
          </div>
        </div>

        <div className="bg-card border border-border rounded-md overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ФИО</TableHead>
                <TableHead className="w-[240px]">Отдел</TableHead>
                <TableHead className="w-[100px]">Активен</TableHead>
                <TableHead className="w-[60px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((sp) => (
                <TableRow key={sp.id}>
                  <TableCell>
                    <Input
                      defaultValue={sp.full_name}
                      className="h-8"
                      onBlur={(e) => {
                        const v = e.target.value.trim();
                        if (v && v !== sp.full_name) {
                          update.mutate({ id: sp.id, patch: { full_name: v } });
                        }
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Select
                      value={sp.department_id ?? UNASSIGNED}
                      onValueChange={(v) =>
                        update.mutate({
                          id: sp.id,
                          patch: { department_id: v === UNASSIGNED ? null : v },
                        })
                      }
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue placeholder="—" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={UNASSIGNED}>— Без отдела —</SelectItem>
                        {depts.map((d) => (
                          <SelectItem key={d.id} value={d.id}>
                            {d.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={sp.is_active}
                      onCheckedChange={(v) =>
                        update.mutate({ id: sp.id, patch: { is_active: v } })
                      }
                    />
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        if (confirm(`Удалить "${sp.full_name}"?`)) {
                          del.mutate(sp.id);
                        }
                      }}
                      className="text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-sm text-muted-foreground py-6">
                    Нет менеджеров.
                  </TableCell>
                </TableRow>
              ) : null}
            </TableBody>
          </Table>
        </div>
      </main>
    </div>
  );
}
