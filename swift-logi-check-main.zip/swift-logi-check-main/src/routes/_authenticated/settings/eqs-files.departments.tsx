import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { ArrowLeft, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAuth } from "@/hooks/useAuth";
import {
  listDepartments,
  createDepartment,
  updateDepartment,
  deleteDepartment,
} from "@/lib/departments.functions";

export const Route = createFileRoute("/_authenticated/settings/eqs-files/departments")({
  head: () => ({ meta: [{ title: "Отделы — Logis" }] }),
  component: DepartmentsPage,
});

function DepartmentsPage() {
  const { hasPermission, me } = useAuth();
  if (me && !hasPermission("departments.manage")) {
    throw redirect({ to: "/forbidden" });
  }

  const qc = useQueryClient();
  const listFn = useServerFn(listDepartments);
  const createFn = useServerFn(createDepartment);
  const updateFn = useServerFn(updateDepartment);
  const deleteFn = useServerFn(deleteDepartment);

  const q = useQuery({ queryKey: ["departments"], queryFn: () => listFn() });
  const items = q.data?.items ?? [];

  const invalidate = () => qc.invalidateQueries({ queryKey: ["departments"] });

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  const create = useMutation({
    mutationFn: () =>
      createFn({
        data: {
          name: name.trim(),
          description: description.trim() || undefined,
          sort_order: items.length,
          is_active: true,
        },
      }),
    onSuccess: () => {
      invalidate();
      setName("");
      setDescription("");
      toast.success("Отдел создан");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const update = useMutation({
    mutationFn: (input: { id: string; patch: Record<string, unknown> }) =>
      updateFn({ data: { id: input.id, ...input.patch } }),
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      invalidate();
      toast.success("Отдел удалён");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="text-foreground">
      <div className="border-b border-border bg-card">
        <div className="max-w-[1200px] mx-auto px-6 py-3">
          <Link to="/settings/eqs-files" className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1">
            <ArrowLeft className="size-3" /> EQS Files
          </Link>
          <h1 className="text-base font-semibold tracking-tight mt-1">Отделы</h1>
        </div>
      </div>

      <main className="max-w-[1200px] mx-auto px-6 py-6 space-y-6">
        <div className="bg-card border border-border rounded-md p-4">
          <h2 className="text-sm font-semibold mb-3">Добавить отдел</h2>
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1 min-w-[220px] flex-1">
              <Label htmlFor="dep-name" className="text-xs">Название</Label>
              <Input
                id="dep-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Логистика"
              />
            </div>
            <div className="space-y-1 min-w-[260px] flex-[2]">
              <Label htmlFor="dep-desc" className="text-xs">Описание</Label>
              <Input
                id="dep-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Необязательно"
              />
            </div>
            <Button
              onClick={() => {
                if (!name.trim()) {
                  toast.error("Введите название");
                  return;
                }
                create.mutate();
              }}
              disabled={create.isPending}
            >
              Добавить
            </Button>
          </div>
        </div>

        <div className="bg-card border border-border rounded-md overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Название</TableHead>
                <TableHead>Описание</TableHead>
                <TableHead className="w-[100px]">Порядок</TableHead>
                <TableHead className="w-[100px]">Активен</TableHead>
                <TableHead className="w-[60px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((d) => (
                <TableRow key={d.id}>
                  <TableCell>
                    <Input
                      defaultValue={d.name}
                      className="h-8"
                      onBlur={(e) => {
                        if (e.target.value && e.target.value !== d.name) {
                          update.mutate({ id: d.id, patch: { name: e.target.value } });
                        }
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      defaultValue={d.description ?? ""}
                      className="h-8"
                      onBlur={(e) => {
                        if ((e.target.value || null) !== d.description) {
                          update.mutate({
                            id: d.id,
                            patch: { description: e.target.value || null },
                          });
                        }
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      defaultValue={d.sort_order}
                      className="h-8 w-[80px]"
                      onBlur={(e) => {
                        const v = parseInt(e.target.value, 10);
                        if (!Number.isNaN(v) && v !== d.sort_order) {
                          update.mutate({ id: d.id, patch: { sort_order: v } });
                        }
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={d.is_active}
                      onCheckedChange={(v) =>
                        update.mutate({ id: d.id, patch: { is_active: v } })
                      }
                    />
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        if (confirm(`Удалить отдел "${d.name}"? Пользователи останутся без отдела.`)) {
                          del.mutate(d.id);
                        }
                      }}
                      className="text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-sm text-muted-foreground py-6">
                    Отделы не созданы.
                  </TableCell>
                </TableRow>
              ) : null}
            </TableBody>
          </Table>
        </div>
      </main>
    </div>
  );
}
