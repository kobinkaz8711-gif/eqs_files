import { createFileRoute, Link } from "@tanstack/react-router";
import { Users, ShieldCheck, KeyRound, Settings2, Boxes, Receipt, FileText, ToggleLeft } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/_authenticated/settings/")({
  head: () => ({ meta: [{ title: "Настройки — Logis" }] }),
  component: SettingsHub,
});

function SettingsHub() {
  const { hasPermission, hasAnyPermission } = useAuth();

  const cards = [
    {
      to: "/settings/users",
      title: "Пользователи",
      desc: "Управление сотрудниками: приглашения, роли, статус.",
      icon: Users,
      show: hasPermission("users.manage"),
    },
    {
      to: "/settings/roles",
      title: "Роли и права",
      desc: "Настройка ролей и матрица прав доступа.",
      icon: ShieldCheck,
      show: hasPermission("roles.manage"),
    },
    {
      to: "/settings/permissions",
      title: "Список прав",
      desc: "Справочник всех системных прав доступа.",
      icon: KeyRound,
      show: hasAnyPermission(["roles.manage", "users.manage"]),
    },
    {
      to: "/settings/modules",
      title: "Модули и доступы",
      desc: "Регистр модулей системы и список отделов с доступом к каждому.",
      icon: Boxes,
      show: hasPermission("modules.manage"),
    },
    {
      to: "/settings/functional-modules",
      title: "Функциональные модули",
      desc: "Включение и выключение опциональной функциональности.",
      icon: ToggleLeft,
      show: hasPermission("modules.manage"),
    },
    {
      to: "/settings/module",
      title: "Настройки модуля",
      desc: "Типы перевозок, чек-листы, шаблоны писем менеджеру.",
      icon: Settings2,
      show: hasPermission("checklist.manage"),
    },
    {
      to: "/settings/invoice-generator",
      title: "Invoice Generator",
      desc: "Реквизиты компании, плательщика, VAT и параметры PDF-документов.",
      icon: Receipt,
      show: true,
    },
    {
      to: "/settings/eqs-files",
      title: "EQS Files",
      desc: "Справочники бюджета: статьи, маппинг расходов, RT billing, customers, отчётный период.",
      icon: FileText,
      show: hasPermission("admin.full"),
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 lg:py-14">
      <header className="mb-10">
        <p className="text-xs font-semibold uppercase tracking-widest text-primary mb-3">
          Конфигурация
        </p>
        <h1 className="text-4xl lg:text-5xl font-semibold tracking-tight leading-[1.05] mb-3">
          Настройки
        </h1>
        <p className="text-lg text-muted-foreground max-w-[58ch]">
          Управление пользователями, ролями и параметрами сервиса.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {cards
          .filter((c) => c.show)
          .map((c) => (
            <Link
              key={c.to}
              to={c.to}
              className="group p-7 bg-card rounded-2xl border border-border shadow-sm hover:border-primary/40 hover:shadow-md transition-all"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                  <c.icon className="size-5" />
                </div>
                <h2 className="text-lg font-semibold tracking-tight">{c.title}</h2>
              </div>
              <p className="text-sm text-muted-foreground">{c.desc}</p>
            </Link>
          ))}
      </div>
    </div>
  );
}
