import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  listFeatureFlags,
  setFeatureFlag,
  FEATURE_FLAGS,
} from "@/lib/featureFlags.functions";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/settings/functional-modules")({
  head: () => ({ meta: [{ title: "Функциональные модули — Logis" }] }),
  component: FunctionalModulesPage,
});

function FunctionalModulesPage() {
  const fetchFlags = useServerFn(listFeatureFlags);
  const saveFlag = useServerFn(setFeatureFlag);
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["feature-flags"],
    queryFn: () => fetchFlags(),
  });

  const mut = useMutation({
    mutationFn: (vars: { code: string; enabled: boolean }) =>
      saveFlag({ data: vars }),
    onSuccess: () => {
      toast.success("Saved");
      qc.invalidateQueries({ queryKey: ["feature-flags"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const flagMap = new Map((data?.items ?? []).map((f) => [f.code, f.enabled]));

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <header className="mb-8">
        <h1 className="text-3xl font-semibold tracking-tight mb-2">
          Функциональные модули
        </h1>
        <p className="text-sm text-muted-foreground">
          Включение/выключение опциональной функциональности приложения.
        </p>
      </header>

      <Card className="divide-y">
        {FEATURE_FLAGS.map((f) => {
          const enabled = flagMap.get(f.code) ?? false;
          return (
            <div
              key={f.code}
              className="flex items-start gap-4 p-4"
            >
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm">{f.label}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  {f.description}
                </div>
                <div className="text-[10px] font-mono text-muted-foreground mt-1">
                  {f.code}
                </div>
              </div>
              <Switch
                checked={enabled}
                disabled={isLoading || mut.isPending}
                onCheckedChange={(v) =>
                  mut.mutate({ code: f.code, enabled: !!v })
                }
              />
            </div>
          );
        })}
      </Card>
    </div>
  );
}
