import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  listEqsEquipmentTypeMap,
  upsertEqsEquipmentType,
  deleteEqsEquipmentType,
} from "@/lib/eqs-booking.functions";

export const Route = createFileRoute("/_authenticated/settings/eqs-files/equipment-types")({
  head: () => ({ meta: [{ title: "EQS Equipment Types" }] }),
  component: EquipmentTypesPage,
});

function EquipmentTypesPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listEqsEquipmentTypeMap);
  const upsertFn = useServerFn(upsertEqsEquipmentType);
  const deleteFn = useServerFn(deleteEqsEquipmentType);

  const q = useQuery({ queryKey: ["eqs-equipment-types"], queryFn: () => listFn() });
  const [newIso, setNewIso] = useState("");
  const [newLabel, setNewLabel] = useState("");

  const addMut = useMutation({
    mutationFn: () => upsertFn({ data: { iso_code: newIso, label: newLabel } }),
    onSuccess: () => {
      toast.success("Saved");
      setNewIso("");
      setNewLabel("");
      qc.invalidateQueries({ queryKey: ["eqs-equipment-types"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Error"),
  });
  const delMut = useMutation({
    mutationFn: (iso: string) => deleteFn({ data: { iso_code: iso } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["eqs-equipment-types"] }),
  });

  return (
    <div className="max-w-3xl mx-auto px-6 py-8">
      <Button variant="ghost" size="sm" asChild className="mb-4">
        <Link to="/settings/eqs-files">
          <ArrowLeft className="size-4 mr-1" /> EQS Files Settings
        </Link>
      </Button>
      <h1 className="text-2xl font-semibold mb-1">EQS Equipment Types</h1>
      <p className="text-sm text-muted-foreground mb-6">
        Маппинг ISO-кодов на текстовые метки equipment_type, ожидаемые EQS.
      </p>

      <div className="flex gap-2 mb-4">
        <Input
          placeholder="ISO (e.g. 22G1)"
          value={newIso}
          onChange={(e) => setNewIso(e.target.value)}
          className="max-w-[160px]"
        />
        <Input
          placeholder="EQS label"
          value={newLabel}
          onChange={(e) => setNewLabel(e.target.value)}
        />
        <Button
          onClick={() => addMut.mutate()}
          disabled={!newIso || !newLabel || addMut.isPending}
        >
          <Plus className="size-4 mr-1" /> Add / Update
        </Button>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/30">
            <tr>
              <th className="text-left p-2 w-[180px]">ISO Code</th>
              <th className="text-left p-2">EQS Label</th>
              <th className="w-12"></th>
            </tr>
          </thead>
          <tbody>
            {(q.data?.items ?? []).map((row) => (
              <tr key={row.iso_code} className="border-t">
                <td className="p-2 font-mono">{row.iso_code}</td>
                <td className="p-2">{row.label}</td>
                <td className="p-2 text-right">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => delMut.mutate(row.iso_code)}
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </td>
              </tr>
            ))}
            {q.data?.items.length === 0 && (
              <tr>
                <td colSpan={3} className="p-6 text-center text-muted-foreground">
                  Справочник пуст
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
