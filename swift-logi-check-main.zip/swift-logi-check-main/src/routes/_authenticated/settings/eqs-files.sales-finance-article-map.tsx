import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import {
  listSalesFinanceArticleMap,
  upsertSalesFinanceArticleMap,
  deleteSalesFinanceArticleMap,
  listBudgetArticlesByScope,
} from "@/lib/files.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

export const Route = createFileRoute(
  "/_authenticated/settings/eqs-files/sales-finance-article-map",
)({
  head: () => ({ meta: [{ title: "Sales ↔ Finance Article Map" }] }),
  component: Page,
});

function Page() {
  const qc = useQueryClient();
  const list = useServerFn(listSalesFinanceArticleMap);
  const listArticles = useServerFn(listBudgetArticlesByScope);
  const upsert = useServerFn(upsertSalesFinanceArticleMap);
  const del = useServerFn(deleteSalesFinanceArticleMap);

  const mapQ = useQuery({ queryKey: ["sf-map"], queryFn: () => list() });
  const artQ = useQuery({ queryKey: ["budget-articles-all"], queryFn: () => listArticles() });

  const [search, setSearch] = useState("");
  const [newSales, setNewSales] = useState<string>("");
  const [newFinance, setNewFinance] = useState<string>("");

  const upsertMut = useMutation({
    mutationFn: (v: { sales_article_id: string; finance_article_id: string }) =>
      upsert({ data: v }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["sf-map"] });
      setNewSales("");
      setNewFinance("");
      toast.success("Saved");
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });
  const delMut = useMutation({
    mutationFn: (sales_article_id: string) => del({ data: { sales_article_id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["sf-map"] }),
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const rows = (mapQ.data?.rows ?? []) as any[];
  const allArticles = (artQ.data?.rows ?? []) as any[];
  const salesArticles = useMemo(
    () => allArticles.filter((a) => (a.scope ?? "SALES") === "SALES"),
    [allArticles],
  );
  const financeArticles = useMemo(
    () => allArticles.filter((a) => a.scope === "FINANCE"),
    [allArticles],
  );

  const mappedSales = useMemo(() => new Set(rows.map((r) => r.sales_article_id)), [rows]);
  const unmappedSales = useMemo(
    () => salesArticles.filter((a) => !mappedSales.has(a.id)),
    [salesArticles, mappedSales],
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter(
      (r) =>
        (r.sales?.name ?? "").toLowerCase().includes(q) ||
        (r.sales?.code ?? "").toLowerCase().includes(q) ||
        (r.finance?.name ?? "").toLowerCase().includes(q) ||
        (r.finance?.code ?? "").toLowerCase().includes(q),
    );
  }, [rows, search]);

  return (
    <div className="max-w-5xl mx-auto px-6 py-8">
      <Button variant="ghost" size="sm" asChild className="mb-3">
        <Link to="/settings/eqs-files">
          <ArrowLeft className="size-4 mr-1" /> EQS Files Settings
        </Link>
      </Button>
      <h1 className="text-2xl font-semibold tracking-tight mb-1">
        Sales ↔ Finance Article Map
      </h1>
      <p className="text-sm text-muted-foreground mb-5">
        Соответствие статей продаж и финансовых статей. Несколько sales-статей могут
        соответствовать одной finance-статье. Используется в отчёте Financial result adjustment
        для plan-стороны и факта без charge type.
      </p>

      <div className="mb-5 p-4 rounded-xl border border-border bg-card">
        <div className="flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-[220px]">
            <label className="text-xs text-muted-foreground">Sales article</label>
            <Select value={newSales} onValueChange={setNewSales}>
              <SelectTrigger>
                <SelectValue placeholder="Select sales article…" />
              </SelectTrigger>
              <SelectContent>
                {unmappedSales.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.code} — {a.name}
                  </SelectItem>
                ))}
                {unmappedSales.length === 0 && (
                  <div className="p-2 text-xs text-muted-foreground">
                    All sales articles are mapped
                  </div>
                )}
              </SelectContent>
            </Select>
          </div>
          <div className="flex-1 min-w-[220px]">
            <label className="text-xs text-muted-foreground">Finance article</label>
            <Select value={newFinance} onValueChange={setNewFinance}>
              <SelectTrigger>
                <SelectValue placeholder="Select finance article…" />
              </SelectTrigger>
              <SelectContent>
                {financeArticles.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.code} — {a.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button
            disabled={!newSales || !newFinance || upsertMut.isPending}
            onClick={() =>
              upsertMut.mutate({ sales_article_id: newSales, finance_article_id: newFinance })
            }
          >
            <Plus className="size-4 mr-1" /> Add
          </Button>
        </div>
      </div>

      <div className="mb-3">
        <Input
          placeholder="Search by name / code"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
        />
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs text-muted-foreground">
            <tr>
              <th className="text-left font-medium px-3 py-2">Sales article</th>
              <th className="text-left font-medium px-3 py-2">Finance article</th>
              <th className="px-3 py-2 w-[100px]"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.sales_article_id} className="border-t border-border">
                <td className="px-3 py-2">
                  <div className="font-medium">{r.sales?.name ?? "—"}</div>
                  <div className="text-xs text-muted-foreground">
                    {r.sales?.code ?? ""}
                    {r.sales?.kind && (
                      <Badge variant="outline" className="ml-2 text-[10px]">
                        {r.sales.kind}
                      </Badge>
                    )}
                  </div>
                </td>
                <td className="px-3 py-2">
                  <Select
                    value={r.finance_article_id}
                    onValueChange={(v) =>
                      upsertMut.mutate({ sales_article_id: r.sales_article_id, finance_article_id: v })
                    }
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {financeArticles.map((a) => (
                        <SelectItem key={a.id} value={a.id}>
                          {a.code} — {a.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </td>
                <td className="px-3 py-2 text-right">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => delMut.mutate(r.sales_article_id)}
                  >
                    <Trash2 className="size-4 text-destructive" />
                  </Button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={3} className="p-6 text-center text-muted-foreground text-sm">
                  No mappings.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
