import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Trash2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  createRole,
  deleteRole,
  listPermissions,
  listRoles,
  setRolePermissions,
} from "@/lib/roles.functions";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/_authenticated/settings/roles")({
  head: () => ({ meta: [{ title: "Роли и права — Logis" }] }),
  component: RolesPage,
});

function groupCode(code: string): string {
  return code.split(".")[0] ?? code;
}

const GROUP_LABEL: Record<string, string> = {
  checklist: "Чек-листы",
  users: "Пользователи",
  roles: "Роли",
  settings: "Настройки",
  admin: "Администрирование",
};

function RolesPage() {
  const { hasPermission } = useAuth();
  const canManage = hasPermission("roles.manage");
  const qc = useQueryClient();

  const rolesFn = useServerFn(listRoles);
  const permsFn = useServerFn(listPermissions);
  const setPermsFn = useServerFn(setRolePermissions);
  const createFn = useServerFn(createRole);
  const deleteFn = useServerFn(deleteRole);

  const rolesQ = useQuery({ queryKey: ["roles"], queryFn: () => rolesFn() });
  const permsQ = useQuery({ queryKey: ["permissions"], queryFn: () => permsFn() });

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [draft, setDraft] = useState<string[]>([]);
  const [createOpen, setCreateOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");

  useEffect(() => {
    if (rolesQ.data && !selectedId) {
      setSelectedId(rolesQ.data.items[0]?.id ?? null);
    }
  }, [rolesQ.data, selectedId]);

  const selected = rolesQ.data?.items.find((r) => r.id === selectedId) ?? null;

  useEffect(() => {
    if (selected) setDraft(selected.permission_ids);
  }, [selected]);

  const grouped = useMemo(() => {
    const items = permsQ.data?.items ?? [];
    const map = new Map<string, typeof items>();
    for (const p of items) {
      const g = groupCode(p.code);
      if (!map.has(g)) map.set(g, []);
      map.get(g)!.push(p);
    }
    return Array.from(map.entries());
  }, [permsQ.data]);

  const save = useMutation({
    mutationFn: () =>
      setPermsFn({ data: { role_id: selected!.id, permission_ids: draft } }),
    onSuccess: () => {
      toast.success("Права роли сохранены");
      qc.invalidateQueries({ queryKey: ["roles"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const create = useMutation({
    mutationFn: () =>
      createFn({ data: { name: newName.trim(), description: newDesc || undefined } }),
    onSuccess: () => {
      toast.success("Роль создана");
      setCreateOpen(false);
      setNewName("");
      setNewDesc("");
      qc.invalidateQueries({ queryKey: ["roles"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Роль удалена");
      setSelectedId(null);
      qc.invalidateQueries({ queryKey: ["roles"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const dirty =
    !!selected &&
    (draft.length !== selected.permission_ids.length ||
      draft.some((id) => !selected.permission_ids.includes(id)));

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 lg:py-14">
      <header className="mb-8 flex items-end justify-between gap-6 flex-wrap">
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-primary mb-3">
            Доступы
          </p>
          <h1 className="text-4xl font-semibold tracking-tight">Роли и права</h1>
          <p className="text-muted-foreground mt-2 max-w-[58ch]">
            Назначайте права отдельным ролям. Системные роли защищены от удаления.
          </p>
        </div>
        {canManage ? (
          <Button onClick={() => setCreateOpen(true)}>
            Новая роль
          </Button>
        ) : null}
      </header>

      <div className="grid grid-cols-12 gap-6">
        {/* Roles list */}
        <div className="col-span-12 md:col-span-4">
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <ul className="divide-y divide-border">
              {rolesQ.data?.items.map((r) => (
                <li key={r.id}>
                  <button
                    onClick={() => setSelectedId(r.id)}
                    className={`w-full text-left px-4 py-3 hover:bg-accent/40 transition-colors flex items-center justify-between gap-2 ${
                      selectedId === r.id ? "bg-accent/60" : ""
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="font-medium truncate">{r.name}</p>
                      {r.description ? (
                        <p className="text-xs text-muted-foreground truncate">
                          {r.description}
                        </p>
                      ) : null}
                    </div>
                    {r.is_system ? (
                      <Badge variant="secondary" className="shrink-0">
                        Системная
                      </Badge>
                    ) : null}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Permissions matrix */}
        <div className="col-span-12 md:col-span-8">
          {selected ? (
            <div className="bg-card border border-border rounded-2xl p-6">
              <div className="flex items-center justify-between mb-5 gap-3 flex-wrap">
                <div>
                  <h2 className="text-lg font-semibold tracking-tight">{selected.name}</h2>
                  <p className="text-sm text-muted-foreground">
                    {selected.description || "Без описания"}
                  </p>
                </div>
                <div className="flex gap-2">
                  {canManage && !selected.is_system ? (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (confirm(`Удалить роль «${selected.name}»?`)) {
                          remove.mutate(selected.id);
                        }
                      }}
                    >
                      Удалить
                    </Button>
                  ) : null}
                  {canManage ? (
                    <Button
                      size="sm"
                      onClick={() => save.mutate()}
                      disabled={!dirty || save.isPending}
                    >
                      {save.isPending ? (
                        <Loader2 className="size-4 animate-spin" />
                      ) : (
                        "Сохранить"
                      )}
                    </Button>
                  ) : null}
                </div>
              </div>

              <div className="space-y-5">
                {grouped.map(([group, items]) => (
                  <div key={group}>
                    <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">
                      {GROUP_LABEL[group] ?? group}
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {items.map((p) => {
                        const checked = draft.includes(p.id);
                        return (
                          <label
                            key={p.id}
                            className={`flex items-start gap-3 p-3 rounded-lg border border-border cursor-pointer hover:border-primary/40 transition-colors ${
                              checked ? "bg-primary/5 border-primary/30" : ""
                            }`}
                          >
                            <Checkbox
                              checked={checked}
                              disabled={!canManage}
                              onCheckedChange={(v) =>
                                setDraft((prev) =>
                                  v ? [...prev, p.id] : prev.filter((id) => id !== p.id),
                                )
                              }
                            />
                            <div className="min-w-0">
                              <p className="text-sm font-medium font-mono">{p.code}</p>
                              {p.description ? (
                                <p className="text-xs text-muted-foreground">
                                  {p.description}
                                </p>
                              ) : null}
                            </div>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-card border border-dashed border-border rounded-2xl p-10 text-center text-muted-foreground">
              Выберите роль для редактирования
            </div>
          )}
        </div>
      </div>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Новая роль</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Название</Label>
              <Input value={newName} onChange={(e) => setNewName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Описание</Label>
              <Input value={newDesc} onChange={(e) => setNewDesc(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              Отмена
            </Button>
            <Button onClick={() => create.mutate()} disabled={!newName || create.isPending}>
              {create.isPending ? <Loader2 className="size-4 animate-spin" /> : "Создать"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
