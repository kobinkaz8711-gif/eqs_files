import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { ArrowLeft, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAuth } from "@/hooks/useAuth";
import {
  listModules,
  createModule,
  updateModule,
  deleteModule,
  setModuleDepartments,
  type ModuleDTO,
} from "@/lib/modules.functions";
import { listDepartments } from "@/lib/departments.functions";

export const Route = createFileRoute("/_authenticated/settings/modules")({
  head: () => ({ meta: [{ title: "Модули и доступы — Logis" }] }),
  component: ModulesPage,
});

function ModulesPage() {
  const { hasPermission, me } = useAuth();
  if (me && !hasPermission("modules.manage")) {
    throw redirect({ to: "/forbidden" });
  }

  const qc = useQueryClient();
  const listFn = useServerFn(listModules);
  const createFn = useServerFn(createModule);
  const updateFn = useServerFn(updateModule);
  const deleteFn = useServerFn(deleteModule);
  const setDeptFn = useServerFn(setModuleDepartments);
  const depFn = useServerFn(listDepartments);

  const modQ = useQuery({ queryKey: ["modules"], queryFn: () => listFn() });
  const depQ = useQuery({ queryKey: ["departments"], queryFn: () => depFn() });
  const items = modQ.data?.items ?? [];
  const departments = depQ.data?.items ?? [];

  const invalidate = () => qc.invalidateQueries({ queryKey: ["modules"] });

  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [route, setRoute] = useState("");

  const create = useMutation({
    mutationFn: () =>
      createFn({
        data: {
          code: code.trim().toLowerCase(),
          name: name.trim(),
          route: route.trim() || undefined,
          is_active: true,
          sort_order: items.length,
        },
      }),
    onSuccess: () => {
      invalidate();
      setCode("");
      setName("");
      setRoute("");
      toast.success("Модуль создан");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const update = useMutation({
    mutationFn: (input: { id: string; patch: Record<string, unknown> }) =>
      updateFn({ data: { id: input.id, ...input.patch } }),
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      invalidate();
      toast.success("Модуль удалён");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setDept = useMutation({
    mutationFn: (input: { module_id: string; department_ids: string[] }) =>
      setDeptFn({ data: input }),
    onSuccess: () => {
      invalidate();
      toast.success("Доступы обновлены");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="text-foreground">
      <div className="border-b border-border bg-card">
        <div className="max-w-[1200px] mx-auto px-6 py-3">
          <Link to="/settings" className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1">
            <ArrowLeft className="size-3" /> Настройки
          </Link>
          <h1 className="text-base font-semibold tracking-tight mt-1">Модули и доступы</h1>
          <p className="text-xs text-muted-foreground mt-1">
            Если у модуля не выбран ни один отдел — модуль доступен всем.
          </p>
        </div>
      </div>

      <main className="max-w-[1200px] mx-auto px-6 py-6 space-y-6">
        <div className="bg-card border border-border rounded-md p-4">
          <h2 className="text-sm font-semibold mb-3">Добавить модуль</h2>
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1 w-[180px]">
              <Label htmlFor="mod-code" className="text-xs">Код (a-z, 0-9, _, -)</Label>
              <Input
                id="mod-code"
                value={code}
                onChange={(e) => setCode(e.target.value.toLowerCase())}
                placeholder="reports"
                className="font-mono"
              />
            </div>
            <div className="space-y-1 min-w-[200px] flex-1">
              <Label htmlFor="mod-name" className="text-xs">Название</Label>
              <Input
                id="mod-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Отчёты"
              />
            </div>
            <div className="space-y-1 min-w-[180px] flex-1">
              <Label htmlFor="mod-route" className="text-xs">Маршрут</Label>
              <Input
                id="mod-route"
                value={route}
                onChange={(e) => setRoute(e.target.value)}
                placeholder="/reports"
                className="font-mono"
              />
            </div>
            <Button
              onClick={() => {
                if (!code.trim() || !name.trim()) {
                  toast.error("Заполните код и название");
                  return;
                }
                create.mutate();
              }}
              disabled={create.isPending}
            >
              Добавить
            </Button>
          </div>
        </div>

        <div className="bg-card border border-border rounded-md overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[140px]">Код</TableHead>
                <TableHead>Название</TableHead>
                <TableHead>Маршрут</TableHead>
                <TableHead>Доступ для отделов</TableHead>
                <TableHead className="w-[100px]">Активен</TableHead>
                <TableHead className="w-[60px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((m) => (
                <ModuleRow
                  key={m.id}
                  module={m}
                  departments={departments}
                  onUpdatePatch={(patch) => update.mutate({ id: m.id, patch })}
                  onSetDepts={(ids) => setDept.mutate({ module_id: m.id, department_ids: ids })}
                  onDelete={() => {
                    if (confirm(`Удалить модуль "${m.name}"?`)) del.mutate(m.id);
                  }}
                />
              ))}
              {items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-sm text-muted-foreground py-6">
                    Модули не созданы.
                  </TableCell>
                </TableRow>
              ) : null}
            </TableBody>
          </Table>
        </div>
      </main>
    </div>
  );
}

function ModuleRow({
  module,
  departments,
  onUpdatePatch,
  onSetDepts,
  onDelete,
}: {
  module: ModuleDTO;
  departments: { id: string; name: string; is_active: boolean }[];
  onUpdatePatch: (patch: Record<string, unknown>) => void;
  onSetDepts: (ids: string[]) => void;
  onDelete: () => void;
}) {
  const [open, setOpen] = useState(false);
  const selectedIds = new Set(module.department_ids);

  const toggle = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    onSetDepts(Array.from(next));
  };

  const selectedLabels = departments
    .filter((d) => selectedIds.has(d.id))
    .map((d) => d.name);

  return (
    <TableRow>
      <TableCell className="font-mono text-xs">{module.code}</TableCell>
      <TableCell>
        <Input
          defaultValue={module.name}
          className="h-8"
          onBlur={(e) => {
            if (e.target.value && e.target.value !== module.name) {
              onUpdatePatch({ name: e.target.value });
            }
          }}
        />
      </TableCell>
      <TableCell>
        <Input
          defaultValue={module.route ?? ""}
          className="h-8 font-mono text-xs"
          placeholder="/path"
          onBlur={(e) => {
            const next = e.target.value || null;
            if (next !== module.route) onUpdatePatch({ route: next });
          }}
        />
      </TableCell>
      <TableCell>
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 justify-start max-w-[280px] w-full font-normal">
              {selectedLabels.length === 0 ? (
                <span className="text-muted-foreground">Все отделы (без ограничений)</span>
              ) : (
                <span className="truncate">{selectedLabels.join(", ")}</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[280px] p-2" align="start">
            <div className="max-h-[260px] overflow-y-auto space-y-1">
              {departments.length === 0 ? (
                <p className="text-xs text-muted-foreground p-2">Сначала создайте отделы.</p>
              ) : (
                departments.map((d) => (
                  <label
                    key={d.id}
                    className="flex items-center gap-2 text-sm cursor-pointer hover:bg-accent rounded px-2 py-1.5"
                  >
                    <Checkbox
                      checked={selectedIds.has(d.id)}
                      onCheckedChange={() => toggle(d.id)}
                    />
                    <span className="flex-1">{d.name}</span>
                    {!d.is_active ? (
                      <Badge variant="secondary" className="text-[10px]">off</Badge>
                    ) : null}
                  </label>
                ))
              )}
            </div>
            {selectedIds.size > 0 ? (
              <Button
                variant="ghost"
                size="sm"
                className="w-full mt-1 h-7 text-xs"
                onClick={() => onSetDepts([])}
              >
                Очистить (доступ всем)
              </Button>
            ) : null}
          </PopoverContent>
        </Popover>
      </TableCell>
      <TableCell>
        <Switch
          checked={module.is_active}
          onCheckedChange={(v) => onUpdatePatch({ is_active: v })}
        />
      </TableCell>
      <TableCell>
        <Button
          variant="ghost"
          size="icon"
          onClick={onDelete}
          className="text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="size-4" />
        </Button>
      </TableCell>
    </TableRow>
  );
}
