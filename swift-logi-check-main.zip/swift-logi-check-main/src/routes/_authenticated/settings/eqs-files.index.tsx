import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, BookOpen, GitBranch, Receipt, Users, Calendar, Building2, UserSquare2, Cable, Container, Award } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/settings/eqs-files/")({
  head: () => ({ meta: [{ title: "EQS Files Settings" }] }),
  component: EqsSettingsHub,
});

type Card = {
  to: string;
  title: string;
  desc: string;
  icon: typeof BookOpen;
  soon?: boolean;
};

const cards: Card[] = [
  {
    to: "/settings/eqs-files/departments",
    title: "Отделы",
    desc: "Справочник отделов EQS Files. Код отдела используется в префиксе номера файла.",
    icon: Building2,
  },
  {
    to: "/settings/eqs-files/sales-persons",
    title: "Sales Persons",
    desc: "Справочник менеджеров продаж, привязанных к отделам.",
    icon: UserSquare2,
  },
  {
    to: "/settings/eqs-files/budget-articles",
    title: "Sales Budget Articles",
    desc: "Справочник статей бюджета продаж (REVENUE/COST), используется в плане и факте.",
    icon: BookOpen,
  },
  {
    to: "/settings/eqs-files/finance-budget-articles",
    title: "Finance Budget Articles",
    desc: "Справочник статей финансового бюджета.",
    icon: BookOpen,
  },
  {
    to: "/settings/eqs-files/mapping",
    title: "Cost/Charge → Article Mapping",
    desc: "Привязка типов расходов и сборов EQS к статьям бюджета (Sales и Finance).",
    icon: GitBranch,
  },
  {
    to: "/settings/eqs-files/sales-finance-article-map",
    title: "Sales ↔ Finance Article Map",
    desc: "Соответствие sales-статей бюджета и finance-статей (many-to-one). Используется в отчёте Financial result adjustment.",
    icon: GitBranch,
  },


  {
    to: "/settings/eqs-files/rt-billing",
    title: "RT Billing Rules",
    desc: "Правила расчёта ожидаемой выручки RT-billing.",
    icon: Receipt,
    soon: true,
  },
  {
    to: "/settings/eqs-files/customers",
    title: "Customers",
    desc: "Справочник клиентов EQS.",
    icon: Users,
    soon: true,
  },
  {
    to: "/settings/eqs-files/reporting-period",
    title: "Reporting Period Control",
    desc: "Управление отчётным периодом для блокировки изменений.",
    icon: Calendar,
    soon: true,
  },
  {
    to: "/settings/eqs-files/sftp",
    title: "EQS SFTP",
    desc: "Параметры подключения к SFTP-серверу EQS для обмена бронированиями.",
    icon: Cable,
  },
  {
    to: "/settings/eqs-files/equipment-types",
    title: "EQS Equipment Types",
    desc: "Маппинг ISO-кодов контейнеров на equipment_type, ожидаемый EQS.",
    icon: Container,
  },
  {
    to: "/settings/eqs-files/grades",
    title: "Equipment Grades",
    desc: "Справочник грейдов (состояния) контейнеров: CW, CIC, ASIS и т.д.",
    icon: Award,
  },
];

function EqsSettingsHub() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <Button variant="ghost" size="sm" asChild className="mb-4">
        <Link to="/settings">
          <ArrowLeft className="size-4 mr-1" /> Settings
        </Link>
      </Button>
      <h1 className="text-3xl font-semibold tracking-tight mb-2">EQS Files</h1>
      <p className="text-muted-foreground mb-8">
        Справочники и настройки модуля EQS Files.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {cards.map((c) => (
          <Link
            key={c.to}
            to={c.to as "/settings/eqs-files/budget-articles"}
            className="group p-6 bg-card rounded-2xl border border-border hover:border-primary/40 transition-all"
          >
            <div className="flex items-center gap-3 mb-2">
              <div className="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                <c.icon className="size-5" />
              </div>
              <h2 className="text-lg font-semibold tracking-tight">{c.title}</h2>
              {c.soon && (
                <span className="text-[10px] uppercase tracking-wide text-muted-foreground border border-border rounded px-1.5 py-0.5 ml-auto">
                  soon
                </span>
              )}
            </div>
            <p className="text-sm text-muted-foreground">{c.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
