import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listBudgetArticles,
  listMapping,
  upsertMapping,
  deleteMapping,
} from "@/lib/files.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/settings/eqs-files/mapping")({
  head: () => ({ meta: [{ title: "Cost/Charge → Article Mapping" }] }),
  component: MappingPage,
});

const NONE = "__none__";

function MappingPage() {
  const qc = useQueryClient();
  const list = useServerFn(listMapping);
  const listArticles = useServerFn(listBudgetArticles);
  const upsert = useServerFn(upsertMapping);
  const del = useServerFn(deleteMapping);

  const mapQ = useQuery({ queryKey: ["mapping"], queryFn: () => list() });
  const salesQ = useQuery({
    queryKey: ["budget-articles", "SALES"],
    queryFn: () => listArticles({ data: { scope: "SALES" } }),
  });
  const finQ = useQuery({
    queryKey: ["budget-articles", "FINANCE"],
    queryFn: () => listArticles({ data: { scope: "FINANCE" } }),
  });

  const [filter, setFilter] = useState("");
  const [draft, setDraft] = useState({
    source_type: "",
    source_code: "",
    article_id: "",
    finance_article_id: "" as string,
  });
  const [pending, setPending] = useState<
    Record<string, { article_id?: string; finance_article_id?: string }>
  >({});

  const upsertMut = useMutation({
    mutationFn: (vars: {
      id?: string;
      source_type: string;
      source_code: string;
      article_id: string;
      finance_article_id?: string | null;
    }) => upsert({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["mapping"] });
      setDraft({ source_type: "", source_code: "", article_id: "", finance_article_id: "" });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });
  const delMut = useMutation({
    mutationFn: (id: string) => del({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["mapping"] }),
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const items = (mapQ.data?.items ?? []) as any[];
  const unmapped = (mapQ.data?.unmapped ?? []) as { source_type: string; source_code: string }[];
  const salesArticles = (salesQ.data?.items ?? []) as any[];
  const financeArticles = (finQ.data?.items ?? []) as any[];

  // Finance article kind must match source_type:
  // CostType -> COST, ChargeType -> REVENUE
  const expectedFinanceKind = (sourceType: string | null | undefined) =>
    sourceType === "CostType" ? "COST" : sourceType === "ChargeType" ? "REVENUE" : null;
  const financeFor = (sourceType: string | null | undefined, currentId?: string | null) => {
    const need = expectedFinanceKind(sourceType);
    const base = need ? financeArticles.filter((a) => a.kind === need) : [];
    // Keep currently-saved value visible even if it no longer matches
    if (currentId && !base.some((a) => a.id === currentId)) {
      const cur = financeArticles.find((a) => a.id === currentId);
      if (cur) return [cur, ...base];
    }
    return base;
  };


  const f = filter.trim().toLowerCase();
  const filtered = f
    ? items.filter(
        (m) =>
          m.source_type?.toLowerCase().includes(f) ||
          m.source_code?.toLowerCase().includes(f) ||
          m.source_name?.toLowerCase().includes(f) ||
          m.budget_articles?.code?.toLowerCase().includes(f) ||
          m.finance_budget_articles?.code?.toLowerCase().includes(f),
      )
    : items;

  const CodeCell = ({ code, name }: { code: string; name?: string }) =>
    name ? (
      <Tooltip>
        <TooltipTrigger asChild>
          <span className="font-mono text-xs cursor-help underline decoration-dotted decoration-muted-foreground/50 underline-offset-2">
            {code}
          </span>
        </TooltipTrigger>
        <TooltipContent>{name}</TooltipContent>
      </Tooltip>
    ) : (
      <span className="font-mono text-xs">{code}</span>
    );

  const UsageCell = ({ n }: { n: number }) => (
    <span
      className={
        "tabular-nums " + (n > 0 ? "text-foreground" : "text-muted-foreground/50")
      }
    >
      {n}
    </span>
  );

  return (
    <TooltipProvider delayDuration={150}>
    <div className="max-w-6xl mx-auto px-6 py-10">
      <Button variant="ghost" size="sm" asChild className="mb-4">
        <Link to="/settings/eqs-files">
          <ArrowLeft className="size-4 mr-1" /> EQS Files
        </Link>
      </Button>
      <h1 className="text-2xl font-semibold tracking-tight mb-1">
        Cost / Charge → Article Mapping
      </h1>
      <p className="text-muted-foreground text-sm mb-6">
        Привязка типов расходов и сборов EQS к статьям Sales- и (опционально) Finance-бюджета.
      </p>

      {unmapped.length > 0 && (
        <div className="rounded-xl border border-amber-500/40 bg-amber-500/5 mb-6 overflow-hidden">
          <div className="px-4 py-3 border-b border-amber-500/30 text-sm font-medium">
            {unmapped.length} unmapped charge type(s) found in EQS finance lines
          </div>
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr>
                <th className="text-left p-2 font-medium w-28">Source</th>
                <th className="text-left p-2 font-medium w-28">Code</th>
                <th className="text-right p-2 font-medium w-16">Usage</th>
                <th className="text-left p-2 font-medium">Sales Article</th>
                <th className="text-left p-2 font-medium">Finance Article</th>
                <th className="w-28"></th>
              </tr>
            </thead>
            <tbody>
              {unmapped.slice(0, 30).map((u) => {
                const key = `${u.source_type}::${u.source_code}`;
                const p = pending[key] ?? {};
                return (
                  <tr key={key} className="border-t border-border">
                    <td className="p-2 font-mono text-xs">{u.source_type}</td>
                    <td className="p-2"><CodeCell code={u.source_code} name={(u as any).source_name} /></td>
                    <td className="p-2 text-right"><UsageCell n={(u as any).usage_count ?? 0} /></td>
                    <td className="p-2">
                      <Select
                        value={p.article_id ?? ""}
                        onValueChange={(v) =>
                          setPending({ ...pending, [key]: { ...p, article_id: v } })
                        }
                      >
                        <SelectTrigger className="h-8">
                          <SelectValue placeholder="Sales article…" />
                        </SelectTrigger>
                        <SelectContent>
                          {salesArticles.map((a) => (
                            <SelectItem key={a.id} value={a.id}>
                              [{a.kind}] {a.code} — {a.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="p-2">
                      <Select
                        value={p.finance_article_id ?? NONE}
                        onValueChange={(v) =>
                          setPending({
                            ...pending,
                            [key]: { ...p, finance_article_id: v === NONE ? undefined : v },
                          })
                        }
                      >
                        <SelectTrigger className="h-8">
                          <SelectValue placeholder="Finance article…" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={NONE}>— None —</SelectItem>
                          {financeFor(u.source_type, p.finance_article_id).map((a) => (
                            <SelectItem key={a.id} value={a.id}>
                              [{a.kind}] {a.code} — {a.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="p-2 text-right">
                      <Button
                        size="sm"
                        disabled={!p.article_id || upsertMut.isPending}
                        onClick={() =>
                          upsertMut.mutate({
                            source_type: u.source_type,
                            source_code: u.source_code,
                            article_id: p.article_id!,
                            finance_article_id: p.finance_article_id ?? null,
                          })
                        }
                      >
                        Map
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <div className="mb-3">
        <Input
          placeholder="Filter…"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40">
            <tr>
              <th className="text-left p-3 font-medium w-28">Source</th>
              <th className="text-left p-3 font-medium w-32">Code</th>
              <th className="text-right p-3 font-medium w-20">Usage</th>
              <th className="text-left p-3 font-medium">Sales Article</th>
              <th className="text-left p-3 font-medium">Finance Article</th>
              <th className="w-12"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((m) => (
              <tr key={m.id} className="border-t border-border">
                <td className="p-3 font-mono text-xs">{m.source_type}</td>
                <td className="p-3"><CodeCell code={m.source_code} name={m.source_name} /></td>
                <td className="p-3 text-right"><UsageCell n={m.usage_count ?? 0} /></td>
                <td className="p-3">
                  <div className="flex items-center gap-2">
                    <Select
                      value={m.article_id}
                      onValueChange={(v) =>
                        upsertMut.mutate({
                          id: m.id,
                          source_type: m.source_type,
                          source_code: m.source_code,
                          article_id: v,
                        })
                      }
                    >
                      <SelectTrigger className="h-8 max-w-md">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {salesArticles.map((a) => (
                          <SelectItem key={a.id} value={a.id}>
                            [{a.kind}] {a.code} — {a.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {m.budget_articles?.kind && (
                      <Badge variant="outline" className="text-[10px]">
                        {m.budget_articles.kind}
                      </Badge>
                    )}
                  </div>
                </td>
                <td className="p-3">
                  <Select
                    value={m.finance_article_id ?? NONE}
                    onValueChange={(v) =>
                      upsertMut.mutate({
                        id: m.id,
                        source_type: m.source_type,
                        source_code: m.source_code,
                        article_id: m.article_id,
                        finance_article_id: v === NONE ? null : v,
                      })
                    }
                  >
                    <SelectTrigger className="h-8 max-w-md">
                      <SelectValue placeholder="— None —" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NONE}>— None —</SelectItem>
                      {financeFor(m.source_type, m.finance_article_id).map((a) => (
                        <SelectItem key={a.id} value={a.id}>
                          [{a.kind}] {a.code} — {a.name}
                          {expectedFinanceKind(m.source_type) &&
                          a.kind !== expectedFinanceKind(m.source_type)
                            ? " ⚠ mismatch"
                            : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </td>
                <td className="p-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      if (confirm(`Delete mapping ${m.source_type}/${m.source_code}?`))
                        delMut.mutate(m.id);
                    }}
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </td>
              </tr>
            ))}
            <tr className="border-t border-border bg-muted/20">
              <td className="p-2">
                <Input
                  className="h-8 font-mono"
                  placeholder="CHARGE"
                  value={draft.source_type}
                  onChange={(e) =>
                    setDraft({ ...draft, source_type: e.target.value.toUpperCase() })
                  }
                />
              </td>
              <td className="p-2">
                <Input
                  className="h-8 font-mono"
                  placeholder="CODE"
                  value={draft.source_code}
                  onChange={(e) =>
                    setDraft({ ...draft, source_code: e.target.value.toUpperCase() })
                  }
                />
              </td>
              <td className="p-2"></td>
              <td className="p-2">
                <Select
                  value={draft.article_id}
                  onValueChange={(v) => setDraft({ ...draft, article_id: v })}
                >
                  <SelectTrigger className="h-8 max-w-md">
                    <SelectValue placeholder="Sales article…" />
                  </SelectTrigger>
                  <SelectContent>
                    {salesArticles.map((a) => (
                      <SelectItem key={a.id} value={a.id}>
                        [{a.kind}] {a.code} — {a.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </td>
              <td className="p-2">
                <Select
                  value={draft.finance_article_id || NONE}
                  onValueChange={(v) =>
                    setDraft({ ...draft, finance_article_id: v === NONE ? "" : v })
                  }
                >
                  <SelectTrigger className="h-8 max-w-md">
                    <SelectValue placeholder="Finance article…" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NONE}>— None —</SelectItem>
                    {financeFor(draft.source_type, draft.finance_article_id).map((a) => (
                      <SelectItem key={a.id} value={a.id}>
                        [{a.kind}] {a.code} — {a.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </td>
              <td className="p-2">
                <Button
                  size="icon"
                  disabled={
                    !draft.source_type ||
                    !draft.source_code ||
                    !draft.article_id ||
                    upsertMut.isPending
                  }
                  onClick={() =>
                    upsertMut.mutate({
                      source_type: draft.source_type,
                      source_code: draft.source_code,
                      article_id: draft.article_id,
                      finance_article_id: draft.finance_article_id || null,
                    })
                  }
                >
                  <Plus className="size-4" />
                </Button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    </TooltipProvider>
  );
}
