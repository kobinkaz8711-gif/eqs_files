import { createFileRoute, redirect, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { ArrowLeft, Trash2, Copy } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { TemplateEditor } from "@/components/templates/TemplateEditor";
import { TransportTypeSelect } from "@/components/TransportTypeSelect";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { useT } from "@/i18n/i18n";
import type { ChecklistTemplate } from "@/lib/types";
import {
  listTransportTypes,
  createTransportType,
  updateTransportType,
  deleteTransportType,
  getTemplate,
  saveTemplate,
  listEmailTemplates,
  upsertEmailTemplate,
  copyTemplate,
  type ChecklistTemplateDTO,
  type EmailTemplateDTO,
} from "@/lib/templates.functions";

export const Route = createFileRoute("/_authenticated/settings/module")({
  head: () => ({ meta: [{ title: "Настройки модуля — Logis" }] }),
  beforeLoad: ({ context }) => {
    // best-effort; full check via component
  },
  component: ModuleSettingsPage,
});

function ModuleSettingsPage() {
  const { hasPermission, me } = useAuth();
  const t = useT();
  if (me && !hasPermission("checklist.manage")) {
    throw redirect({ to: "/forbidden" });
  }

  return (
    <div className="text-foreground">
      <div className="border-b border-border bg-card">
        <div className="max-w-[1200px] mx-auto px-6 py-3 flex items-center justify-between gap-4 flex-wrap">
          <div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Link to="/tools" className="hover:text-foreground inline-flex items-center gap-1">
                <ArrowLeft className="size-3" /> {t("mod.back")}
              </Link>
            </div>
            <h1 className="text-base font-semibold tracking-tight mt-1">
              {t("mod.title")}
            </h1>
          </div>
        </div>
      </div>

      <main className="max-w-[1200px] mx-auto px-6 py-6">
        <Tabs defaultValue="types" className="w-full">
          <TabsList>
            <TabsTrigger value="types">{t("mod.tabs.types")}</TabsTrigger>
            <TabsTrigger value="checklist">{t("mod.tabs.checklist")}</TabsTrigger>
            <TabsTrigger value="email">{t("mod.tabs.email")}</TabsTrigger>
          </TabsList>

          <TabsContent value="types" className="mt-6">
            <TransportTypesTab />
          </TabsContent>
          <TabsContent value="checklist" className="mt-6">
            <ChecklistTab />
          </TabsContent>
          <TabsContent value="email" className="mt-6">
            <EmailTab />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

// ---------- Types tab ----------

function TransportTypesTab() {
  const t = useT();
  const queryClient = useQueryClient();
  const fetchTypes = useServerFn(listTransportTypes);
  const createFn = useServerFn(createTransportType);
  const updateFn = useServerFn(updateTransportType);
  const deleteFn = useServerFn(deleteTransportType);

  const { data: types = [] } = useQuery({
    queryKey: ["transport-types"],
    queryFn: () => fetchTypes(),
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["transport-types"] });
  };

  const create = useMutation({
    mutationFn: (input: { code: string; label: string }) =>
      createFn({
        data: {
          code: input.code,
          label: input.label,
          sort_order: types.length,
          is_active: true,
        },
      }),
    onSuccess: () => {
      invalidate();
      setCode("");
      setLabel("");
      toast.success(t("mod.types.created"));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const update = useMutation({
    mutationFn: (input: { code: string; patch: Record<string, unknown> }) =>
      updateFn({ data: input }),
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: (code: string) => deleteFn({ data: { code } }),
    onSuccess: () => {
      invalidate();
      toast.success(t("mod.types.deleted"));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const [code, setCode] = useState("");
  const [label, setLabel] = useState("");

  return (
    <div className="space-y-6">
      <div className="bg-card border border-border rounded-md p-4">
        <h2 className="text-sm font-semibold mb-3">{t("mod.types.addTitle")}</h2>
        <div className="flex flex-wrap items-end gap-3">
          <div className="space-y-1">
            <Label htmlFor="code" className="text-xs">{t("mod.types.code")}</Label>
            <Input
              id="code"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder={t("mod.types.codePh")}
              className="w-[180px] font-mono"
            />
          </div>
          <div className="space-y-1 flex-1 min-w-[220px]">
            <Label htmlFor="label" className="text-xs">{t("mod.types.name")}</Label>
            <Input
              id="label"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder={t("mod.types.namePh")}
            />
          </div>
          <Button
            onClick={() => {
              if (!code.trim() || !label.trim()) {
                toast.error(t("mod.types.fillBoth"));
                return;
              }
              create.mutate({ code: code.trim(), label: label.trim() });
            }}
            disabled={create.isPending}
          >
            {t("mod.types.add")}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          {t("mod.types.tplHint")}
        </p>
      </div>

      <div className="bg-card border border-border rounded-md overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[120px]">{t("mod.types.col.code")}</TableHead>
              <TableHead>{t("mod.types.col.name")}</TableHead>
              <TableHead className="w-[100px]">{t("mod.types.col.order")}</TableHead>
              <TableHead className="w-[100px]">{t("mod.types.col.active")}</TableHead>
              <TableHead className="w-[80px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {types.map((tt) => (
              <TableRow key={tt.code}>
                <TableCell className="font-mono text-xs">{tt.code}</TableCell>
                <TableCell>
                  <Input
                    defaultValue={tt.label}
                    className="h-8"
                    onBlur={(e) => {
                      if (e.target.value !== tt.label) {
                        update.mutate({
                          code: tt.code,
                          patch: { label: e.target.value },
                        });
                      }
                    }}
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    defaultValue={tt.sort_order}
                    className="h-8 w-[80px]"
                    onBlur={(e) => {
                      const v = parseInt(e.target.value, 10);
                      if (!Number.isNaN(v) && v !== tt.sort_order) {
                        update.mutate({ code: tt.code, patch: { sort_order: v } });
                      }
                    }}
                  />
                </TableCell>
                <TableCell>
                  <Switch
                    checked={tt.is_active}
                    onCheckedChange={(v) =>
                      update.mutate({ code: tt.code, patch: { is_active: v } })
                    }
                  />
                </TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      if (confirm(t("mod.types.delConfirm", tt.code))) {
                        del.mutate(tt.code);
                      }
                    }}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {types.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-sm text-muted-foreground py-6">
                  {t("mod.types.empty")}
                </TableCell>
              </TableRow>
            ) : null}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

// ---------- Checklist tab ----------

function ChecklistTab() {
  const t = useT();
  const queryClient = useQueryClient();
  const fetchTypes = useServerFn(listTransportTypes);
  const fetchTemplate = useServerFn(getTemplate);
  const saveFn = useServerFn(saveTemplate);

  const { data: types = [] } = useQuery({
    queryKey: ["transport-types"],
    queryFn: () => fetchTypes(),
  });

  const [transportType, setTransportType] = useState<string>("");
  useEffect(() => {
    if (!transportType && types.length > 0) setTransportType(types[0].code);
  }, [types, transportType]);

  const { data: template } = useQuery({
    queryKey: ["template", transportType],
    queryFn: () => fetchTemplate({ data: { transportTypeCode: transportType } }),
    enabled: !!transportType,
  });

  const [draft, setDraft] = useState<ChecklistTemplateDTO | null>(null);
  useEffect(() => {
    setDraft(template ?? null);
  }, [template]);

  const save = useMutation({
    mutationFn: (tpl: ChecklistTemplateDTO) =>
      saveFn({
        data: {
          id: tpl.id,
          name: tpl.name,
          sections: tpl.sections.map((s) => ({
            id: s.id,
            title: s.title,
            sort_order: s.sort_order,
            items: s.items.map((i) => ({
              id: i.id,
              label: i.label,
              hint: i.hint ?? null,
              required: i.required,
              critical: i.critical,
              sort_order: i.sort_order,
              depends_on_item_id: i.depends_on_item_id ?? null,
            })),
          })),
        },
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["template", transportType] });
      toast.success(t("mod.cl.saved"));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-4">
      <div className="bg-card border border-border rounded-md p-3 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <span className="text-[11px] uppercase tracking-wider text-muted-foreground">
            {t("mod.cl.transport")}
          </span>
          <div className="w-[260px]">
            <TransportTypeSelect
              value={transportType}
              onChange={setTransportType}
              types={types}
              includeInactive
            />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <CopyTemplateButton
            sourceCode={transportType}
            types={types}
            disabled={!transportType}
          />
          <Button
            onClick={() => draft && save.mutate(draft)}
            disabled={!draft || save.isPending}
          >
            {t("mod.cl.save")}
          </Button>
        </div>
      </div>

      {draft ? (
        <TemplateEditor
          template={draft as unknown as ChecklistTemplate}
          onChange={(tpl) => setDraft(tpl as unknown as ChecklistTemplateDTO)}
        />
      ) : (
        <div className="p-8 text-center rounded-md border border-dashed border-border bg-card">
          <p className="text-sm text-muted-foreground">
            {t("mod.cl.pick")}
          </p>
        </div>
      )}
    </div>
  );
}

// ---------- Email tab ----------

function EmailTab() {
  const t = useT();
  const queryClient = useQueryClient();
  const fetchTypes = useServerFn(listTransportTypes);
  const fetchEmails = useServerFn(listEmailTemplates);
  const upsertFn = useServerFn(upsertEmailTemplate);

  const { data: types = [] } = useQuery({
    queryKey: ["transport-types"],
    queryFn: () => fetchTypes(),
  });
  const { data: emails = [] } = useQuery({
    queryKey: ["email-templates"],
    queryFn: () => fetchEmails(),
  });

  const [scope, setScope] = useState<string>("__global__");

  const transportCode = scope === "__global__" ? null : scope;

  const find = (kind: "ok" | "missing"): EmailTemplateDTO | undefined =>
    emails.find((e) => e.kind === kind && e.transport_type_code === transportCode);

  const globalFor = (kind: "ok" | "missing") =>
    emails.find((e) => e.kind === kind && e.transport_type_code === null);

  const upsert = useMutation({
    mutationFn: (input: {
      kind: "ok" | "missing";
      subject: string;
      body: string;
    }) =>
      upsertFn({
        data: {
          transport_type_code: transportCode,
          kind: input.kind,
          subject: input.subject,
          body: input.body,
        },
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["email-templates"] });
      toast.success(t("mod.email.saved"));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-4">
      <div className="bg-card border border-border rounded-md p-3 flex items-center gap-3 flex-wrap">
        <span className="text-[11px] uppercase tracking-wider text-muted-foreground">
          {t("mod.email.scope")}
        </span>
        <Select value={scope} onValueChange={setScope}>
          <SelectTrigger className="w-[300px] h-9">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__global__">{t("mod.email.global")}</SelectItem>
            {types.map((tt) => (
              <SelectItem key={tt.code} value={tt.code}>
                <span className="font-mono text-xs text-muted-foreground mr-2">{tt.code}</span>
                {tt.label.replace(`${tt.code} — `, "")}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {transportCode ? (
          <p className="text-xs text-muted-foreground">
            {t("mod.email.overrideHint")}
          </p>
        ) : null}
      </div>

      <div className="bg-card border border-border rounded-md p-4 space-y-3">
        <h3 className="text-sm font-semibold">{t("mod.email.placeholders")}</h3>
        <ul className="text-xs text-muted-foreground space-y-1 font-mono">
          <li>{"{{missing_list}}"} {t("mod.email.ph.missing")}</li>
          <li>{"{{transport_type}}"} {t("mod.email.ph.transport")}</li>
          <li>{"{{transport_code}}"} {t("mod.email.ph.code")}</li>
        </ul>
      </div>

      <EmailEditor
        title={t("mod.email.missingTitle")}
        kind="missing"
        current={find("missing")}
        fallback={transportCode ? globalFor("missing") : undefined}
        onSave={(d) => upsert.mutate({ kind: "missing", ...d })}
        pending={upsert.isPending}
      />

      <EmailEditor
        title={t("mod.email.okTitle")}
        kind="ok"
        current={find("ok")}
        fallback={transportCode ? globalFor("ok") : undefined}
        onSave={(d) => upsert.mutate({ kind: "ok", ...d })}
        pending={upsert.isPending}
      />
    </div>
  );
}

function EmailEditor({
  title,
  kind,
  current,
  fallback,
  onSave,
  pending,
}: {
  title: string;
  kind: "ok" | "missing";
  current?: EmailTemplateDTO;
  fallback?: EmailTemplateDTO;
  onSave: (d: { subject: string; body: string }) => void;
  pending: boolean;
}) {
  const t = useT();
  const initial = current ?? fallback;
  const [subject, setSubject] = useState(initial?.subject ?? "");
  const [body, setBody] = useState(initial?.body ?? "");

  useEffect(() => {
    setSubject(initial?.subject ?? "");
    setBody(initial?.body ?? "");
  }, [initial?.id, initial?.subject, initial?.body]);

  return (
    <div className="bg-card border border-border rounded-md p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">{title}</h3>
        {!current && fallback ? (
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
            {t("mod.email.usingGlobal")}
          </span>
        ) : null}
      </div>
      <div className="space-y-1">
        <Label htmlFor={`subj-${kind}`} className="text-xs">{t("mod.email.subject")}</Label>
        <Input
          id={`subj-${kind}`}
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        />
      </div>
      <div className="space-y-1">
        <Label htmlFor={`body-${kind}`} className="text-xs">{t("mod.email.body")}</Label>
        <Textarea
          id={`body-${kind}`}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          rows={10}
          className="font-mono text-xs"
        />
      </div>
      <div className="flex justify-end">
        <Button
          onClick={() => onSave({ subject, body })}
          disabled={pending || !subject.trim() || !body.trim()}
        >
          {t("mod.email.save")}
        </Button>
      </div>
    </div>
  );
}

// ---------- Copy template ----------

function CopyTemplateButton({
  sourceCode,
  types,
  disabled,
}: {
  sourceCode: string;
  types: { code: string; label: string; is_active: boolean }[];
  disabled?: boolean;
}) {
  const t = useT();
  const queryClient = useQueryClient();
  const copyFn = useServerFn(copyTemplate);
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"existing" | "new">("new");
  const [targetCode, setTargetCode] = useState("");
  const [targetLabel, setTargetLabel] = useState("");
  const [overwrite, setOverwrite] = useState(false);

  useEffect(() => {
    if (!open) {
      setMode("new");
      setTargetCode("");
      setTargetLabel("");
      setOverwrite(false);
    }
  }, [open]);

  const copy = useMutation({
    mutationFn: (input: {
      mode: "existing" | "new";
      targetCode: string;
      targetLabel?: string;
      overwrite: boolean;
    }) =>
      copyFn({
        data: {
          sourceTransportTypeCode: sourceCode,
          mode: input.mode,
          targetCode: input.targetCode,
          targetLabel: input.targetLabel,
          overwrite: input.overwrite,
        },
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transport-types"] });
      queryClient.invalidateQueries({ queryKey: ["template"] });
      toast.success(t("mod.copy.copied"));
      setOpen(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const others = types.filter((tt) => tt.code !== sourceCode);

  const onSubmit = () => {
    if (mode === "new") {
      const code = targetCode.trim().toUpperCase();
      const label = targetLabel.trim();
      if (!code || !label) {
        toast.error(t("mod.types.fillBoth"));
        return;
      }
      if (!/^[A-Z0-9_-]+$/.test(code)) {
        toast.error(t("mod.copy.codeRegex"));
        return;
      }
      copy.mutate({ mode: "new", targetCode: code, targetLabel: label, overwrite: false });
    } else {
      if (!targetCode) {
        toast.error(t("mod.copy.pickTarget"));
        return;
      }
      copy.mutate({ mode: "existing", targetCode, overwrite });
    }
  };

  return (
    <>
      <Button
        variant="outline"
        onClick={() => setOpen(true)}
        disabled={disabled}
      >
        <Copy className="size-4" />
        {t("mod.copy.btn")}
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("mod.copy.title")}</DialogTitle>
            <DialogDescription>
              {t("mod.copy.source")}{" "}
              <span className="font-mono">{sourceCode}</span>
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex gap-2">
              <Button
                type="button"
                variant={mode === "new" ? "default" : "outline"}
                size="sm"
                onClick={() => setMode("new")}
                className="flex-1"
              >
                {t("mod.copy.toNew")}
              </Button>
              <Button
                type="button"
                variant={mode === "existing" ? "default" : "outline"}
                size="sm"
                onClick={() => setMode("existing")}
                className="flex-1"
              >
                {t("mod.copy.toExisting")}
              </Button>
            </div>

            {mode === "new" ? (
              <div className="space-y-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t("mod.copy.newCode")}</Label>
                  <Input
                    value={targetCode}
                    onChange={(e) => setTargetCode(e.target.value.toUpperCase())}
                    placeholder={t("mod.types.codePh")}
                    className="font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t("mod.copy.newName")}</Label>
                  <Input
                    value={targetLabel}
                    onChange={(e) => setTargetLabel(e.target.value)}
                    placeholder={t("mod.types.namePh")}
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t("mod.copy.target")}</Label>
                  <Select value={targetCode} onValueChange={setTargetCode}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder={t("mod.copy.targetPh")} />
                    </SelectTrigger>
                    <SelectContent>
                      {others.map((tt) => (
                        <SelectItem key={tt.code} value={tt.code}>
                          <span className="font-mono text-xs text-muted-foreground mr-2">
                            {tt.code}
                          </span>
                          {tt.label.replace(`${tt.code} — `, "")}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer">
                  <Switch checked={overwrite} onCheckedChange={setOverwrite} />
                  {t("mod.copy.overwrite")}
                </label>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              {t("mod.copy.cancel")}
            </Button>
            <Button onClick={onSubmit} disabled={copy.isPending}>
              <Copy className="size-4" />
              {t("mod.copy.copy")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
