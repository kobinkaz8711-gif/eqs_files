import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Trash2, KeyRound, Columns3, CheckCircle2, AlertTriangle, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { useT } from "@/i18n/i18n";
import {
  ALL_FIELDS,
  useVisibleColumns,
  type FieldKey,
} from "@/lib/containerExtractorSettings";
import { listApiKeys, addApiKey, deleteApiKey } from "@/lib/containerExtractorKeys.functions";

export const Route = createFileRoute("/_authenticated/settings/container-extractor")({
  head: () => ({ meta: [{ title: "Container Extractor — Settings" }] }),
  component: ContainerExtractorSettings,
});

function ContainerExtractorSettings() {
  const t = useT();
  const [cols, setCols] = useVisibleColumns();
  const [newKey, setNewKey] = useState("");
  const [newLabel, setNewLabel] = useState("");

  const qc = useQueryClient();
  const fetchKeys = useServerFn(listApiKeys);
  const runAdd = useServerFn(addApiKey);
  const runDelete = useServerFn(deleteApiKey);

  const { data: keys = [], isLoading } = useQuery({
    queryKey: ["cci-api-keys"],
    queryFn: () => fetchKeys(),
  });

  const addMut = useMutation({
    mutationFn: (vars: { key: string; label?: string }) => runAdd({ data: vars }),
    onSuccess: () => {
      setNewKey("");
      setNewLabel("");
      qc.invalidateQueries({ queryKey: ["cci-api-keys"] });
      toast.success("Ключ сохранён. Посмотреть его больше нельзя.");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const delMut = useMutation({
    mutationFn: (id: string) => runDelete({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["cci-api-keys"] });
      toast.success("Ключ удалён");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleColumn = (k: FieldKey) => {
    const next = cols.includes(k) ? cols.filter((c) => c !== k) : [...cols, k];
    const ordered = ALL_FIELDS.filter((f) => next.includes(f));
    setCols(ordered);
  };

  const handleAdd = () => {
    const trimmed = newKey.trim();
    if (trimmed.length < 20) {
      toast.error("Ключ слишком короткий");
      return;
    }
    addMut.mutate({ key: trimmed, label: newLabel.trim() || undefined });
  };

  const savedCount = keys.length;
  const ready = savedCount > 0;

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <Link
        to="/container-extractor"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6"
      >
        <ArrowLeft className="size-4" />
        {t("cciSet.back")}
      </Link>

      <h1 className="text-3xl font-semibold tracking-tight mb-2">{t("cciSet.title")}</h1>
      <p className="text-muted-foreground mb-8">{t("cciSet.subtitle")}</p>

      {/* Status */}
      <section
        className={`rounded-2xl border p-5 mb-6 flex items-start gap-3 ${
          ready
            ? "border-emerald-500/30 bg-emerald-500/5"
            : "border-amber-500/30 bg-amber-500/5"
        }`}
      >
        {ready ? (
          <CheckCircle2 className="size-5 text-emerald-500 shrink-0 mt-0.5" />
        ) : (
          <AlertTriangle className="size-5 text-amber-500 shrink-0 mt-0.5" />
        )}
        <div className="text-sm">
          <div className="font-medium mb-0.5">{t("cciSet.status.title")}</div>
          <div className="text-muted-foreground">
            {isLoading
              ? "Загрузка…"
              : ready
                ? t("cciSet.status.ready", savedCount)
                : t("cciSet.status.none")}
          </div>
        </div>
      </section>

      {/* API Keys */}
      <section className="rounded-2xl border border-border bg-card p-6 mb-6">
        <div className="flex items-center gap-2 mb-1">
          <KeyRound className="size-4 text-primary" />
          <h2 className="font-semibold">{t("cciSet.keys.title")}</h2>
        </div>
        <p className="text-sm text-muted-foreground mb-1">{t("cciSet.keys.desc")}</p>
        <p className="text-xs text-muted-foreground mb-4 flex items-center gap-1.5">
          <Lock className="size-3" />
          Ключи хранятся в зашифрованном виде. После сохранения посмотреть значение нельзя.
        </p>

        <div className="space-y-2 mb-4">
          {keys.length === 0 && !isLoading && (
            <div className="text-sm text-muted-foreground italic">{t("cciSet.keys.empty")}</div>
          )}
          {keys.map((k, i) => (
            <div key={k.id} className="flex items-center gap-2 p-2 rounded-lg border border-border">
              <div className="text-xs text-muted-foreground tabular w-6">#{i + 1}</div>
              <div className="flex-1 font-mono text-sm">
                {k.label ? `${k.label} · ` : ""}
                <span className="text-muted-foreground">{"•".repeat(8)}{k.last4}</span>
                <span className="text-xs text-muted-foreground ml-2">({k.key_length} симв.)</span>
              </div>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => delMut.mutate(k.id)}
                disabled={delMut.isPending}
                title={t("cciSet.keys.remove")}
              >
                <Trash2 className="size-4 text-destructive" />
              </Button>
            </div>
          ))}
        </div>

        <div className="space-y-2 pt-4 border-t border-border">
          <div className="text-sm font-medium">Добавить новый ключ</div>
          <Input
            type="password"
            value={newKey}
            onChange={(e) => setNewKey(e.target.value)}
            placeholder="AIza..."
            className="font-mono text-sm"
            autoComplete="off"
          />
          <Input
            value={newLabel}
            onChange={(e) => setNewLabel(e.target.value)}
            placeholder="Название (необязательно)"
            className="text-sm"
          />
          <Button size="sm" onClick={handleAdd} disabled={addMut.isPending || !newKey.trim()}>
            {addMut.isPending ? "Сохранение..." : "Сохранить ключ"}
          </Button>
        </div>
      </section>

      {/* Columns */}
      <section className="rounded-2xl border border-border bg-card p-6">
        <div className="flex items-center gap-2 mb-1">
          <Columns3 className="size-4 text-primary" />
          <h2 className="font-semibold">{t("cciSet.cols.title")}</h2>
        </div>
        <p className="text-sm text-muted-foreground mb-4">{t("cciSet.cols.desc")}</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {ALL_FIELDS.map((f) => (
            <label
              key={f}
              className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-accent/40 cursor-pointer"
            >
              <Checkbox checked={cols.includes(f)} onCheckedChange={() => toggleColumn(f)} />
              <span className="text-sm">{t(`cci.field.${f}` as Parameters<typeof t>[0])}</span>
            </label>
          ))}
        </div>
        <div className="mt-3 text-xs text-muted-foreground">
          {t("cciSet.cols.counter", cols.length, ALL_FIELDS.length)}
        </div>
      </section>
    </div>
  );
}
