import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listPermissions } from "@/lib/roles.functions";

export const Route = createFileRoute("/_authenticated/settings/permissions")({
  head: () => ({ meta: [{ title: "Список прав — Logis" }] }),
  component: PermissionsPage,
});

function PermissionsPage() {
  const fn = useServerFn(listPermissions);
  const q = useQuery({ queryKey: ["permissions"], queryFn: () => fn() });

  return (
    <div className="max-w-4xl mx-auto px-6 py-10 lg:py-14">
      <header className="mb-8">
        <p className="text-xs font-semibold uppercase tracking-widest text-primary mb-3">
          Справочник
        </p>
        <h1 className="text-4xl font-semibold tracking-tight">Список прав</h1>
        <p className="text-muted-foreground mt-2 max-w-[58ch]">
          Все доступные права в системе. Назначайте их ролям в разделе «Роли и права».
        </p>
      </header>
      <div className="bg-card border border-border rounded-2xl divide-y divide-border">
        {q.data?.items.map((p) => (
          <div key={p.id} className="px-5 py-4 flex items-center justify-between gap-4">
            <div>
              <p className="font-mono text-sm font-medium">{p.code}</p>
              <p className="text-sm text-muted-foreground">{p.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
