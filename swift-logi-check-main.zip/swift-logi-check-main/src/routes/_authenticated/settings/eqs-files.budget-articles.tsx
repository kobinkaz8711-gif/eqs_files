import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listBudgetArticles,
  upsertBudgetArticle,
  deleteBudgetArticle,
} from "@/lib/files.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Plus, Trash2, Pencil, Check, X } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/settings/eqs-files/budget-articles")({
  head: () => ({ meta: [{ title: "Sales Budget Articles" }] }),
  component: BudgetArticlesPage,
});

type Kind = "REVENUE" | "COST";
type EditDraft = { code: string; name: string; kind: Kind; sort_order: string };

function BudgetArticlesPage() {
  const qc = useQueryClient();
  const list = useServerFn(listBudgetArticles);
  const upsert = useServerFn(upsertBudgetArticle);
  const del = useServerFn(deleteBudgetArticle);

  const q = useQuery({ queryKey: ["budget-articles", "SALES"], queryFn: () => list({ data: { scope: "SALES" } }) });

  const [draft, setDraft] = useState<EditDraft>({
    code: "",
    name: "",
    kind: "COST",
    sort_order: "0",
  });

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<EditDraft>({
    code: "",
    name: "",
    kind: "COST",
    sort_order: "0",
  });

  const addMut = useMutation({
    mutationFn: () =>
      upsert({
        data: {
          code: draft.code,
          name: draft.name,
          kind: draft.kind,
          scope: "SALES",
          sort_order: parseInt(draft.sort_order, 10) || 0,
        },
      }),
    onSuccess: () => {
      setDraft({ code: "", name: "", kind: "COST", sort_order: "0" });
      qc.invalidateQueries({ queryKey: ["budget-articles"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const saveMut = useMutation({
    mutationFn: (id: string) =>
      upsert({
        data: {
          id,
          code: editDraft.code,
          name: editDraft.name,
          kind: editDraft.kind,
          scope: "SALES",
          sort_order: parseInt(editDraft.sort_order, 10) || 0,
        },
      }),
    onSuccess: () => {
      setEditingId(null);
      qc.invalidateQueries({ queryKey: ["budget-articles"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const delMut = useMutation({
    mutationFn: (id: string) => del({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["budget-articles"] }),
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const items = (q.data?.items ?? []) as any[];

  const startEdit = (a: any) => {
    setEditingId(a.id);
    setEditDraft({
      code: a.code ?? "",
      name: a.name ?? "",
      kind: (a.kind as Kind) ?? "COST",
      sort_order: String(a.sort_order ?? 0),
    });
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <Button variant="ghost" size="sm" asChild className="mb-4">
        <Link to="/settings/eqs-files">
          <ArrowLeft className="size-4 mr-1" /> EQS Files
        </Link>
      </Button>
      <h1 className="text-2xl font-semibold tracking-tight mb-1">Sales Budget Articles</h1>
      <p className="text-muted-foreground text-sm mb-6">
        Справочник статей бюджета продаж. Используется в плане и при маппинге факта.
      </p>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40">
            <tr>
              <th className="text-left p-3 font-medium w-32">Code</th>
              <th className="text-left p-3 font-medium">Name</th>
              <th className="text-left p-3 font-medium w-28">Kind</th>
              <th className="text-right p-3 font-medium w-20">Order</th>
              <th className="w-24"></th>
            </tr>
          </thead>
          <tbody>
            {items.map((a) =>
              editingId === a.id ? (
                <tr key={a.id} className="border-t border-border bg-muted/20">
                  <td className="p-2">
                    <Input
                      className="h-8 font-mono"
                      value={editDraft.code}
                      onChange={(e) =>
                        setEditDraft({ ...editDraft, code: e.target.value.toUpperCase() })
                      }
                    />
                  </td>
                  <td className="p-2">
                    <Input
                      className="h-8"
                      value={editDraft.name}
                      onChange={(e) => setEditDraft({ ...editDraft, name: e.target.value })}
                    />
                  </td>
                  <td className="p-2">
                    <Select
                      value={editDraft.kind}
                      onValueChange={(v: Kind) => setEditDraft({ ...editDraft, kind: v })}
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="REVENUE">REVENUE</SelectItem>
                        <SelectItem value="COST">COST</SelectItem>
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="p-2">
                    <Input
                      type="number"
                      className="h-8 text-right"
                      value={editDraft.sort_order}
                      onChange={(e) =>
                        setEditDraft({ ...editDraft, sort_order: e.target.value })
                      }
                    />
                  </td>
                  <td className="p-2">
                    <div className="flex gap-1 justify-end">
                      <Button
                        size="icon"
                        variant="ghost"
                        disabled={
                          !editDraft.code || !editDraft.name || saveMut.isPending
                        }
                        onClick={() => saveMut.mutate(a.id)}
                      >
                        <Check className="size-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => setEditingId(null)}
                      >
                        <X className="size-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ) : (
                <tr key={a.id} className="border-t border-border">
                  <td className="p-3 font-mono text-xs">{a.code}</td>
                  <td className="p-3">{a.name}</td>
                  <td className="p-3">
                    <Badge variant={a.kind === "REVENUE" ? "default" : "secondary"}>
                      {a.kind}
                    </Badge>
                  </td>
                  <td className="p-3 text-right font-mono text-xs">{a.sort_order ?? 0}</td>
                  <td className="p-3">
                    <div className="flex gap-1 justify-end">
                      <Button variant="ghost" size="icon" onClick={() => startEdit(a)}>
                        <Pencil className="size-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          if (confirm(`Delete article ${a.code}?`)) delMut.mutate(a.id);
                        }}
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ),
            )}
            <tr className="border-t border-border bg-muted/20">
              <td className="p-2">
                <Input
                  className="h-8 font-mono"
                  placeholder="CODE"
                  value={draft.code}
                  onChange={(e) => setDraft({ ...draft, code: e.target.value.toUpperCase() })}
                />
              </td>
              <td className="p-2">
                <Input
                  className="h-8"
                  placeholder="Name"
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                />
              </td>
              <td className="p-2">
                <Select
                  value={draft.kind}
                  onValueChange={(v: Kind) => setDraft({ ...draft, kind: v })}
                >
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="REVENUE">REVENUE</SelectItem>
                    <SelectItem value="COST">COST</SelectItem>
                  </SelectContent>
                </Select>
              </td>
              <td className="p-2">
                <Input
                  type="number"
                  className="h-8 text-right"
                  value={draft.sort_order}
                  onChange={(e) => setDraft({ ...draft, sort_order: e.target.value })}
                />
              </td>
              <td className="p-2">
                <div className="flex justify-end">
                  <Button
                    size="icon"
                    disabled={!draft.code || !draft.name || addMut.isPending}
                    onClick={() => addMut.mutate()}
                  >
                    <Plus className="size-4" />
                  </Button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
