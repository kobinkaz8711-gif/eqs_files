import { createFileRoute } from "@tanstack/react-router";
import { ArrowDownRight, ArrowUpRight, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useT } from "@/i18n/i18n";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Операционная сводка — Logis" }] }),
  component: DashboardPage,
});

const queue = [
  { id: "LOG-2487", type: "FCL", shipper: "ООО «Балтика-Лоджистик»", route: "Шанхай → СПб", pct: 92, missing: 1, critical: false, sla: "—", assignee: "А. Кузнецова", status: "ready" },
  { id: "LOG-2486", type: "AIR", shipper: "Pharma Trade GmbH", route: "Франкфурт → Москва", pct: 58, missing: 4, critical: true, sla: "3ч 12м", assignee: "А. Кузнецова", status: "blocked" },
  { id: "LOG-2485", type: "ROAD", shipper: "ИП Воронин Д.А.", route: "Минск → Москва", pct: 100, missing: 0, critical: false, sla: "—", assignee: "С. Лебедев", status: "sent" },
  { id: "LOG-2484", type: "LCL", shipper: "Yantai Goldex", route: "Циндао → Новороссийск", pct: 67, missing: 3, critical: false, sla: "1д 4ч", assignee: "М. Игнатьева", status: "in_review" },
  { id: "LOG-2483", type: "RAIL", shipper: "АО «УралТранс»", route: "Чэнду → Электроугли", pct: 41, missing: 7, critical: true, sla: "11ч", assignee: "С. Лебедев", status: "blocked" },
  { id: "LOG-2482", type: "FCL", shipper: "Nordic Foods AB", route: "Гётеборг → СПб", pct: 84, missing: 2, critical: false, sla: "—", assignee: "М. Игнатьева", status: "in_review" },
  { id: "LOG-2481", type: "EXPORT", shipper: "ООО «АгроЭкспорт»", route: "Краснодар → Стамбул", pct: 100, missing: 0, critical: false, sla: "—", assignee: "А. Кузнецова", status: "sent" },
];

const breakdown = [
  { code: "FCL", count: 18, pct: 38 },
  { code: "LCL", count: 9, pct: 19 },
  { code: "AIR", count: 6, pct: 13 },
  { code: "ROAD", count: 7, pct: 15 },
  { code: "RAIL", count: 4, pct: 9 },
  { code: "SEA", count: 3, pct: 6 },
];

function DashboardPage() {
  const t = useT();
  const kpis = [
    { label: t("dash.kpi.inProgress"), value: 47, delta: +6, hint: t("dash.kpi.inProgressHint") },
    { label: t("dash.kpi.waiting"), value: 12, delta: +3, hint: t("dash.kpi.waitingHint") },
    { label: t("dash.kpi.ready"), value: 18, delta: -2, hint: t("dash.kpi.readyHint") },
    { label: t("dash.kpi.avg"), value: "73%", delta: +4, hint: t("dash.kpi.avgHint") },
  ];

  return (
    <div className="max-w-[1400px] mx-auto px-6 py-6">
      <div className="flex items-end justify-between gap-4 mb-5">
        <div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>{t("dash.crumb.ops")}</span>
            <span>/</span>
            <span className="text-foreground">{t("dash.crumb.summary")}</span>
          </div>
          <h1 className="text-xl font-semibold tracking-tight mt-1">{t("dash.title")}</h1>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
            <Input placeholder={t("dash.search")} className="h-9 w-[280px] pl-8 text-sm" />
          </div>
          <Button variant="outline" size="sm" className="h-9 gap-2">{t("dash.filters")}</Button>
          <Button size="sm" className="h-9 gap-2">{t("dash.newRequest")}</Button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 border border-border rounded-md bg-card overflow-hidden mb-5">
        {kpis.map((k, i) => (
          <div key={k.label} className={`p-4 ${i < kpis.length - 1 ? "lg:border-r border-border" : ""} ${i < 2 ? "border-b lg:border-b-0 border-border" : ""}`}>
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">{k.label}</p>
              <DeltaChip value={k.delta} />
            </div>
            <p className="text-2xl font-semibold tracking-tight tabular-nums mt-1">{k.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{k.hint}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-12 gap-5">
        <div className="col-span-12 xl:col-span-8 bg-card border border-border rounded-md overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-border">
            <div className="flex items-center gap-4">
              <h2 className="text-sm font-semibold">{t("dash.queue.title")}</h2>
              <div className="flex items-center gap-1 text-xs">
                <TabPill active>{t("dash.tab.all", 47)}</TabPill>
                <TabPill>{t("dash.tab.mine", 18)}</TabPill>
                <TabPill>{t("dash.tab.blocked", 7)}</TabPill>
                <TabPill>{t("dash.tab.ready", 18)}</TabPill>
              </div>
            </div>
            <button className="text-xs text-muted-foreground hover:text-foreground">{t("dash.openAll")}</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] uppercase tracking-wider text-muted-foreground border-b border-border bg-surface/60">
                  <th className="text-left font-medium px-4 py-2">{t("dash.col.id")}</th>
                  <th className="text-left font-medium px-2 py-2">{t("dash.col.type")}</th>
                  <th className="text-left font-medium px-2 py-2">{t("dash.col.shipper")}</th>
                  <th className="text-left font-medium px-2 py-2 w-[160px]">{t("dash.col.readiness")}</th>
                  <th className="text-left font-medium px-2 py-2">{t("dash.col.sla")}</th>
                  <th className="text-left font-medium px-2 py-2">{t("dash.col.assignee")}</th>
                  <th className="text-left font-medium px-4 py-2">{t("dash.col.status")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {queue.map((r) => (
                  <tr key={r.id} className="hover:bg-muted/40 cursor-pointer">
                    <td className="px-4 py-2.5 font-mono text-xs text-muted-foreground">{r.id}</td>
                    <td className="px-2 py-2.5">
                      <span className="font-mono text-[11px] px-1.5 py-0.5 rounded bg-muted border border-border">{r.type}</span>
                    </td>
                    <td className="px-2 py-2.5 min-w-[260px]">
                      <p className="text-sm font-medium leading-tight">{r.shipper}</p>
                      <p className="text-xs text-muted-foreground leading-tight mt-0.5">{r.route}</p>
                    </td>
                    <td className="px-2 py-2.5">
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                          <div
                            className={`h-full ${
                              r.critical ? "bg-destructive" : r.pct >= 100 ? "bg-success" : r.pct >= 75 ? "bg-info" : "bg-warning"
                            }`}
                            style={{ width: `${r.pct}%` }}
                          />
                        </div>
                        <span className="tabular-nums text-xs text-muted-foreground w-9 text-right">{r.pct}%</span>
                      </div>
                      {r.missing > 0 && (
                        <p className="text-[11px] text-muted-foreground mt-1">
                          {r.critical ? (
                            <span className="text-destructive font-medium">{r.missing} {t("dash.critical")} </span>
                          ) : null}
                          {t("dash.missing", r.missing)}
                        </p>
                      )}
                    </td>
                    <td className="px-2 py-2.5 text-xs tabular-nums text-muted-foreground">{r.sla}</td>
                    <td className="px-2 py-2.5 text-xs">{r.assignee}</td>
                    <td className="px-4 py-2.5"><StatusBadge value={r.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="col-span-12 xl:col-span-4 space-y-5">
          <div className="bg-card border border-border rounded-md">
            <div className="px-4 py-2.5 border-b border-border flex items-center justify-between">
              <h2 className="text-sm font-semibold">{t("dash.breakdown")}</h2>
              <span className="text-[11px] text-muted-foreground">{t("dash.last7d")}</span>
            </div>
            <ul className="divide-y divide-border">
              {breakdown.map((b) => (
                <li key={b.code} className="flex items-center gap-3 px-4 py-2.5 text-sm">
                  <span className="font-mono text-[11px] w-12 px-1.5 py-0.5 rounded bg-muted border border-border text-center">{b.code}</span>
                  <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary/70" style={{ width: `${b.pct * 2.5}%` }} />
                  </div>
                  <span className="tabular-nums text-xs text-muted-foreground w-12 text-right">{b.count} · {b.pct}%</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-card border border-border rounded-md">
            <div className="px-4 py-2.5 border-b border-border flex items-center justify-between">
              <h2 className="text-sm font-semibold">{t("dash.sla.title")}</h2>
              <span className="text-[11px] font-medium text-destructive">{t("dash.sla.active", 4)}</span>
            </div>
            <ul className="divide-y divide-border text-sm">
              {[
                { id: "LOG-2486", text: "Pharma Trade GmbH · нет ответа 23ч", tone: "destructive" },
                { id: "LOG-2483", text: "АО «УралТранс» · просрочка 11ч", tone: "destructive" },
                { id: "LOG-2479", text: "ООО «Дельта» · ожидание HS-кода", tone: "warning" },
                { id: "LOG-2477", text: "GreenWay Logistics · нет коммерческого инвойса", tone: "warning" },
              ].map((i) => (
                <li key={i.id} className="px-4 py-2.5 flex items-start gap-3">
                  <span className={`size-1.5 rounded-full mt-1.5 shrink-0 ${i.tone === "destructive" ? "bg-destructive" : "bg-warning"}`} />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-mono text-muted-foreground">{i.id}</p>
                    <p className="text-sm leading-snug">{i.text}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

function DeltaChip({ value }: { value: number }) {
  if (value === 0) return null;
  const positive = value > 0;
  return (
    <span className={`inline-flex items-center gap-0.5 text-[10px] font-medium tabular-nums ${positive ? "text-success" : "text-muted-foreground"}`}>
      {positive ? <ArrowUpRight className="size-3" /> : <ArrowDownRight className="size-3" />}
      {positive ? "+" : ""}
      {value}
    </span>
  );
}

function TabPill({ children, active = false }: { children: React.ReactNode; active?: boolean }) {
  return (
    <button className={`px-2 py-1 rounded text-xs font-medium transition-colors ${active ? "bg-foreground/5 text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-muted/60"}`}>
      {children}
    </button>
  );
}

function StatusBadge({ value }: { value: string }) {
  const t = useT();
  const map: Record<string, { label: string; cls: string; dot: string }> = {
    ready: { label: t("dash.status.ready"), cls: "bg-success/10 text-success border-success/20", dot: "bg-success" },
    blocked: { label: t("dash.status.blocked"), cls: "bg-destructive/10 text-destructive border-destructive/20", dot: "bg-destructive" },
    in_review: { label: t("dash.status.in_review"), cls: "bg-info/10 text-info border-info/20", dot: "bg-info" },
    sent: { label: t("dash.status.sent"), cls: "bg-muted text-muted-foreground border-border", dot: "bg-muted-foreground" },
  };
  const m = map[value] ?? map.in_review;
  return (
    <span className={`inline-flex items-center gap-1.5 text-[11px] font-medium px-2 py-0.5 rounded-full border ${m.cls}`}>
      <span className={`size-1.5 rounded-full ${m.dot}`} />
      {m.label}
    </span>
  );
}
