import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Files, Plus, Search, Boxes, BarChart3, RefreshCw, FileBarChart2, MoreHorizontal, Copy, ClipboardCopy } from "lucide-react";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listFiles, getFilesFilterOptions, refreshFilesFromExt } from "@/lib/files.functions";
import { formatContainerLine } from "@/lib/utils";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { CopyFileDialog } from "@/components/CopyFileDialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";


export const Route = createFileRoute("/_authenticated/eqs-files/")({
  component: EqsFilesPage,
  head: () => ({
    meta: [{ title: "EQS Files" }, { name: "description", content: "EQS Files" }],
  }),
});

const STATUS_LABEL: Record<string, string> = {
  DR: "Draft",
  OP: "Open",
  RP: "RP",
  RCL: "Ready for CL",
  CL: "Closed",
  CN: "Cancelled",
};

function EqsFilesPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const fetchFiles = useServerFn(listFiles);
  const fetchOptions = useServerFn(getFilesFilterOptions);
  const refreshFn = useServerFn(refreshFilesFromExt);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("ALL");
  const [originSub, setOriginSub] = useState<string>("ALL");
  const [destSub, setDestSub] = useState<string>("ALL");
  const [opDate, setOpDate] = useState<string>(() => `${new Date().getFullYear()}-01-01`);
  const [dept, setDept] = useState<string>("ALL");
  const [eqType, setEqType] = useState<string>("ALL");
  const [showCancelled, setShowCancelled] = useState<boolean>(false);
  const [hideDraft, setHideDraft] = useState<boolean>(false);
  const [copyState, setCopyState] = useState<{ id: string; mode: "plain" | "with_budget" } | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["files", { q, status, originSub, destSub, showCancelled, hideDraft, opDate, dept, eqType }],
    queryFn: () =>
      fetchFiles({
        data: {
          q: q || undefined,
          status: status === "ALL" ? undefined : (status as any),
          originSubregion: originSub === "ALL" ? undefined : originSub,
          destSubregion: destSub === "ALL" ? undefined : destSub,
          include_cancelled: showCancelled,
          hide_draft: hideDraft,
          op_date: opDate || undefined,
          department_id: dept === "ALL" ? undefined : dept,
          container_type: eqType === "ALL" ? undefined : eqType,
        },
      }),
  });

  const { data: opts } = useQuery({
    queryKey: ["files-filter-options"],
    queryFn: () => fetchOptions(),
  });

  const refreshMut = useMutation({
    mutationFn: (scope: "open" | "all_visible") => {
      const ids = (data?.items ?? []).map((f: any) => f.id);
      return refreshFn({ data: { file_ids: ids, scope } });
    },
    onSuccess: (r: any) => {
      toast.success(
        `Refreshed ${r?.processed ?? 0} files · +${r?.added_units ?? 0} units · ${r?.finance_rows ?? 0} finance rows`,
      );
      qc.invalidateQueries({ queryKey: ["files"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Refresh failed"),
  });



  return (
    <div className="max-w-6xl mx-auto px-4 py-4">
      <div className="mb-3 flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-md bg-primary/10 text-primary grid place-items-center">
            <Files className="size-5" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">EQS Files</h1>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => refreshMut.mutate("open")}
            disabled={refreshMut.isPending}
            title="Refresh open files (DR/OP/RP) from EQS: links new units from bookings, recomputes finance"
            aria-label="Refresh from EQS"
          >
            <RefreshCw className={`size-4 ${refreshMut.isPending ? "animate-spin" : ""}`} />
          </Button>
          <Button variant="outline" onClick={() => navigate({ to: "/eqs-files/reporting" })}>
            <FileBarChart2 className="size-4 mr-1" /> Reporting
          </Button>
          <Button variant="outline" onClick={() => navigate({ to: "/recent-units" })}>
            <Boxes className="size-4 mr-1" /> Recent units
          </Button>
          <Button variant="outline" onClick={() => navigate({ to: "/sales-dashboard" })}>
            <BarChart3 className="size-4 mr-1" /> Sales dashboard
          </Button>
          <Button onClick={() => navigate({ to: "/eqs-files/new" })}>
            <Plus className="size-4 mr-1" /> New File
          </Button>
        </div>
      </div>




      <div className="flex flex-wrap items-end gap-2 mb-2">
        <div className="flex-1 min-w-[160px] max-w-[260px]">
          <label className="text-xs text-muted-foreground mb-1 block">Search</label>
          <div className="relative">
            <Search className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="File # / customer / accno"
              className="pl-9"
            />
          </div>
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Dept</label>
          <Select value={dept} onValueChange={setDept}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="All depts" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All depts</SelectItem>
              {(opts?.departmentOptions ?? []).map((o: any) => (
                <SelectItem key={o.id} value={o.id}>
                  {o.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">EQ type</label>
          <Select value={eqType} onValueChange={setEqType}>
            <SelectTrigger className="w-[110px]">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All</SelectItem>
              {(opts?.containerTypeOptions ?? []).map((o: any) => (
                <SelectItem key={o.id} value={o.id}>
                  {o.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">OP date from</label>
          <Input type="date" value={opDate} onChange={(e) => setOpDate(e.target.value)} className="w-[150px]" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">File status</label>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="w-[130px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All statuses</SelectItem>
              {Object.entries(STATUS_LABEL).map(([k, v]) => (
                <SelectItem key={k} value={k}>
                  {v}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Route</label>
          <div className="flex gap-1">
            <Select value={originSub} onValueChange={setOriginSub}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="From" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">From (any)</SelectItem>
                {(opts?.originOptions ?? []).map((o: any) => (
                  <SelectItem key={o.id} value={o.id}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={destSub} onValueChange={setDestSub}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="To" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">To (any)</SelectItem>
                {(opts?.destOptions ?? []).map((o: any) => (
                  <SelectItem key={o.id} value={o.id}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>



      <div className="flex justify-end gap-4 mb-4">
        <label className="inline-flex items-center gap-2 text-xs select-none">
          <input
            type="checkbox"
            checked={hideDraft}
            onChange={(e) => setHideDraft(e.target.checked)}
            className="size-4"
          />
          Hide draft
        </label>
        <label className="inline-flex items-center gap-2 text-xs select-none">
          <input
            type="checkbox"
            checked={showCancelled}
            onChange={(e) => setShowCancelled(e.target.checked)}
            className="size-4"
          />
          Show cancelled
        </label>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
        <TooltipProvider delayDuration={150}>
        <table className="w-full text-xs">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="w-8 px-1 py-1.5"></th>
              <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">File #</th>
              <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">Status</th>
              <th className="text-left font-medium px-2 py-1.5 min-w-[180px]">Customer</th>
              <th className="text-left font-medium px-2 py-1.5 w-[110px] min-w-[110px] max-w-[110px]">Containers</th>
              <th className="text-left font-medium px-2 py-1.5 min-w-[220px]">Route</th>
              <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap min-w-[140px]">SM/Dept</th>
              <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap min-w-[110px]">Creat./Deprt.</th>
              <th className="text-right font-medium px-2 py-1.5 whitespace-nowrap">GPM/Rev (USD)</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={9} className="p-6 text-center text-muted-foreground">
                  Loading…
                </td>
              </tr>
            )}
            {!isLoading && (data?.items.length ?? 0) === 0 && (
              <tr>
                <td colSpan={9} className="p-8 text-center text-muted-foreground">
                  No files yet. Click "New File" to create one.
                </td>
              </tr>
            )}
            {data?.items.map((f: any) => {
              const cts = (f.container_types ?? []) as Array<{ container_type: string; grade: string | null; planned_qty: number; attached_qty?: number }>;
              const baseBadge = "inline-flex items-center justify-center rounded-[3px] border px-1.5 py-[1px] font-mono text-[10px] leading-tight whitespace-nowrap w-fit";
              const neutralBadge = `${baseBadge} border-foreground/80 bg-background`;
              const badgeClsFor = (planned: number, attached: number) => {
                if (!f.has_booking) {
                  if (attached > 0) return `${baseBadge} border-rose-700 text-rose-800 bg-rose-100`;
                  return neutralBadge;
                }
                if (attached === 0) return `${baseBadge} border-sky-500 text-sky-700 bg-sky-50`;
                if (attached > planned) return `${baseBadge} border-red-500 text-red-700 bg-red-50`;
                if (attached === planned) return `${baseBadge} border-emerald-500 text-emerald-700 bg-emerald-50`;
                return `${baseBadge} border-amber-500 text-amber-700 bg-amber-50`;
              };
              return (
              <tr
                key={f.id}
                className="group border-t border-border hover:bg-muted/30 cursor-pointer"
                onClick={() => navigate({ to: "/eqs-files/$id", params: { id: f.id } })}
              >
                <td className="px-1 py-1 w-8 align-middle" onClick={(e) => e.stopPropagation()}>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-6 opacity-0 group-hover:opacity-100 focus-visible:opacity-100 data-[state=open]:opacity-100"
                        aria-label="Row actions"
                      >
                        <MoreHorizontal className="size-3.5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" className="w-56">
                      <DropdownMenuItem onSelect={() => setCopyState({ id: f.id, mode: "plain" })}>
                        <Copy className="size-4 mr-2" /> Copy
                      </DropdownMenuItem>
                      <DropdownMenuItem onSelect={() => setCopyState({ id: f.id, mode: "with_budget" })}>
                        <ClipboardCopy className="size-4 mr-2" /> Copy with planned budget
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </td>
                <td className="px-2 py-1 font-mono whitespace-nowrap">
                  <Link
                    to="/eqs-files/$id"
                    params={{ id: f.id }}
                    className="text-primary hover:underline"
                  >
                    {f.file_number ?? "—"}
                  </Link>
                </td>
                <td className="px-2 py-1 whitespace-nowrap">
                  <Badge variant={f.status === "DR" ? "secondary" : "default"} className="text-[10px] px-1.5 py-0">
                    {STATUS_LABEL[f.status] ?? f.status}
                  </Badge>
                </td>
                <td className="px-2 py-1 min-w-[180px] max-w-[220px]">
                  <div className="truncate">{f.customer_name ?? "—"}</div>
                  <div className="text-[11px] text-muted-foreground font-mono truncate">
                    {f.customer_accno ?? ""}
                  </div>
                </td>
                <td className="px-2 py-1 w-[110px] min-w-[110px] max-w-[110px] align-middle">
                  {cts.length === 0 ? (
                    <span className="text-muted-foreground">—</span>
                  ) : cts.length <= 2 ? (
                    <div className="flex flex-col gap-0.5">
                      {cts.map((c, i) => (
                        <span key={`${c.container_type}-${c.grade ?? ""}-${i}`} className={badgeClsFor(c.planned_qty, c.attached_qty ?? 0)}>
                          {formatContainerLine(c.container_type, c.grade, c.planned_qty)}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <span className={neutralBadge}>misc</span>
                      </TooltipTrigger>
                      <TooltipContent className="font-mono text-xs">
                        {cts.map((c, i) => (
                          <div key={i}>{formatContainerLine(c.container_type, c.grade, c.planned_qty)}</div>
                        ))}
                      </TooltipContent>
                    </Tooltip>
                  )}
                </td>
                <td className="px-2 py-1 min-w-[220px] max-w-[260px]">
                  <div className="truncate">
                    {f.origin_subregion_desc ?? f.origin_subregion ?? "—"} →{" "}
                    {f.dest_subregion_desc ?? f.dest_subregion ?? "—"}
                  </div>
                  {(f.origin_locn_desc || f.dest_locn_desc || f.origin_locn || f.dest_locn) && (
                    <div className="text-[11px] text-muted-foreground mt-0.5 truncate">
                      {f.origin_locn_desc ?? f.origin_locn ?? "—"} →{" "}
                      {f.dest_locn_desc ?? f.dest_locn ?? "—"}
                    </div>
                  )}
                </td>
                <td className="px-2 py-1 whitespace-nowrap min-w-[140px] max-w-[180px]">
                  <div className="truncate">{f.sm_name ?? "—"}</div>
                  <div className="text-[11px] text-muted-foreground font-mono">{f.dept_code ?? ""}</div>
                </td>
                <td className="px-2 py-1 whitespace-nowrap">
                  <div className="font-mono">
                    {f.created_at ? String(f.created_at).slice(0, 10) : "—"}
                  </div>
                  <div className="text-[10px] text-muted-foreground font-mono">
                    {f.planned_departure_date ?? "—"}
                  </div>
                </td>
                <td className="px-2 py-1 text-right whitespace-nowrap">
                  <div className={`font-mono tabular-nums ${(f.gpm_usd ?? 0) < 0 ? "text-red-600" : "text-emerald-600"}`}>
                    {Number(f.gpm_usd ?? 0).toFixed(2)}
                  </div>
                  <div className="text-[10px] text-muted-foreground font-mono tabular-nums">
                    {Number(f.revenue_usd ?? 0).toFixed(2)}
                  </div>
                </td>
              </tr>
              );
            })}
          </tbody>
        </table>
        </TooltipProvider>
        </div>
      </div>

      <CopyFileDialog
        fileId={copyState?.id ?? null}
        mode={copyState?.mode ?? "plain"}
        open={!!copyState}
        onOpenChange={(v) => { if (!v) setCopyState(null); }}
      />
    </div>
  );
}
