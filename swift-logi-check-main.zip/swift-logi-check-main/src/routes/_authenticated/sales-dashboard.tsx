import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  getSalesDashboard,
  getSalesFilterOptions,
} from "@/lib/sales.functions";
import { listFeatureFlags } from "@/lib/featureFlags.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TrendingUp, X, ArrowLeft, ArrowUp, ArrowDown, Plus } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { CreateFileFromSalesDialog } from "@/components/CreateFileFromSalesDialog";
import { useNavigate } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/sales-dashboard")({
  component: SalesDashboardPage,
  head: () => ({ meta: [{ title: "Sales Dashboard" }] }),
  errorComponent: ({ error }) => (
    <div className="p-8 text-sm text-destructive">{String(error?.message ?? error)}</div>
  ),
  notFoundComponent: () => <div className="p-8">Not found</div>,
});

const fmtUsd = (n: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(n || 0);
const fmtInt = (n: number) =>
  new Intl.NumberFormat("en-US").format(Math.round(n || 0));

function ymd(d: Date) {
  return d.toISOString().slice(0, 10);
}

function SalesDashboardPage() {
  const fetchDash = useServerFn(getSalesDashboard);
  const fetchOpts = useServerFn(getSalesFilterOptions);
  const fetchFlags = useServerFn(listFeatureFlags);

  const { data: flagsData } = useQuery({
    queryKey: ["feature-flags"],
    queryFn: () => fetchFlags(),
  });
  const createFromSalesEnabled =
    flagsData?.items.find(
      (f) => f.code === "create_files_from_sales_invoices",
    )?.enabled ?? false;


  const now = new Date();
  const yearStart = new Date(now.getFullYear(), 0, 1);
  const yearEnd = new Date(now.getFullYear(), 11, 31);

  const [dateFrom, setDateFrom] = useState(ymd(yearStart));
  const [dateTo, setDateTo] = useState(ymd(yearEnd));
  const [buyer, setBuyer] = useState("");
  const [salesPerson, setSalesPerson] = useState<string>("ALL");
  const [country, setCountry] = useState<string>("ALL");
  const [iso, setIso] = useState<string>("ALL");
  const [direction, setDirection] = useState<"ALL" | "SALE" | "CN">("ALL");
  const [linkStatus, setLinkStatus] = useState<"ALL" | "LINKED" | "UNLINKED">(
    "ALL",
  );
  const [page, setPage] = useState(0);
  const [viewMode, setViewMode] = useState<"unit" | "invoice">("invoice");
  const [sortBy, setSortBy] = useState<"date" | "invoice" | "amount" | "file">("date");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const navigate = useNavigate();
  const PAGE = 50;


  const filters = useMemo(
    () => ({
      dateFrom,
      dateTo,
      buyer: buyer || undefined,
      salesPersons: salesPerson === "ALL" ? undefined : [salesPerson],
      countries: country === "ALL" ? undefined : [country],
      isoCodes: iso === "ALL" ? undefined : [iso],
      direction,
      linkStatus,
    }),
    [dateFrom, dateTo, buyer, salesPerson, country, iso, direction, linkStatus],
  );

  const { data: opts } = useQuery({
    queryKey: ["sales-opts"],
    queryFn: () => fetchOpts(),
  });

  const { data, isLoading } = useQuery({
    queryKey: ["sales-dash", filters],
    queryFn: () => fetchDash({ data: filters }),
  });

  const rows = data?.rows ?? [];
  const kpi = data?.kpi;

  const displayRows = useMemo(() => {
    const base = (() => {
      if (viewMode === "unit") {
        return rows.map((r: any) => ({ ...r, _ids: [r.id] as string[] }));
      }
      const groups = new Map<string, any>();
      for (const r of rows) {
        const key = r.invoice_no ?? `__${r.id}`;
        const g = groups.get(key);
        if (!g) {
          groups.set(key, {
            id: key,
            invoice_no: r.invoice_no,
            invoice_date: r.invoice_date,
            sale_direction: r.sale_direction,
            buyer_accno: r.buyer_accno,
            buyer_name: r.buyer_name,
            sales_person: r.sales_person,
            sale_subregion: r.sale_subregion,
            sale_subregion_desc: r.sale_subregion_desc,
            sale_locn_desc: r.sale_locn_desc,
            currency: r.currency,
            amount_base: Number(r.amount_base ?? 0),
            _units: new Set<string>(r.unit_no ? [r.unit_no] : []),
            _isos: new Set<string>(r.unit_iso ? [r.unit_iso] : []),
            _files: new Map<string, string>(
              r.file_id ? [[r.file_id, r.file_number ?? ""]] : [],
            ),
            _ids: [r.id] as string[],
          });
        } else {
          g.amount_base += Number(r.amount_base ?? 0);
          if (r.unit_no) g._units.add(r.unit_no);
          if (r.unit_iso) g._isos.add(r.unit_iso);
          if (r.file_id) g._files.set(r.file_id, r.file_number ?? "");
          if (r.invoice_date && (!g.invoice_date || r.invoice_date > g.invoice_date))
            g.invoice_date = r.invoice_date;
          g._ids.push(r.id);
        }
      }
      return Array.from(groups.values()).map((g) => ({
        ...g,
        unit_count: g._units.size,
        unit_no: g._units.size === 1 ? Array.from(g._units)[0] : `${g._units.size} units`,
        unit_iso: Array.from(g._isos).join(", "),
        file_id: g._files.size === 1 ? Array.from(g._files.keys())[0] : null,
        file_number:
          g._files.size === 1
            ? Array.from(g._files.values())[0]
            : g._files.size > 1
              ? `${g._files.size} files`
              : null,
      }));
    })();

    const dir = sortDir === "asc" ? 1 : -1;
    const cmp = (a: any, b: any) => {
      switch (sortBy) {
        case "invoice":
          return ((a.invoice_no ?? "") > (b.invoice_no ?? "") ? 1 : -1) * dir;
        case "amount":
          return (Number(a.amount_base ?? 0) - Number(b.amount_base ?? 0)) * dir;
        case "file": {
          const av = a.file_number ?? "";
          const bv = b.file_number ?? "";
          if (!av && bv) return 1;
          if (av && !bv) return -1;
          return (av > bv ? 1 : av < bv ? -1 : 0) * dir;
        }
        case "date":
        default:
          return ((a.invoice_date ?? "") > (b.invoice_date ?? "") ? 1 : -1) * dir;
      }
    };
    return [...base].sort(cmp);
  }, [rows, viewMode, sortBy, sortDir]);

  const toggleSort = (col: "invoice" | "amount" | "file" | "date") => {
    if (sortBy === col) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortBy(col);
      setSortDir(col === "amount" || col === "date" ? "desc" : "asc");
    }
    setPage(0);
  };


  const pageRows = displayRows.slice(page * PAGE, (page + 1) * PAGE);
  const pageCount = Math.max(1, Math.ceil(displayRows.length / PAGE));

  const clearFilters = () => {
    setBuyer("");
    setSalesPerson("ALL");
    setCountry("ALL");
    setIso("ALL");
    setDirection("ALL");
    setLinkStatus("ALL");
    setPage(0);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-4">
      <div className="mb-5 flex items-center gap-3">
        <Button asChild variant="ghost" size="sm" className="h-9 gap-1">
          <Link to="/eqs-files">
            <ArrowLeft className="size-4" />
            Back to files
          </Link>
        </Button>
        <div className="size-10 rounded-md bg-primary/10 text-primary grid place-items-center">
          <TrendingUp className="size-5" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Sales Dashboard</h1>
          <p className="text-xs text-muted-foreground">
            Sales from EQS — link status to files
          </p>
        </div>
      </div>

      {/* Filters */}
      <Card className="p-3 mb-4">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2 items-end">
          <div>
            <label className="text-[10px] uppercase text-muted-foreground">From</label>
            <Input
              type="date"
              value={dateFrom}
              onChange={(e) => {
                setDateFrom(e.target.value);
                setPage(0);
              }}
              className="h-8"
            />
          </div>
          <div>
            <label className="text-[10px] uppercase text-muted-foreground">To</label>
            <Input
              type="date"
              value={dateTo}
              onChange={(e) => {
                setDateTo(e.target.value);
                setPage(0);
              }}
              className="h-8"
            />
          </div>
          <div>
            <label className="text-[10px] uppercase text-muted-foreground">Buyer</label>
            <Input
              placeholder="accno or name"
              value={buyer}
              onChange={(e) => {
                setBuyer(e.target.value);
                setPage(0);
              }}
              className="h-8"
            />
          </div>
          <div>
            <label className="text-[10px] uppercase text-muted-foreground">
              Sales person
            </label>
            <Select
              value={salesPerson}
              onValueChange={(v) => {
                setSalesPerson(v);
                setPage(0);
              }}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                <SelectItem value="ALL">All</SelectItem>
                {opts?.salesPersons.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-[10px] uppercase text-muted-foreground">Country</label>
            <Select
              value={country}
              onValueChange={(v) => {
                setCountry(v);
                setPage(0);
              }}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                <SelectItem value="ALL">All</SelectItem>
                {opts?.countries.map((c) => (
                  <SelectItem key={c.code} value={c.code}>
                    {c.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-[10px] uppercase text-muted-foreground">EQType</label>
            <Select
              value={iso}
              onValueChange={(v) => {
                setIso(v);
                setPage(0);
              }}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                <SelectItem value="ALL">All</SelectItem>
                {opts?.isoCodes.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-[10px] uppercase text-muted-foreground">Sales / CN</label>
            <Select value={direction} onValueChange={(v: any) => setDirection(v)}>
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All</SelectItem>
                <SelectItem value="SALE">Sales only</SelectItem>
                <SelectItem value="CN">Credit notes</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-1">
            <div className="flex-1">
              <label className="text-[10px] uppercase text-muted-foreground">Link</label>
              <Select value={linkStatus} onValueChange={(v: any) => setLinkStatus(v)}>
                <SelectTrigger className="h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All</SelectItem>
                  <SelectItem value="LINKED">Linked</SelectItem>
                  <SelectItem value="UNLINKED">Not linked</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="self-end h-8 w-8"
              onClick={clearFilters}
              title="Clear filters"
            >
              <X className="size-4" />
            </Button>
          </div>
        </div>
      </Card>

      {/* KPI */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
        <KpiCard
          label="Total sales"
          value={fmtUsd(kpi?.totalSales ?? 0)}
          sub={`${fmtInt(kpi?.containers ?? 0)} containers · ${fmtInt(kpi?.cntSale ?? 0)} invoices`}
        />
        <KpiCard
          label="Credit notes"
          value={fmtUsd(kpi?.totalCN ?? 0)}
          sub={`${fmtInt(kpi?.cntCN ?? 0)} notes`}
          danger
        />
        <KpiCard
          label="Avg price / container"
          value={fmtUsd(kpi?.avgPrice ?? 0)}
        />
        <KpiCard
          label="Linked to files"
          value={`${(kpi?.linkedPctCnt ?? 0).toFixed(1)}%`}
          sub={`by amount: ${(kpi?.linkedPctAmt ?? 0).toFixed(1)}%`}
        />
      </div>

      {/* Link split */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <LinkPill
          label="Linked"
          count={kpi?.linkedCnt ?? 0}
          amount={kpi?.linkedAmt ?? 0}
          active={linkStatus === "LINKED"}
          onClick={() => setLinkStatus(linkStatus === "LINKED" ? "ALL" : "LINKED")}
        />
        <LinkPill
          label="Not linked"
          count={kpi?.unlinkedCnt ?? 0}
          amount={kpi?.unlinkedAmt ?? 0}
          active={linkStatus === "UNLINKED"}
          onClick={() => setLinkStatus(linkStatus === "UNLINKED" ? "ALL" : "UNLINKED")}
          warn
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_300px] gap-4">
        {/* Table */}
        <Card className="overflow-hidden">
          <div className="px-3 py-2 border-b text-xs text-muted-foreground flex items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <div>
                {isLoading ? "Loading…" : `${fmtInt(displayRows.length)} ${viewMode === "unit" ? "rows" : "invoices"}`}
              </div>
              <div className="flex rounded-md border overflow-hidden">
                <button
                  onClick={() => {
                    setViewMode("invoice");
                    setSelectedIds(new Set());
                    setPage(0);
                  }}
                  className={`px-2 py-1 text-xs ${viewMode === "invoice" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
                >
                  Per invoice
                </button>
                <button
                  onClick={() => {
                    setViewMode("unit");
                    setSelectedIds(new Set());
                    setPage(0);
                  }}
                  className={`px-2 py-1 text-xs ${viewMode === "unit" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
                >
                  Per unit
                </button>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <Button
                size="sm"
                variant="ghost"
                disabled={page === 0}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                className="h-7 px-2 text-xs"
              >
                Prev
              </Button>
              <span>
                {page + 1} / {pageCount}
              </span>
              <Button
                size="sm"
                variant="ghost"
                disabled={page + 1 >= pageCount}
                onClick={() => setPage((p) => p + 1)}
                className="h-7 px-2 text-xs"
              >
                Next
              </Button>
            </div>
          </div>
          {createFromSalesEnabled && selectedIds.size > 0 && (
            <div className="px-3 py-2 border-b bg-primary/5 flex items-center justify-between gap-2 text-xs">
              <div>
                <span className="font-medium">{selectedIds.size}</span>{" "}
                {viewMode === "invoice" ? "invoice(s)" : "unit(s)"} selected
                <button
                  className="ml-3 text-muted-foreground hover:text-foreground underline"
                  onClick={() => setSelectedIds(new Set())}
                >
                  Clear
                </button>
              </div>
              <Button
                size="sm"
                onClick={() => setShowCreateDialog(true)}
                className="h-7 gap-1"
              >
                <Plus className="size-3.5" />
                Create file from selection
              </Button>
            </div>
          )}
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-muted/50 text-muted-foreground">
                <tr>
                  {createFromSalesEnabled && (
                    <Th className="w-6">
                      <Checkbox
                        checked={
                          pageRows.length > 0 &&
                          pageRows
                            .filter((r: any) => !r.file_id)
                            .every((r: any) => selectedIds.has(r.id))
                        }
                        onCheckedChange={(v) => {
                          setSelectedIds((prev) => {
                            const next = new Set(prev);
                            if (v) {
                              for (const r of pageRows) {
                                if (!r.file_id) next.add(r.id);
                              }
                            } else {
                              for (const r of pageRows) next.delete(r.id);
                            }
                            return next;
                          });
                        }}
                      />
                    </Th>
                  )}
                  <Th>
                    <SortBtn col="invoice" sortBy={sortBy} sortDir={sortDir} onClick={toggleSort}>
                      Invoice
                    </SortBtn>
                  </Th>
                  <Th>
                    <SortBtn col="date" sortBy={sortBy} sortDir={sortDir} onClick={toggleSort}>
                      Date
                    </SortBtn>
                  </Th>
                  <Th>Unit</Th>
                  <Th>EQType</Th>
                  <Th>Buyer</Th>
                  <Th>Sales person</Th>
                  <Th>Country</Th>
                  <Th className="text-right whitespace-nowrap">
                    <SortBtn col="amount" sortBy={sortBy} sortDir={sortDir} onClick={toggleSort}>
                      Amount
                    </SortBtn>
                  </Th>
                  <Th className="whitespace-nowrap">
                    <SortBtn col="file" sortBy={sortBy} sortDir={sortDir} onClick={toggleSort}>
                      File
                    </SortBtn>
                  </Th>
                </tr>
              </thead>
              <tbody>
                {pageRows.map((r: any) => {
                  const isCN = r.sale_direction === "CN" || Number(r.amount) < 0;
                  const checked = selectedIds.has(r.id);
                  return (
                    <tr key={r.id} className="border-t hover:bg-muted/30">
                      {createFromSalesEnabled && (
                        <Td>
                          {!r.file_id ? (
                            <Checkbox
                              checked={checked}
                              onCheckedChange={(v) => {
                                setSelectedIds((prev) => {
                                  const next = new Set(prev);
                                  if (v) next.add(r.id);
                                  else next.delete(r.id);
                                  return next;
                                });
                              }}
                            />
                          ) : null}
                        </Td>
                      )}
                      <Td>
                        <span className="font-mono">{r.invoice_no}</span>
                        {isCN && (
                          <Badge variant="destructive" className="ml-1 text-[9px] px-1">
                            CN
                          </Badge>
                        )}
                      </Td>
                      <Td>{r.invoice_date}</Td>
                      <Td className="font-mono">{r.unit_no}</Td>
                      <Td>{r.unit_iso}</Td>
                      <Td className="max-w-[180px] truncate" title={r.buyer_name}>
                        {r.buyer_name}
                      </Td>
                      <Td>{r.sales_person}</Td>
                      <Td title={r.sale_locn_desc ?? r.sale_locn ?? undefined}>
                        {r.sale_subregion_desc ?? r.sale_subregion}
                      </Td>
                      <Td className="text-right tabular-nums whitespace-nowrap">
                        {Number(r.amount_base).toLocaleString("en-US", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                        <span className="ml-1 text-muted-foreground">{r.currency}</span>
                      </Td>
                      <Td className="whitespace-nowrap">
                        {r.file_id ? (
                          <Link
                            to="/eqs-files/$id"
                            params={{ id: r.file_id }}
                            className="text-primary underline font-mono"
                          >
                            {r.file_number}
                          </Link>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </Td>
                    </tr>
                  );
                })}
                {pageRows.length === 0 && !isLoading && (
                  <tr>
                    <td colSpan={createFromSalesEnabled ? 10 : 9} className="p-6 text-center text-muted-foreground">
                      No sales for these filters
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>


        {/* Side aggregates */}
        <div className="space-y-3">
          <AggCard
            title="Top buyers"
            items={(data?.topBuyers ?? []).map((b: any) => ({
              key: b.accno,
              label: b.name,
              sub: b.accno,
              value: fmtUsd(b.amt),
              active: buyer === b.accno,
              onClick: () => {
                setBuyer(buyer === b.accno ? "" : b.accno);
                setPage(0);
              },
            }))}
          />
          <AggCard
            title="Sales persons"
            items={(data?.topSP ?? []).slice(0, 10).map((s: any) => ({
              key: s.sp,
              label: s.sp,
              sub: `${s.cnt}`,
              value: fmtUsd(s.amt),
              active: salesPerson === s.sp,
              onClick: () => {
                setSalesPerson(salesPerson === s.sp ? "ALL" : s.sp);
                setPage(0);
              },
            }))}
          />
          <AggCard
            title="By country"
            items={(data?.byCountry ?? []).slice(0, 12).map((c: any) => ({
              key: c.code,
              label: c.country,
              sub: `${c.cnt}`,
              value: fmtUsd(c.amt),
              active: country === c.code,
              onClick: () => {
                setCountry(country === c.code ? "ALL" : c.code);
                setPage(0);
              },
            }))}
          />
          <AggCard
            title="By EQType"
            items={(data?.byIso ?? []).map((c: any) => ({
              key: c.iso,
              label: c.iso,
              sub: `${c.cnt}`,
              value: fmtUsd(c.amt),
              active: iso === c.iso,
              onClick: () => {
                setIso(iso === c.iso ? "ALL" : c.iso);
                setPage(0);
              },
            }))}
          />
        </div>
      </div>

      {createFromSalesEnabled && showCreateDialog && (() => {
        const ids = new Set<string>();
        for (const r of displayRows as any[]) {
          if (!selectedIds.has(r.id)) continue;
          for (const id of (r._ids ?? []) as string[]) ids.add(id);
        }
        const saleIds = Array.from(ids);
        if (saleIds.length === 0) {
          setShowCreateDialog(false);
          return null;
        }
        return (
          <CreateFileFromSalesDialog
            saleIds={saleIds}
            onClose={() => setShowCreateDialog(false)}
            onCreated={(fileId) => {
              setShowCreateDialog(false);
              setSelectedIds(new Set());
              navigate({ to: "/eqs-files/$id", params: { id: fileId } });
            }}
          />
        );
      })()}
    </div>
  );
}

function SortBtn({
  col,
  sortBy,
  sortDir,
  onClick,
  children,
}: {
  col: "invoice" | "amount" | "file" | "date";
  sortBy: string;
  sortDir: "asc" | "desc";
  onClick: (c: "invoice" | "amount" | "file" | "date") => void;
  children: React.ReactNode;
}) {
  const active = sortBy === col;
  return (
    <button
      onClick={() => onClick(col)}
      className={`inline-flex items-center gap-0.5 hover:text-foreground ${active ? "text-foreground" : ""}`}
    >
      {children}
      {active &&
        (sortDir === "asc" ? (
          <ArrowUp className="size-3" />
        ) : (
          <ArrowDown className="size-3" />
        ))}
    </button>
  );
}


function KpiCard({
  label,
  value,
  sub,
  danger,
}: {
  label: string;
  value: string;
  sub?: string;
  danger?: boolean;
}) {
  return (
    <Card className="p-3">
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <div
        className={`text-xl font-semibold mt-1 tabular-nums ${
          danger ? "text-destructive" : ""
        }`}
      >
        {value}
      </div>
      {sub && <div className="text-[11px] text-muted-foreground mt-0.5">{sub}</div>}
    </Card>
  );
}

function LinkPill({
  label,
  count,
  amount,
  active,
  warn,
  onClick,
}: {
  label: string;
  count: number;
  amount: number;
  active: boolean;
  warn?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`text-left rounded-xl border p-4 transition-all ${
        active
          ? "border-primary bg-primary/5"
          : "border-border hover:border-primary/40"
      }`}
    >
      <div className="flex items-baseline justify-between">
        <div
          className={`text-sm font-medium ${
            warn ? "text-amber-600 dark:text-amber-400" : ""
          }`}
        >
          {label}
        </div>
        <div className="text-xs text-muted-foreground">click to filter</div>
      </div>
      <div className="mt-1 flex items-baseline gap-3">
        <div className="text-2xl font-semibold tabular-nums">{fmtInt(count)}</div>
        <div className="text-sm text-muted-foreground tabular-nums">
          {fmtUsd(amount)}
        </div>
      </div>
    </button>
  );
}

function AggCard({
  title,
  items,
}: {
  title: string;
  items: {
    key?: string;
    label: string;
    sub?: string;
    value: string;
    active?: boolean;
    onClick?: () => void;
  }[];
}) {
  return (
    <Card className="p-3">
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground mb-2">
        {title}
      </div>
      <div className="space-y-1">
        {items.length === 0 && (
          <div className="text-xs text-muted-foreground">No data</div>
        )}
        {items.map((it, i) => {
          const inner = (
            <>
              <div className="min-w-0 text-left">
                <div className="truncate" title={it.label}>
                  {it.label}
                </div>
                {it.sub && (
                  <div className="text-[10px] text-muted-foreground font-mono">
                    {it.sub}
                  </div>
                )}
              </div>
              <div className="tabular-nums shrink-0">{it.value}</div>
            </>
          );
          if (it.onClick) {
            return (
              <button
                key={it.key ?? i}
                onClick={it.onClick}
                className={`w-full flex items-center justify-between gap-2 text-xs rounded px-1.5 py-1 transition-colors ${
                  it.active
                    ? "bg-primary/10 ring-1 ring-primary/40"
                    : "hover:bg-muted/60"
                }`}
              >
                {inner}
              </button>
            );
          }
          return (
            <div
              key={it.key ?? i}
              className="flex items-center justify-between gap-2 text-xs px-1.5 py-1"
            >
              {inner}
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function Th({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <th
      className={`text-left font-medium px-2 py-1.5 whitespace-nowrap ${className ?? ""}`}
    >
      {children}
    </th>
  );
}
function Td({
  children,
  className,
  title,
}: {
  children: React.ReactNode;
  className?: string;
  title?: string;
}) {
  return (
    <td className={`px-2 py-1 whitespace-nowrap ${className ?? ""}`} title={title}>
      {children}
    </td>
  );
}
