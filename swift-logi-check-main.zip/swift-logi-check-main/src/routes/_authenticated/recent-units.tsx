import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, useMemo, Fragment } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listRecentUnitsGlobal, getLocationsForFilter, getRecentUnitsFilterOptions } from "@/lib/files.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Plus, ExternalLink, Boxes, Check, ChevronsUpDown, X } from "lucide-react";
import { CreateFileFromBookingDialog } from "@/components/RecentUnitsDialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { cn } from "@/lib/utils";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/recent-units")({
  component: RecentUnitsPage,
  head: () => ({
    meta: [{ title: "Recent Units" }, { name: "description", content: "Recent Units" }],
  }),
});

type LocOption = {
  value: string; // "loc:CODE" or "country:SUBREGION_ID"
  kind: "loc" | "country";
  label: string;
  search: string;
};

function RecentUnitsPage() {
  const navigate = useNavigate();
  const list = useServerFn(listRecentUnitsGlobal);
  const getLocs = useServerFn(getLocationsForFilter);
  const getFilterOpts = useServerFn(getRecentUnitsFilterOptions);
  const [q, setQ] = useState("");
  const [linkStatus, setLinkStatus] = useState<"all" | "linked" | "unlinked">("all");
  const [createForBooking, setCreateForBooking] = useState<string | null>(null);

  const [fromSel, setFromSel] = useState<string | null>(null);
  const [toSel, setToSel] = useState<string | null>(null);
  const [statusSel, setStatusSel] = useState<string[]>([]);
  const [typeSel, setTypeSel] = useState<string[]>([]);
  const [customerSel, setCustomerSel] = useState<string[]>([]);

  // Split fromSel/toSel into locn vs subregion arrays
  const splitSel = (sel: string | null): { locn: string[]; sub: string[] } => {
    if (!sel) return { locn: [], sub: [] };
    if (sel.startsWith("loc:")) return { locn: [sel.slice(4)], sub: [] };
    if (sel.startsWith("country:")) return { locn: [], sub: [sel.slice(8)] };
    return { locn: [], sub: [] };
  };
  const fromParts = splitSel(fromSel);
  const toParts = splitSel(toSel);

  const recentQ = useQuery({
    queryKey: [
      "recent-units-global",
      q,
      linkStatus,
      statusSel,
      typeSel,
      customerSel,
      fromSel,
      toSel,
    ],
    queryFn: () =>
      list({
        data: {
          q: q || undefined,
          only_unlinked: linkStatus === "unlinked",
          only_linked: linkStatus === "linked",
          status: statusSel.length ? statusSel : undefined,
          iso_codes: typeSel.length ? typeSel : undefined,
          customers: customerSel.length ? customerSel : undefined,
          from_locn: fromParts.locn.length ? fromParts.locn : undefined,
          from_subregion: fromParts.sub.length ? fromParts.sub : undefined,
          to_locn: toParts.locn.length ? toParts.locn : undefined,
          to_subregion: toParts.sub.length ? toParts.sub : undefined,
        },
      }),
  });

  const locsQ = useQuery({
    queryKey: ["locations-filter"],
    queryFn: () => getLocs(),
    staleTime: Infinity,
  });

  const filterOptsQ = useQuery({
    queryKey: ["recent-units-filter-options"],
    queryFn: () => getFilterOpts(),
    staleTime: Infinity,
  });

  const items = (recentQ.data?.items ?? []) as any[];

  const fromOptions = useMemo<LocOption[]>(
    () => buildLocOptions(locsQ.data?.locations ?? []),
    [locsQ.data],
  );
  const toOptions = fromOptions;

  const statusOptions = useMemo(
    () => filterOptsQ.data?.statuses ?? [],
    [filterOptsQ.data],
  );
  const typeOptions = useMemo(
    () => filterOptsQ.data?.isoCodes ?? [],
    [filterOptsQ.data],
  );
  const customerOptions = useMemo(
    () => (filterOptsQ.data?.customers ?? []) as string[],
    [filterOptsQ.data],
  );

  const grouped = useMemo(() => {
    const map = new Map<string, any[]>();
    for (const it of items) {
      const k = it.booking_no ?? "—";
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(it);
    }
    return map;
  }, [items]);

  const hasAnyFilter = !!fromSel || !!toSel || statusSel.length > 0 || typeSel.length > 0 || customerSel.length > 0;

  return (
    <div className="w-full px-6 py-6">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" asChild>
            <Link to="/eqs-files">
              <ArrowLeft className="size-4 mr-1" /> Back to EQS Files
            </Link>
          </Button>
          <div className="flex items-center gap-2">
            <Boxes className="size-5 text-primary" />
            <h1 className="text-xl font-semibold tracking-tight">Recent units</h1>
          </div>
        </div>
      </div>

      <div className="flex gap-2 items-center mb-3 flex-wrap">
        <Input
          placeholder="Filter by unit, booking, customer, internal ref, location…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="flex-1 min-w-[220px] max-w-md h-8"
        />
        <Select value={linkStatus} onValueChange={(v) => setLinkStatus(v as "all" | "linked" | "unlinked")}>
          <SelectTrigger className="h-8 w-[140px]" aria-label="Link status">
            <SelectValue placeholder="Link status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All units</SelectItem>
            <SelectItem value="linked">Linked</SelectItem>
            <SelectItem value="unlinked">Unlinked</SelectItem>
          </SelectContent>
        </Select>
        <LocCombo label="From" value={fromSel} onChange={setFromSel} options={fromOptions} />
        <LocCombo label="To" value={toSel} onChange={setToSel} options={toOptions} />
        <MultiCombo label="Status" values={statusSel} onChange={setStatusSel} options={statusOptions} />
        <MultiCombo label="Type" values={typeSel} onChange={setTypeSel} options={typeOptions} />
        <MultiCombo label="Customer" values={customerSel} onChange={setCustomerSel} options={customerOptions} />
        {hasAnyFilter && (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              setFromSel(null);
              setToSel(null);
              setStatusSel([]);
              setTypeSel([]);
              setCustomerSel([]);
            }}
          >
            <X className="h-3 w-3 mr-1" /> Clear
          </Button>
        )}
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        {recentQ.isLoading && (
          <div className="p-6 text-center text-muted-foreground text-sm">Loading…</div>
        )}
        {!recentQ.isLoading && grouped.size === 0 && (
          <div className="p-6 text-center text-muted-foreground text-sm">No units found.</div>
        )}
        {grouped.size > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-muted/50 text-muted-foreground">
                <tr>
                  <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">Unit</th>
                  <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">Type</th>
                  <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">OnHire</th>
                  <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">From</th>
                  <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">To</th>
                  <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">Status</th>
                  <th className="text-left font-medium px-2 py-1.5 whitespace-nowrap">File</th>
                  <th className="px-2 py-1.5" />
                </tr>
              </thead>
              <tbody>
                {Array.from(grouped.entries()).map(([bk, units]) => {
                  const first = units[0];
                  const linkedCount = units.filter((u: any) => u.linked_file_id).length;
                  const allLinked = linkedCount === units.length;
                  return (
                    <Fragment key={`group-${bk}`}>
                      <tr key={`bk-${bk}`} className="border-t border-border bg-muted/20">
                        <td colSpan={7} className="px-2 py-1.5">
                          <span className="font-semibold">Booking </span>
                          <span className="font-mono">{bk}</span>
                          <span className="text-muted-foreground ml-2">
                            · {first.locn_pol_name ?? first.locn_pol ?? "—"} →{" "}
                            {first.do_locn_name ?? first.do_locn ?? first.locn_pod_name ?? first.locn_pod ?? "—"}
                          </span>
                          {first.accname && (
                            <span className="ml-2 text-muted-foreground">· {first.accname}{first.accno ? ` (${first.accno})` : ""}</span>
                          )}
                          {first.internal_ref && (
                            <span className="ml-2 text-muted-foreground">· ref {first.internal_ref}</span>
                          )}

                          <span className="ml-2 text-muted-foreground">
                            ({units.length} unit{units.length === 1 ? "" : "s"}
                            {linkedCount > 0 ? `, ${linkedCount} linked` : ""})
                          </span>
                        </td>
                        <td className="px-2 py-1 text-right">
                          {!allLinked && bk !== "—" && (
                            <Button
                              size="sm"
                              variant="secondary"
                              className="h-7 px-2 text-xs"
                              onClick={() => setCreateForBooking(bk)}
                            >
                              <Plus className="h-3 w-3 mr-1" />
                              Create file from booking
                            </Button>
                          )}
                        </td>
                      </tr>
                      {units.map((u: any) => (
                        <tr key={`${u.unit_no}-${bk}`} className="border-t border-border hover:bg-muted/30">
                          <td className="px-2 py-1 font-mono whitespace-nowrap">{u.unit_no}</td>
                          <td className="px-2 py-1 font-mono whitespace-nowrap">{u.iso_code ?? "—"}</td>
                          <td className="px-2 py-1 font-mono whitespace-nowrap">{u.onhire_date ?? "—"}</td>
                          <td className="px-2 py-1">
                            {u.locn_pol_name ?? "—"}
                            {u.locn_pol && (
                              <span className="ml-1 font-mono text-muted-foreground">({u.locn_pol})</span>
                            )}
                          </td>
                          <td className="px-2 py-1">
                            {u.do_locn_name ?? u.locn_pod_name ?? "—"}
                            {(u.do_locn ?? u.locn_pod) && (
                              <span className="ml-1 font-mono text-muted-foreground">
                                ({u.do_locn ?? u.locn_pod})
                              </span>
                            )}
                          </td>
                          <td className="px-2 py-1 whitespace-nowrap">{u.status ?? "—"}</td>
                          <td className="px-2 py-1 whitespace-nowrap">
                            {u.linked_file_number ? (
                              <button
                                className="text-primary hover:underline font-mono inline-flex items-center gap-1"
                                onClick={() =>
                                  navigate({
                                    to: "/eqs-files/$id",
                                    params: { id: u.linked_file_id },
                                  })
                                }
                              >
                                {u.linked_file_number}
                                <ExternalLink className="h-3 w-3" />
                              </button>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </td>
                          <td />
                        </tr>
                      ))}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {createForBooking && (
        <CreateFileFromBookingDialog
          bookingNo={createForBooking}
          onClose={() => setCreateForBooking(null)}
          onCreated={(fileId) => {
            setCreateForBooking(null);
            navigate({ to: "/eqs-files/$id", params: { id: fileId } });
          }}
        />
      )}
    </div>
  );
}

function buildLocOptions(
  allLocs: { locn_id: string; locn_desc: string | null; subregion_id: string | null; subregion_desc: string | null }[],
): LocOption[] {
  // Countries (subregions) — all known
  const countryMap = new Map<string, string>();
  for (const l of allLocs) {
    if (l.subregion_id) countryMap.set(l.subregion_id, l.subregion_desc ?? l.subregion_id);
  }
  const countries: LocOption[] = Array.from(countryMap.entries())
    .map(([id, label]) => ({
      value: `country:${id}`,
      kind: "country" as const,
      label: `🌐 ${label}`,
      search: `${label} ${id}`.toLowerCase(),
    }))
    .sort((a, b) => a.label.localeCompare(b.label));

  const locs: LocOption[] = allLocs
    .filter((l) => l.locn_id)
    .map((l) => {
      const name = l.locn_desc ?? l.locn_id;
      return {
        value: `loc:${l.locn_id}`,
        kind: "loc" as const,
        label: `${l.locn_id} — ${name}`,
        search: `${l.locn_id} ${name}`.toLowerCase(),
      };
    })
    .sort((a, b) => a.label.localeCompare(b.label));

  return [...countries, ...locs];
}

function LocCombo({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string | null;
  onChange: (v: string | null) => void;
  options: LocOption[];
}) {
  const [open, setOpen] = useState(false);
  const current = value ? options.find((o) => o.value === value) : null;
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="h-8 justify-between min-w-[140px] max-w-[260px]">
          <span className="truncate">
            <span className="text-muted-foreground">{label}:</span>{" "}
            {current ? current.label : "Any"}
          </span>
          <ChevronsUpDown className="h-3 w-3 opacity-50 ml-1 shrink-0" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[320px] p-0" align="start">
        <Command
          filter={(val, search) => {
            const opt = options.find((o) => o.value === val);
            if (!opt) return 0;
            return opt.search.includes(search.toLowerCase()) ? 1 : 0;
          }}
        >
          <CommandInput placeholder={`Search ${label.toLowerCase()}…`} />
          <CommandList>
            <CommandEmpty>No results.</CommandEmpty>
            {value && (
              <CommandGroup>
                <CommandItem
                  value="__clear__"
                  onSelect={() => {
                    onChange(null);
                    setOpen(false);
                  }}
                >
                  <X className="h-3 w-3 mr-2" /> Clear
                </CommandItem>
              </CommandGroup>
            )}
            <CommandGroup>
              {options.map((o) => (
                <CommandItem
                  key={o.value}
                  value={o.value}
                  onSelect={() => {
                    onChange(o.value);
                    setOpen(false);
                  }}
                >
                  <Check className={cn("mr-2 h-3 w-3", value === o.value ? "opacity-100" : "opacity-0")} />
                  {o.label}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

function MultiCombo({
  label,
  values,
  onChange,
  options,
}: {
  label: string;
  values: string[];
  onChange: (v: string[]) => void;
  options: string[];
}) {
  const [open, setOpen] = useState(false);
  const summary = values.length === 0 ? "Any" : values.length === 1 ? values[0] : `${values.length} selected`;
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="h-8 justify-between min-w-[120px] max-w-[220px]">
          <span className="truncate">
            <span className="text-muted-foreground">{label}:</span> {summary}
          </span>
          <ChevronsUpDown className="h-3 w-3 opacity-50 ml-1 shrink-0" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[240px] p-0" align="start">
        <Command>
          <CommandInput placeholder={`Search ${label.toLowerCase()}…`} />
          <CommandList>
            <CommandEmpty>No results.</CommandEmpty>
            {values.length > 0 && (
              <CommandGroup>
                <CommandItem value="__clear__" onSelect={() => onChange([])}>
                  <X className="h-3 w-3 mr-2" /> Clear
                </CommandItem>
              </CommandGroup>
            )}
            <CommandGroup>
              {options.map((o) => {
                const checked = values.includes(o);
                return (
                  <CommandItem
                    key={o}
                    value={o}
                    onSelect={() => {
                      onChange(checked ? values.filter((v) => v !== o) : [...values, o]);
                    }}
                  >
                    <Check className={cn("mr-2 h-3 w-3", checked ? "opacity-100" : "opacity-0")} />
                    {o}
                  </CommandItem>
                );
              })}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
