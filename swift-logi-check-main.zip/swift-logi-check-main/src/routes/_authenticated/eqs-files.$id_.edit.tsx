import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  getFile,
  updateFile,
  searchBuyers,
  searchLocations,
  listCountries,
} from "@/lib/files.functions";
import { listGrades } from "@/lib/grades.functions";
import { listSalesPersons } from "@/lib/salesPersons.functions";
import { ContainerTypesEditor, type CTRow } from "@/components/ContainerTypesEditor";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Plus, X } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/eqs-files/$id_/edit")({
  component: EditFilePage,
  head: () => ({ meta: [{ title: "Edit EQS File" }] }),
});

const CONTAINER_TYPE_OPTIONS = [
  "20DV", "20DC", "20HC", "20RF", "20OT", "20FR", "20TK",
  "40DV", "40DC", "40HC", "40RF", "40HR", "40OT", "40FR", "40NOR",
  "45HC", "45HR",
];

function EditFilePage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const fetchFile = useServerFn(getFile);
  const fetchBuyers = useServerFn(searchBuyers);
  const fetchLocations = useServerFn(searchLocations);
  const fetchSPs = useServerFn(listSalesPersons);
  const fetchCountries = useServerFn(listCountries);
  const fetchGrades = useServerFn(listGrades);
  const update = useServerFn(updateFile);

  const fileQ = useQuery({
    queryKey: ["file", id],
    queryFn: () => fetchFile({ data: { id } }),
  });
  const { data: sps } = useQuery({
    queryKey: ["sales-persons"],
    queryFn: () => fetchSPs(),
  });
  const { data: countries } = useQuery({
    queryKey: ["countries"],
    queryFn: () => fetchCountries(),
  });
  const { data: grades } = useQuery({
    queryKey: ["equipment-grades"],
    queryFn: () => fetchGrades(),
  });
  const activeGrades = (grades?.items ?? []).filter((g: any) => g.is_active);

  const [form, setForm] = useState({
    customer_accno: "",
    customer_name: "",
    lessee_order: "",
    origin_country_code: "",
    dest_country_code: "",
    origin_subregion: "",
    dest_subregion: "",
    origin_locn: "",
    dest_locn: "",
    planned_departure_date: "",
    planned_arrival_date: "",
    business_date: "",
    sales_person_id: "",
    notes: "",
  });
  const [containerTypes, setContainerTypes] = useState<CTRow[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    if (!fileQ.data || hydrated) return;
    const f: any = fileQ.data.file;
    setForm({
      customer_accno: f.customer_accno ?? "",
      customer_name: f.customer_name ?? "",
      lessee_order: f.lessee_order ?? "",
      origin_country_code: f.origin_country_code ?? "",
      dest_country_code: f.dest_country_code ?? "",
      origin_subregion: f.origin_subregion ?? "",
      dest_subregion: f.dest_subregion ?? "",
      origin_locn: f.origin_locn ?? "",
      dest_locn: f.dest_locn ?? "",
      planned_departure_date: f.planned_departure_date ?? "",
      planned_arrival_date: f.planned_arrival_date ?? "",
      business_date: f.business_date ?? "",
      sales_person_id: f.sales_person_id ?? "",
      notes: f.notes ?? "",
    });
    setContainerTypes(
      (fileQ.data.containerTypes ?? []).map((c: any) => ({
        container_type: c.container_type,
        planned_qty: c.planned_qty,
        grade: c.grade ?? null,
        daily_rate: c.daily_rate ?? null,
        repl_value: c.repl_value ?? null,
        free_min_days: c.free_min_days ?? null,
        charge1_code: c.charge1_code ?? null,
        charge1_amount: c.charge1_amount ?? null,
        charge2_code: c.charge2_code ?? null,
        charge2_amount: c.charge2_amount ?? null,
        charge3_code: c.charge3_code ?? null,
        charge3_amount: c.charge3_amount ?? null,
        charge4_code: c.charge4_code ?? null,
        charge4_amount: c.charge4_amount ?? null,
        cost1_code: c.cost1_code ?? null,
        cost1_currency: c.cost1_currency ?? null,
        cost1_amount: c.cost1_amount ?? null,
        cost1_supplier_accno: c.cost1_supplier_accno ?? null,
        cost2_code: c.cost2_code ?? null,
        cost2_currency: c.cost2_currency ?? null,
        cost2_amount: c.cost2_amount ?? null,
        cost2_supplier_accno: c.cost2_supplier_accno ?? null,
      })),
    );
    setHydrated(true);
  }, [fileQ.data, hydrated]);

  const [buyerQ, setBuyerQ] = useState("");
  const [originQ, setOriginQ] = useState("");
  const [destQ, setDestQ] = useState("");

  const buyers = useQuery({
    queryKey: ["buyers", buyerQ],
    queryFn: () => fetchBuyers({ data: { q: buyerQ } }),
    enabled: buyerQ.length >= 2,
  });
  const origins = useQuery({
    queryKey: ["loc", "o", originQ, form.origin_country_code],
    queryFn: () =>
      fetchLocations({
        data: { q: originQ, country_code: form.origin_country_code || undefined },
      }),
    enabled: originQ.length >= 1,
  });
  const dests = useQuery({
    queryKey: ["loc", "d", destQ, form.dest_country_code],
    queryFn: () =>
      fetchLocations({
        data: { q: destQ, country_code: form.dest_country_code || undefined },
      }),
    enabled: destQ.length >= 1,
  });

  const mutate = useMutation({
    mutationFn: () =>
      update({
        data: {
          id,
          customer_accno: form.customer_accno || null,
          customer_name: form.customer_name || null,
          lessee_order: form.lessee_order || null,
          origin_country_code: form.origin_country_code || null,
          dest_country_code: form.dest_country_code || null,
          origin_subregion: form.origin_subregion || null,
          dest_subregion: form.dest_subregion || null,
          origin_locn: form.origin_locn || null,
          dest_locn: form.dest_locn || null,
          planned_departure_date: form.planned_departure_date || null,
          planned_arrival_date: form.planned_arrival_date || null,
          business_date: form.business_date || null,
          sales_person_id: form.sales_person_id || null,
          notes: form.notes || null,
          container_types: containerTypes.filter(
            (c) => c.container_type && c.planned_qty > 0,
          ),
        },
      }),
    onSuccess: () => {
      toast.success("File updated");
      qc.invalidateQueries({ queryKey: ["file", id] });
      navigate({ to: "/eqs-files/$id", params: { id } });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  if (fileQ.isLoading || !hydrated) return <div className="p-8">Loading…</div>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => navigate({ to: "/eqs-files/$id", params: { id } })}
        className="mb-4"
      >
        <ArrowLeft className="size-4 mr-1" /> Back to file
      </Button>
      <h1 className="text-2xl font-semibold mb-6">Edit File</h1>

      <div className="space-y-5 rounded-xl border border-border bg-card p-6">
        <div>
          <Label>Customer</Label>
          <Input
            placeholder="Search by accno or name"
            value={buyerQ}
            onChange={(e) => setBuyerQ(e.target.value)}
          />
          {form.customer_accno && (
            <div className="text-xs mt-1 text-muted-foreground">
              Selected: <span className="font-mono">{form.customer_accno}</span> —{" "}
              {form.customer_name}{" "}
              <button
                type="button"
                className="underline ml-2"
                onClick={() =>
                  setForm({ ...form, customer_accno: "", customer_name: "" })
                }
              >
                clear
              </button>
            </div>
          )}
          {buyers.data && buyerQ.length >= 2 && (
            <div className="mt-2 max-h-48 overflow-auto border border-border rounded">
              {buyers.data.items.map((b: any) => (
                <button
                  key={b.accno}
                  type="button"
                  className="w-full text-left px-3 py-2 hover:bg-muted text-sm border-b border-border last:border-0"
                  onClick={() => {
                    setForm({
                      ...form,
                      customer_accno: b.accno,
                      customer_name: b.customer_name,
                    });
                    setBuyerQ("");
                  }}
                >
                  <span className="font-mono">{b.accno}</span> — {b.customer_name}{" "}
                  <span className="text-muted-foreground text-xs">
                    ({b.country_code}, {b.sale_count}{" "}
                    {b.source === "lessee" ? "leases" : b.source === "both" ? "sales+leases" : "sales"})
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div>
          <Label>Lessee order</Label>
          <Input
            value={form.lessee_order}
            onChange={(e) => setForm({ ...form, lessee_order: e.target.value })}
            placeholder="Lessee PO / order reference"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <CountryLocationField
            title="Origin"
            countries={countries?.items ?? []}
            country={form.origin_country_code}
            onCountry={(c) => setForm((f) => ({ ...f, origin_country_code: c }))}
            locnQ={originQ}
            setLocnQ={setOriginQ}
            locnValue={form.origin_locn}
            results={origins.data?.items ?? []}
            onPickLoc={(loc) =>
              setForm((f) => ({
                ...f,
                origin_country_code: f.origin_country_code || loc.country_code,
                origin_locn: loc.locn_id,
                origin_subregion: loc.subregion_id,
              }))
            }
            onClearLoc={() =>
              setForm((f) => ({ ...f, origin_locn: "", origin_subregion: "" }))
            }
          />
          <CountryLocationField
            title="Destination"
            countries={countries?.items ?? []}
            country={form.dest_country_code}
            onCountry={(c) => setForm((f) => ({ ...f, dest_country_code: c }))}
            locnQ={destQ}
            setLocnQ={setDestQ}
            locnValue={form.dest_locn}
            results={dests.data?.items ?? []}
            onPickLoc={(loc) =>
              setForm((f) => ({
                ...f,
                dest_country_code: f.dest_country_code || loc.country_code,
                dest_locn: loc.locn_id,
                dest_subregion: loc.subregion_id,
              }))
            }
            onClearLoc={() =>
              setForm((f) => ({ ...f, dest_locn: "", dest_subregion: "" }))
            }
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label>Planned departure</Label>
            <Input
              type="date"
              value={form.planned_departure_date}
              onChange={(e) =>
                setForm({ ...form, planned_departure_date: e.target.value })
              }
            />
          </div>
          <div>
            <Label>Planned arrival</Label>
            <Input
              type="date"
              value={form.planned_arrival_date}
              onChange={(e) =>
                setForm({ ...form, planned_arrival_date: e.target.value })
              }
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label>Sales Person</Label>
            <Select
              value={form.sales_person_id}
              onValueChange={(v) => setForm({ ...form, sales_person_id: v })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select…" />
              </SelectTrigger>
              <SelectContent>
                {sps?.items?.filter((s: any) => s.is_active).map((s: any) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.full_name}
                    {s.departments?.code ? ` — ${s.departments.code}` : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Business Date</Label>
            <Input
              type="date"
              value={form.business_date}
              onChange={(e) => setForm({ ...form, business_date: e.target.value })}
            />
          </div>
        </div>

        <ContainerTypesEditor
          rows={containerTypes}
          setRows={setContainerTypes}
          containerTypeOptions={CONTAINER_TYPE_OPTIONS}
          grades={activeGrades.map((g: any) => ({ code: g.code, label: g.label }))}
          allowEmpty
        />

        <div>
          <Label>Notes</Label>
          <Textarea
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            rows={3}
          />
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button
            variant="outline"
            onClick={() => navigate({ to: "/eqs-files/$id", params: { id } })}
          >
            Cancel
          </Button>
          <Button onClick={() => mutate.mutate()} disabled={mutate.isPending}>
            {mutate.isPending ? "Saving…" : "Save changes"}
          </Button>
        </div>
      </div>
    </div>
  );
}

function CountryLocationField({
  title,
  countries,
  country,
  onCountry,
  locnQ,
  setLocnQ,
  locnValue,
  results,
  onPickLoc,
  onClearLoc,
}: {
  title: string;
  countries: { country_code: string; country_name: string }[];
  country: string;
  onCountry: (c: string) => void;
  locnQ: string;
  setLocnQ: (s: string) => void;
  locnValue: string;
  results: any[];
  onPickLoc: (loc: any) => void;
  onClearLoc: () => void;
}) {
  return (
    <div className="rounded-lg border border-border p-3 space-y-3">
      <div className="text-sm font-medium">{title}</div>
      <div>
        <Label>Country *</Label>
        <Select value={country} onValueChange={onCountry}>
          <SelectTrigger>
            <SelectValue placeholder="Select country…" />
          </SelectTrigger>
          <SelectContent className="max-h-72">
            {countries.map((c) => (
              <SelectItem key={c.country_code} value={c.country_code}>
                {c.country_name} ({c.country_code})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Location</Label>
        <Input
          placeholder="Search location (optional)"
          value={locnQ}
          onChange={(e) => setLocnQ(e.target.value)}
        />
        {locnValue && (
          <div className="text-xs mt-1 flex items-center gap-2">
            <span className="text-muted-foreground">
              Selected: <span className="font-mono">{locnValue}</span>
            </span>
            <button
              type="button"
              className="text-xs underline text-muted-foreground"
              onClick={() => {
                onClearLoc();
                setLocnQ("");
              }}
            >
              clear
            </button>
          </div>
        )}
        {locnQ.length >= 1 && results.length > 0 && (
          <div className="mt-2 max-h-40 overflow-auto border border-border rounded">
            {results.map((l: any) => (
              <button
                key={l.locn_id}
                type="button"
                className="w-full text-left px-3 py-2 hover:bg-muted text-sm border-b border-border last:border-0"
                onClick={() => {
                  onPickLoc(l);
                  setLocnQ("");
                }}
              >
                <span className="font-mono">{l.locn_id}</span> — {l.locn_desc}{" "}
                <span className="text-muted-foreground text-xs">
                  ({l.country_code} · {l.subregion_id})
                </span>
              </button>
            ))}
          </div>
        )}
        {locnQ.length >= 1 && results.length === 0 && (
          <div className="text-xs mt-1 text-muted-foreground">No matches</div>
        )}
      </div>
    </div>
  );
}
