import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload,
  FileText,
  Image as ImageIcon,
  CheckCircle2,
  Loader2,
  Activity,
  Clock,
  Layers,
  Copy,
  Search,
  ArrowUpDown,
  ChevronRight,
  FileSpreadsheet,
  Play,
  Square,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import { toast } from "sonner";

import { cn } from "@/lib/utils";
import { extractCertificate, type ExtractedCertificate } from "@/lib/certificateExtractor.functions";
import { listApiKeys } from "@/lib/containerExtractorKeys.functions";
import { useQuery } from "@tanstack/react-query";
import { useT as useTfn } from "@/i18n/i18n";
import { useVisibleColumns } from "@/lib/containerExtractorSettings";

export const Route = createFileRoute("/_authenticated/container-extractor")({
  component: ContainerExtractorPage,
  head: () => ({
    meta: [
      { title: "Container Certificate AI Extractor" },
      {
        name: "description",
        content:
          "Extract structured container certificate data from PDFs and images using Gemini AI.",
      },
    ],
  }),
});

type JobStatus = "queued" | "uploading" | "processing" | "extracting" | "completed" | "failed";

type Job = {
  id: string;
  file: File;
  status: JobStatus;
  progress: number;
  result?: ExtractedCertificate;
  error?: string;
  elapsedMs?: number;
  startedAt: number;
};

const FIELDS: { key: keyof ExtractedCertificate; w?: string }[] = [
  { key: "container_number", w: "min-w-[140px]" },
  { key: "equipment", w: "min-w-[120px]" },
  { key: "supplier", w: "min-w-[140px]" },
  { key: "manufacturer", w: "min-w-[160px]" },
  { key: "gross_weight", w: "min-w-[110px]" },
  { key: "tare_weight", w: "min-w-[110px]" },
  { key: "payload", w: "min-w-[110px]" },
  { key: "csc_number", w: "min-w-[140px]" },
  { key: "csc_valid_to", w: "min-w-[120px]" },
  { key: "iso_code", w: "min-w-[90px]" },
  { key: "year", w: "min-w-[80px]" },
];
const FIELD_BY_KEY = Object.fromEntries(FIELDS.map((f) => [f.key, f])) as Record<
  keyof ExtractedCertificate,
  (typeof FIELDS)[number]
>;

const ACCEPT = ["application/pdf", "image/jpeg", "image/png", "image/webp"];

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => {
      const s = String(r.result);
      const i = s.indexOf(",");
      resolve(i >= 0 ? s.slice(i + 1) : s);
    };
    r.onerror = () => reject(r.error);
    r.readAsDataURL(file);
  });
}

function ContainerExtractorPage() {
  const runExtract = useServerFn(extractCertificate);
  const t = useTfn();
  const [visibleColumns] = useVisibleColumns();
  const fetchKeys = useServerFn(listApiKeys);
  const { data: apiKeys = [] } = useQuery({ queryKey: ["cci-api-keys"], queryFn: () => fetchKeys() });
  const visibleFields = useMemo(
    () => visibleColumns.map((k) => FIELD_BY_KEY[k]).filter(Boolean),
    [visibleColumns],
  );
  const [jobs, setJobs] = useState<Job[]>([]);
  const [dragging, setDragging] = useState(false);
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<keyof ExtractedCertificate | null>(null);
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [queueCollapsed, setQueueCollapsed] = useState(false);
  const [isRunning, setIsRunning] = useState(true);
  const runningRef = useRef(true);
  const inputRef = useRef<HTMLInputElement>(null);

  const stats = useMemo(() => {
    const total = jobs.length;
    const completed = jobs.filter((j) => j.status === "completed").length;
    const failed = jobs.filter((j) => j.status === "failed").length;
    const active = jobs.filter((j) =>
      ["queued", "uploading", "processing", "extracting"].includes(j.status),
    ).length;
    const times = jobs.filter((j) => j.elapsedMs).map((j) => j.elapsedMs!);
    const avg = times.length ? Math.round(times.reduce((a, b) => a + b, 0) / times.length) : 0;
    return { total, completed, failed, active, avg };
  }, [jobs]);

  const updateJob = useCallback((id: string, patch: Partial<Job>) => {
    setJobs((prev) => prev.map((j) => (j.id === id ? { ...j, ...patch } : j)));
  }, []);

  const processJob = useCallback(
    async (job: Job) => {
      if (!runningRef.current) {
        updateJob(job.id, { status: "queued", progress: 5 });
        return;
      }
      try {
        updateJob(job.id, { status: "uploading", progress: 15 });
        const base64 = await fileToBase64(job.file);
        if (!runningRef.current) {
          updateJob(job.id, { status: "queued", progress: 5 });
          return;
        }
        updateJob(job.id, { status: "processing", progress: 45 });

        // simulate streaming progress while waiting
        const tick = setInterval(() => {
          setJobs((prev) =>
            prev.map((j) =>
              j.id === job.id && j.status !== "completed" && j.status !== "failed"
                ? { ...j, status: "extracting", progress: Math.min(92, j.progress + 4) }
                : j,
            ),
          );
        }, 350);

        const res = await runExtract({
          data: {
            fileName: job.file.name,
            mimeType: job.file.type || "application/octet-stream",
            base64,
          },
        });

        clearInterval(tick);

        if (!res.ok) {
          updateJob(job.id, { status: "failed", progress: 100, error: res.error });
          toast.error(t("cci.toast.failed", job.file.name));
          return;
        }

        const baseName = job.file.name.replace(/\.[^.]+$/, "");
        const resultWithName = {
          ...res.data,
          container_number: baseName,
        };
        updateJob(job.id, {
          status: "completed",
          progress: 100,
          result: resultWithName,
          elapsedMs: res.elapsedMs,
        });
        toast.success(t("cci.toast.extracted", job.file.name));
      } catch (e) {
        updateJob(job.id, {
          status: "failed",
          progress: 100,
          error: e instanceof Error ? e.message : t("cci.toast.unknown"),
        });
        toast.error(t("cci.toast.failed", job.file.name));
      }
    },
    [runExtract, updateJob, t],
  );

  const addFiles = useCallback(
    (files: FileList | File[]) => {
      const arr = Array.from(files).filter((f) => {
        if (!ACCEPT.includes(f.type)) {
          toast.error(t("cci.toast.unsupported", f.name));
          return false;
        }
        if (f.size > 15 * 1024 * 1024) {
          toast.error(t("cci.toast.tooLarge", f.name));
          return false;
        }
        return true;
      });
      if (!arr.length) return;
      const newJobs: Job[] = arr.map((file) => ({
        id: crypto.randomUUID(),
        file,
        status: "queued",
        progress: 5,
        startedAt: Date.now(),
      }));
      setJobs((prev) => [...newJobs, ...prev]);
      if (runningRef.current) newJobs.forEach((j) => void processJob(j));
    },
    [processJob, t],
  );

  // Paste from clipboard
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const files = e.clipboardData?.files;
      if (files && files.length) addFiles(files);
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [addFiles]);

  const completed = jobs.filter((j) => j.status === "completed" && j.result);

  const filteredRows = useMemo(() => {
    const q = search.trim().toLowerCase();
    let rows = completed.map((j) => ({ id: j.id, fileName: j.file.name, ...j.result! }));
    if (q) {
      rows = rows.filter((r) =>
        Object.values(r).some((v) => String(v ?? "").toLowerCase().includes(q)),
      );
    }
    if (sortKey) {
      rows = [...rows].sort((a, b) => {
        const av = String(a[sortKey] ?? "");
        const bv = String(b[sortKey] ?? "");
        return sortDir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
      });
    }
    return rows;
  }, [completed, search, sortKey, sortDir]);

  const toggleSort = (k: keyof ExtractedCertificate) => {
    if (sortKey === k) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(k);
      setSortDir("asc");
    }
  };

  const exportCSV = () => {
    if (!filteredRows.length) return;
    const headers = ["file_name", ...visibleFields.map((f) => f.key)];
    const csv = [
      headers.join(","),
      ...filteredRows.map((r) =>
        headers
          .map((h) => {
            const v = (r as Record<string, unknown>)[h] ?? "";
            const s = String(v).replace(/"/g, '""');
            return /[,"\n]/.test(s) ? `"${s}"` : s;
          })
          .join(","),
      ),
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `certificates-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t("cci.csv.exported"));
  };

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(filteredRows, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `certificates-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportXLSX = async () => {
    if (!filteredRows.length) return;
    const XLSX = await import("xlsx");
    const headers = ["file_name", ...visibleFields.map((f) => f.key)];
    const aoa = [
      headers,
      ...filteredRows.map((r) =>
        headers.map((h) => (r as Record<string, unknown>)[h] ?? ""),
      ),
    ];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = headers.map(() => ({ wch: 18 }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Certificates");
    XLSX.writeFile(wb, `certificates-${Date.now()}.xlsx`);
    toast.success(t("cci.xlsx.exported"));
  };

  const hasFiles = jobs.length > 0;
  const queuedCount = jobs.filter((j) => j.status === "queued").length;

  const handleStart = useCallback(() => {
    runningRef.current = true;
    setIsRunning(true);
    setJobs((prev) => {
      prev.filter((j) => j.status === "queued").forEach((j) => void processJob(j));
      return prev;
    });
  }, [processJob]);

  const handleStop = useCallback(() => {
    runningRef.current = false;
    setIsRunning(false);
  }, []);

  return (
    <div className="min-h-[calc(100vh-3rem)] bg-gradient-to-b from-background to-surface">
      <div className="mx-auto w-full px-6 py-8 lg:py-10">
        {apiKeys.length === 0 && (
          <div className="mb-6 rounded-lg border border-warning/30 bg-warning/5 px-4 py-3 text-sm">
            <span className="font-medium">{t("cci.noKeys.title")}</span>{" "}
            {t("cci.noKeys.body")}{" "}
            <Link
              to="/settings/container-extractor"
              className="text-primary underline underline-offset-2"
            >
              {t("cci.noKeys.cta")}
            </Link>{" "}
            {t("cci.noKeys.tail")}
          </div>
        )}

        {/* Title + settings */}
        <div className="mb-8 flex items-center justify-between gap-4">
          <h1 className="text-3xl lg:text-4xl font-semibold tracking-tight text-foreground leading-tight">
            {t("cci.hero.title1")}{" "}
            <span className="bg-gradient-to-r from-primary to-info bg-clip-text text-transparent">
              {t("cci.hero.title2")}
            </span>
          </h1>
          <Link to="/settings/container-extractor">
            <Button variant="outline" size="sm">
              {t("cci.moduleSettings")}
            </Button>
          </Link>
        </div>





        <div className="space-y-6">
          <div className="space-y-6 min-w-0">
            {/* Upload */}
            <motion.div
              layout
              onDragOver={(e) => {
                e.preventDefault();
                setDragging(true);
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragging(false);
                if (e.dataTransfer.files?.length) addFiles(e.dataTransfer.files);
              }}
              className={cn(
                "relative rounded-2xl border-2 border-dashed bg-card transition-all overflow-hidden p-5",
                dragging
                  ? "border-primary bg-primary/[0.03] shadow-[0_0_0_4px_rgba(49,73,130,0.08)]"
                  : "border-border hover:border-border-strong",
              )}
            >
              <input
                ref={inputRef}
                type="file"
                multiple
                accept={ACCEPT.join(",")}
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.length) addFiles(e.target.files);
                  e.target.value = "";
                }}
              />
              <div className="flex flex-row items-center gap-4">
                <motion.div
                  animate={dragging ? { scale: 1.08, rotate: -3 } : { scale: 1, rotate: 0 }}
                  className={cn(
                    "rounded-xl grid place-items-center shrink-0 size-10",
                    dragging ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary",
                  )}
                >
                  <Upload className="size-5" />
                </motion.div>
                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-foreground text-base truncate">
                    {dragging ? t("cci.drop.active") : t("cci.drop.idle")}
                  </div>
                  <div className="text-sm text-muted-foreground mt-0.5 truncate">{t("cci.drop.hint")}</div>
                </div>
                <Button onClick={() => inputRef.current?.click()} className="shrink-0">
                  {t("cci.drop.select")}
                </Button>
              </div>
            </motion.div>


            {/* Queue */}
            <AnimatePresence>
              {hasFiles && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="rounded-2xl border border-border bg-card overflow-hidden"
                >
                  <div className="px-5 py-3.5 border-b border-border flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setQueueCollapsed((v) => !v)}
                      className="flex items-center gap-2 group"
                    >
                      <ChevronRight
                        className={cn(
                          "size-4 text-muted-foreground transition-transform",
                          !queueCollapsed && "rotate-90",
                        )}
                      />
                      <Layers className="size-4 text-muted-foreground" />
                      <h2 className="font-semibold text-sm">{t("cci.queue.title")}</h2>
                      <span className="text-xs text-muted-foreground">{t("cci.queue.files", jobs.length)}</span>
                    </button>
                    <div className="flex items-center gap-2">
                      {isRunning ? (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleStop}
                          disabled={stats.active === 0}
                        >
                          <Square className="size-3.5" />
                          Остановить
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          onClick={handleStart}
                          disabled={queuedCount === 0}
                        >
                          <Play className="size-3.5" />
                          Запустить
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setJobs([])}
                        className="text-muted-foreground"
                      >
                        {t("cci.queue.clear")}
                      </Button>
                    </div>
                  </div>
                  <AnimatePresence initial={false}>
                    {!queueCollapsed && (
                      <motion.ul
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="divide-y divide-border overflow-hidden"
                      >
                        <AnimatePresence initial={false}>
                          {jobs.map((job) => (
                            <JobRow key={job.id} job={job} onRetry={() => processJob(job)} />
                          ))}
                        </AnimatePresence>
                      </motion.ul>
                    )}
                  </AnimatePresence>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Results table */}
            <div className="rounded-2xl border border-border bg-card overflow-hidden">
              <div className="px-5 py-3.5 border-b border-border flex flex-wrap items-center gap-3 justify-between">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="size-4 text-muted-foreground" />
                  <h2 className="font-semibold text-sm">{t("cci.results.title")}</h2>
                  <span className="text-xs text-muted-foreground">
                    {t("cci.results.of", filteredRows.length, completed.length)}
                  </span>
                </div>
                <div className="flex items-center gap-2 flex-1 justify-end min-w-0">
                  <div className="relative max-w-xs w-full">
                    <Search className="size-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder={t("cci.results.search")}
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      className="h-8 pl-8 text-sm"
                    />
                  </div>
                  <Button size="sm" variant="outline" onClick={exportJSON} disabled={!filteredRows.length}>
                    JSON
                  </Button>
                  <Button size="sm" variant="outline" onClick={exportCSV} disabled={!filteredRows.length}>
                    CSV
                  </Button>
                  <Button size="sm" onClick={() => void exportXLSX()} disabled={!filteredRows.length}>
                    Excel
                  </Button>
                </div>
              </div>
              <div className="overflow-x-auto">
                {completed.length === 0 ? (
                  <EmptyTable />
                ) : (
                  <table className="w-full text-sm tabular">
                    <thead className="sticky top-0 bg-surface/80 backdrop-blur">
                      <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                        <th className="px-4 py-2.5 font-medium min-w-[200px]">{t("cci.results.fileCol")}</th>
                        {visibleFields.map((f) => (
                          <th key={f.key} className={cn("px-3 py-2.5 font-medium", f.w)}>
                            <button
                              onClick={() => toggleSort(f.key)}
                              className="inline-flex items-center gap-1 hover:text-foreground"
                            >
                              {t(`cci.field.${f.key}` as Parameters<typeof t>[0])}
                              <ArrowUpDown className="size-3 opacity-50" />
                            </button>
                          </th>
                        ))}
                        <th className="px-3 py-2.5 font-medium sticky right-0 bg-surface/80 backdrop-blur">
                          {""}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRows.map((row) => (
                        <tr
                          key={row.id}
                          className="border-t border-border hover:bg-accent/40 transition-colors group"
                        >
                          <td className="px-4 py-2.5 font-medium text-foreground truncate max-w-[260px]">
                            <span className="inline-flex items-center gap-2">
                              <FileText className="size-3.5 text-muted-foreground" />
                              {row.fileName}
                            </span>
                          </td>
                          {visibleFields.map((f) => (
                            <td key={f.key} className="px-3 py-2.5 text-foreground/90">
                              {row[f.key] ?? <span className="text-muted-foreground/60">—</span>}
                            </td>
                          ))}
                          <td className="px-3 py-2.5 sticky right-0 bg-card group-hover:bg-accent/40">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="opacity-0 group-hover:opacity-100 h-7"
                              onClick={() => {
                                void navigator.clipboard.writeText(JSON.stringify(row, null, 2));
                                toast.success(t("cci.results.copyRow"));
                              }}
                            >
                              <Copy className="size-3.5" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  icon: Icon,
  tone = "default",
}: {
  label: string;
  value: number | string;
  icon: React.ComponentType<{ className?: string }>;
  tone?: "default" | "success" | "info";
}) {
  const toneCls =
    tone === "success"
      ? "bg-success/10 text-success"
      : tone === "info"
        ? "bg-info/10 text-info"
        : "bg-primary/10 text-primary";
  return (
    <motion.div
      whileHover={{ y: -2 }}
      className="rounded-xl border border-border bg-card p-4 transition-shadow hover:shadow-[0_8px_24px_-12px_rgba(15,23,42,0.12)]"
    >
      <div className="flex items-center justify-between">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          {label}
        </div>
        <div className={cn("size-7 rounded-md grid place-items-center", toneCls)}>
          <Icon className="size-3.5" />
        </div>
      </div>
      <AnimatedNumber value={value} />
    </motion.div>
  );
}

function AnimatedNumber({ value }: { value: number | string }) {
  const [display, setDisplay] = useState(value);
  useEffect(() => {
    if (typeof value !== "number") {
      setDisplay(value);
      return;
    }
    const from = typeof display === "number" ? display : 0;
    const dur = 500;
    const start = performance.now();
    let raf = 0;
    const step = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      setDisplay(Math.round(from + (value - from) * p));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return <div className="mt-2 text-2xl font-semibold tracking-tight tabular">{display}</div>;
}




function JobRow({ job, onRetry }: { job: Job; onRetry: () => void }) {
  const t = useTfn();
  const isImg = job.file.type.startsWith("image/");
  const statusMeta: Record<JobStatus, { label: string; cls: string }> = {
    queued: { label: t("cci.status.queued"), cls: "bg-muted text-muted-foreground" },
    uploading: { label: t("cci.status.uploading"), cls: "bg-info/10 text-info" },
    processing: { label: t("cci.status.processing"), cls: "bg-info/10 text-info" },
    extracting: { label: t("cci.status.extracting"), cls: "bg-primary/10 text-primary" },
    completed: { label: t("cci.status.completed"), cls: "bg-success/10 text-success" },
    failed: { label: t("cci.status.failed"), cls: "bg-destructive/10 text-destructive" },
  };
  const meta = statusMeta[job.status];

  return (
    <motion.li
      layout
      initial={{ opacity: 0, y: -4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="px-5 py-3.5"
    >
      <div className="flex items-center gap-3">
        <div className="size-10 rounded-lg bg-secondary border border-border grid place-items-center shrink-0 text-muted-foreground">
          {isImg ? <ImageIcon className="size-4" /> : <FileText className="size-4" />}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 min-w-0">
            <div className="truncate text-sm font-medium">{job.file.name}</div>
            <span className={cn("text-[10px] font-medium px-1.5 py-0.5 rounded uppercase tracking-wide", meta.cls)}>
              {meta.label}
            </span>
            {job.status === "completed" && job.elapsedMs && (
              <span className="text-xs text-muted-foreground tabular">{(job.elapsedMs / 1000).toFixed(2)}s</span>
            )}
          </div>
          <div className="mt-1.5 h-1 rounded-full bg-secondary overflow-hidden">
            <motion.div
              className={cn(
                "h-full rounded-full",
                job.status === "failed"
                  ? "bg-destructive"
                  : job.status === "completed"
                    ? "bg-success"
                    : "bg-primary",
              )}
              animate={{ width: `${job.progress}%` }}
              transition={{ duration: 0.4 }}
            />
          </div>
          {job.status === "completed" && job.result?.container_number && (
            <div className="mt-1.5 text-xs text-muted-foreground truncate">
              {job.result.container_number} · {job.result.iso_code ?? "—"} · {job.result.gross_weight ?? "—"}
            </div>
          )}
          {job.status === "failed" && (
            <div className="mt-1.5 text-xs text-destructive truncate">{job.error}</div>
          )}
        </div>
        <div className="shrink-0">
          {job.status === "failed" ? (
            <Button size="sm" variant="outline" onClick={onRetry}>
              {t("cci.retry")}
            </Button>
          ) : job.status === "completed" ? (
            <CheckCircle2 className="size-5 text-success" />
          ) : (
            <Loader2 className="size-4 text-muted-foreground animate-spin" />
          )}
        </div>
      </div>
    </motion.li>
  );
}

function EmptyTable() {
  const t = useTfn();
  return (
    <div className="py-16 text-center">
      <div className="mx-auto size-14 rounded-2xl bg-secondary grid place-items-center mb-4">
        <FileSpreadsheet className="size-6 text-muted-foreground" />
      </div>
      <div className="font-medium">{t("cci.results.empty.title")}</div>
      <div className="text-sm text-muted-foreground mt-1">{t("cci.results.empty.body")}</div>
    </div>
  );
}

