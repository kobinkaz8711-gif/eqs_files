import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useEffect, Fragment } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  getFile,
  openFile,
  closeFile,
  cancelFile,
  confirmRp,
  setReadyForCl,
  revertFileStatus,
  getFileEvents,
  getFileWarnings,
  listBudgetArticles,
  upsertBudgetPlanLine,
  deleteBudgetPlanLine,
  listFileUnitAssignments,
  searchRecentUnits,
  assignUnit,
  assignBooking,
  unlinkUnit,
  getBudgetFact,
  getFileFinance,
  refreshFileFinance,
  setBudgetUnlocked,
  updateFile,
  changeFileDepartment,
  listFileBookings,
  assignFileBooking,
  unlinkFileBooking,
  syncFileBookingUnits,
  refreshFileFromExt,
  setFileStatusDates,
} from "@/lib/files.functions";

import { listDepartments } from "@/lib/departments.functions";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ArrowLeft, Plus, Trash2, AlertTriangle, Pencil, Loader2, Send, RotateCw, RotateCcw, RefreshCw, Link2Off, MoreHorizontal, Copy, ClipboardCopy, CalendarClock, Check, X } from "lucide-react";
import { CopyFileDialog } from "@/components/CopyFileDialog";
import { SetStatusDateDialog, EditStatusDatesDialog, type StatusKey, type StatusDates } from "@/components/StatusDateDialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Can } from "@/components/auth/Can";
import { toast } from "sonner";
import { EqsBookingDialog } from "@/components/EqsBookingDialog";
import { getEqsExportHistory, retryEqsExport, getEqsExportDownloadUrl } from "@/lib/eqs-booking.functions";
import { ContainerTypesEditor, type CTRow } from "@/components/ContainerTypesEditor";
import { listGrades } from "@/lib/grades.functions";

const CONTAINER_TYPE_OPTIONS = [
  "20DV", "20DC", "20HC", "20RF", "20OT", "20FR", "20TK",
  "40DV", "40DC", "40HC", "40RF", "40HR", "40OT", "40FR", "40NOR",
  "45HC", "45HR",
];

export const Route = createFileRoute("/_authenticated/eqs-files/$id")({
  component: FileDetailPage,
  head: () => ({ meta: [{ title: "EQS File" }] }),
});

const STATUS_LABEL: Record<string, string> = {
  DR: "Draft",
  OP: "Open",
  RP: "Reporting Period",
  RCL: "Ready for Close",
  CL: "Closed",
  CN: "Cancelled",
};


function FileDetailPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const fetchFile = useServerFn(getFile);
  const fetchArticles = useServerFn(listBudgetArticles);
  const open = useServerFn(openFile);
  const close = useServerFn(closeFile);
  const cancel = useServerFn(cancelFile);
  const confirmRpFn = useServerFn(confirmRp);
  const readyForClFn = useServerFn(setReadyForCl);
  const revertStatusFn = useServerFn(revertFileStatus);
  const fetchHistory = useServerFn(getFileEvents);
  const fetchWarnings = useServerFn(getFileWarnings);

  const upsertLine = useServerFn(upsertBudgetPlanLine);
  const deleteLine = useServerFn(deleteBudgetPlanLine);
  const fetchUnits = useServerFn(listFileUnitAssignments);
  const searchUnits = useServerFn(searchRecentUnits);
  const assignUnitFn = useServerFn(assignUnit);
  const assignBookingFn = useServerFn(assignBooking);
  const unlinkUnitFn = useServerFn(unlinkUnit);
  const fetchFact = useServerFn(getBudgetFact);
  const fetchFinance = useServerFn(getFileFinance);
  const refreshFinanceFn = useServerFn(refreshFileFinance);
  const setUnlockedFn = useServerFn(setBudgetUnlocked);
  const updateFileFn = useServerFn(updateFile);
  const changeDeptFn = useServerFn(changeFileDepartment);
  const fetchDepts = useServerFn(listDepartments);
  const fetchBookings = useServerFn(listFileBookings);
  const assignBookingManualFn = useServerFn(assignFileBooking);
  const unlinkBookingFn = useServerFn(unlinkFileBooking);
  const syncBookingFn = useServerFn(syncFileBookingUnits);
  const refreshFromExtFn = useServerFn(refreshFileFromExt);


  const fileQ = useQuery({
    queryKey: ["file", id],
    queryFn: () => fetchFile({ data: { id } }),
    refetchInterval: (q) => {
      const state = (q.state.data as any)?.file?.eqs_booking_state;
      return state === "awaiting_id" ? 30_000 : false;
    },
  });
  const artQ = useQuery({
    queryKey: ["articles", "SALES"],
    queryFn: () => fetchArticles({ data: { scope: "SALES" } }),
  });
  const deptsQ = useQuery({
    queryKey: ["departments"],
    queryFn: () => fetchDepts(),
  });
  const histQ = useQuery({
    queryKey: ["file-history", id],
    queryFn: () => fetchHistory({ data: { id } }),
  });
  const warnQ = useQuery({
    queryKey: ["file-warnings", id],
    queryFn: () => fetchWarnings({ data: { id } }),
  });
  const unitsQ = useQuery({
    queryKey: ["file-units", id],
    queryFn: () => fetchUnits({ data: { id } }),
  });
  const factQ = useQuery({
    queryKey: ["file-fact", id],
    queryFn: () => fetchFact({ data: { id } }),
  });
  const financeQ = useQuery({
    queryKey: ["file-finance", id],
    queryFn: () => fetchFinance({ data: { id } }),
  });

  const file = fileQ.data?.file as any;
  const lines = (fileQ.data?.budgetLines ?? []) as any[];
  const containerTypes = (fileQ.data?.containerTypes ?? []) as any[];
  const unitsCount = (fileQ.data?.unitsCount ?? 0) as number;

  const refetch = () => {
    qc.invalidateQueries({ queryKey: ["file", id] });
    qc.invalidateQueries({ queryKey: ["file-history", id] });
    qc.invalidateQueries({ queryKey: ["file-warnings", id] });
    qc.invalidateQueries({ queryKey: ["file-units", id] });
  };

  // Unit assignment local state
  const [unitQuery, setUnitQuery] = useState("");
  const [unitInput, setUnitInput] = useState("");
  const [showOnlyMatching, setShowOnlyMatching] = useState(true);
  const [showUnlinked, setShowUnlinked] = useState(false);
  const [showAssign, setShowAssign] = useState(false);
  const [eventTypeFilter, setEventTypeFilter] = useState<string>("all");
  const [factExpanded, setFactExpanded] = useState<string | null>(null);
  const [planCurrency, setPlanCurrency] = useState<"USD" | "EUR">("USD");
  const [planView, setPlanView] = useState<"per_type" | "overall">("overall");
  const [draftOpenFor, setDraftOpenFor] = useState<string | null>(null);
  const [factCurrency, setFactCurrency] = useState<"USD" | "EUR">("USD");
  const [factViewLevel, setFactViewLevel] = useState<"file" | "unit">("file");
  const [factDetail, setFactDetail] = useState<"summary" | "details">("summary");
  const [factShowData, setFactShowData] = useState<
    "all" | "budget" | "booked" | "accruals" | "rt"
  >("all");
  const [factSelectedArticle, setFactSelectedArticle] = useState<string | null>(null);
  const [fxRateInput, setFxRateInput] = useState<string>("");
  const [financeCurrency, setFinanceCurrency] = useState<"USD" | "EUR">("USD");
  const [financeShowData, setFinanceShowData] = useState<"all" | "booked" | "accruals">("all");
  const [financeExpanded, setFinanceExpanded] = useState<{ invoice: string | null; costType: string | null }>({ invoice: null, costType: null });
  const [changeDeptOpen, setChangeDeptOpen] = useState(false);
  const [newDeptId, setNewDeptId] = useState<string>("");
  useEffect(() => {
    const v = (fileQ.data?.file as any)?.fx_rate_eur_usd;
    setFxRateInput(v == null ? "" : String(v));
  }, [fileQ.data?.file?.id, (fileQ.data?.file as any)?.fx_rate_eur_usd]);

  // EQS booking dialog
  const [eqsDialogOpen, setEqsDialogOpen] = useState(false);
  const [copyMode, setCopyMode] = useState<"plain" | "with_budget" | null>(null);
  const fetchEqsHistory = useServerFn(getEqsExportHistory);
  const retryEqsFn = useServerFn(retryEqsExport);
  const getEqsUrl = useServerFn(getEqsExportDownloadUrl);
  const eqsHistoryQ = useQuery({
    queryKey: ["eqs-history", id],
    queryFn: () => fetchEqsHistory({ data: { file_id: id } }),
    refetchInterval: (q) => {
      const state = (fileQ.data?.file as any)?.eqs_booking_state;
      return state === "awaiting_id" ? 30_000 : false;
    },
  });
  const retryEqsMut = useMutation({
    mutationFn: () => retryEqsFn({ data: { file_id: id } }),
    onSuccess: () => {
      toast.success("Retry sent");
      qc.invalidateQueries({ queryKey: ["file", id] });
      qc.invalidateQueries({ queryKey: ["eqs-history", id] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Retry failed"),
  });
  const openEqsFile = async (bucket: "eqs-outbox" | "eqs-inbox", path: string) => {
    try {
      const { url } = await getEqsUrl({ data: { bucket, path } });
      window.open(url, "_blank");
    } catch (e: any) {
      toast.error(e?.message ?? "Download failed");
    }
  };


  const extUnitsQ = useQuery({
    queryKey: ["recent-units", id, unitQuery],
    queryFn: () => searchUnits({ data: { file_id: id, q: unitQuery } }),
  });

  const assignMut = useMutation({
    mutationFn: (vars: { unit_no: string; booking_no?: string }) =>
      assignUnitFn({ data: { file_id: id, ...vars } }),

    onSuccess: () => {
      toast.success("Unit assigned");
      setUnitInput("");
      setUnitQuery("");
      qc.invalidateQueries({ queryKey: ["file-units", id] });
      qc.invalidateQueries({ queryKey: ["file", id] });
      qc.invalidateQueries({ queryKey: ["recent-units", id] });
      qc.invalidateQueries({ queryKey: ["file-warnings", id] });
      qc.invalidateQueries({ queryKey: ["file-history", id] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });
  const assignBookingMut = useMutation({
    mutationFn: (booking_no: string) =>
      assignBookingFn({ data: { file_id: id, booking_no } }),
    onSuccess: (r: any) => {
      toast.success(`Assigned ${r?.count ?? 0} unit(s) from booking`);
      qc.invalidateQueries({ queryKey: ["file-units", id] });
      qc.invalidateQueries({ queryKey: ["file", id] });
      qc.invalidateQueries({ queryKey: ["recent-units", id] });
      qc.invalidateQueries({ queryKey: ["file-warnings", id] });
      qc.invalidateQueries({ queryKey: ["file-history", id] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const unlinkMut = useMutation({
    mutationFn: (assignment_id: string) => unlinkUnitFn({ data: { assignment_id, file_id: id } }),
    onMutate: async (assignment_id: string) => {
      await qc.cancelQueries({ queryKey: ["file-units", id] });
      const prev = qc.getQueryData<any>(["file-units", id]);
      if (prev?.items) {
        qc.setQueryData(["file-units", id], {
          ...prev,
          items: prev.items.map((u: any) =>
            u.id === assignment_id ? { ...u, is_active: false, unlinked_at: new Date().toISOString() } : u,
          ),
        });
      }
      return { prev };
    },
    onSuccess: () => {
      toast.success("Unit unlinked");
      qc.invalidateQueries({ queryKey: ["file-units", id] });
      qc.invalidateQueries({ queryKey: ["file", id] });
      qc.invalidateQueries({ queryKey: ["file-warnings", id] });
      qc.invalidateQueries({ queryKey: ["file-history", id] });
    },
    onError: (e: any, _v, ctx: any) => {
      if (ctx?.prev) qc.setQueryData(["file-units", id], ctx.prev);
      toast.error(e?.message ?? "Failed");
    },
  });

  const refreshFinanceM = useMutation({
    mutationFn: () => refreshFinanceFn({ data: { file_id: id } }),
    onSuccess: (r: any) => {
      toast.success(`Finance refreshed (${r?.count ?? 0} lines)`);
      qc.invalidateQueries({ queryKey: ["file-finance", id] });
      qc.invalidateQueries({ queryKey: ["file-fact", id] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const bookingsQ = useQuery({
    queryKey: ["file-bookings", id],
    queryFn: () => fetchBookings({ data: { file_id: id } }),
  });

  const invalidateAll = () => {
    qc.invalidateQueries({ queryKey: ["file", id] });
    qc.invalidateQueries({ queryKey: ["file-bookings", id] });
    qc.invalidateQueries({ queryKey: ["file-units", id] });
    qc.invalidateQueries({ queryKey: ["recent-units", id] });
    qc.invalidateQueries({ queryKey: ["file-warnings", id] });
    qc.invalidateQueries({ queryKey: ["file-history", id] });
    qc.invalidateQueries({ queryKey: ["file-finance", id] });
    qc.invalidateQueries({ queryKey: ["file-fact", id] });
  };

  const [manualBookingNo, setManualBookingNo] = useState("");

  const addBookingMut = useMutation({
    mutationFn: (booking_no: string) =>
      assignBookingManualFn({ data: { file_id: id, booking_no } }),
    onSuccess: () => {
      toast.success("Booking linked");
      setManualBookingNo("");
      invalidateAll();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const unlinkBookingMut = useMutation({
    mutationFn: (assignment_id: string) =>
      unlinkBookingFn({ data: { assignment_id, file_id: id } }),
    onSuccess: (r: any) => {
      toast.success(`Booking unlinked (${r?.unlinked_units ?? 0} unit(s) unlinked)`);
      invalidateAll();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const syncBookingMut = useMutation({
    mutationFn: (booking_no: string) =>
      syncBookingFn({ data: { file_id: id, booking_no } }),
    onSuccess: (r: any) => {
      toast.success(`Linked ${r?.added ?? 0} unit(s) from booking`);
      invalidateAll();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const refreshFileMut = useMutation({
    mutationFn: () => refreshFromExtFn({ data: { file_id: id } }),
    onSuccess: (r: any) => {
      toast.success(`Refreshed: +${r?.added_units ?? 0} units · ${r?.finance_rows ?? 0} finance rows`);
      invalidateAll();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });




  const openMut = useMutation({
    mutationFn: (status_date: string) => open({ data: { id, status_date } }),
    onSuccess: () => {
      toast.success("File opened");
      refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });
  const confirmRpMut = useMutation({
    mutationFn: (status_date: string) => confirmRpFn({ data: { id, status_date } }),
    onSuccess: () => {
      toast.success("RP confirmed, snapshot created");
      refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });
  const readyForClMut = useMutation({
    mutationFn: (status_date: string) => readyForClFn({ data: { id, status_date } }),
    onSuccess: () => {
      toast.success("Marked Ready for Close, snapshot created");
      refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });
  const closeMut = useMutation({
    mutationFn: (status_date: string) => close({ data: { id, status_date } }),
    onSuccess: () => {
      toast.success("File closed, final snapshot created");
      refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });
  const cancelMut = useMutation({
    mutationFn: (vars: { reason: string; status_date: string }) =>
      cancel({ data: { id, reason: vars.reason, status_date: vars.status_date } }),
    onSuccess: () => {
      toast.success("File cancelled");
      refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });
  const revertMut = useMutation({
    mutationFn: (notes: string) => revertStatusFn({ data: { id, notes } }),
    onSuccess: (r: any) => {
      toast.success(`Status reverted to ${r?.new_status ?? ""}`);
      refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const setStatusDatesFn = useServerFn(setFileStatusDates);
  const setStatusDatesMut = useMutation({
    mutationFn: (patch: StatusDates) => setStatusDatesFn({ data: { id, ...patch } }),
    onSuccess: () => {
      toast.success("Status dates updated");
      setEditDatesOpen(false);
      refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  // Status-date dialogs
  const [pendingStatus, setPendingStatus] = useState<StatusKey | null>(null);
  const [editDatesOpen, setEditDatesOpen] = useState(false);

  const confirmStatusChange = ({ date, reason }: { date: string; reason?: string }) => {
    if (!pendingStatus) return;
    switch (pendingStatus) {
      case "OP": openMut.mutate(date); break;
      case "RP": confirmRpMut.mutate(date); break;
      case "RCL": readyForClMut.mutate(date); break;
      case "CL": closeMut.mutate(date); break;
      case "CN": cancelMut.mutate({ reason: reason ?? "", status_date: date }); break;
    }
    setPendingStatus(null);
  };

  const changeDeptMut = useMutation({
    mutationFn: () =>
      changeDeptFn({ data: { id, department_id: newDeptId } }),
    onSuccess: (r: any) => {
      toast.success(`Department changed. New number: ${r?.file_number ?? ""}`);
      setChangeDeptOpen(false);
      refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });




  const [newLine, setNewLine] = useState({
    article_id: "",
    container_type: "",
    planned_qty: "1",
    amount_per_unit: "",
    currency: "USD",
    amount_usd: "",
    amount_eur: "",
  });

  const addLine = useMutation({
    mutationFn: () =>
      upsertLine({
        data: {
          file_id: id,
          article_id: newLine.article_id,
          container_type: newLine.container_type || null,
          planned_qty: parseInt(newLine.planned_qty, 10) || 1,
          amount_per_unit: parseFloat(newLine.amount_per_unit) || 0,
          currency: newLine.currency,
          amount_usd: newLine.amount_usd ? parseFloat(newLine.amount_usd) : null,
          amount_eur: newLine.amount_eur ? parseFloat(newLine.amount_eur) : null,
          source_type: "MANUAL" as const,
        },
      }),
    onSuccess: () => {
      setNewLine({
        article_id: "",
        container_type: "",
        planned_qty: "1",
        amount_per_unit: "",
        currency: "USD",
        amount_usd: "",
        amount_eur: "",
      });
      refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const delLine = useMutation({
    mutationFn: (lineId: string) => deleteLine({ data: { id: lineId } }),
    onSuccess: () => refetch(),
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const [editingLine, setEditingLine] = useState<{
    id: string;
    amount_per_unit: string;
    currency: string;
  } | null>(null);

  const editLine = useMutation({
    mutationFn: (payload: {
      id: string;
      article_id: string;
      container_type: string | null;
      planned_qty: number;
      amount_per_unit: number;
      currency: string;
      source_type: "MANUAL" | "TEMPLATE" | "IMPORT";
      notes: string | null;
    }) =>
      upsertLine({
        data: {
          id: payload.id,
          file_id: id,
          article_id: payload.article_id,
          container_type: payload.container_type,
          planned_qty: payload.planned_qty,
          amount_per_unit: payload.amount_per_unit,
          currency: payload.currency,
          source_type: payload.source_type,
          notes: payload.notes,
        },
      }),
    onSuccess: () => {
      setEditingLine(null);
      refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  if (fileQ.isLoading) return <div className="p-8">Loading…</div>;
  if (!file) return <div className="p-8">Not found</div>;

  const planLocked = file.status !== "DR" && !file.budget_unlocked;

  // Per-line amount converters. Use file.fx_rate_eur_usd to derive the
  // opposite-currency value when stored amount_usd/amount_eur are null,
  // so editing FX rate immediately reflects in totals.
  const fxRate = Number((file as any)?.fx_rate_eur_usd ?? 0) || 0;
  const usdOf = (l: any) => {
    if (l.amount_usd != null) return Number(l.amount_usd);
    if (l.currency === "USD") return Number(l.total_amount ?? 0);
    if (l.currency === "EUR" && fxRate > 0) return Number(l.total_amount ?? 0) * fxRate;
    return 0;
  };
  const eurOf = (l: any) => {
    if (l.amount_eur != null) return Number(l.amount_eur);
    if (l.currency === "EUR") return Number(l.total_amount ?? 0);
    if (l.currency === "USD" && fxRate > 0) return Number(l.total_amount ?? 0) / fxRate;
    return 0;
  };
  const amountInCur = (l: any) => (planCurrency === "USD" ? usdOf(l) : eurOf(l));
  const calcTotals = (rows: any[]) =>
    rows.reduce(
      (acc, l) => {
        const k = l.budget_articles?.kind;
        const a = amountInCur(l);
        if (k === "REVENUE") acc.revenue += a;
        else acc.cost += a;
        return acc;
      },
      { revenue: 0, cost: 0 },
    );

  // Overall view: aggregate per article across container types.
  // total_amount is already amount_per_unit * planned_qty for that type,
  // so we just sum across types (do NOT multiply by qty again).
  const overallLines = (() => {
    const m = new Map<string, any>();
    for (const l of lines) {
      const key = l.article_id;
      const u = usdOf(l);
      const e = eurOf(l);
      const ex = m.get(key);
      if (ex) {
        ex.amount_usd = Number(ex.amount_usd) + u;
        ex.amount_eur = Number(ex.amount_eur) + e;
      } else {
        m.set(key, {
          ...l,
          container_type: null,
          planned_qty: null,
          amount_usd: u,
          amount_eur: e,
          total_amount: null,
        });
      }
    }
    return Array.from(m.values());
  })();
  const overallTotals = calcTotals(overallLines);
  // cost is stored signed (negative for costs), so GPM = revenue + cost
  const overallGpm = overallTotals.revenue + overallTotals.cost;

  // Per-type view: group lines by container_type, preserving the order from containerTypes
  const perTypeGroups = (() => {
    const order = containerTypes.map((c: any) => c.container_type as string);
    const map = new Map<string, any[]>();
    for (const ct of order) map.set(ct, []);
    for (const l of lines) {
      const ct = l.container_type ?? "—";
      if (!map.has(ct)) map.set(ct, []);
      map.get(ct)!.push(l);
    }
    return Array.from(map.entries()).map(([container_type, rows]) => {
      const totals = calcTotals(rows);
      const ctRow: any = containerTypes.find((c: any) => c.container_type === container_type);
      return {
        container_type,
        grade: ctRow?.grade ?? null,
        rows,
        planned_qty: ctRow?.planned_qty ?? null,
        totals,
        gpm: totals.revenue + totals.cost,
      };
    });
  })();




  return (
    <div className="max-w-5xl mx-auto px-4 py-4">
      <div className="rounded-lg border border-border bg-card px-4 py-2 mb-2">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap min-w-0">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate({ to: "/eqs-files" })}
            >
              <ArrowLeft className="size-4 mr-1" /> Back
            </Button>
            <h1 className="text-lg font-semibold font-mono">{file.file_number}</h1>
            <Badge>{STATUS_LABEL[file.status] ?? file.status}</Badge>
            {file.eqs_booking_state === "awaiting_id" && (
              <Badge variant="outline" className="border-amber-500 text-amber-700 gap-1">
                <Loader2 className="size-3 animate-spin" />
                Awaiting EQS Booking ID
              </Badge>
            )}
            {file.eqs_booking_state === "created" && file.eqs_booking_id && (
              <Badge variant="outline" className="border-emerald-500 text-emerald-700">
                EQS Booking: {file.eqs_booking_id}
              </Badge>
            )}
            {file.eqs_booking_state === "incomplete" && (
              <Badge
                variant="outline"
                className="border-amber-500 text-amber-700"
                title="EQS принял букинг, но не заполнил его полностью"
              >
                EQS Booking incomplete{file.eqs_booking_id ? `: ${file.eqs_booking_id}` : ""}
              </Badge>
            )}
            {file.eqs_booking_state === "failed" && (
              <Badge
                variant="outline"
                className="border-red-500 text-red-700"
                title={file.eqs_booking_error ?? ""}
              >
                EQS Booking failed
              </Badge>
            )}

            {(warnQ.data?.items?.length ?? 0) > 0 && (
              <Badge variant="destructive" className="gap-1">
                <AlertTriangle className="size-3" />
                {warnQ.data!.items.length}
              </Badge>
            )}
          </div>
          <div className="flex gap-2 flex-wrap justify-end">
            <Button
              size="sm"
              variant="outline"
              className="h-9 w-9 p-0"
              onClick={() => refreshFileMut.mutate()}
              disabled={refreshFileMut.isPending}
              title="Pull new units from linked bookings and refresh finance from EQS"
            >
              <RefreshCw className={`size-4 ${refreshFileMut.isPending ? "animate-spin" : ""}`} />
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="h-9 w-9 p-0"
              onClick={() => navigate({ to: "/eqs-files/$id/edit", params: { id } })}
              title="Edit file"
              aria-label="Edit file"
            >
              <Pencil className="size-4" />
            </Button>

            {file.status === "DR" && (
              <Button size="sm" onClick={() => setPendingStatus("OP")} disabled={openMut.isPending}>
                Open File
              </Button>
            )}
            {file.status === "OP" && (
              <Button size="sm" onClick={() => setPendingStatus("RP")} disabled={confirmRpMut.isPending}>
                Confirm RP
              </Button>
            )}
            {file.status === "RP" && (
              <Button size="sm" onClick={() => setPendingStatus("RCL")} disabled={readyForClMut.isPending}>
                Set Ready for CL
              </Button>
            )}
            {file.status === "RCL" && (
              <Button size="sm" onClick={() => setPendingStatus("CL")} disabled={closeMut.isPending}>
                Close File
              </Button>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="outline" className="gap-1">
                  <MoreHorizontal className="size-4" /> More
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem onSelect={() => setCopyMode("plain")}>
                  <Copy className="size-4 mr-2" /> Copy
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => setCopyMode("with_budget")}>
                  <ClipboardCopy className="size-4 mr-2" /> Copy with planned budget
                </DropdownMenuItem>
                <DropdownMenuSeparator />



                {file.status === "OP" &&
                  (file.eqs_booking_state == null ||
                    file.eqs_booking_state === "failed" ||
                    file.eqs_booking_state === "incomplete") && (
                    <DropdownMenuItem onSelect={() => setEqsDialogOpen(true)}>
                      <Send className="size-4 mr-2" />
                      {file.eqs_booking_state === "incomplete" ? "Resend Booking" : "Create Booking in EQS"}
                    </DropdownMenuItem>
                  )}

                {file.status === "OP" &&
                  (file.eqs_booking_state === "failed" ||
                    file.eqs_booking_state === "incomplete") && (
                    <DropdownMenuItem
                      onSelect={() => retryEqsMut.mutate()}
                      disabled={retryEqsMut.isPending}
                    >
                      <RotateCw className="size-4 mr-2" /> Retry EQS
                    </DropdownMenuItem>
                  )}

                <Can role="Admin">
                  {file.status !== "DR" && (
                    <DropdownMenuItem
                      onSelect={() => {
                        const r = window.prompt("Revert reason (optional):", "");
                        if (r === null) return;
                        revertMut.mutate(r);
                      }}
                      disabled={revertMut.isPending}
                    >
                      <RotateCcw className="size-4 mr-2" /> Revert status
                    </DropdownMenuItem>
                  )}
                  {(file.op_date || file.rp_date || file.rcl_date || file.cl_date || file.cn_date) && (
                    <DropdownMenuItem onSelect={() => setEditDatesOpen(true)}>
                      <CalendarClock className="size-4 mr-2" /> Set status date
                    </DropdownMenuItem>
                  )}
                </Can>

                {file.status !== "CL" && file.status !== "CN" && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      className="text-destructive focus:text-destructive"
                      onSelect={() => setPendingStatus("CN")}
                      disabled={cancelMut.isPending}
                    >
                      <Trash2 className="size-4 mr-2" /> Cancel
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

        </div>
        <div className="mt-2 text-sm text-muted-foreground flex flex-wrap items-center gap-x-2 gap-y-1">
          <span className="inline-flex items-center gap-1">
            {file.departments?.name ?? "—"}
            <button
              type="button"
              className="text-muted-foreground hover:text-foreground p-0.5"
              title="Change department"
              onClick={() => setChangeDeptOpen(true)}
            >
              <Pencil className="size-3" />
            </button>
          </span>
          <span>·</span>
          <span>
            {file.customer_name ?? "—"}
            {file.customer_accno ? (
              <span className="font-mono text-xs ml-1">({file.customer_accno})</span>
            ) : null}
          </span>
          <span>·</span>
          <span>
            Sales:{" "}
            {file.sales_person?.full_name ??
              file.sales_manager?.full_name ??
              file.sales_manager?.email ??
              "—"}
          </span>
          <span>·</span>
          <span className="text-xs">
            <span className="font-mono">{file.origin_country_code ?? file.origin_subregion ?? "—"}</span>
            {file.origin_locn && (
              <span title={file.origin_locn}>/{(file as any).origin_locn_desc ?? file.origin_locn}</span>
            )}
            {" → "}
            <span className="font-mono">{file.dest_country_code ?? file.dest_subregion ?? "—"}</span>
            {file.dest_locn && (
              <span title={file.dest_locn}>/{(file as any).dest_locn_desc ?? file.dest_locn}</span>
            )}
          </span>
          <span>·</span>
          <span className="font-mono text-xs">
            {file.planned_departure_date ?? "—"} → {file.planned_arrival_date ?? "—"}
          </span>
          {(file.op_date || file.rp_date || file.rcl_date || file.cl_date || file.cn_date) && (
            <span className="ml-auto font-mono text-xs flex flex-wrap items-center gap-x-3 gap-y-0.5">
              {file.op_date && (<span><span className="text-muted-foreground">OP:</span> {file.op_date}</span>)}
              {file.rp_date && (<span><span className="text-muted-foreground">RP:</span> {file.rp_date}</span>)}
              {file.rcl_date && (<span><span className="text-muted-foreground">RfCL:</span> {file.rcl_date}</span>)}
              {file.cl_date && (<span><span className="text-muted-foreground">CL:</span> {file.cl_date}</span>)}
              {file.cn_date && (<span><span className="text-muted-foreground">CN:</span> {file.cn_date}</span>)}
            </span>
          )}
        </div>
        <div className="mt-1 text-sm flex flex-wrap items-center gap-x-2 gap-y-1">
          <span className="text-muted-foreground">Types:</span>
          {containerTypes.length === 0 ? (
            <span className="text-muted-foreground">—</span>
          ) : (
            containerTypes.map((c) => (
              <Badge key={c.id} variant="outline" className="font-mono text-[11px]">
                {c.container_type}{(c as any).grade ? ` ${(c as any).grade}` : ""}×{c.planned_qty}
              </Badge>
            ))
          )}
          <span className="text-muted-foreground ml-2">·</span>
          <span className="text-muted-foreground">Units:</span>
          <span className="font-mono text-xs">
            {unitsCount}/{containerTypes.reduce((s, c) => s + (c.planned_qty || 0), 0)}
          </span>
          {file.notes && (
            <>
              <span className="text-muted-foreground ml-2">·</span>
              <span className="text-muted-foreground truncate max-w-[40ch]" title={file.notes}>
                {file.notes}
              </span>
            </>
          )}
        </div>
      </div>

      <AlertDialog
        open={changeDeptOpen}
        onOpenChange={(o) => {
          setChangeDeptOpen(o);
          if (o) setNewDeptId(file.department_id ?? "");
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Сменить отдел?</AlertDialogTitle>
            <AlertDialogDescription>
              Номер файла будет перевыпущен. Текущий:{" "}
              <span className="font-mono">{file.file_number}</span>. После
              смены отдела префикс и порядковый номер изменятся.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-2">
            <Select value={newDeptId} onValueChange={setNewDeptId}>
              <SelectTrigger>
                <SelectValue placeholder="Выберите отдел…" />
              </SelectTrigger>
              <SelectContent>
                {(deptsQ.data?.items ?? []).map((d: any) => (
                  <SelectItem key={d.id} value={d.id}>
                    {d.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction
              disabled={!newDeptId || newDeptId === file.department_id || changeDeptMut.isPending}
              onClick={(e) => {
                e.preventDefault();
                changeDeptMut.mutate();
              }}
            >
              Сменить и перевыпустить номер
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>



      <Tabs defaultValue="fact" className="w-full">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="booking-types">
            Booking Types{containerTypes.length > 0 && (
              <span className="ml-1 text-xs">({containerTypes.length})</span>
            )}
          </TabsTrigger>
          <TabsTrigger value="units">
            Units{" "}
            {(unitsQ.data?.items?.filter((u: any) => u.is_active).length ?? 0) > 0 && (
              <span className="ml-1 text-xs">({unitsQ.data!.items.filter((u: any) => u.is_active).length})</span>
            )}
          </TabsTrigger>
          <div className="w-px h-5 bg-border mx-2 self-center" aria-hidden />
          <TabsTrigger value="plan">Budget Plan</TabsTrigger>
          <TabsTrigger value="fact">Budget Fact</TabsTrigger>
          <TabsTrigger value="finance">Finance</TabsTrigger>
          <div className="w-px h-5 bg-border mx-2 self-center" aria-hidden />
          <TabsTrigger value="warnings">
            Warnings{" "}
            {(warnQ.data?.items?.length ?? 0) > 0 && (
              <span className="ml-1 text-xs">({warnQ.data!.items.length})</span>
            )}
          </TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="eqs">EQS Interface</TabsTrigger>
        </TabsList>

        <TabsContent value="booking-types" className="mt-4">
          <BookingTypesTab
            fileId={id}
            initialRows={containerTypes}
          />
        </TabsContent>



        <TabsContent value="plan" className="mt-4">


      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center gap-2 flex-wrap min-h-[50px]">
          <h2 className="font-semibold mr-2">Budget plan</h2>
          {planLocked && (
            <Badge variant="outline" className="text-xs h-7 leading-none flex items-center">
              Locked · {file.status}
            </Badge>
          )}
          {file.budget_unlocked && (
            <Badge variant="outline" className="text-xs h-7 leading-none flex items-center border-amber-500 text-amber-700">
              Unlocked · {file.status}
            </Badge>
          )}
          {file.status !== "DR" && (
            <button
              type="button"
              className={`px-2 py-1 text-xs rounded-md border border-border ${file.budget_unlocked ? "bg-muted font-medium" : ""}`}
              onClick={async () => {
                try {
                  await setUnlockedFn({ data: { file_id: file.id, unlocked: !file.budget_unlocked } });
                  toast.success(file.budget_unlocked ? "Budget locked" : "Budget unlocked");
                  qc.invalidateQueries({ queryKey: ["file", id] });
                } catch (e: any) {
                  toast.error(e?.message ?? "Failed");
                }
              }}
            >
              {file.budget_unlocked ? "Lock budget" : "Unlock budget"}
            </button>
          )}

          <div className="flex rounded-md border border-border ml-2 text-xs">
            <button
              type="button"
              className={`px-2 py-1 ${planView === "overall" ? "bg-muted font-medium" : ""}`}
              onClick={() => setPlanView("overall")}
            >
              Overall
            </button>
            <button
              type="button"
              className={`px-2 py-1 border-l border-border ${planView === "per_type" ? "bg-muted font-medium" : ""}`}
              onClick={() => setPlanView("per_type")}
            >
              Per type
            </button>
          </div>
          <div className="flex rounded-md border border-border text-xs">
            <button
              type="button"
              className={`px-2 py-1 ${planCurrency === "USD" ? "bg-muted font-medium" : ""}`}
              onClick={() => setPlanCurrency("USD")}
            >
              USD
            </button>
            <button
              type="button"
              className={`px-2 py-1 border-l border-border ${planCurrency === "EUR" ? "bg-muted font-medium" : ""}`}
              onClick={() => setPlanCurrency("EUR")}
            >
              EUR
            </button>
          </div>
        </div>
        {/* Top summary matrix — Plan only */}
        <div className="px-4 py-3 border-b border-border bg-muted/20">
          <div className="flex items-center justify-between mb-2 h-7">
            <div className="text-xs font-medium text-muted-foreground">File total</div>
            <label className="flex items-center gap-1 text-xs text-muted-foreground">
              FX rate EUR/USD:
              <Input
                type="number"
                step="0.0001"
                min="0"
                placeholder="e.g. 1.0850"
                className="h-7 w-28"
                value={fxRateInput}
                disabled={planLocked}
                onChange={(e) => setFxRateInput(e.target.value)}
              />
              {(() => {
                const current = (file as any)?.fx_rate_eur_usd;
                const currentStr = current == null ? "" : String(current);
                const dirty = fxRateInput !== currentStr;
                if (!dirty || planLocked) return null;
                return (
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-7 px-2"
                    onClick={async () => {
                      const raw = fxRateInput.trim();
                      const num = raw === "" ? null : Number(raw);
                      if (num !== null && !Number.isFinite(num)) {
                        toast.error("Invalid number");
                        return;
                      }
                      try {
                        await updateFileFn({
                          data: { id: file.id, fx_rate_eur_usd: num },
                        });
                        await Promise.all([
                          qc.invalidateQueries({ queryKey: ["file", id] }),
                          qc.invalidateQueries({ queryKey: ["file-fact", id] }),
                        ]);
                        toast.success("FX rate updated");
                      } catch (err: any) {
                        toast.error(err?.message ?? "Failed");
                      }
                    }}
                  >
                    Update
                  </Button>
                );
              })()}
            </label>
          </div>

          <div className="overflow-x-auto">
            <table className="text-xs">
              <thead>
                <tr className="text-xs text-muted-foreground">
                  <th className="text-left p-2 pr-16"></th>
                  <th className="text-right p-2">Plan</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="p-2 pr-16 font-medium">Revenue</td>
                  <td className="p-2 text-right font-mono">
                    {overallTotals.revenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
                <tr>
                  <td className="p-2 pr-16 font-medium">Cost</td>
                  <td className="p-2 text-right font-mono">
                    {overallTotals.cost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
                <tr className="border-t border-border">
                  <td className="p-2 pr-16 font-medium">GPM</td>
                  <td className={`p-2 text-right font-mono font-semibold ${overallGpm >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                    {overallGpm.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        {(() => {
          const fmtNum = (n: number) =>
            n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

          const renderPlanTable = (
            rows: any[],
            opts: {
              ctForAdd: string | null;
              key: string;
              showDraft: boolean;
              totals: { revenue: number; cost: number };
              gpm: number;
              qty?: number;
              showKindBadge?: boolean;
            },
          ) => {
            const draftArticle = artQ.data?.items.find((a: any) => a.id === newLine.article_id);
            const draftKind = draftArticle?.kind as "REVENUE" | "COST" | undefined;
            const draftAmtNum = parseFloat(newLine.amount_per_unit) || 0;
            const isPerType = planView === "per_type";
            const qty = opts.qty ?? 1;
            const colCount = isPerType ? 5 : 5;
            return (
            <div key={opts.key} className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-muted/40">
                  {isPerType ? (
                    <tr>
                      <th className="text-left p-2 font-medium">Budget Article</th>
                      <th className="text-right p-2 font-medium">Per Unit</th>
                      <th className="text-right p-2 font-medium">Total</th>
                      <th className="text-left p-2 font-medium">Data Type</th>
                      <th className="w-10"></th>
                    </tr>
                  ) : (
                    <tr>
                      <th className="text-left p-2 font-medium">Budget Article</th>
                      <th className="text-right p-2 font-medium">Revenue</th>
                      <th className="text-right p-2 font-medium">Cost</th>
                      <th className="text-right p-2 font-medium">GPM Impact</th>
                      <th className="text-left p-2 font-medium">Data Type</th>
                    </tr>
                  )}
                </thead>
                <tbody>
                  {rows.map((l: any) => {
                    const kind = l.budget_articles?.kind;
                    const total = amountInCur(l);
                    const isRev = kind === "REVENUE";
                    const isCost = kind === "COST";
                    const signedTotalStored = (isRev ? total : 0) + (isCost ? total : 0);
                    const rowQty = isPerType
                      ? (Number(qty || l.planned_qty) || 1)
                      : (Number(l.planned_qty ?? qty) || 1);
                    const perUnitSigned = Number(l.amount_per_unit ?? 0);
                    const signedTotal = isPerType ? perUnitSigned * rowQty : signedTotalStored;
                    const perUnit = isPerType ? perUnitSigned : signedTotalStored / rowQty;
                    const valueClass = isCost ? "text-red-600" : isRev ? "text-emerald-600" : "";
                    return (
                      <tr key={l.id ?? l.article_id} className="border-t border-border">
                        <td className="p-2">
                          <div>
                            {l.budget_articles?.name ?? "—"}
                            {opts.showKindBadge && (
                              <Badge variant="outline" className="ml-1 text-[10px] py-0">
                                {kind}
                              </Badge>
                            )}
                          </div>
                        </td>
                        {(() => {
                          const edit = editingLine;
                          return isPerType ? (
                          edit && edit.id === l.id ? (
                            <>
                              <td className="p-2">
                                <div className="flex gap-1 justify-end">
                                  <Input
                                    type="number"
                                    step="0.01"
                                    className="h-8 text-right w-24"
                                    value={edit.amount_per_unit}
                                    onChange={(e) => {
                                      const raw = e.target.value;
                                      let next = raw;
                                      if (isCost && raw !== "" && raw !== "-") {
                                        const n = parseFloat(raw);
                                        if (!isNaN(n) && n > 0) next = String(-n);
                                      }
                                      setEditingLine({ ...edit, amount_per_unit: next });
                                    }}
                                  />
                                  <Select
                                    value={edit.currency}
                                    onValueChange={(v) => setEditingLine({ ...edit, currency: v })}
                                  >
                                    <SelectTrigger className="h-8 w-20">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {["USD", "EUR", "RUB", "CNY", "AED"].map((c) => (
                                        <SelectItem key={c} value={c}>{c}</SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                              </td>
                              <td className={`p-2 text-right font-mono font-medium ${valueClass}`}>
                                {fmtNum((parseFloat(edit.amount_per_unit) || 0) * rowQty)}
                              </td>
                              <td className="p-2">
                                <Badge variant="outline" className="text-[10px] py-0 border-slate-400 text-slate-600">
                                  BUDGET
                                </Badge>
                              </td>
                              <td className="p-2">
                                <div className="flex gap-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    disabled={editLine.isPending}
                                    onClick={() =>
                                      editLine.mutate({
                                        id: l.id,
                                        article_id: l.article_id,
                                        container_type: l.container_type ?? null,
                                        planned_qty: rowQty,
                                        amount_per_unit: parseFloat(edit.amount_per_unit) || 0,
                                        currency: edit.currency,
                                        source_type: (l.source_type ?? "MANUAL") as "MANUAL" | "TEMPLATE" | "IMPORT",
                                        notes: l.notes ?? null,
                                      })
                                    }
                                  >
                                    <Check className="size-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => setEditingLine(null)}
                                  >
                                    <X className="size-4" />
                                  </Button>
                                </div>
                              </td>
                            </>
                          ) : (
                          <>
                            <td className={`p-2 text-right font-mono ${valueClass}`}>
                              {fmtNum(perUnit)}
                            </td>
                            <td className={`p-2 text-right font-mono font-medium ${valueClass}`}>
                              {fmtNum(signedTotal)}
                            </td>
                            <td className="p-2">
                              <Badge variant="outline" className="text-[10px] py-0 border-slate-400 text-slate-600">
                                BUDGET
                              </Badge>
                            </td>
                            <td className="p-2">
                              {!planLocked && l.id && (
                                <div className="flex gap-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => {
                                      setNewLine({
                                        article_id: "",
                                        container_type: "",
                                        planned_qty: "1",
                                        amount_per_unit: "",
                                        currency: "USD",
                                        amount_usd: "",
                                        amount_eur: "",
                                      });
                                      setEditingLine({
                                        id: l.id,
                                        amount_per_unit: String(l.amount_per_unit ?? ""),
                                        currency: l.currency ?? "USD",
                                      });
                                    }}
                                  >
                                    <Pencil className="size-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => delLine.mutate(l.id)}
                                  >
                                    <Trash2 className="size-4" />
                                  </Button>
                                </div>
                              )}
                            </td>
                          </>
                          )
                        ) : (
                          <>
                            <td className="p-2 text-right font-mono">
                              {isRev ? fmtNum(total) : "—"}
                            </td>
                            <td className="p-2 text-right font-mono">
                              {isCost ? fmtNum(total) : "—"}
                            </td>
                            <td className={`p-2 text-right font-mono font-medium ${signedTotal >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                              {fmtNum(signedTotal)}
                            </td>
                            <td className="p-2">
                              <Badge variant="outline" className="text-[10px] py-0 border-slate-400 text-slate-600">
                                BUDGET
                              </Badge>
                            </td>
                          </>
                        );
                        })()}
                      </tr>
                    );
                  })}
                  {!planLocked && isPerType && opts.ctForAdd && opts.showDraft && (
                    <tr className="border-t border-border bg-muted/20">
                      <td className="p-2">
                        <Select
                          value={
                            newLine.container_type === opts.ctForAdd
                              ? newLine.article_id
                              : ""
                          }
                          onValueChange={(v) => {
                            const pickedKind = artQ.data?.items.find((a: any) => a.id === v)?.kind;
                            const curAmt = parseFloat(newLine.amount_per_unit);
                            let nextAmt = newLine.amount_per_unit;
                            if (pickedKind === "COST" && !isNaN(curAmt) && curAmt > 0) {
                              nextAmt = String(-curAmt);
                            }
                            setNewLine({
                              ...newLine,
                              container_type: opts.ctForAdd!,
                              planned_qty: String(qty),
                              article_id: v,
                              amount_per_unit: nextAmt,
                            });
                          }}

                        >
                          <SelectTrigger className="h-8">
                            <SelectValue placeholder="Select article…" />
                          </SelectTrigger>
                          <SelectContent>
                            {artQ.data?.items.map((a: any) => (
                              <SelectItem key={a.id} value={a.id}>
                                [{a.kind}] {a.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-2">
                        <div className="flex gap-1">
                          <Input
                            type="number"
                            step="0.01"
                            className="h-8 text-right"
                            placeholder={draftKind === "COST" ? "Cost / unit" : "Revenue / unit"}
                            value={
                              newLine.container_type === opts.ctForAdd
                                ? newLine.amount_per_unit
                                : ""
                            }
                            onChange={(e) => {
                              const raw = e.target.value;
                              let next = raw;
                              if (draftKind === "COST" && raw !== "" && raw !== "-") {
                                const n = parseFloat(raw);
                                if (!isNaN(n) && n > 0) next = String(-n);
                              }
                              setNewLine({
                                ...newLine,
                                container_type: opts.ctForAdd!,
                                planned_qty: String(qty),
                                amount_per_unit: next,
                              });
                            }}

                          />
                          <Select
                            value={
                              newLine.container_type === opts.ctForAdd
                                ? newLine.currency
                                : "USD"
                            }
                            onValueChange={(v) =>
                              setNewLine({
                                ...newLine,
                                container_type: opts.ctForAdd!,
                                planned_qty: String(qty),
                                currency: v,
                              })
                            }
                          >
                            <SelectTrigger className="h-8 w-20">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {["USD", "EUR", "RUB", "CNY", "AED"].map((c) => (
                                <SelectItem key={c} value={c}>
                                  {c}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </td>
                      <td className={`p-2 text-right font-mono ${
                        newLine.container_type === opts.ctForAdd && draftKind
                          ? (draftKind === "COST" ? "text-red-600" : "text-emerald-600")
                          : "text-muted-foreground"
                      }`}>
                        {newLine.container_type === opts.ctForAdd && draftKind
                          ? fmtNum((draftKind === "COST" ? -Math.abs(draftAmtNum) : draftAmtNum) * qty)
                          : "0.00"}
                      </td>
                      <td className="p-2">
                        <Badge variant="outline" className="text-[10px] py-0 border-slate-400 text-slate-600">
                          BUDGET
                        </Badge>
                      </td>
                      <td className="p-2">
                        <Button
                          size="icon"
                          disabled={
                            newLine.container_type !== opts.ctForAdd ||
                            !newLine.article_id ||
                            !newLine.amount_per_unit ||
                            addLine.isPending
                          }
                          onClick={() => {
                            addLine.mutate(undefined, {
                              onSuccess: () => setDraftOpenFor(null),
                            });
                          }}
                        >
                          <Plus className="size-4" />
                        </Button>
                      </td>
                    </tr>
                  )}
                </tbody>
                <tfoot>
                  {isPerType ? (
                    <tr className="border-t-2 border-border bg-muted/30 font-semibold">
                      <td className="p-2">Total</td>
                      <td className={`p-2 text-right font-mono ${opts.gpm >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                        {fmtNum((opts.totals.revenue + opts.totals.cost) / (opts.qty ?? 1))}
                      </td>
                      <td className={`p-2 text-right font-mono ${opts.gpm >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                        {fmtNum(opts.totals.revenue + opts.totals.cost)}
                      </td>
                      <td className="p-2"></td>
                      <td className="p-2"></td>
                    </tr>
                  ) : (
                    <tr className="border-t-2 border-border bg-muted/30 font-semibold">
                      <td className="p-2">Total</td>
                      <td className="p-2 text-right font-mono">{fmtNum(opts.totals.revenue)}</td>
                      <td className="p-2 text-right font-mono">{fmtNum(opts.totals.cost)}</td>
                      <td className={`p-2 text-right font-mono ${opts.gpm >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                        {fmtNum(opts.gpm)}
                      </td>
                      <td className="p-2"></td>
                    </tr>
                  )}
                </tfoot>
              </table>
            </div>
            );
          };


          if (planView === "overall") {
            const firstCt = perTypeGroups[0];
            return (
              <div>
                {!planLocked && (
                  <div className="px-2 py-1 text-xs font-medium bg-muted/30 border-y border-border flex items-center justify-between">
                    <span className="font-mono">Overall</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 px-2"
                      disabled={!firstCt}
                      title={!firstCt ? "Add container types in the file header first" : undefined}
                      onClick={() => {
                        if (!firstCt) return;
                        setPlanView("per_type");
                        setDraftOpenFor(firstCt.container_type);
                        setNewLine({
                          article_id: "",
                          container_type: firstCt.container_type,
                          planned_qty: String(firstCt.planned_qty ?? 1),
                          amount_per_unit: "",
                          currency: "USD",
                          amount_usd: "",
                          amount_eur: "",
                        });
                      }}
                    >
                      <Plus className="size-3 mr-1" />
                      Add line
                    </Button>
                  </div>
                )}
                {renderPlanTable(overallLines, {
                  ctForAdd: null,
                  key: "overall",
                  showDraft: false,
                  totals: overallTotals,
                  gpm: overallGpm,
                  showKindBadge: false,
                })}
              </div>
            );
          }

          return (
            <div className="space-y-4">
              {perTypeGroups.map((g) => (
                <div key={g.container_type}>
                  <div className="px-2 py-1 text-xs font-medium bg-muted/30 border-y border-border flex items-center justify-between">
                    <span className="font-mono">
                      {g.container_type}
                      {g.grade && (
                        <span className="ml-1 text-muted-foreground">{g.grade}</span>
                      )}
                      {g.planned_qty != null && (
                        <span className="ml-2 text-muted-foreground">
                          × {g.planned_qty}
                        </span>
                      )}
                    </span>
                    {!planLocked && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 px-2"
                        onClick={() => {
                          setDraftOpenFor((cur) =>
                            cur === g.container_type ? null : g.container_type,
                          );
                          setNewLine({
                            article_id: "",
                            container_type: g.container_type,
                            planned_qty: "1",
                            amount_per_unit: "",
                            currency: "USD",
                            amount_usd: "",
                            amount_eur: "",
                          });
                        }}
                      >
                        <Plus className="size-3 mr-1" />
                        {draftOpenFor === g.container_type ? "Cancel" : "Add line"}
                      </Button>
                    )}
                  </div>
                  {renderPlanTable(g.rows, {
                    ctForAdd: g.container_type,
                    key: `pt-${g.container_type}`,
                    showDraft: draftOpenFor === g.container_type,
                    totals: g.totals,
                    gpm: g.gpm,
                    qty: g.planned_qty ?? 1,
                    showKindBadge: true,
                  })}
                </div>
              ))}
              {perTypeGroups.length === 0 && (
                <div className="p-4 text-xs text-muted-foreground">
                  No container types defined. Add container types in the file header.
                </div>
              )}
            </div>
          );
        })()}


      </div>

        </TabsContent>

        <TabsContent value="fact" className="mt-4">
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2 flex-wrap min-h-[50px]">

              <h2 className="font-semibold mr-2">Budget Fact / Budget Execution</h2>

              {/* View level */}
              <div className="flex rounded-md border border-border text-xs">
                <button
                  type="button"
                  className={`px-2 py-1 ${factViewLevel === "file" ? "bg-muted font-medium" : ""}`}
                  onClick={() => setFactViewLevel("file")}
                >
                  File total
                </button>
                <button
                  type="button"
                  className={`px-2 py-1 border-l border-border ${factViewLevel === "unit" ? "bg-muted font-medium" : ""}`}
                  onClick={() => setFactViewLevel("unit")}
                >
                  By UnitNo
                </button>
              </div>

              {/* Detail mode */}
              <div className="flex rounded-md border border-border text-xs">
                <button
                  type="button"
                  className={`px-2 py-1 ${factDetail === "summary" ? "bg-muted font-medium" : ""}`}
                  onClick={() => setFactDetail("summary")}
                >
                  Summary
                </button>
                <button
                  type="button"
                  className={`px-2 py-1 border-l border-border ${factDetail === "details" ? "bg-muted font-medium" : ""}`}
                  onClick={() => setFactDetail("details")}
                >
                  Details
                </button>
              </div>

              {/* Show data */}
              <div className="flex rounded-md border border-border text-xs">
                {([
                  ["all", "All"],
                  ["budget", "Budget"],
                  ["booked", "Booked"],
                  ["accruals", "Accruals"],
                  ["rt", "RT Expected"],
                ] as const).map(([k, label], i) => (
                  <button
                    key={k}
                    type="button"
                    className={`px-2 py-1 ${i > 0 ? "border-l border-border" : ""} ${factShowData === k ? "bg-muted font-medium" : ""}`}
                    onClick={() => setFactShowData(k)}
                  >
                    {label}
                  </button>
                ))}
              </div>

              {/* Currency */}
              <div className="flex rounded-md border border-border text-xs">
                <button
                  type="button"
                  className={`px-2 py-1 ${factCurrency === "USD" ? "bg-muted font-medium" : ""}`}
                  onClick={() => setFactCurrency("USD")}
                >
                  USD
                </button>
                <button
                  type="button"
                  className={`px-2 py-1 border-l border-border ${factCurrency === "EUR" ? "bg-muted font-medium" : ""}`}
                  onClick={() => setFactCurrency("EUR")}
                >
                  EUR
                </button>
              </div>

            </div>


            {(() => {
              if (factQ.isLoading) {
                return <div className="p-4 text-sm text-muted-foreground">Loading…</div>;
              }
              const allLines = (factQ.data?.lines ?? []) as any[];
              const allSummary = (factQ.data?.summary ?? []) as any[];

              // Filter by currency
              const fLinesByCur = allLines.filter((l) => (l.currency ?? "USD") === factCurrency);
              const sumByCur = allSummary.filter((s) => s.currency === factCurrency);

              // Apply Show data filter to lines (Budget filter handled separately via summary.plan)
              const visibleLines = fLinesByCur.filter((l) => {
                if (factShowData === "all") return true;
                if (factShowData === "booked") return l.source_kind === "booked_finance";
                if (factShowData === "accruals") return l.source_kind === "cost_accrual";
                if (factShowData === "rt") return l.source_kind === "billing_expected_revenue";
                if (factShowData === "budget") return l.source_kind === "budgeted";
                return true;
              });

              const fmt = (n: number) =>
                n ? n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "—";

              // ============ Top summary matrix (Revenue / Cost x Budgeted/Executed/Accrued/Booked) ============
              const filteredSummary = factSelectedArticle
                ? sumByCur.filter((s) => (s.article_id ?? "_") === factSelectedArticle)
                : sumByCur;
              const topAgg = {
                rev: { b: 0, a: 0, k: 0, e: 0, bg: 0, fc: 0 },
                cost: { b: 0, a: 0, k: 0, e: 0, bg: 0, fc: 0 },
              };
              for (const s of filteredSummary) {
                const bucket = s.kind === "REVENUE" ? topAgg.rev : topAgg.cost;
                bucket.b += Number(s.plan ?? 0);
                bucket.a += Number(s.accrued ?? 0) + Number(s.expected_rt ?? 0);
                bucket.k += Number(s.booked ?? 0);
                bucket.e += Number(s.executed ?? 0);
                bucket.bg += Number((s as any).budgeted ?? 0);
                bucket.fc += Number((s as any).forecast ?? s.executed ?? 0);
              }

              // ============ Article rows ============
              type Row = {
                key: string;
                article_id: string | null;
                article_name: string;
                kind: string | null;
                revenue: number;
                cost: number;
                indicators: Set<string>;
                is_unmapped: boolean;
                is_extra: boolean;
                has_plan: boolean;
                has_booked: boolean;
                has_accrual: boolean;
                has_rt: boolean;
              };
              const articleMap = new Map<string, Row>();
              const ensureRow = (
                article_id: string | null,
                article_name: string,
                kind: string | null,
                is_unmapped: boolean,
              ): Row => {
                const k = article_id ?? "_unmapped_";
                let r = articleMap.get(k);
                if (!r) {
                  r = {
                    key: k,
                    article_id,
                    article_name,
                    kind,
                    revenue: 0,
                    cost: 0,
                    indicators: new Set(),
                    is_unmapped,
                    is_extra: false,
                    has_plan: false,
                    has_booked: false,
                    has_accrual: false,
                    has_rt: false,
                  };
                  articleMap.set(k, r);
                }
                return r;
              };

              // Seed from summary so plan-only / extra flags are visible even when filter hides lines
              for (const s of sumByCur) {
                const r = ensureRow(
                  s.article_id ?? null,
                  s.article_name ?? "(Unmapped)",
                  s.kind,
                  !!s.is_unmapped,
                );
                if (Number(s.budgeted) !== 0) {
                  r.has_plan = true;
                  r.indicators.add("BUDGET");
                }
                if (Number(s.booked) !== 0) {
                  r.has_booked = true;
                  r.indicators.add("BOOKED");
                }
                if (Number(s.accrued) !== 0) {
                  r.has_accrual = true;
                  r.indicators.add("ACCRUAL");
                }
                if (Number(s.expected_rt) !== 0) {
                  r.has_rt = true;
                  r.indicators.add("RT EXPECTED");
                }
                 // BUDGETED indicator removed — duplicates the BUDGET badge.
                 // The "Budgeted" matrix column already surfaces the remainder.

                if (s.is_unmapped) r.indicators.add("UNMAPPED");
                if (s.is_extra) {
                  r.is_extra = true;
                  r.indicators.add("UNPLANNED");
                }
              }

              // Aggregate amounts based on visible (filtered) lines.
              // Budget-режим: budgeted-строки уже лежат в visibleLines со знаком
              // (cost → отрицательный, revenue → положительный), считается единообразно.
              for (const l of visibleLines) {
                const kind = l.article_kind;
                const r = ensureRow(
                  l.article_id ?? null,
                  l.article_name ?? "(Unmapped)",
                  kind,
                  !!l.is_unmapped,
                );
                const amt = Number(l.amount ?? 0);
                if (kind === "REVENUE") r.revenue += amt;
                else r.cost += amt;
              }


              const rows = Array.from(articleMap.values())
                .filter((r) => {
                  // Drop rows that have nothing relevant under current filter
                  if (factShowData === "budget") return r.has_plan;
                  if (factShowData === "booked") return r.has_booked;
                  if (factShowData === "accruals") return r.has_accrual;
                  if (factShowData === "rt") return r.has_rt;
                  return r.has_plan || r.has_booked || r.has_accrual || r.has_rt;
                })
                .sort((a, b) => a.article_name.localeCompare(b.article_name));

              const statusFor = (r: Row): string => {
                if (r.is_unmapped) return "unmapped";
                if (!r.has_plan && (r.has_booked || r.has_accrual || r.has_rt))
                  return r.has_booked ? "unplanned booked" : "unplanned";
                if (r.has_plan && !r.has_booked && !r.has_accrual && !r.has_rt) return "budget only";
                if (r.has_accrual && !r.has_booked) return "accrual only";
                if (r.has_rt && !r.has_booked) return "expected";
                if (r.has_booked && (r.has_accrual || r.has_rt)) return "partially booked";
                if (r.has_booked) return "booked";
                return "—";
              };

              const indicatorClass = (ind: string) => {
                switch (ind) {
                  case "BUDGET":
                    return "border-slate-400 text-slate-600";
                  // BUDGETED case removed.

                  case "BOOKED":
                    return "border-emerald-500 text-emerald-700";
                  case "ACCRUAL":
                    return "border-amber-500 text-amber-700";
                  case "RT EXPECTED":
                    return "border-sky-500 text-sky-700";
                  case "UNPLANNED":
                    return "border-blue-500 text-blue-700";
                  case "UNMAPPED":
                    return "border-red-500 text-red-700";
                  default:
                    return "";
                }
              };

              const unmappedLineCount = fLinesByCur.filter((l) => l.is_unmapped).length;

              return (
                <>
                  {/* Top summary matrix */}
                  <div className="px-4 py-3 border-b border-border bg-muted/20">
                    <div className="flex items-center justify-between mb-2 h-7">
                      <div className="text-xs font-medium text-muted-foreground">
                        {factSelectedArticle
                          ? `Selected: ${rows.find((r) => r.key === factSelectedArticle)?.article_name ?? ""}`
                          : "File total"}
                      </div>
                      <div className="flex items-center gap-3">
                        {factSelectedArticle && (
                          <button
                            type="button"
                            onClick={() => setFactSelectedArticle(null)}
                            className="text-xs underline text-muted-foreground"
                          >
                            Clear selection
                          </button>
                        )}
                        <span className="text-xs text-muted-foreground">
                          Click a row to drill down.
                        </span>
                      </div>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="text-xs">
                        <thead>
                          <tr className="text-xs text-muted-foreground">
                            <th className="text-left p-2"></th>
                            <th className="text-right p-2">Plan</th>
                            <th className="text-right p-2">Booked</th>
                            <th className="text-right p-2">Accrued</th>
                            <th className="text-right p-2">Budgeted</th>
                            <th className="text-right p-2">Forecast</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td className="p-2 pr-6 font-medium">Revenue</td>
                            <td className="p-2 text-right font-mono">{fmt(topAgg.rev.b)}</td>
                            <td className="p-2 text-right font-mono">{fmt(topAgg.rev.k)}</td>
                            <td className="p-2 text-right font-mono">{fmt(topAgg.rev.a)}</td>
                            <td className="p-2 text-right font-mono">{fmt(topAgg.rev.bg)}</td>
                            <td className="p-2 text-right font-mono font-semibold">{fmt(topAgg.rev.fc)}</td>
                          </tr>
                          <tr>
                            <td className="p-2 pr-6 font-medium">Cost</td>
                            <td className="p-2 text-right font-mono">{fmt(topAgg.cost.b)}</td>
                            <td className="p-2 text-right font-mono">{fmt(topAgg.cost.k)}</td>
                            <td className="p-2 text-right font-mono">{fmt(topAgg.cost.a)}</td>
                            <td className="p-2 text-right font-mono">{fmt(topAgg.cost.bg)}</td>
                            <td className="p-2 text-right font-mono font-semibold">{fmt(topAgg.cost.fc)}</td>
                          </tr>
                          <tr className="border-t border-border">
                            <td className="p-2 pr-6 font-medium">GPM (Forecast)</td>
                            <td className="p-2 text-right font-mono">{fmt(topAgg.rev.b + topAgg.cost.b)}</td>
                            <td className="p-2"></td>
                            <td className="p-2"></td>
                            <td className="p-2"></td>
                            <td className={`p-2 text-right font-mono font-semibold ${(topAgg.rev.fc + topAgg.cost.fc) >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                              {fmt(topAgg.rev.fc + topAgg.cost.fc)}
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>



                  {unmappedLineCount > 0 && (
                    <div className="px-4 py-2 border-b border-border bg-amber-500/10 text-xs text-amber-700 dark:text-amber-400 flex items-center justify-between">
                      <span>{unmappedLineCount} finance line(s) without article mapping in {factCurrency}.</span>
                      <a href="/settings/eqs-files/mapping" className="underline font-medium ml-2">
                        Configure mapping →
                      </a>
                    </div>
                  )}

                  {rows.length === 0 ? (
                    <div className="p-4 text-sm text-muted-foreground">
                      Nothing to show for current filter in {factCurrency}.
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead className="bg-muted/40">
                          <tr>
                            {factViewLevel === "unit" && (
                              <th className="text-left p-2 font-medium">UnitNo</th>
                            )}
                            <th className="text-left p-2 font-medium">Budget Article</th>
                            {factDetail === "details" && (
                              <>
                                <th className="text-left p-2 font-medium">Contact</th>
                                <th className="text-left p-2 font-medium">Charge / Cost Type</th>
                              </>
                            )}
                            <th className="text-right p-2 font-medium">Revenue</th>
                            <th className="text-right p-2 font-medium">Cost</th>
                            <th className="text-right p-2 font-medium">GPM Impact</th>
                            <th className="text-left p-2 font-medium">Data Type</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(() => {
                            // Build display rows depending on view level / detail mode
                            type Disp = {
                              key: string;
                              article_id: string | null;
                              article_name: string;
                              unit_no?: string | null;
                              contact?: string | null;
                              type_code?: string | null;
                              revenue: number;
                              cost: number;
                              indicators: Set<string>;
                              is_unmapped: boolean;
                              status: string;
                              kind: string | null;
                              has_plan: boolean;
                              has_booked: boolean;
                              has_accrual: boolean;
                              has_rt: boolean;
                            };
                            const disp: Disp[] = [];

                            if (factViewLevel === "file" && factDetail === "summary") {
                              for (const r of rows) {
                                disp.push({
                                  key: r.key,
                                  article_id: r.article_id,
                                  article_name: r.article_name,
                                  revenue: r.revenue,
                                  cost: r.cost,
                                  indicators: r.indicators,
                                  is_unmapped: r.is_unmapped,
                                  status: statusFor(r),
                                  kind: r.kind,
                                  has_plan: r.has_plan,
                                  has_booked: r.has_booked,
                                  has_accrual: r.has_accrual,
                                  has_rt: r.has_rt,
                                });
                              }
                            } else {
                              // Need to expand from visibleLines (Budget filter shows nothing here)
                              const groupKeyParts: (l: any) => string[] = (l) => {
                                const parts: string[] = [];
                                if (factViewLevel === "unit") parts.push(l.unit_no ?? "—");
                                parts.push(l.article_id ?? "_unmapped_");
                                if (factDetail === "details") {
                                  parts.push(l.contact ?? "—");
                                  parts.push(`${l.source_type ?? ""}::${l.source_code ?? ""}`);
                                }
                                return parts;
                              };
                              const grp = new Map<string, Disp>();
                              const sourceLines = visibleLines;

                              for (const l of sourceLines) {
                                const parts = groupKeyParts(l);
                                const key = parts.join("||");
                                let d = grp.get(key);
                                if (!d) {
                                  const baseRow = articleMap.get(l.article_id ?? "_unmapped_");
                                  d = {
                                    key,
                                    article_id: l.article_id ?? null,
                                    article_name: l.article_name ?? "(Unmapped)",
                                    unit_no: factViewLevel === "unit" ? l.unit_no ?? null : undefined,
                                    contact: factDetail === "details" ? l.contact ?? null : undefined,
                                    type_code:
                                      factDetail === "details"
                                        ? `${l.source_type ?? ""}/${l.source_code ?? ""}`
                                        : undefined,
                                    revenue: 0,
                                    cost: 0,
                                    indicators: new Set(),
                                    is_unmapped: !!l.is_unmapped,
                                    status: "—",
                                    kind: l.article_kind,
                                    has_plan: !!baseRow?.has_plan,
                                    has_booked: false,
                                    has_accrual: false,
                                    has_rt: false,
                                  };
                                  grp.set(key, d);
                                }
                                const amt = Number(l.amount ?? 0);
                                if (l.article_kind === "REVENUE") d.revenue += amt;
                                else d.cost += amt;
                                if (l.source_kind === "booked_finance") {
                                  d.has_booked = true;
                                  d.indicators.add("BOOKED");
                                } else if (l.source_kind === "cost_accrual") {
                                  d.has_accrual = true;
                                  d.indicators.add("ACCRUAL");
                                } else if (l.source_kind === "billing_expected_revenue") {
                                  d.has_rt = true;
                                  d.indicators.add("RT EXPECTED");
                                }
                                if (l.is_unmapped) d.indicators.add("UNMAPPED");
                              }
                              for (const d of grp.values()) {
                                d.status = statusFor({
                                  ...d,
                                  is_extra: false,
                                  has_plan: d.has_plan,
                                } as unknown as Row);
                                disp.push(d);
                              }
                              disp.sort((a, b) => {
                                if (factViewLevel === "unit") {
                                  const u = (a.unit_no ?? "").localeCompare(b.unit_no ?? "");
                                  if (u !== 0) return u;
                                }
                                return a.article_name.localeCompare(b.article_name);
                              });
                            }

                            const colSpan =
                              (factViewLevel === "unit" ? 1 : 0) +
                              1 +
                              (factDetail === "details" ? 2 : 0) +
                              4;

                            if (disp.length === 0) {
                              return (
                                <tr>
                                  <td colSpan={colSpan} className="p-4 text-sm text-muted-foreground">
                                    Nothing to show for current filter.
                                  </td>
                                </tr>
                              );
                            }

                            const totalRevenue = disp.reduce((s, d) => s + d.revenue, 0);
                            const totalCost = disp.reduce((s, d) => s + d.cost, 0);
                            const totalGpm = totalRevenue + totalCost;
                            const articleColSpan = 1 + (factDetail === "details" ? 2 : 0);

                            const renderedRows = disp.map((d) => {
                              const result = d.revenue + d.cost;
                              const isSelected =
                                factViewLevel === "file" &&
                                factDetail === "summary" &&
                                factSelectedArticle === d.key;
                              const expanded =
                                factViewLevel === "file" &&
                                factDetail === "summary" &&
                                factExpanded === d.key;
                              const drill = visibleLines.filter(
                                (l) => (l.article_id ?? null) === (d.article_id ?? null),
                              );

                              return (
                                <>
                                  <tr
                                    key={d.key}
                                    className={`border-t border-border cursor-pointer hover:bg-muted/30 ${
                                      isSelected ? "bg-muted/50" : ""
                                    }`}
                                    onClick={() => {
                                      if (factViewLevel === "file" && factDetail === "summary") {
                                        const next = expanded ? null : d.key;
                                        setFactExpanded(next);
                                        setFactSelectedArticle(next);
                                      }
                                    }}
                                  >
                                    {factViewLevel === "unit" && (
                                      <td className="p-2 font-mono text-xs">{d.unit_no ?? "—"}</td>
                                    )}
                                    <td className="p-2">
                                      {d.is_unmapped ? (
                                        <Badge variant="outline" className="text-amber-600 border-amber-600">
                                          Unmapped
                                        </Badge>
                                      ) : (
                                        <span>{d.article_name}</span>
                                      )}
                                    </td>
                                    {factDetail === "details" && (
                                      <>
                                        <td className="p-2 text-xs">{d.contact ?? "—"}</td>
                                        <td className="p-2 text-xs font-mono">{d.type_code ?? "—"}</td>
                                      </>
                                    )}
                                    <td className="p-2 text-right font-mono">
                                      {d.revenue ? fmt(d.revenue) : "—"}
                                    </td>
                                    <td className="p-2 text-right font-mono">
                                      {d.cost ? fmt(d.cost) : "—"}
                                    </td>
                                    <td
                                      className={`p-2 text-right font-mono ${
                                        result > 0 ? "text-emerald-600" : result < 0 ? "text-red-600" : ""
                                      }`}
                                    >
                                      {result ? (result > 0 ? "+" : "") + fmt(Math.abs(result)).replace(/^/, result < 0 ? "-" : "") : "—"}
                                    </td>
                                    <td className="p-2">
                                      <div className="flex flex-wrap gap-1">
                                        {Array.from(d.indicators).map((ind) => (
                                          <Badge
                                            key={ind}
                                            variant="outline"
                                            className={`text-[10px] ${indicatorClass(ind)}`}
                                          >
                                            {ind}
                                          </Badge>
                                        ))}
                                      </div>
                                    </td>
                                  </tr>
                                  {expanded && (
                                    <tr key={d.key + "-d"} className="border-t border-border bg-muted/20">
                                      <td colSpan={colSpan} className="p-2">
                                        {drill.length === 0 ? (
                                          <div className="text-xs text-muted-foreground">
                                            No fact lines (plan only).
                                          </div>
                                        ) : (
                                          <table className="w-full text-xs">
                                            <thead>
                                              <tr className="text-muted-foreground">
                                                <th className="text-left p-2">Source</th>
                                                <th className="text-left p-2">Unit</th>
                                                <th className="text-left p-2">Booking</th>
                                                <th className="text-left p-2">Contact</th>
                                                <th className="text-left p-2">Code</th>
                                                <th className="text-left p-2">Invoice</th>
                                                <th className="text-left p-2">Date</th>
                                                <th className="text-left p-2">Eff. from</th>
                                                <th className="text-left p-2">Eff. to</th>
                                                <th className="text-right p-2">Amount</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                              {drill.map((l: any) => {
                                                const ind =
                                                  l.source_kind === "booked_finance"
                                                    ? "BOOKED"
                                                    : l.source_kind === "cost_accrual"
                                                    ? "ACCRUAL"
                                                    : l.source_kind === "budgeted"
                                                    ? "BUDGET"
                                                    : "RT EXPECTED";
                                                const isBudget = l.source_kind === "budgeted";
                                                return (
                                                  <tr key={`${l.origin}-${l.id}`}>
                                                    <td className="p-2">
                                                      <Badge
                                                        variant="outline"
                                                        className={`text-[10px] ${indicatorClass(ind)}`}
                                                      >
                                                        {ind}
                                                      </Badge>
                                                    </td>
                                                    <td className="p-2 font-mono">
                                                      {isBudget ? (l.unit_no ?? "not assigned") : (l.unit_no ?? "—")}
                                                    </td>

                                                    <td className="p-2 font-mono">{l.booking_no ?? "—"}</td>
                                                    <td className="p-2">
                                                      {isBudget ? <span className="text-muted-foreground">budget</span> : (l.contact ?? "—")}
                                                    </td>
                                                    <td className="p-2 font-mono">{l.source_code ?? "—"}</td>
                                                    <td className="p-2 font-mono">{l.invoice_no ?? "—"}</td>
                                                    <td className="p-2 font-mono">
                                                      {l.business_date
                                                        ? new Date(l.business_date).toLocaleDateString()
                                                        : "—"}
                                                    </td>
                                                    <td className="p-2 font-mono">
                                                      {l.effective_from
                                                        ? new Date(l.effective_from).toLocaleDateString()
                                                        : "—"}
                                                    </td>
                                                    <td className="p-2 font-mono">
                                                      {l.effective_to
                                                        ? new Date(l.effective_to).toLocaleDateString()
                                                        : "—"}
                                                    </td>
                                                    <td className="p-2 text-right font-mono">
                                                      {Number(l.amount ?? 0).toFixed(2)}
                                                    </td>
                                                  </tr>
                                                );
                                              })}
                                            </tbody>
                                          </table>
                                        )}
                                      </td>
                                    </tr>
                                  )}
                                </>
                              );
                            });

                            return (
                              <>
                                {renderedRows}
                                <tr className="border-t-2 border-border bg-muted/40 font-medium">
                                  {factViewLevel === "unit" && <td className="p-2" />}
                                  <td className="p-2" colSpan={articleColSpan}>Total</td>
                                  <td className="p-2 text-right font-mono">
                                    {totalRevenue ? fmt(totalRevenue) : "—"}
                                  </td>
                                  <td className="p-2 text-right font-mono">
                                    {totalCost ? fmt(totalCost) : "—"}
                                  </td>
                                  <td
                                    className={`p-2 text-right font-mono ${
                                      totalGpm > 0 ? "text-emerald-600" : totalGpm < 0 ? "text-red-600" : ""
                                    }`}
                                  >
                                    {totalGpm
                                      ? (totalGpm > 0 ? "+" : "-") + fmt(Math.abs(totalGpm))
                                      : "—"}
                                  </td>
                                  <td className="p-2" />
                                </tr>
                              </>
                            );
                          })()}
                        </tbody>
                      </table>
                    </div>
                  )}
                </>
              );
            })()}
          </div>
        </TabsContent>

        <TabsContent value="finance" className="mt-4">
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2 flex-wrap min-h-[50px]">
              <h2 className="font-semibold mr-2">Finance</h2>
              <div className="flex rounded-md border border-border text-xs">
                <button
                  type="button"
                  className={`px-2 py-1 ${financeCurrency === "USD" ? "bg-muted font-medium" : ""}`}
                  onClick={() => setFinanceCurrency("USD")}
                >
                  USD
                </button>
                <button
                  type="button"
                  className={`px-2 py-1 border-l border-border ${financeCurrency === "EUR" ? "bg-muted font-medium" : ""}`}
                  onClick={() => setFinanceCurrency("EUR")}
                >
                  EUR
                </button>
              </div>
              <div className="flex rounded-md border border-border text-xs">
                {([
                  ["all", "All"],
                  ["booked", "Booked"],
                  ["accruals", "Accruals"],
                ] as const).map(([k, label], i) => (
                  <button
                    key={k}
                    type="button"
                    className={`px-2 py-1 ${i > 0 ? "border-l border-border" : ""} ${financeShowData === k ? "bg-muted font-medium" : ""}`}
                    onClick={() => setFinanceShowData(k)}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <button
                type="button"
                className="ml-auto px-2 py-1 text-xs rounded-md border border-border hover:bg-muted disabled:opacity-50"
                disabled={refreshFinanceM.isPending}
                onClick={() => refreshFinanceM.mutate()}
              >
                {refreshFinanceM.isPending ? "Refreshing…" : "Refresh"}
              </button>

            </div>

            {(() => {
              if (financeQ.isLoading) {
                return <div className="p-4 text-sm text-muted-foreground">Loading…</div>;
              }
              const allCur = ((financeQ.data?.invoices ?? []) as any[]).filter(
                (i) => i.currency === financeCurrency,
              );
              const invoices = allCur.filter((i) => {
                if (financeShowData === "booked") return i.status === "booked";
                if (financeShowData === "accruals") return i.status === "accrual";
                return true;
              });
              const fmt = (n: number | null | undefined) =>
                n == null || n === 0
                  ? "—"
                  : Number(n).toLocaleString(undefined, {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    });

              // Totals classified by invoice kind (not by sign of amount).
              // Always computed across the full currency set (independent of Show data filter).
              let revBooked = 0;
              let costBooked = 0;
              let revAccrued = 0;
              let costAccrued = 0;
              for (const inv of allCur) {
                const a = Number(inv.amount_on_file ?? 0);
                const isAccrual = inv.status === "accrual";
                if (inv.kind === "revenue") {
                  if (isAccrual) revAccrued += a;
                  else revBooked += a;
                } else if (inv.kind === "cost") {
                  if (isAccrual) costAccrued += a;
                  else costBooked += a;
                } else if (inv.kind === "mixed") {
                  for (const ct of inv.cost_types ?? []) {
                    const v = Number(ct.amount_on_file ?? 0);
                    if (v >= 0) {
                      if (isAccrual) revAccrued += v;
                      else revBooked += v;
                    } else {
                      if (isAccrual) costAccrued += v;
                      else costBooked += v;
                    }
                  }
                }
              }


              return (
                <>
                  {/* Top summary matrix — same layout as Budget Fact, only Booked filled */}
                  <div className="px-4 py-3 border-b border-border bg-muted/20">
                    <div className="flex items-center justify-between mb-2 h-7">
                      <div className="text-xs font-medium text-muted-foreground">File total</div>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="text-xs">
                        <thead>
                          <tr className="text-xs text-muted-foreground">
                            <th className="text-left p-2"></th>
                            <th className="text-right p-2">Plan</th>
                            <th className="text-right p-2">Booked</th>
                            <th className="text-right p-2">Accrued</th>
                            <th className="text-right p-2">Budgeted</th>
                            <th className="text-right p-2">Forecast</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td className="p-2 pr-6 font-medium">Revenue</td>
                            <td className="p-2 text-right font-mono">—</td>
                            <td className="p-2 text-right font-mono">{fmt(revBooked)}</td>
                            <td className="p-2 text-right font-mono">{fmt(revAccrued)}</td>
                            <td className="p-2 text-right font-mono">—</td>
                            <td className="p-2 text-right font-mono">—</td>
                          </tr>
                          <tr>
                            <td className="p-2 pr-6 font-medium">Cost</td>
                            <td className="p-2 text-right font-mono">—</td>
                            <td className="p-2 text-right font-mono">{fmt(costBooked)}</td>
                            <td className="p-2 text-right font-mono">{fmt(costAccrued)}</td>
                            <td className="p-2 text-right font-mono">—</td>
                            <td className="p-2 text-right font-mono">—</td>
                          </tr>
                          <tr className="border-t border-border">
                            <td className="p-2 pr-6 font-medium">GPM (Forecast)</td>
                            <td className="p-2 text-right font-mono">—</td>
                            <td className="p-2 text-right font-mono">{fmt(revBooked + costBooked)}</td>
                            <td className="p-2 text-right font-mono">{fmt(revAccrued + costAccrued)}</td>
                            <td className="p-2"></td>
                            <td className="p-2 text-right font-mono">—</td>
                          </tr>

                        </tbody>
                      </table>
                    </div>
                  </div>

                  {invoices.length === 0 ? (
                    <div className="p-4 text-sm text-muted-foreground">
                      No invoices linked to this file in {financeCurrency}.
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead className="bg-muted/40">
                          <tr>
                            <th className="text-left p-2 font-medium w-6"></th>
                            <th className="text-left p-2 font-medium">Status</th>
                            <th className="text-left p-2 font-medium">Invoice No</th>
                            <th className="text-left p-2 font-medium">Date</th>
                            <th className="text-left p-2 font-medium">Party</th>
                            <th className="text-left p-2 font-medium">Kind</th>

                            <th className="text-left p-2 font-medium">Currency</th>
                            <th className="text-right p-2 font-medium">Invoice total</th>
                            <th className="text-right p-2 font-medium">On file</th>
                          </tr>

                        </thead>
                        <tbody>
                          {invoices.map((inv) => {
                            const isOpen = financeExpanded.invoice === inv.invoice_no;
                            return (
                              <Fragment key={inv.invoice_no}>
                                <tr
                                  className="border-t border-border hover:bg-muted/30 cursor-pointer"
                                  onClick={() =>
                                    setFinanceExpanded((s) =>
                                      s.invoice === inv.invoice_no
                                        ? { invoice: null, costType: null }
                                        : { invoice: inv.invoice_no, costType: null },
                                    )
                                  }
                                >
                                  <td className="p-2 text-muted-foreground">{isOpen ? "▾" : "▸"}</td>
                                  <td className="p-2">
                                    <Badge
                                      variant="outline"
                                      className={`text-[10px] py-0 ${
                                        inv.status === "accrual"
                                          ? "border-amber-500 text-amber-700"
                                          : "border-emerald-500 text-emerald-700"
                                      }`}
                                    >
                                      {inv.status === "accrual" ? "ACCRUAL" : "BOOKED"}
                                    </Badge>
                                  </td>
                                  <td className="p-2 font-medium">{inv.invoice_no}</td>
                                  <td className="p-2">{inv.invoice_date ? inv.invoice_date.slice(0, 10) : "—"}</td>
                                  <td className="p-2">{inv.party_name ?? "—"}</td>
                                  <td className="p-2">
                                    {inv.kind === "revenue" ? (
                                      <span className="text-emerald-600 font-medium">Revenue</span>
                                    ) : inv.kind === "cost" ? (
                                      <span className="text-rose-600 font-medium">Cost</span>
                                    ) : inv.kind === "mixed" ? (
                                      <span className="text-amber-600 font-medium">Mixed</span>
                                    ) : (
                                      "—"
                                    )}
                                  </td>

                                  <td className="p-2">{inv.currency}</td>
                                  <td className="p-2 text-right font-mono">{fmt(inv.invoice_total)}</td>
                                  <td className="p-2 text-right font-mono">{fmt(inv.amount_on_file)}</td>
                                </tr>
                                {isOpen &&
                                  (inv.cost_types ?? []).map((ct: any) => {
                                    const ctKey = ct.source_code ?? "—";
                                    const ctOpen = financeExpanded.costType === ctKey;
                                    return (
                                      <Fragment key={`${inv.invoice_no}-${ctKey}`}>
                                        <tr
                                          className="border-t border-border bg-muted/10 hover:bg-muted/30 cursor-pointer"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setFinanceExpanded((s) => ({
                                              invoice: inv.invoice_no,
                                              costType: s.costType === ctKey ? null : ctKey,
                                            }));
                                          }}
                                        >
                                          <td className="p-2"></td>
                                          <td className="p-2 pl-6 text-muted-foreground" colSpan={6}>
                                            {ctOpen ? "▾" : "▸"} {ct.source_code ?? "—"}
                                            <span className="ml-2 text-xs text-muted-foreground">
                                              ({ct.units.length} container{ct.units.length === 1 ? "" : "s"})
                                            </span>
                                          </td>
                                          <td className="p-2"></td>
                                          <td className="p-2 text-right font-mono">{fmt(ct.amount_on_file)}</td>
                                        </tr>
                                        {ctOpen &&
                                          (ct.units ?? []).map((u: any) => (
                                            <tr
                                              key={`${inv.invoice_no}-${ctKey}-${u.unit_no ?? "_"}`}
                                              className="border-t border-border bg-muted/5"
                                            >
                                              <td className="p-2"></td>
                                              <td className="p-2 pl-10 text-muted-foreground" colSpan={6}>
                                                {u.unit_no ?? "—"}
                                              </td>
                                              <td className="p-2"></td>
                                              <td className="p-2 text-right font-mono">{fmt(u.amount_on_file)}</td>
                                            </tr>
                                          ))}
                                      </Fragment>
                                    );
                                  })}
                              </Fragment>
                            );
                          })}
                        </tbody>
                        <tfoot>
                          <tr className="border-t-2 border-border bg-muted/30 font-medium">
                            <td className="p-2"></td>
                            <td className="p-2" colSpan={5}>Total</td>
                            <td className="p-2">{financeCurrency}</td>
                            <td className="p-2 text-right font-mono">
                              {fmt(invoices.reduce((s, i) => s + Number(i.invoice_total ?? 0), 0))}
                            </td>
                            <td className="p-2 text-right font-mono">
                              {fmt(invoices.reduce((s, i) => s + Number(i.amount_on_file ?? 0), 0))}
                            </td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  )}
                </>
              );
            })()}
          </div>
        </TabsContent>






        <TabsContent value="warnings" className="mt-4">
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            {(warnQ.data?.items?.length ?? 0) === 0 ? (
              <div className="p-4 text-sm text-muted-foreground">No warnings.</div>
            ) : (
              <ul className="divide-y divide-border">
                {warnQ.data!.items.map((w: any) => (
                  <li key={w.id} className="p-4 text-sm">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline">{w.severity ?? w.level ?? "warn"}</Badge>
                      <span className="font-mono text-xs">{w.code ?? ""}</span>
                    </div>
                    <div>{w.message ?? ""}</div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </TabsContent>

        <TabsContent value="units" className="mt-4">
          <div className="rounded-xl border border-border bg-card overflow-hidden mb-4">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2 flex-wrap">
              <h2 className="font-semibold flex-1">Linked bookings</h2>
              <Input
                placeholder="Booking #"
                value={manualBookingNo}
                onChange={(e) => setManualBookingNo(e.target.value)}
                className="h-8 w-40"
              />
              <Button
                size="sm"
                variant="secondary"
                disabled={!manualBookingNo.trim() || addBookingMut.isPending}
                onClick={() => addBookingMut.mutate(manualBookingNo.trim())}
              >
                <Plus className="h-3 w-3 mr-1" /> Add booking
              </Button>
            </div>
            {(bookingsQ.data?.bookings ?? []).length === 0 ? (
              <div className="p-4 text-sm text-muted-foreground">
                No bookings linked yet. Assign a booking from the Recent Units list below, or add one manually.
              </div>
            ) : (
              <ul className="divide-y divide-border">
                {(bookingsQ.data?.bookings ?? []).map((b: any) => (
                  <li key={b.id} className="p-3 flex flex-wrap items-center gap-2 text-sm">
                    <span className="font-mono font-semibold">{b.booking_no}</span>
                    <Badge variant="outline" className="text-[10px]">{b.source}</Badge>
                    <span className="text-muted-foreground">
                      {b.linked_units} linked · {b.pending_units.length} pending in EQS
                    </span>
                    <div className="flex-1" />
                    {b.pending_units.length > 0 && (
                      <Button
                        size="sm"
                        variant="secondary"
                        disabled={syncBookingMut.isPending}
                        onClick={() => syncBookingMut.mutate(b.booking_no)}
                      >
                        <Plus className="h-3 w-3 mr-1" />
                        Link {b.pending_units.length} pending
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={unlinkBookingMut.isPending}
                      onClick={() => {
                        if (
                          !confirm(
                            `Unlink booking ${b.booking_no}? This will also unlink ${b.linked_units} unit(s) from this file.`,
                          )
                        )
                          return;
                        unlinkBookingMut.mutate(b.id);
                      }}
                    >
                      <Link2Off className="h-3 w-3 mr-1" /> Unlink
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </div>


          {showAssign && (
          <div className="rounded-xl border border-border bg-card overflow-hidden mb-4">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2 flex-wrap">
              <h2 className="font-semibold flex-1">Recent Units</h2>
              <Button
                size="sm"
                variant={showOnlyMatching ? "default" : "outline"}
                onClick={() => setShowOnlyMatching((v) => !v)}
              >
                {showOnlyMatching ? "Showing matching" : "Showing all"}
              </Button>
              <div className="text-xs text-muted-foreground w-full">
                File origin: <span className="font-mono">{file?.origin_locn ?? "—"}</span>
                {extUnitsQ.data?.file_origin_country ? <> ({extUnitsQ.data.file_origin_country})</> : null}
                {" · "}Types: <span className="font-mono">{(extUnitsQ.data?.file_container_types ?? []).join(", ") || "—"}</span>
                {" · "}Origin matches if location or country matches. Mismatch creates a warning.
              </div>
            </div>
            <div className="p-3 border-b border-border">
              <Input
                placeholder="Filter by unit, booking, origin, destination…"
                value={unitInput}
                onChange={(e) => {
                  setUnitInput(e.target.value);
                  setUnitQuery(e.target.value);
                }}
              />
            </div>
            <div className="max-h-96 overflow-auto">
              {(() => {
                const all = (extUnitsQ.data?.items ?? []) as any[];
                const visible = showOnlyMatching
                  ? all.filter((u) => u.origin_match && u.type_match)
                  : all;
                if (visible.length === 0) {
                  return (
                    <div className="p-4 text-sm text-muted-foreground">
                      {all.length === 0
                        ? "No recent units found."
                        : "No matching units. Toggle to show all."}
                    </div>
                  );
                }
                return (
                <table className="w-full text-sm">
                  <thead className="bg-muted/40 sticky top-0">
                    <tr>
                      <th className="text-left p-2 font-medium">UnitNo</th>
                      <th className="text-left p-2 font-medium">Type</th>
                      <th className="text-left p-2 font-medium">OnHire</th>
                      <th className="text-left p-2 font-medium">From</th>
                      <th className="text-left p-2 font-medium">To</th>
                      <th className="text-left p-2 font-medium">Match</th>
                      <th className="p-2" />
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const items = visible;
                      const groups = new Map<string, any[]>();
                      for (const it of items) {
                        const k = it.booking_no ?? "—";
                        if (!groups.has(k)) groups.set(k, []);
                        groups.get(k)!.push(it);
                      }
                      const rows: React.ReactNode[] = [];
                      for (const [bk, units] of groups) {
                        const first = units[0];
                        rows.push(
                          <tr key={`bk-${bk}`} className="border-t border-border bg-muted/20">
                            <td colSpan={6} className="p-2 text-xs">
                              <span className="font-semibold">Booking </span>
                              <span className="font-mono">{bk}</span>
                              <span className="text-muted-foreground ml-2">
                                · {first.locn_pol_name ?? first.locn_pol ?? "—"} → {first.do_locn_name ?? first.do_locn ?? "—"}
                              </span>
                              <span className="ml-2 text-muted-foreground">({units.length} unit{units.length === 1 ? "" : "s"})</span>
                            </td>
                            <td className="p-2 text-right">
                              <Button
                                size="sm"
                                variant="secondary"
                                disabled={assignBookingMut.isPending || bk === "—"}
                                onClick={() => {
                                  const mismatches = units.filter((u) => !u.origin_match || !u.type_match);
                                  if (
                                    mismatches.length > 0 &&
                                    !confirm(
                                      `Booking ${bk}: ${mismatches.length} unit(s) mismatch file origin/type. Assign all ${units.length} anyway? Warnings will be created.`,
                                    )
                                  )
                                    return;
                                  assignBookingMut.mutate(bk);
                                }}
                              >
                                <Plus className="h-3 w-3 mr-1" />
                                Assign booking
                              </Button>
                            </td>
                          </tr>,
                        );
                        for (const u of units) {
                          rows.push(
                            <tr key={`${u.unit_no}-${bk}`} className="border-t border-border">
                              <td className="p-2 font-mono">{u.unit_no}</td>
                              <td className="p-2 font-mono text-xs">{u.iso_code ?? "—"}</td>
                              <td className="p-2 font-mono text-xs">{u.onhire_date ?? "—"}</td>
                              <td className="p-2 text-xs">
                                {u.locn_pol_name ?? "—"}
                                {u.locn_pol ? <span className="ml-1 font-mono text-muted-foreground">({u.locn_pol})</span> : null}
                              </td>
                              <td className="p-2 text-xs">
                                {u.do_locn_name ?? "—"}
                                {u.do_locn ? <span className="ml-1 font-mono text-muted-foreground">({u.do_locn})</span> : null}
                              </td>
                              <td className="p-2">
                                <div className="flex flex-col gap-1">
                                  {u.origin_match ? (
                                    <Badge className="w-fit">origin</Badge>
                                  ) : (
                                    <Badge variant="outline" className="w-fit text-amber-600 border-amber-600">origin ≠</Badge>
                                  )}
                                  {u.type_match ? (
                                    <Badge className="w-fit">type</Badge>
                                  ) : (
                                    <Badge variant="outline" className="w-fit text-amber-600 border-amber-600">type ≠</Badge>
                                  )}
                                </div>
                              </td>
                              <td className="p-2 text-right">
                                <Button
                                  size="sm"
                                  variant={u.origin_match && u.type_match ? "default" : "outline"}
                                  onClick={() => {
                                    const issues: string[] = [];
                                    if (!u.origin_match)
                                      issues.push(
                                        `origin ${u.locn_pol_name ?? u.locn_pol ?? "?"} ≠ file ${extUnitsQ.data?.file_origin_name ?? file?.origin_locn ?? "?"}`,
                                      );
                                    if (!u.type_match)
                                      issues.push(
                                        `type ${u.iso_code ?? "?"} not in file types`,
                                      );
                                    if (
                                      issues.length > 0 &&
                                      !confirm(
                                        `Unit ${u.unit_no}: ${issues.join("; ")}. Assign anyway? A warning will be created.`,
                                      )
                                    )
                                      return;
                                    assignMut.mutate({ unit_no: u.unit_no, booking_no: u.booking_no });
                                  }}
                                  disabled={assignMut.isPending}
                                >
                                  <Plus className="h-3 w-3 mr-1" />
                                  Assign unit
                                </Button>
                              </td>
                            </tr>,
                          );
                        }
                      }
                      return rows;
                    })()}
                  </tbody>
                </table>
                );
              })()}
            </div>
          </div>
          )}




          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2">
              <h2 className="font-semibold flex-1">Assigned Units</h2>
              <Button
                size="sm"
                variant={showAssign ? "default" : "secondary"}
                onClick={() => setShowAssign((v) => !v)}
              >
                <Plus className="h-3 w-3 mr-1" />
                {showAssign ? "Hide assign" : "Assign Units"}
              </Button>
              <Button
                size="sm"
                variant={showUnlinked ? "default" : "outline"}
                onClick={() => setShowUnlinked((v) => !v)}
              >
                {showUnlinked ? "Hide unlinked" : "Show unlinked"}
              </Button>


            </div>
            {(() => {
              const all = (unitsQ.data?.items ?? []) as any[];
              const visible = showUnlinked ? all : all.filter((u) => u.is_active);
              if (visible.length === 0) {
                return (
                  <div className="p-4 text-sm text-muted-foreground">
                    {all.length === 0 ? "No units assigned yet." : "No active units. Toggle to show unlinked."}
                  </div>
                );
              }
              return (
              <table className="w-full text-sm">
                <thead className="bg-muted/40">
                  <tr>
                    <th className="text-left p-3 font-medium">UnitNo</th>
                    <th className="text-left p-3 font-medium">Type</th>
                    <th className="text-left p-3 font-medium">Grade</th>
                    <th className="text-left p-3 font-medium">Booking</th>
                    <th className="text-left p-3 font-medium">OnHire</th>
                    <th className="text-left p-3 font-medium">POL</th>
                    <th className="text-left p-3 font-medium">POD</th>
                    <th className="text-left p-3 font-medium">Effective from</th>
                    <th className="text-left p-3 font-medium">Effective to</th>
                    <th className="text-right p-3 font-medium">Purchase price</th>
                    <th className="text-left p-3 font-medium">Status</th>
                    <th className="p-3" />
                  </tr>
                </thead>
                <tbody>
                  {visible.map((u: any) => (
                    <tr key={u.id} className="border-t border-border">
                      <td className="p-3 font-mono">{u.unit_no}</td>
                      <td className="p-3 font-mono text-xs">{u.unit_type ?? "—"}</td>
                      <td className="p-3 font-mono text-xs">{u.grade ?? "—"}</td>
                      <td className="p-3 font-mono text-xs">{u.booking_no ?? "—"}</td>
                      <td className="p-3 font-mono text-xs">{u.onhire_date ?? "—"}</td>
                      <td className="p-3 font-mono text-xs">{u.locn_pol ?? "—"}</td>
                      <td className="p-3 font-mono text-xs">{u.locn_pod ?? "—"}</td>
                      <td className="p-3 font-mono text-xs">
                        <span>{u.effective_date_from ?? "—"}</span>
                        {u.effective_from_source && (
                          <Badge variant="outline" className="ml-1 text-[10px] border-slate-400 text-slate-600">
                            {u.effective_from_source}
                          </Badge>
                        )}
                      </td>
                      <td className="p-3 font-mono text-xs">
                        <span>{u.effective_date_to ?? "—"}</span>
                        {u.effective_to_source && (
                          <Badge variant="outline" className="ml-1 text-[10px] border-emerald-500 text-emerald-700">
                            {u.effective_to_source}
                          </Badge>
                        )}
                      </td>
                      <td className="p-3 text-right font-mono text-xs">
                        {u.amt_ppb != null ? Number(u.amt_ppb).toFixed(2) : "—"}
                      </td>
                      <td className="p-3">
                        {u.is_active ? (
                          <Badge>Active</Badge>
                        ) : (
                          <Badge variant="outline">Unlinked</Badge>
                        )}
                      </td>
                      <td className="p-3 text-right">
                        {u.is_active && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => unlinkMut.mutate(u.id)}
                            disabled={unlinkMut.isPending}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              );
            })()}
          </div>
        </TabsContent>


        <TabsContent value="history" className="mt-4">
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2 flex-wrap">
              <h2 className="font-semibold flex-1">Events</h2>
              <Select value={eventTypeFilter} onValueChange={setEventTypeFilter}>
                <SelectTrigger className="h-8 w-[200px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All event types</SelectItem>
                  <SelectItem value="status">Status changes</SelectItem>
                  <SelectItem value="file_updated">File edits</SelectItem>
                  <SelectItem value="unit_assigned">Unit assigned</SelectItem>
                  <SelectItem value="unit_unlinked">Unit unlinked</SelectItem>
                  <SelectItem value="budget_lock">Budget lock / unlock</SelectItem>
                </SelectContent>

              </Select>
            </div>
            {(() => {
              const all = (histQ.data?.items ?? []) as any[];
              const visible =
                eventTypeFilter === "all"
                  ? all
                  : eventTypeFilter === "budget_lock"
                    ? all.filter((e) => e.type === "budget_locked" || e.type === "budget_unlocked")
                    : all.filter((e) => e.type === eventTypeFilter);

              if (visible.length === 0) {
                return (
                  <div className="p-4 text-sm text-muted-foreground">
                    {all.length === 0 ? "No events yet." : "No events for this type."}
                  </div>
                );
              }
              const fmt = (v: unknown) =>
                v === null || v === undefined || v === ""
                  ? "—"
                  : typeof v === "object"
                    ? JSON.stringify(v)
                    : String(v);
              return (
                <table className="w-full text-sm">
                  <thead className="bg-muted/40">
                    <tr>
                      <th className="text-left p-3 font-medium">When</th>
                      <th className="text-left p-3 font-medium">Event</th>
                      <th className="text-left p-3 font-medium">Details</th>
                      <th className="text-left p-3 font-medium">By</th>
                      <th className="text-left p-3 font-medium">Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {visible.map((e: any) => (
                      <tr key={`${e.type}-${e.id}`} className="border-t border-border">
                        <td className="p-3 font-mono text-xs whitespace-nowrap">
                          {new Date(e.at).toLocaleString()}
                        </td>
                        <td className="p-3">
                          <div className="flex flex-wrap items-center gap-1">
                            {e.type === "status" && <Badge variant="outline">Status</Badge>}
                            {e.type === "unit_assigned" && <Badge>Unit assigned</Badge>}
                            {e.type === "unit_unlinked" && (
                              <Badge variant="secondary">Unit unlinked</Badge>
                            )}
                            {e.type === "file_updated" && (
                              <Badge variant="outline">File edited</Badge>
                            )}
                            {e.type === "budget_unlocked" && (
                              <Badge variant="outline" className="border-emerald-600 text-emerald-700 bg-emerald-500/10">
                                Budget unlocked
                              </Badge>
                            )}
                            {e.type === "budget_locked" && (
                              <Badge variant="outline" className="border-slate-500 text-slate-700 bg-slate-500/10">
                                Budget locked
                              </Badge>
                            )}

                            {e.after_rp && (
                              <Badge
                                variant="outline"
                                className="text-amber-700 border-amber-600 bg-amber-500/10 text-[10px]"
                              >
                                After RP
                              </Badge>
                            )}
                          </div>
                        </td>
                        <td className="p-3 text-xs">
                          {e.type === "status" ? (
                            <span>
                              {e.from_status ? (
                                <span className="text-muted-foreground">
                                  {STATUS_LABEL[e.from_status] ?? e.from_status} →{" "}
                                </span>
                              ) : null}
                              <span className="font-medium">
                                {STATUS_LABEL[e.to_status] ?? e.to_status}
                              </span>
                            </span>
                          ) : e.type === "file_updated" || e.type === "budget_locked" || e.type === "budget_unlocked" ? (
                            <div className="space-y-0.5">
                              {Object.entries(e.changes ?? {}).map(
                                ([field, diff]: [string, any]) => (
                                  <div key={field} className="font-mono text-[11px]">
                                    <span className="text-muted-foreground">{field}:</span>{" "}
                                    <span className="line-through text-muted-foreground">
                                      {fmt(diff.old)}
                                    </span>{" "}
                                    →{" "}
                                    <span className="font-medium">{fmt(diff.new)}</span>
                                  </div>
                                ),
                              )}
                            </div>
                          ) : (
                            <span className="font-mono">{e.unit_no}</span>
                          )}
                        </td>
                        <td className="p-3 text-xs">{e.actor_name ?? "—"}</td>
                        <td className="p-3 text-muted-foreground text-xs">
                          {e.notes ?? "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              );
            })()}

          </div>
        </TabsContent>

        <TabsContent value="eqs" className="mt-4">
          <div className="rounded-lg border bg-card p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-base font-semibold">EQS Booking Exports</h2>
              {file.status === "OP" && (
                <Button size="sm" variant="outline" className="gap-1" onClick={() => setEqsDialogOpen(true)}>
                  <Send className="size-4" /> New Export
                </Button>
              )}
            </div>
            {eqsHistoryQ.data?.items.length === 0 && (
              <div className="text-sm text-muted-foreground py-6 text-center">
                No EQS exports yet.
              </div>
            )}
            {(eqsHistoryQ.data?.items ?? []).length > 0 && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-xs text-muted-foreground border-b">
                    <tr>
                      <th className="text-left p-2">Created</th>
                      <th className="text-left p-2">Filename</th>
                      <th className="text-left p-2">Status</th>
                      <th className="text-left p-2">Booking ID</th>
                      <th className="text-left p-2">Response</th>
                      <th className="text-left p-2">Sent</th>
                      <th className="text-left p-2">Ack</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(eqsHistoryQ.data?.items ?? []).map((e: any) => (
                      <tr key={e.id} className="border-b last:border-b-0">
                        <td className="p-2 whitespace-nowrap">{new Date(e.created_at).toLocaleString()}</td>
                        <td className="p-2">
                          <button
                            className="text-primary hover:underline font-mono text-xs"
                            onClick={() => openEqsFile("eqs-outbox", e.payload_path)}
                          >
                            {e.filename}
                          </button>
                        </td>
                        <td className="p-2">
                          {e.status === "pending" && <Badge variant="outline">pending</Badge>}
                          {e.status === "sent" && <Badge variant="outline" className="border-amber-500 text-amber-700">sent</Badge>}
                          {e.status === "acknowledged" && <Badge variant="outline" className="border-emerald-500 text-emerald-700">acknowledged</Badge>}
                          {e.status === "failed" && <Badge variant="outline" className="border-red-500 text-red-700">failed</Badge>}
                        </td>
                        <td className="p-2 font-mono text-xs">{e.eqs_booking_id ?? "—"}</td>
                        <td className="p-2">
                          {e.response_path ? (
                            <button
                              className="text-primary hover:underline font-mono text-xs"
                              onClick={() => openEqsFile("eqs-inbox", e.response_path)}
                            >
                              {e.response_filename}
                            </button>
                          ) : (
                            e.error ? <span className="text-red-700 text-xs">{e.error}</span> : "—"
                          )}
                        </td>
                        <td className="p-2 whitespace-nowrap text-xs">{e.sent_at ? new Date(e.sent_at).toLocaleString() : "—"}</td>
                        <td className="p-2 whitespace-nowrap text-xs">{e.acknowledged_at ? new Date(e.acknowledged_at).toLocaleString() : "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </TabsContent>

      </Tabs>

      <EqsBookingDialog
        fileId={id}
        open={eqsDialogOpen}
        onOpenChange={setEqsDialogOpen}
        onSent={() => {
          qc.invalidateQueries({ queryKey: ["file", id] });
          qc.invalidateQueries({ queryKey: ["eqs-history", id] });
        }}
      />
      <CopyFileDialog
        fileId={id}
        mode={copyMode ?? "plain"}
        open={copyMode !== null}
        onOpenChange={(v) => { if (!v) setCopyMode(null); }}
      />
      <SetStatusDateDialog
        open={pendingStatus !== null}
        onOpenChange={(v) => { if (!v) setPendingStatus(null); }}
        status={pendingStatus ?? "OP"}
        withReason={pendingStatus === "CN"}
        reasonLabel="Cancel reason"
        reasonRequired={pendingStatus === "CN"}
        pending={
          openMut.isPending || confirmRpMut.isPending || readyForClMut.isPending ||
          closeMut.isPending || cancelMut.isPending
        }
        onConfirm={confirmStatusChange}
      />
      <EditStatusDatesDialog
        open={editDatesOpen}
        onOpenChange={setEditDatesOpen}
        initial={{
          op_date: file?.op_date ?? null,
          rp_date: file?.rp_date ?? null,
          rcl_date: file?.rcl_date ?? null,
          cl_date: file?.cl_date ?? null,
          cn_date: file?.cn_date ?? null,
        }}
        currentStatus={STATUS_LABEL[file?.status] ?? file?.status ?? "—"}
        pending={setStatusDatesMut.isPending}
        onConfirm={(patch) => setStatusDatesMut.mutate(patch)}
      />
    </div>
  );
}

function BookingTypesTab({
  fileId,
  initialRows,
}: {
  fileId: string;
  initialRows: any[];
}) {
  const qc = useQueryClient();
  const updateFileFn = useServerFn(updateFile);
  const fetchGrades = useServerFn(listGrades);
  const gradesQ = useQuery({
    queryKey: ["equipment-grades"],
    queryFn: () => fetchGrades(),
  });
  const activeGrades = (gradesQ.data?.items ?? []).filter((g: any) => g.is_active);

  const toRow = (c: any): CTRow => ({
    container_type: c.container_type,
    planned_qty: c.planned_qty,
    grade: c.grade ?? null,
    daily_rate: c.daily_rate ?? null,
    repl_value: c.repl_value ?? null,
    free_min_days: c.free_min_days ?? null,
    charge1_code: c.charge1_code ?? null,
    charge1_amount: c.charge1_amount ?? null,
    charge2_code: c.charge2_code ?? null,
    charge2_amount: c.charge2_amount ?? null,
    charge3_code: c.charge3_code ?? null,
    charge3_amount: c.charge3_amount ?? null,
    charge4_code: c.charge4_code ?? null,
    charge4_amount: c.charge4_amount ?? null,
    cost1_code: c.cost1_code ?? null,
    cost1_currency: c.cost1_currency ?? null,
    cost1_amount: c.cost1_amount ?? null,
    cost1_supplier_accno: c.cost1_supplier_accno ?? null,
    cost2_code: c.cost2_code ?? null,
    cost2_currency: c.cost2_currency ?? null,
    cost2_amount: c.cost2_amount ?? null,
    cost2_supplier_accno: c.cost2_supplier_accno ?? null,
  });

  const [rows, setRows] = useState<CTRow[]>(() => initialRows.map(toRow));
  const [baseline, setBaseline] = useState<string>(() =>
    JSON.stringify(initialRows.map(toRow)),
  );

  useEffect(() => {
    const next = initialRows.map(toRow);
    setRows(next);
    setBaseline(JSON.stringify(next));
  }, [initialRows]);

  const dirty = JSON.stringify(rows) !== baseline;

  const saveMut = useMutation({
    mutationFn: () =>
      updateFileFn({
        data: {
          id: fileId,
          container_types: rows.filter((c) => c.container_type && c.planned_qty > 0),
        },
      }),
    onSuccess: () => {
      toast.success("Booking types saved");
      qc.invalidateQueries({ queryKey: ["file", fileId] });
      qc.invalidateQueries({ queryKey: ["file-fact", fileId] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  return (
    <div className="rounded-xl border border-border bg-card p-4 space-y-4">
      <ContainerTypesEditor
        rows={rows}
        setRows={setRows}
        containerTypeOptions={CONTAINER_TYPE_OPTIONS}
        grades={activeGrades.map((g: any) => ({ code: g.code, label: g.label }))}
        allowEmpty
      />
      <div className="flex justify-end gap-2 pt-2 border-t border-border">
        <Button
          variant="outline"
          size="sm"
          disabled={!dirty || saveMut.isPending}
          onClick={() => setRows(JSON.parse(baseline))}
        >
          Reset
        </Button>
        <Button
          size="sm"
          disabled={!dirty || saveMut.isPending}
          onClick={() => saveMut.mutate()}
        >
          {saveMut.isPending ? "Saving…" : "Save"}
        </Button>
      </div>
    </div>
  );
}


function Info({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border bg-card p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-sm mt-0.5">{children}</div>
    </div>
  );
}
