import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, FileBarChart2, Scale } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/eqs-files/reporting/")({
  head: () => ({ meta: [{ title: "EQS Files — Reporting" }] }),
  component: ReportingHub,
});

type Card = {
  to: string;
  title: string;
  desc: string;
  icon: typeof FileBarChart2;
  soon?: boolean;
};

const cards: Card[] = [
  {
    to: "/eqs-files/reporting/file-financial",
    title: "File financial report",
    desc: "Бюджет vs факт по файлам в разрезе выбранного статуса и периода его установки.",
    icon: FileBarChart2,
  },
  {
    to: "/eqs-files/reporting/financial-adjustment",
    title: "Financial result adjustment",
    desc: "Та же логика, что File financial report, но в разрезе статей бюджета / cost·charge types.",
    icon: Scale,
  },

];

function ReportingHub() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <Button variant="ghost" size="sm" asChild className="mb-4">
        <Link to="/eqs-files">
          <ArrowLeft className="size-4 mr-1" /> EQS Files
        </Link>
      </Button>
      <h1 className="text-3xl font-semibold tracking-tight mb-2">Reporting</h1>
      <p className="text-muted-foreground mb-8">Отчёты по EQS Files.</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {cards.map((c, i) => {
          const inner = (
            <>
              <div className="flex items-center gap-3 mb-2">
                <div className="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                  <c.icon className="size-5" />
                </div>
                <h2 className="text-lg font-semibold tracking-tight">{c.title}</h2>
                {c.soon && (
                  <span className="text-[10px] uppercase tracking-wide text-muted-foreground border border-border rounded px-1.5 py-0.5 ml-auto">
                    soon
                  </span>
                )}
              </div>
              <p className="text-sm text-muted-foreground">{c.desc}</p>
            </>
          );
          if (c.soon) {
            return (
              <div
                key={i}
                className="p-6 bg-card rounded-2xl border border-border opacity-60 cursor-not-allowed"
              >
                {inner}
              </div>
            );
          }
          return (
            <Link
              key={i}
              to={c.to as "/eqs-files/reporting/file-financial" | "/eqs-files/reporting/financial-adjustment"}

              className="group p-6 bg-card rounded-2xl border border-border hover:border-primary/40 transition-all"
            >
              {inner}
            </Link>
          );
        })}
      </div>
    </div>
  );
}