import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, FileText, Files } from "lucide-react";
import { Card } from "@/components/ui/card";
import { useT } from "@/i18n/i18n";

export const Route = createFileRoute("/_authenticated/tools")({
  component: ToolsPage,
});

function ToolsPage() {
  const t = useT();

  const tools = [
    {
      title: t("tools.cci.title"),
      description: t("tools.cci.desc"),
      url: "/container-extractor",
      icon: Sparkles,
      show: true,
    },
    {
      title: t("tools.invoice.title"),
      description: t("tools.invoice.desc"),
      url: "/invoice-generator",
      icon: FileText,
      show: true,
    },
    {
      title: t("tools.eqs.title"),
      description: t("tools.eqs.desc"),
      url: "/eqs-files",
      icon: Files,
      show: true,
    },
  ].filter((item) => item.show);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">{t("tools.title")}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t("tools.subtitle")}</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {tools.map((item) => (
          <Link key={item.url} to={item.url} className="group">
            <Card className="p-5 h-full transition-all hover:border-primary/40 hover:shadow-md">
              <div className="flex items-start gap-3">
                <div className="size-10 rounded-md bg-primary/10 text-primary grid place-items-center shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <item.icon className="size-5" />
                </div>
                <div className="min-w-0">
                  <div className="font-medium">{item.title}</div>
                  <div className="text-sm text-muted-foreground mt-0.5">{item.description}</div>
                </div>
              </div>
            </Card>
          </Link>
        ))}
        {tools.length === 0 && (
          <div className="text-sm text-muted-foreground">{t("tools.empty")}</div>
        )}
      </div>
    </div>
  );
}
