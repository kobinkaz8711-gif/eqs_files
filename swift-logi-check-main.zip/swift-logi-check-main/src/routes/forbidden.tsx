import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useT } from "@/i18n/i18n";

export const Route = createFileRoute("/forbidden")({
  head: () => ({
    meta: [{ title: "Доступ запрещён — Logis" }],
  }),
  component: ForbiddenPage,
});

function ForbiddenPage() {
  const t = useT();
  return (
    <div className="min-h-screen grid place-items-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="mx-auto size-12 rounded-full bg-destructive/10 text-destructive grid place-items-center mb-5">
          <ShieldOff className="size-6" />
        </div>
        <h1 className="text-2xl font-semibold tracking-tight mb-2">{t("forbidden.title")}</h1>
        <p className="text-sm text-muted-foreground mb-6">{t("forbidden.body")}</p>
        <Button asChild>
          <Link to="/">{t("forbidden.home")}</Link>
        </Button>
      </div>
    </div>
  );
}
