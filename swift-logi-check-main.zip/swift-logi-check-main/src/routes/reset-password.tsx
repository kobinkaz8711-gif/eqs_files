import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useT } from "@/i18n/i18n";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [{ title: "Сброс пароля — Logis" }] }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const t = useT();
  const [mode, setMode] = useState<"request" | "set">("request");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const hash = window.location.hash;
    if (hash.includes("type=recovery") || hash.includes("access_token")) {
      setMode("set");
    }
  }, []);

  const requestReset = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(t("reset.sent"));
  };

  const setNewPassword = async (e: FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      toast.error(t("reset.minLen"));
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(t("reset.updated"));
    navigate({ to: "/" });
  };

  return (
    <div className="min-h-screen grid place-items-center bg-background px-4">
      <div className="w-full max-w-md bg-card border border-border rounded-2xl shadow-sm p-8">
        <p className="text-xs font-semibold uppercase tracking-widest text-primary mb-2">
          {t("reset.kicker")}
        </p>
        <h1 className="text-2xl font-semibold tracking-tight mb-1">
          {mode === "request" ? t("reset.requestTitle") : t("reset.setTitle")}
        </h1>
        <p className="text-sm text-muted-foreground mb-6">
          {mode === "request" ? t("reset.requestSub") : t("reset.setSub")}
        </p>

        {mode === "request" ? (
          <form onSubmit={requestReset} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">{t("reset.email")}</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="size-4 animate-spin" /> : t("reset.send")}
            </Button>
          </form>
        ) : (
          <form onSubmit={setNewPassword} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="password">{t("reset.newPassword")}</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={8}
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="size-4 animate-spin" /> : t("reset.save")}
            </Button>
          </form>
        )}
      </div>
    </div>
  );
}
