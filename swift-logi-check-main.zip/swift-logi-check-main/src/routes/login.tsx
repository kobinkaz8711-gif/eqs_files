import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, ShieldCheck } from "lucide-react";
import cmsLogo from "@/assets/cms-logo.png";
import { useT } from "@/i18n/i18n";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { toast } from "sonner";

const searchSchema = z.object({
  redirect: z.string().optional(),
});

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Вход — CMS" },
      { name: "description", content: "Вход в корпоративную CMS платформу." },
    ],
  }),
  validateSearch: (s) => searchSchema.parse(s),
  component: LoginPage,
});

function LoginPage() {
  const { signIn, session } = useAuth();
  const t = useT();
  const navigate = useNavigate();
  const search = useSearch({ from: "/login" });

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (session) {
      navigate({ to: (search.redirect as string) || "/" });
    }
  }, [session, navigate, search.redirect]);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const { error } = await signIn(email.trim(), password);
    if (error) {
      setLoading(false);
      setError(error);
      toast.error(t("login.failed"), { description: error });
      return;
    }
    toast.success(t("login.success"));
    navigate({ to: (search.redirect as string) || "/" });
  };

  return (
    <div className="min-h-screen relative flex items-center justify-center px-4 bg-background overflow-hidden">
      {/* glow background */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(60rem 40rem at 70% -10%, color-mix(in oklab, var(--primary) 22%, transparent), transparent), radial-gradient(40rem 30rem at -10% 110%, color-mix(in oklab, var(--primary) 14%, transparent), transparent)",
        }}
      />

      <div className="w-full max-w-[420px]">
        <div className="mb-8 flex items-center justify-between gap-2.5">
          <div className="flex items-center gap-2.5">
            <img src={cmsLogo} alt="CMS" width={36} height={36} className="size-9 object-contain" />
            <span className="text-base font-semibold tracking-[0.18em] uppercase bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent">
              CMS
            </span>
          </div>
          <LanguageSwitcher />
        </div>

        <div className="bg-card/80 backdrop-blur-xl border border-border rounded-2xl shadow-xl p-8">
          <div className="mb-7">
            <p className="text-xs font-semibold uppercase tracking-widest text-primary mb-2">
              {t("login.kicker")}
            </p>
            <h1 className="text-2xl font-semibold tracking-tight">{t("login.title")}</h1>
            <p className="text-sm text-muted-foreground mt-1.5">{t("login.subtitle")}</p>
          </div>

          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">{t("login.email")}</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@company.com"
                className="h-10"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">{t("login.password")}</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="h-10"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 text-sm text-muted-foreground cursor-pointer">
                <Checkbox
                  checked={remember}
                  onCheckedChange={(v) => setRemember(!!v)}
                />
                {t("login.remember")}
              </label>
              <Link
                to="/reset-password"
                className="text-sm text-primary hover:underline underline-offset-4"
              >
                {t("login.forgot")}
              </Link>
            </div>

            {error ? (
              <p className="text-sm text-destructive border border-destructive/30 bg-destructive/5 rounded-md px-3 py-2">
                {error}
              </p>
            ) : null}

            <Button type="submit" className="w-full h-10" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  {t("login.submitting")}
                </>
              ) : (
                t("login.submit")
              )}
            </Button>
          </form>
        </div>

        <p className="mt-6 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
          <ShieldCheck className="size-3.5" />
          {t("login.secure")}
        </p>
      </div>
    </div>
  );
}
