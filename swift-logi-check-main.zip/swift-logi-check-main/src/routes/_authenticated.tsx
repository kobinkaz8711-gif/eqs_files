import { createFileRoute, Outlet, redirect, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { getMyContext } from "@/lib/auth.functions";
import { TopNav, TopNavLogo } from "@/components/TopNav";
import { UserMenu } from "@/components/auth/UserMenu";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";

export const Route = createFileRoute("/_authenticated")({
  beforeLoad: async ({ location }) => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      throw redirect({
        to: "/login",
        search: { redirect: location.href },
      });
    }
  },
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  const { session, setMe, me } = useAuth();
  const navigate = useNavigate();
  const fetchMe = useServerFn(getMyContext);

  const { data } = useQuery({
    queryKey: ["me", session?.user.id],
    queryFn: () => fetchMe(),
    enabled: !!session,
    staleTime: 30_000,
  });

  useEffect(() => {
    if (data) setMe(data);
  }, [data, setMe]);

  useEffect(() => {
    if (!session) navigate({ to: "/login" });
  }, [session, navigate]);

  if (!session) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col w-full bg-background">
      <header className="h-12 flex items-center border-b border-border bg-card sticky top-0 z-40 px-3 gap-2">
        <TopNavLogo />
        <div className="flex-1" />
        <TopNav />
        <LanguageSwitcher />
        <UserMenu />
      </header>
      <main className="flex-1 min-w-0">
        <Outlet />
      </main>
    </div>
  );
}
