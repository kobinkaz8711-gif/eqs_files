import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export interface TransportTypeDTO {
  code: string;
  label: string;
  sort_order: number;
  is_active: boolean;
}

export interface ChecklistItemDTO {
  id: string;
  label: string;
  hint: string | null;
  required: boolean;
  critical: boolean;
  sort_order: number;
  depends_on_item_id: string | null;
}

export interface ChecklistSectionDTO {
  id: string;
  title: string;
  sort_order: number;
  items: ChecklistItemDTO[];
}

export interface ChecklistTemplateDTO {
  id: string;
  transport_type_code: string;
  name: string;
  sections: ChecklistSectionDTO[];
}

export interface EmailTemplateDTO {
  id: string;
  transport_type_code: string | null;
  kind: "ok" | "missing";
  subject: string;
  body: string;
}

// ---------- Transport types ----------

export const listTransportTypes = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("transport_types")
      .select("code,label,sort_order,is_active")
      .order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return (data ?? []) as TransportTypeDTO[];
  });

const upsertTypeSchema = z.object({
  code: z.string().min(1).max(32).regex(/^[A-Z0-9_-]+$/),
  label: z.string().min(1).max(255),
  sort_order: z.number().int().min(0).max(9999).default(0),
  is_active: z.boolean().default(true),
});

export const createTransportType = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => upsertTypeSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error: tErr } = await supabase.from("transport_types").insert(data);
    if (tErr) throw new Error(tErr.message);
    const { error: tplErr } = await supabase
      .from("checklist_templates")
      .insert({ transport_type_code: data.code, name: data.label });
    if (tplErr) throw new Error(tplErr.message);
    return { ok: true };
  });

export const updateTransportType = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        code: z.string().min(1).max(32),
        patch: z.object({
          label: z.string().min(1).max(255).optional(),
          sort_order: z.number().int().min(0).max(9999).optional(),
          is_active: z.boolean().optional(),
        }),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("transport_types")
      .update(data.patch)
      .eq("code", data.code);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteTransportType = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ code: z.string().min(1).max(32) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("transport_types")
      .delete()
      .eq("code", data.code);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------- Templates ----------

export const getTemplate = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ transportTypeCode: z.string().min(1).max(32) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: tpl, error } = await supabase
      .from("checklist_templates")
      .select("id,transport_type_code,name")
      .eq("transport_type_code", data.transportTypeCode)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!tpl) return null;

    const { data: sections, error: sErr } = await supabase
      .from("checklist_sections")
      .select("id,title,sort_order")
      .eq("template_id", tpl.id)
      .order("sort_order", { ascending: true });
    if (sErr) throw new Error(sErr.message);

    const sectionIds = (sections ?? []).map((s) => s.id);
    type ItemRow = ChecklistItemDTO & { section_id: string };
    let items: ItemRow[] = [];
    if (sectionIds.length > 0) {
      const { data: itemsRaw, error: iErr } = await supabase
        .from("checklist_items")
        .select("id,section_id,label,hint,required,critical,sort_order,depends_on_item_id")
        .in("section_id", sectionIds)
        .order("sort_order", { ascending: true });
      if (iErr) throw new Error(iErr.message);
      items = (itemsRaw ?? []) as ItemRow[];
    }

    const result: ChecklistTemplateDTO = {
      id: tpl.id,
      transport_type_code: tpl.transport_type_code,
      name: tpl.name,
      sections: (sections ?? []).map((s) => ({
        id: s.id,
        title: s.title,
        sort_order: s.sort_order,
        items: items
          .filter((it) => it.section_id === s.id)
          .map(({ id, label, hint, required, critical, sort_order, depends_on_item_id }) => ({
            id,
            label,
            hint,
            required,
            critical,
            sort_order,
            depends_on_item_id: depends_on_item_id ?? null,
          })),
      })),
    };
    return result;
  });

const saveTemplateSchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1).max(255),
  sections: z
    .array(
      z.object({
        id: z.string().uuid(),
        title: z.string().min(1).max(255),
        sort_order: z.number().int().min(0).max(9999),
        items: z
          .array(
            z.object({
              id: z.string().uuid(),
              label: z.string().min(1).max(500),
              hint: z.string().max(500).nullable().optional(),
              required: z.boolean(),
              critical: z.boolean(),
              sort_order: z.number().int().min(0).max(9999),
              depends_on_item_id: z.string().uuid().nullable().optional(),
            }),
          )
          .max(200),
      }),
    )
    .max(50),
});

export const saveTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => saveTemplateSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;

    await supabase
      .from("checklist_templates")
      .update({ name: data.name })
      .eq("id", data.id);

    // Existing sections
    const { data: existingSections } = await supabase
      .from("checklist_sections")
      .select("id")
      .eq("template_id", data.id);
    const existingSectionIds = new Set((existingSections ?? []).map((s) => s.id));
    const incomingSectionIds = new Set(data.sections.map((s) => s.id));
    const sectionsToDelete = [...existingSectionIds].filter(
      (id) => !incomingSectionIds.has(id),
    );
    if (sectionsToDelete.length > 0) {
      await supabase.from("checklist_sections").delete().in("id", sectionsToDelete);
    }

    // Build set of all incoming item ids across the template for FK validation
    const allIncomingItemIds = new Set<string>();
    for (const s of data.sections) for (const it of s.items) allIncomingItemIds.add(it.id);

    for (const section of data.sections) {
      await supabase.from("checklist_sections").upsert({
        id: section.id,
        template_id: data.id,
        title: section.title,
        sort_order: section.sort_order,
      });

      const { data: existingItems } = await supabase
        .from("checklist_items")
        .select("id")
        .eq("section_id", section.id);
      const existingItemIds = new Set((existingItems ?? []).map((i) => i.id));
      const incomingItemIds = new Set(section.items.map((i) => i.id));
      const itemsToDelete = [...existingItemIds].filter(
        (id) => !incomingItemIds.has(id),
      );
      if (itemsToDelete.length > 0) {
        // Clear inbound FK refs to items we're about to delete (ON DELETE SET NULL
        // would also work, but we want explicit control here).
        await supabase
          .from("checklist_items")
          .update({ depends_on_item_id: null })
          .in("depends_on_item_id", itemsToDelete);
        await supabase.from("checklist_items").delete().in("id", itemsToDelete);
      }

      if (section.items.length > 0) {
        // Pass 1: upsert items with depends_on_item_id = null to avoid FK ordering issues.
        await supabase.from("checklist_items").upsert(
          section.items.map((it) => ({
            id: it.id,
            section_id: section.id,
            label: it.label,
            hint: it.hint ?? null,
            required: it.required,
            critical: it.critical,
            sort_order: it.sort_order,
            depends_on_item_id: null,
          })),
        );
      }
    }

    // Pass 2: set dependencies, ignoring refs to items outside the incoming set
    // or self-references.
    for (const section of data.sections) {
      for (const it of section.items) {
        const dep = it.depends_on_item_id ?? null;
        const finalDep =
          dep && dep !== it.id && allIncomingItemIds.has(dep) ? dep : null;
        if (finalDep !== null) {
          await supabase
            .from("checklist_items")
            .update({ depends_on_item_id: finalDep })
            .eq("id", it.id);
        }
      }
    }

    return { ok: true };
  });

// ---------- Copy template ----------

const copyTemplateSchema = z
  .object({
    sourceTransportTypeCode: z.string().min(1).max(32),
    mode: z.enum(["existing", "new"]),
    targetCode: z.string().min(1).max(32).regex(/^[A-Z0-9_-]+$/),
    targetLabel: z.string().min(1).max(255).optional(),
    overwrite: z.boolean().default(false),
  })
  .refine(
    (v) => v.mode === "existing" || (v.mode === "new" && !!v.targetLabel),
    { message: "targetLabel is required when mode is 'new'" },
  );

export const copyTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => copyTemplateSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;

    if (data.sourceTransportTypeCode === data.targetCode) {
      throw new Error("Источник и цель совпадают");
    }

    // Load source template
    const { data: srcTpl, error: srcErr } = await supabase
      .from("checklist_templates")
      .select("id")
      .eq("transport_type_code", data.sourceTransportTypeCode)
      .maybeSingle();
    if (srcErr) throw new Error(srcErr.message);
    if (!srcTpl) throw new Error("Исходный шаблон не найден");

    const { data: srcSections, error: ssErr } = await supabase
      .from("checklist_sections")
      .select("id,title,sort_order")
      .eq("template_id", srcTpl.id)
      .order("sort_order", { ascending: true });
    if (ssErr) throw new Error(ssErr.message);

    const srcSectionIds = (srcSections ?? []).map((s) => s.id);
    type ItemRow = {
      id: string;
      section_id: string;
      label: string;
      hint: string | null;
      required: boolean;
      critical: boolean;
      sort_order: number;
      depends_on_item_id: string | null;
    };
    let srcItems: ItemRow[] = [];
    if (srcSectionIds.length > 0) {
      const { data: rows, error: siErr } = await supabase
        .from("checklist_items")
        .select("id,section_id,label,hint,required,critical,sort_order,depends_on_item_id")
        .in("section_id", srcSectionIds);
      if (siErr) throw new Error(siErr.message);
      srcItems = (rows ?? []) as ItemRow[];
    }

    // Resolve target template
    let targetTemplateId: string;

    if (data.mode === "new") {
      // create transport type + template
      const { count } = await supabase
        .from("transport_types")
        .select("code", { count: "exact", head: true });
      const { error: ttErr } = await supabase.from("transport_types").insert({
        code: data.targetCode,
        label: data.targetLabel!,
        sort_order: count ?? 0,
        is_active: true,
      });
      if (ttErr) throw new Error(ttErr.message);

      const { data: newTpl, error: ntErr } = await supabase
        .from("checklist_templates")
        .insert({
          transport_type_code: data.targetCode,
          name: data.targetLabel!,
        })
        .select("id")
        .single();
      if (ntErr) throw new Error(ntErr.message);
      targetTemplateId = newTpl.id;
    } else {
      const { data: tgtTpl, error: tgtErr } = await supabase
        .from("checklist_templates")
        .select("id")
        .eq("transport_type_code", data.targetCode)
        .maybeSingle();
      if (tgtErr) throw new Error(tgtErr.message);
      if (!tgtTpl) throw new Error("Целевой шаблон не найден");
      targetTemplateId = tgtTpl.id;

      // Check existing content
      const { data: existSections } = await supabase
        .from("checklist_sections")
        .select("id")
        .eq("template_id", targetTemplateId);
      if ((existSections ?? []).length > 0) {
        if (!data.overwrite) {
          throw new Error("В целевом шаблоне уже есть данные. Подтвердите перезапись.");
        }
        const ids = (existSections ?? []).map((s) => s.id);
        if (ids.length > 0) {
          await supabase.from("checklist_items").delete().in("section_id", ids);
          await supabase.from("checklist_sections").delete().in("id", ids);
        }
      }
    }

    // Pass 1: insert sections + items WITHOUT dependencies; collect id mapping
    const idMap = new Map<string, string>(); // old item id -> new item id
    for (const s of srcSections ?? []) {
      const { data: newSection, error: nsErr } = await supabase
        .from("checklist_sections")
        .insert({
          template_id: targetTemplateId,
          title: s.title,
          sort_order: s.sort_order,
        })
        .select("id")
        .single();
      if (nsErr) throw new Error(nsErr.message);

      const itemsForSection = srcItems.filter((it) => it.section_id === s.id);
      if (itemsForSection.length > 0) {
        const { data: inserted, error: niErr } = await supabase
          .from("checklist_items")
          .insert(
            itemsForSection.map((it) => ({
              section_id: newSection.id,
              label: it.label,
              hint: it.hint,
              required: it.required,
              critical: it.critical,
              sort_order: it.sort_order,
              depends_on_item_id: null,
            })),
          )
          .select("id,label,sort_order");
        if (niErr) throw new Error(niErr.message);

        // Match inserted rows back to source by (label, sort_order)
        // Order preserved by Postgres insert, but match defensively.
        const insertedSorted = (inserted ?? []).slice();
        for (let i = 0; i < itemsForSection.length; i++) {
          const src = itemsForSection[i];
          const ins = insertedSorted[i];
          if (ins) idMap.set(src.id, ins.id);
        }
      }
    }

    // Pass 2: set dependencies using remapped ids
    for (const it of srcItems) {
      if (!it.depends_on_item_id) continue;
      const newId = idMap.get(it.id);
      const newDep = idMap.get(it.depends_on_item_id);
      if (newId && newDep) {
        await supabase
          .from("checklist_items")
          .update({ depends_on_item_id: newDep })
          .eq("id", newId);
      }
    }

    return { ok: true, targetCode: data.targetCode };
  });

// ---------- Email templates ----------

export const listEmailTemplates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    // Email templates are needed by all authenticated users to render previews.
    // RLS restricts direct access to managers; the server fn gates by auth.
    const { data, error } = await supabaseAdmin
      .from("email_templates")
      .select("id,transport_type_code,kind,subject,body");
    if (error) throw new Error(error.message);
    return (data ?? []) as EmailTemplateDTO[];
  });


const emailUpsertSchema = z.object({
  transport_type_code: z.string().min(1).max(32).nullable(),
  kind: z.enum(["ok", "missing"]),
  subject: z.string().min(1).max(500),
  body: z.string().min(1).max(10000),
});

export const upsertEmailTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => emailUpsertSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    // Manual upsert by (transport_type_code, kind) since partial unique indexes can't be ON CONFLICT targets directly across the NULL case.
    const query = supabase
      .from("email_templates")
      .select("id")
      .eq("kind", data.kind);
    const existingQ =
      data.transport_type_code === null
        ? query.is("transport_type_code", null)
        : query.eq("transport_type_code", data.transport_type_code);
    const { data: existing, error: selErr } = await existingQ.maybeSingle();
    if (selErr) throw new Error(selErr.message);

    if (existing) {
      const { error } = await supabase
        .from("email_templates")
        .update({ subject: data.subject, body: data.body })
        .eq("id", existing.id);
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabase.from("email_templates").insert(data);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const deleteEmailTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("email_templates")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
