import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from "pdf-lib";
import type { BillingRow } from "./classify";
import { loadInvoiceSettings, lookupChargeName } from "./settings";

const A4 = { w: 595.28, h: 841.89 };
const M = { top: 50, bottom: 50, left: 45, right: 45 };


const today = () => {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
};

const addDays = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
};

const fmt = (n: number) =>
  n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

type Ctx = {
  doc: PDFDocument;
  font: PDFFont;
  bold: PDFFont;
  page: PDFPage;
  y: number;
  pageNum: number;
  totalPages: number;
};

const sanitize = (s: string) =>
  s
    .replace(/\u2116/g, "No.")
    .replace(/[\u2018\u2019\u201A\u201B]/g, "'")
    .replace(/[\u201C\u201D\u201E\u201F]/g, '"')
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/\u2026/g, "...")
    .replace(/\u00A0/g, " ")
    .replace(/[^\x09\x0A\x0D\x20-\x7E\xA0-\xFF]/g, "?");

const text = (ctx: Ctx, s: string, x: number, y: number, size = 9, bold = false, color = rgb(0.1, 0.1, 0.15)) => {
  ctx.page.drawText(sanitize(s), { x, y, size, font: bold ? ctx.bold : ctx.font, color });
};

const textRight = (ctx: Ctx, s: string, xRight: number, y: number, size = 9, bold = false, color = rgb(0.1, 0.1, 0.15)) => {
  const f = bold ? ctx.bold : ctx.font;
  const clean = sanitize(s);
  const w = f.widthOfTextAtSize(clean, size);
  ctx.page.drawText(clean, { x: xRight - w, y, size, font: f, color });
};

const line = (ctx: Ctx, x1: number, y1: number, x2: number, y2: number, width = 0.5, color = rgb(0.78, 0.81, 0.86)) => {
  ctx.page.drawLine({ start: { x: x1, y: y1 }, end: { x: x2, y: y2 }, thickness: width, color });
};

const drawTableHeader = (ctx: Ctx) => {
  const headerY = ctx.y;
  ctx.page.drawRectangle({
    x: M.left, y: headerY - 16, width: A4.w - M.left - M.right, height: 18,
    color: rgb(0.95, 0.96, 0.98),
  });
  text(ctx, "Invoice details", M.left + 6, headerY - 12, 9, true);
  textRight(ctx, "Amount", A4.w - M.right - 6, headerY - 12, 9, true);
  ctx.y = headerY - 22;
};

const newPage = (ctx: Ctx) => {
  ctx.page = ctx.doc.addPage([A4.w, A4.h]);
  ctx.pageNum += 1;
  ctx.y = A4.h - M.top;
  drawTableHeader(ctx);
};

const BRAND = rgb(0.09, 0.18, 0.55); // brand blue

const decodeDataUrl = (dataUrl: string): { bytes: Uint8Array; mime: string } | null => {
  const m = /^data:(image\/(png|jpeg|jpg));base64,(.+)$/i.exec(dataUrl);
  if (!m) return null;
  const mime = m[1].toLowerCase();
  const bin = atob(m[3]);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return { bytes, mime };
};

const drawCompanyHeader = async (
  ctx: Ctx,
  title: string,
  s: ReturnType<typeof loadInvoiceSettings>,
) => {
  const titleSize = 20;
  const titleW = ctx.bold.widthOfTextAtSize(sanitize(title), titleSize);
  text(ctx, title, (A4.w - titleW) / 2, ctx.y - 4, titleSize, true, BRAND);

  const blockTop = ctx.y - 30;
  const colW = (A4.w - M.left - M.right) / 3;

  let c1 = blockTop;
  text(ctx, s.company.name, M.left, c1, 10, true, BRAND); c1 -= 12;
  text(ctx, s.company.sub, M.left, c1, 9, false, BRAND); c1 -= 14;
  for (const l of s.company.lines) { text(ctx, l, M.left, c1, 9, false, BRAND); c1 -= 11; }

  const col2X = M.left + colW + 10;
  let c2 = blockTop - 14;
  text(ctx, `Tel:   ${s.company.tel.replace(/^Tel:\s*/i, "")}`, col2X, c2, 9, false, BRAND); c2 -= 11;
  text(ctx, `Email: ${s.company.email.replace(/^Email:\s*/i, "")}`, col2X, c2, 9, false, BRAND); c2 -= 11;
  text(ctx, s.company.tax, col2X, c2, 9, false, BRAND); c2 -= 11;

  const logoBoxW = 140;
  const logoBoxH = 60;
  const logoX = A4.w - M.right - logoBoxW;
  const logoTop = blockTop + 6;

  let drewLogo = false;
  if (s.logoDataUrl) {
    const decoded = decodeDataUrl(s.logoDataUrl);
    if (decoded) {
      try {
        const img =
          decoded.mime === "image/png"
            ? await ctx.doc.embedPng(decoded.bytes)
            : await ctx.doc.embedJpg(decoded.bytes);
        const scale = Math.min(logoBoxW / img.width, logoBoxH / img.height);
        const w = img.width * scale;
        const h = img.height * scale;
        ctx.page.drawImage(img, {
          x: logoX + (logoBoxW - w),
          y: logoTop - h,
          width: w,
          height: h,
        });
        drewLogo = true;
      } catch {
        /* ignore */
      }
    }
  }
  if (!drewLogo) {
    text(ctx, "MAXX", logoX + 30, logoTop - 22, 22, true, BRAND);
    text(ctx, "SERVICES", logoX + 24, logoTop - 38, 12, true, rgb(0.45, 0.45, 0.5));
  }

  ctx.y = Math.min(c1, c2, blockTop - logoBoxH) - 8;
};

const drawBillToAndMeta = (
  ctx: Ctx,
  docNumber: string,
  account: string,
  s: ReturnType<typeof loadInvoiceSettings>,
  o: DocOverrides,
) => {
  const billToW = 240;
  ctx.page.drawRectangle({
    x: M.left, y: ctx.y - 4, width: billToW, height: 16,
    color: rgb(0.90, 0.92, 0.95),
  });
  text(ctx, "Invoice to:", M.left + 6, ctx.y, 9, true);
  let by = ctx.y - 14;
  text(ctx, s.billTo.name, M.left + 6, by, 9, true); by -= 11;
  for (const l of s.billTo.lines) { text(ctx, l, M.left + 6, by, 9); by -= 11; }
  text(ctx, "Contact:", M.left + 6, by, 9, true);
  by -= 6;

  const mx = A4.w - M.right - 240;
  const mxv = A4.w - M.right - 6;
  const rows: [string, string][] = [
    ["Invoice", docNumber],
    ["Date", o.date ?? ""],
    ["Account", account || s.account],
    ["P.O. #", ""],
    ["Tax Ref", o.taxRef ?? s.taxRef],
    ["Due date", o.dueDate ?? addDays(s.dueDays)],
    ["Internal Contact", s.internalContact],
    ["Printed", o.printed ?? today()],
  ];

  let my = ctx.y;
  rows.forEach(([k, v], i) => {
    if (i % 2 === 0) {
      ctx.page.drawRectangle({ x: mx, y: my - 14, width: 240, height: 14, color: rgb(0.97, 0.98, 0.99) });
    }
    text(ctx, k, mx + 6, my - 10, 8, true);
    textRight(ctx, v, mxv, my - 10, 8);
    my -= 14;
  });

  ctx.y = Math.min(by, my) - 10;
};

const drawRemarks = (ctx: Ctx, remarks: string) => {
  text(ctx, "Invoice Contact / Remarks", M.left, ctx.y, 10, true);
  ctx.y -= 14;
  ctx.page.drawRectangle({
    x: M.left, y: ctx.y - 28, width: A4.w - M.left - M.right, height: 28,
    color: rgb(0.97, 0.98, 0.99),
  });
  text(ctx, "Contact:", M.left + 6, ctx.y - 10, 8, true);
  text(ctx, "Remarks:", M.left + 6, ctx.y - 22, 8, true);
  text(ctx, remarks, M.left + 60, ctx.y - 22, 8);
  ctx.y -= 36;
};

const drawPaymentInstructions = (ctx: Ctx, _s: ReturnType<typeof loadInvoiceSettings>, isCredit: boolean) => {
  if (ctx.y < M.bottom + 140) newPage(ctx);
  const w = A4.w - M.left - M.right;
  ctx.page.drawRectangle({
    x: M.left, y: ctx.y - 4, width: w, height: 16,
    color: rgb(0.55, 0.58, 0.64),
  });
  text(ctx, "Payment instructions:", M.left + 6, ctx.y, 9, true, rgb(1, 1, 1));
  ctx.y -= 22;
  const banks = [
    { name: "Belfius Bank", addr: "Grote Steenweg 454, 2600 Antwerp, Belgium", iban: "BE25 0689 0043 7182", bic: "GKCCBEBB" },
    { name: "ING Bank", addr: "Marnixlaan 24, 1000 Brussels, Belgium", iban: "BE35 3200 0913 4137", bic: "BBRUBEBB" },
  ];
  for (const b of banks) {
    text(ctx, `Bank Name: ${b.name}`, M.left, ctx.y, 9, false, BRAND); ctx.y -= 11;
    text(ctx, `Bank Address: ${b.addr}`, M.left, ctx.y, 9, false, BRAND); ctx.y -= 11;
    text(ctx, `Account no/ IBAN: ${b.iban}`, M.left, ctx.y, 9, false, BRAND); ctx.y -= 11;
    text(ctx, `BIC/SWIFT: ${b.bic}`, M.left, ctx.y, 9, false, BRAND); ctx.y -= 14;
  }
  ctx.y -= 4;
  if (!isCredit) {
    const msg = "PLEASE REFERENCE THE LAST 5 DIGITS OF THE INVOICE NUMBER WITH REMITTANCE";
    const tw = ctx.bold.widthOfTextAtSize(msg, 9);
    text(ctx, msg, (A4.w - tw) / 2, ctx.y, 9, true, BRAND);
    ctx.y -= 16;
  }
};



export type DocumentMeta = {
  number: string;
  customer: string;
  lineCount: number;
  total: number;
  currency: string;
  date: string;
};

export type DocOverrides = {
  remarks?: string;
  date?: string;
  dueDate?: string;
  printed?: string;
  taxRef?: string;
};

export const generatePdf = async (
  title: "Invoice" | "Credit Note",
  docNumber: string,
  rows: BillingRow[],
  overrides: DocOverrides = {},
): Promise<{ bytes: Uint8Array; meta: DocumentMeta }> => {
  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const page = doc.addPage([A4.w, A4.h]);

  const ctx: Ctx = { doc, font, bold, page, y: A4.h - M.top, pageNum: 1, totalPages: 1 };

  const customer = rows[0]?.customer || "MAXSTP03";
  const currency = rows[0]?.currency || "USD";
  const settings = loadInvoiceSettings();
  const remarks = overrides.remarks ?? settings.remarks;

  await drawCompanyHeader(ctx, title, settings);
  drawBillToAndMeta(ctx, docNumber, customer, settings, overrides);
  drawRemarks(ctx, remarks);


  drawTableHeader(ctx);

  let total = 0;
  let zebra = false;
  for (const r of rows) {
    if (ctx.y < M.bottom + 80) { newPage(ctx); zebra = false; }
    const amount = Math.abs(r.total);
    total += amount;
    const chargeName = lookupChargeName(settings, r.charge, r.chargeDescription);
    const desc = `${r.container}: ${r.custOrder} (${chargeName}) Internal Ref: ${r.bookingId}`;
    if (zebra) {
      ctx.page.drawRectangle({
        x: M.left, y: ctx.y - 11, width: A4.w - M.left - M.right, height: 13,
        color: rgb(0.985, 0.99, 0.995),
      });
    }
    text(ctx, desc, M.left + 6, ctx.y - 8, 8.5);
    textRight(ctx, fmt(amount), A4.w - M.right - 6, ctx.y - 8, 8.5);
    ctx.y -= 13;
    zebra = !zebra;
  }

  if (ctx.y < M.bottom + 200) newPage(ctx);
  ctx.y -= 6;
  line(ctx, M.left, ctx.y, A4.w - M.right, ctx.y);
  ctx.y -= 16;
  const sx = A4.w - M.right - 220;
  const sxv = A4.w - M.right - 6;
  const vat = total * (settings.vatPercent / 100);
  const grand = total + vat;
  textRight(ctx, "Summary", sxv, ctx.y, 11, true, BRAND);
  ctx.y -= 14;
  text(ctx, "Net", sx, ctx.y, 9, false, BRAND);
  textRight(ctx, fmt(total), sxv, ctx.y, 9, false, BRAND);
  ctx.y -= 12;
  text(ctx, `VAT @  ${settings.vatPercent.toFixed(2)}%`, sx, ctx.y, 9, false, BRAND);
  textRight(ctx, fmt(vat), sxv, ctx.y, 9, false, BRAND);
  ctx.y -= 8;
  line(ctx, sx - 6, ctx.y, sxv, ctx.y, 0.5, BRAND);
  ctx.y -= 12;
  text(ctx, `Total ${currency}`, sx, ctx.y, 11, true, BRAND);
  textRight(ctx, fmt(grand), sxv, ctx.y, 11, true, BRAND);
  ctx.y -= 28;

  drawPaymentInstructions(ctx, settings, title === "Credit Note");


  ctx.totalPages = doc.getPageCount();
  const pages = doc.getPages();
  pages.forEach((p, i) => {
    p.drawText(`Page ${i + 1} of ${pages.length}`, {
      x: A4.w / 2 - 25, y: 25, size: 8, font, color: rgb(0.45, 0.45, 0.5),
    });
  });

  const bytes = await doc.save();
  return {
    bytes,
    meta: { number: docNumber, customer, lineCount: rows.length, total: grand, currency, date: today() },
  };
};

export const generateInvoiceNumber = (sourceInvoice: string) => sourceInvoice || `I${Date.now()}`;
export const generateCreditNumber = (sourceInvoice: string) => {
  if (!sourceInvoice) return `C${Date.now()}`;
  return sourceInvoice.replace(/^I/, "C");
};
