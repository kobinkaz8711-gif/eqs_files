export type RawRow = {
  invoice: string;
  customer: string;
  contact: string;
  currency: string;
  eqType: string;
  container: string;
  onHired: string;
  puLocation: string;
  offHired: string;
  doLocation: string;
  charge: string;
  billFrom: string;
  billTo: string;
  days: string;
  dailyRate: string;
  addRate: string;
  total: string;
  tax: string;
  bookingId: string;
  custOrder: string;
  clientRef: string;
};

export type BillingRow = {
  id: string;
  invoice: string;
  customer: string;
  contact: string;
  currency: string;
  container: string;
  charge: string;
  chargeDescription: string;
  bookingId: string;
  custOrder: string;
  clientRef: string;
  billFrom: string;
  billTo: string;
  days: number;
  total: number;
  kind: "invoice" | "credit" | "skip";
  category: "provision-4" | "provision-6" | "free" | "additional" | "other";
};

const parseEuroNumber = (raw: string | undefined): number => {
  if (!raw) return 0;
  const cleaned = String(raw).trim().replace(/\s+/g, "").replace(/\./g, "").replace(",", ".");
  if (cleaned === "" || cleaned === "-") return 0;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : 0;
};

const trim = (s: unknown) => String(s ?? "").trim();

export const CHARGE_MAP: Record<string, { description: string; category: BillingRow["category"] }> = {
  RENT: { description: "Container Provision 6: Additional", category: "provision-6" },
  FREE: { description: "Container Provision 6: Additional", category: "free" },
  PCK2: { description: "Container provision 4", category: "provision-4" },
  PCK1: { description: "Container provision 4", category: "provision-4" },
  DROP: { description: "Drop-off Charge", category: "additional" },
  PICK: { description: "Pick-up Charge", category: "additional" },
};

export const classifyRow = (raw: RawRow, idx: number): BillingRow => {
  const total = parseEuroNumber(raw.total);
  const chargeKey = trim(raw.charge).toUpperCase();
  const mapped = CHARGE_MAP[chargeKey] ?? {
    description: chargeKey ? `Charge ${chargeKey}` : "Charge",
    category: "other" as const,
  };

  let kind: BillingRow["kind"] = "skip";
  if (total > 0) kind = "invoice";
  else if (total < 0) kind = "credit";

  return {
    id: `${trim(raw.invoice)}-${idx}`,
    invoice: trim(raw.invoice),
    customer: trim(raw.customer),
    contact: trim(raw.contact),
    currency: trim(raw.currency) || "USD",
    container: trim(raw.container),
    charge: chargeKey,
    chargeDescription: mapped.description,
    bookingId: trim(raw.bookingId),
    custOrder: trim(raw.custOrder),
    clientRef: trim(raw.clientRef),
    billFrom: trim(raw.billFrom),
    billTo: trim(raw.billTo),
    days: parseEuroNumber(raw.days),
    total,
    kind,
    category: mapped.category,
  };
};

export const RAW_COLUMNS: (keyof RawRow)[] = [
  "invoice","customer","contact","currency","eqType","container","onHired","puLocation",
  "offHired","doLocation","charge","billFrom","billTo","days","dailyRate","addRate",
  "total","tax","bookingId","custOrder","clientRef",
];

export const arrayToRaw = (arr: string[]): RawRow => {
  const out = {} as RawRow;
  RAW_COLUMNS.forEach((k, i) => {
    (out as Record<string, string>)[k] = String(arr[i] ?? "");
  });
  return out;
};

export const objectToRaw = (obj: Record<string, unknown>): RawRow => {
  const keys = Object.keys(obj);
  const find = (...names: string[]) => {
    for (const n of names) {
      const k = keys.find((k) => k.trim().toLowerCase().replace(/[^a-z0-9]/g, "") === n.toLowerCase().replace(/[^a-z0-9]/g, ""));
      if (k) return String(obj[k] ?? "");
    }
    return "";
  };
  return {
    invoice: find("Invoice"),
    customer: find("Customer"),
    contact: find("Contact"),
    currency: find("Currency"),
    eqType: find("Eq. Type", "EqType", "Eq Type"),
    container: find("Container"),
    onHired: find("On Hired", "OnHired"),
    puLocation: find("PU Location", "PULocation"),
    offHired: find("Off Hired", "OffHired"),
    doLocation: find("DO Location", "DOLocation"),
    charge: find("Charge"),
    billFrom: find("Bill From", "BillFrom"),
    billTo: find("Bill To", "BillTo"),
    days: find("Days"),
    dailyRate: find("Daily Rate (L)", "Daily Rate", "DailyRate"),
    addRate: find("Addit Rate (L)", "Addit Rate", "AdditRate"),
    total: find("Total (L)", "Total"),
    tax: find("Tax (L)", "Tax"),
    bookingId: find("Booking Id", "BookingId"),
    custOrder: find("Cust Order", "CustOrder"),
    clientRef: find("Client Ref", "ClientRef"),
  };
};

export type ValidationWarning = {
  level: "warning" | "info";
  message: string;
  rowId?: string;
};

export const detectWarnings = (rows: BillingRow[]): ValidationWarning[] => {
  const warnings: ValidationWarning[] = [];
  const seen = new Map<string, BillingRow[]>();
  for (const r of rows) {
    if (!r.container || !r.bookingId) continue;
    const key = `${r.bookingId}::${r.container}::${r.charge}`;
    const arr = seen.get(key) ?? [];
    arr.push(r);
    seen.set(key, arr);
  }
  for (const [, arr] of seen) {
    if (arr.length > 1) {
      warnings.push({
        level: "warning",
        message: `Duplicate ${arr[0].container} (${arr[0].charge}) in booking ${arr[0].bookingId} — ${arr.length} rows`,
        rowId: arr[0].id,
      });
    }
  }
  const skipped = rows.filter((r) => r.kind === "skip").length;
  if (skipped > 0) {
    warnings.push({
      level: "info",
      message: `${skipped} zero-amount row${skipped > 1 ? "s" : ""} excluded from documents`,
    });
  }
  return warnings;
};
