import { create } from "zustand";
import { parseFile, detectWarnings, type BillingRow } from "./parse";
import { generatePdf, generateInvoiceNumber, generateCreditNumber, type DocumentMeta } from "./pdf";
import { loadInvoiceSettings } from "./settings";

export type ProcessingStep =
  | "uploaded"
  | "parsing"
  | "validating"
  | "grouping"
  | "generating"
  | "ready";

export type Warning = ReturnType<typeof detectWarnings>[number];

type DocBundle = {
  bytes: Uint8Array;
  blob: Blob;
  url: string;
  meta: DocumentMeta;
};

type DocOverridesState = {
  date: string;
  dueDate: string;
  printed: string;
  taxRef: string;
};

type State = {
  file: File | null;
  fileName: string | null;
  fileSize: number;
  status: "idle" | "processing" | "ready" | "error";
  step: ProcessingStep | null;
  error: string | null;
  rows: BillingRow[];
  invoiceRows: BillingRow[];
  creditRows: BillingRow[];
  warnings: Warning[];
  invoiceDoc: DocBundle | null;
  creditDoc: DocBundle | null;
  recent: { name: string; at: string; rows: number }[];
  remarks: string;
  overrides: DocOverridesState;
  regenerating: boolean;
};

type Actions = {
  ingestFile: (file: File) => Promise<void>;
  setRemarks: (text: string) => void;
  setOverride: <K extends keyof DocOverridesState>(key: K, value: DocOverridesState[K]) => void;
  regenerate: () => Promise<void>;
  reset: () => void;
};


const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const buildBundle = (b: { bytes: Uint8Array; meta: DocumentMeta }): DocBundle => {
  const copy = new Uint8Array(b.bytes);
  const blob = new Blob([copy.buffer], { type: "application/pdf" });
  return { bytes: b.bytes, blob, url: URL.createObjectURL(blob), meta: b.meta };
};

const todayStr = () => {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
};
const addDaysStr = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
};

const emptyOverrides: DocOverridesState = { date: "", dueDate: "", printed: "", taxRef: "" };

export const useInvoiceStore = create<State & Actions>((set, get) => ({
  file: null,
  fileName: null,
  fileSize: 0,
  status: "idle",
  step: null,
  error: null,
  rows: [],
  invoiceRows: [],
  creditRows: [],
  warnings: [],
  invoiceDoc: null,
  creditDoc: null,
  recent: [],
  remarks: "",
  overrides: emptyOverrides,
  regenerating: false,

  ingestFile: async (file) => {
    const prev = get();
    if (prev.invoiceDoc) URL.revokeObjectURL(prev.invoiceDoc.url);
    if (prev.creditDoc) URL.revokeObjectURL(prev.creditDoc.url);

    const s = loadInvoiceSettings();
    const overrides: DocOverridesState = {
      date: todayStr(),
      dueDate: addDaysStr(s.dueDays),
      printed: todayStr(),
      taxRef: s.taxRef,
    };
    set({
      file, fileName: file.name, fileSize: file.size,
      status: "processing", step: "uploaded", error: null,
      rows: [], invoiceRows: [], creditRows: [], warnings: [],
      invoiceDoc: null, creditDoc: null,
      remarks: s.remarks,
      overrides,
    });

    try {
      await sleep(200); set({ step: "parsing" });
      const rows = await parseFile(file);
      await sleep(150); set({ step: "validating", rows });
      const warnings = detectWarnings(rows);
      await sleep(150); set({ step: "grouping", warnings });
      const invoiceRows = rows.filter((r) => r.kind === "invoice");
      const creditRows = rows.filter((r) => r.kind === "credit");
      await sleep(150); set({ step: "generating", invoiceRows, creditRows });

      const sourceInvoice = rows[0]?.invoice ?? "";
      const invoiceNumber = generateInvoiceNumber(sourceInvoice);
      const creditNumber = generateCreditNumber(sourceInvoice);

      const opts = { remarks: s.remarks, ...overrides };
      const [inv, cr] = await Promise.all([
        invoiceRows.length ? generatePdf("Invoice", invoiceNumber, invoiceRows, opts) : Promise.resolve(null),
        creditRows.length ? generatePdf("Credit Note", creditNumber, creditRows, opts) : Promise.resolve(null),
      ]);

      set({
        step: "ready", status: "ready",
        invoiceDoc: inv ? buildBundle(inv) : null,
        creditDoc: cr ? buildBundle(cr) : null,
        recent: [
          { name: file.name, at: new Date().toLocaleTimeString(), rows: rows.length },
          ...get().recent,
        ].slice(0, 5),
      });
    } catch (e) {
      set({
        status: "error", step: null,
        error: e instanceof Error ? e.message : "Failed to process file",
      });
    }
  },

  setRemarks: (text) => set({ remarks: text }),

  setOverride: (key, value) =>
    set((st) => ({ overrides: { ...st.overrides, [key]: value } })),

  regenerate: async () => {
    const s = get();
    if (s.status !== "ready" || s.regenerating) return;
    set({ regenerating: true });
    try {
      const sourceInvoice = s.rows[0]?.invoice ?? "";
      const invoiceNumber = generateInvoiceNumber(sourceInvoice);
      const creditNumber = generateCreditNumber(sourceInvoice);
      const opts = { remarks: s.remarks, ...s.overrides };
      const [inv, cr] = await Promise.all([
        s.invoiceRows.length ? generatePdf("Invoice", invoiceNumber, s.invoiceRows, opts) : Promise.resolve(null),
        s.creditRows.length ? generatePdf("Credit Note", creditNumber, s.creditRows, opts) : Promise.resolve(null),
      ]);
      if (s.invoiceDoc) URL.revokeObjectURL(s.invoiceDoc.url);
      if (s.creditDoc) URL.revokeObjectURL(s.creditDoc.url);
      set({
        invoiceDoc: inv ? buildBundle(inv) : null,
        creditDoc: cr ? buildBundle(cr) : null,
      });
    } finally {
      set({ regenerating: false });
    }
  },

  reset: () => {
    const { invoiceDoc, creditDoc } = get();
    if (invoiceDoc) URL.revokeObjectURL(invoiceDoc.url);
    if (creditDoc) URL.revokeObjectURL(creditDoc.url);
    set({
      file: null, fileName: null, fileSize: 0,
      status: "idle", step: null, error: null,
      rows: [], invoiceRows: [], creditRows: [], warnings: [],
      invoiceDoc: null, creditDoc: null,
      remarks: "",
      overrides: emptyOverrides,
    });
  },
}));

