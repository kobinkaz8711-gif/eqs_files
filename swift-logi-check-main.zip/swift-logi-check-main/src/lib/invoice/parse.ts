import Papa from "papaparse";
import * as XLSX from "xlsx";
import { arrayToRaw, classifyRow, objectToRaw, type BillingRow } from "./classify";

const parseCsv = async (file: File): Promise<BillingRow[]> => {
  const text = await file.text();
  const delimiter = text.split("\n", 1)[0].includes(";") ? ";" : ",";
  const result = Papa.parse<string[]>(text, { delimiter, skipEmptyLines: true, quoteChar: '"' });
  const rows = result.data as string[][];
  if (rows.length === 0) return [];
  const dataRows = rows.slice(1);
  return dataRows.filter((r) => r.length > 5).map((arr, i) => classifyRow(arrayToRaw(arr), i));
};

const parseExcel = async (file: File): Promise<BillingRow[]> => {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "" });
  return json.map((obj, i) => classifyRow(objectToRaw(obj), i));
};

export const parseFile = async (file: File): Promise<BillingRow[]> => {
  const name = file.name.toLowerCase();
  if (name.endsWith(".csv")) return parseCsv(file);
  if (name.endsWith(".xlsx") || name.endsWith(".xls")) return parseExcel(file);
  throw new Error(`Unsupported file type: ${file.name}`);
};

export type { BillingRow } from "./classify";
export { detectWarnings } from "./classify";
