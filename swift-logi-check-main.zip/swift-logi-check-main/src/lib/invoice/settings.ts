import { useEffect, useState, useCallback } from "react";

export type ChargeMapEntry = { code: string; name: string };
export type ChargeReplacement = { from: string; to: string };

export type InvoiceSettings = {
  company: {
    name: string;
    sub: string;
    lines: string[];
    tel: string;
    email: string;
    tax: string;
  };
  billTo: {
    name: string;
    lines: string[];
  };
  remarks: string;
  taxRef: string;
  vatPercent: number;
  account: string;
  dueDays: number;
  internalContact: string;
  logoDataUrl?: string;
  chargeMap: ChargeMapEntry[];
  chargeReplacements: ChargeReplacement[];
};

export const DEFAULT_CHARGE_MAP: ChargeMapEntry[] = [
  { code: "ACCE", name: "ACCE - Accessories" },
  { code: "BIN", name: "BIN - Barge In" },
  { code: "BOUT", name: "BOUT - Barge Out" },
  { code: "CDI2", name: "Container Provision 1: Additio" },
  { code: "CDIE", name: "CDIE - Per Diem" },
  { code: "CFUL", name: "CFUL – Loaded Container Handli" },
  { code: "CGEN", name: "CGEN - General" },
  { code: "CHDL", name: "CHDL - Handling (General)" },
  { code: "CLRE", name: "CLRE - Container Lease Revenue" },
  { code: "CLUM", name: "CLUM - LumpSum" },
  { code: "CMTR", name: "CMTR - Empty Repo" },
  { code: "COSP", name: "COSP - Cost Split" },
  { code: "CPRO", name: "CPRO - Container Profit Split" },
  { code: "CRAI", name: "CRAI - Rail Services (In)" },
  { code: "CRPR", name: "CRPR - Container Repair" },
  { code: "CSTO", name: "CSTO - Container Storage" },
  { code: "CSUR", name: "CSUR - Container Survey" },
  { code: "CTRP", name: "CTRP - Transport" },
  { code: "CTSA", name: "CTSA - Container Sale" },
  { code: "DMDT", name: "DMDT - demurrage & detention" },
  { code: "DOCR", name: "DOCR - Drop Off Credit (RB)" },
  { code: "DPE2", name: "Container Provision 2" },
  { code: "DPEN", name: "DPEN - Drop Off Penalty" },
  { code: "DPP", name: "DPP" },
  { code: "DRO2", name: "Container Provision 3" },
  { code: "DROP", name: "DROP - Drop Off Fee" },
  { code: "EQCB", name: "EQCB - Custom Bonds" },
  { code: "EQCC", name: "EQCC Equipment Container Cost" },
  { code: "EQGN", name: "EQGN - Equipment General" },
  { code: "FREE", name: "FREE of charge" },
  { code: "HIN", name: "HIN - Handing In" },
  { code: "HOUT", name: "HOUT - Handling Out" },
  { code: "HREP", name: "HREP - Repair Handling" },
  { code: "MBIL", name: "MBIL - Monthly Billing  (Lease)" },
  { code: "PCK2", name: "Container provision 4" },
  { code: "PCKP", name: "PCKP - Pickup fee" },
  { code: "PUC2", name: "Container Provision 5" },
  { code: "PUCR", name: "PUCR - PickUp Credit" },
  { code: "RCDI", name: "RCDI - Return Equipment Leasin" },
  { code: "RCLR", name: "RCLR - Return Lease Revenu" },
  { code: "RCTP", name: "RCTP - Return Container Purcha" },
  { code: "RCTS", name: "RCTS - Return Container Sale" },
  { code: "REN2", name: "Container Provision 6: Additio" },
  { code: "RENT", name: "Rental" },
  { code: "REP2", name: "Container Provision 7: Additio" },
  { code: "REPR", name: "REPR - Repair" },
  { code: "SLOA", name: "SLOA - Supplier LOA Invoice" },
  { code: "STOR", name: "STOR - Storage" },
  { code: "SUBL", name: "Sublease rental" },
  { code: "TRAN", name: "TRAN - Transport/Trucking" },
  { code: "XFEE", name: "Exchange Fee" },
];

export const DEFAULT_INVOICE_SETTINGS: InvoiceSettings = {
  company: {
    name: "Maxx Services Limited",
    sub: "Member of Rhenus Logistics group",
    lines: [
      "131 Ayias Filaxeos Street",
      "Space Court, Office 302",
      "P O Box 56980, 3311 Limassol",
      "CYPRUS",
    ],
    tel: "Tel: +357 25 33 33 19",
    email: "Email: equipment@be.rhenus.com",
    tax: "Tax Reg: CY 10149609P",
  },
  billTo: {
    name: "OOO MAXX INTERMODAL SYSTEMS",
    lines: [
      "vn. ter.g. municipal okrug Avtovo, ul.Portovaya,",
      "15, litera B, room 6-H, room 20",
      "St. Petersburg, 198096",
      "Russian Federation",
    ],
  },
  remarks: "contract No. 112/17 dd. 01.10.2017 pick up locations: China, Russia",
  taxRef: "780501001",
  vatPercent: 0,
  account: "MAXSTP03",
  dueDays: 30,
  internalContact: "Raf De Schutter",
  chargeMap: DEFAULT_CHARGE_MAP,
  chargeReplacements: [],
};

const STORAGE_KEY = "invoice.settings.v1";

export const loadInvoiceSettings = (): InvoiceSettings => {
  if (typeof window === "undefined") return DEFAULT_INVOICE_SETTINGS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_INVOICE_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<InvoiceSettings>;
    return {
      ...DEFAULT_INVOICE_SETTINGS,
      ...parsed,
      company: { ...DEFAULT_INVOICE_SETTINGS.company, ...(parsed.company ?? {}) },
      billTo: { ...DEFAULT_INVOICE_SETTINGS.billTo, ...(parsed.billTo ?? {}) },
      chargeMap: parsed.chargeMap?.length ? parsed.chargeMap : DEFAULT_CHARGE_MAP,
      chargeReplacements: parsed.chargeReplacements ?? [],
    };
  } catch {
    return DEFAULT_INVOICE_SETTINGS;
  }
};

export const replaceChargeCode = (s: InvoiceSettings, code: string): string => {
  const key = (code ?? "").trim().toUpperCase();
  const hit = s.chargeReplacements?.find((e) => e.from.trim().toUpperCase() === key);
  return hit?.to?.trim() ? hit.to.trim() : code;
};

export const lookupChargeName = (
  s: InvoiceSettings,
  code: string,
  fallback?: string,
): string => {
  const effective = replaceChargeCode(s, code);
  const key = effective.trim().toUpperCase();
  const hit = s.chargeMap.find((e) => e.code.trim().toUpperCase() === key);
  return hit?.name || fallback || effective;
};


export const saveInvoiceSettings = (s: InvoiceSettings) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
};

export const useInvoiceSettings = () => {
  const [settings, setSettings] = useState<InvoiceSettings>(DEFAULT_INVOICE_SETTINGS);
  useEffect(() => {
    setSettings(loadInvoiceSettings());
  }, []);
  const save = useCallback((next: InvoiceSettings) => {
    setSettings(next);
    saveInvoiceSettings(next);
  }, []);
  const reset = useCallback(() => {
    setSettings(DEFAULT_INVOICE_SETTINGS);
    saveInvoiceSettings(DEFAULT_INVOICE_SETTINGS);
  }, []);
  return { settings, save, reset };
};
