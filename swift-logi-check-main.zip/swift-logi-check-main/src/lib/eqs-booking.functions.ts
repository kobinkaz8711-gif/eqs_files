import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import ExcelJS from "exceljs";

/** Columns required by EQS booking_input template, in order. */
const COLUMNS = [
  "office_dept",
  "company",
  "customer",
  "contact",
  "sales_person",
  "site_detail",
  "lessee_order",
  "epu_date",
  "edo_date",
  "lessee_type",
  "ct",
  "destination",
  "pickup_location",
  "internal_ref",
  "equipment_type",
  "daily_rate",
  "free_min_days",
  "units_booked",
  "drop_location",
  "drop_depot",
  "drop_quantity",
  // Newly added fields (appended at the end)
  "grade",
  "repl_value",
  "charge1_code",
  "charge1_amount",
  "charge2_code",
  "charge2_amount",
  "charge3_code",
  "charge3_amount",
  "charge4_code",
  "charge4_amount",
  "cost1_code",
  "cost1_currency",
  "cost1_amount",
  "cost1_supplier_accno",
  "cost2_code",
  "cost2_currency",
  "cost2_amount",
  "cost2_supplier_accno",
] as const;

function tsStamp(d = new Date()): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return (
    d.getUTCFullYear().toString() +
    pad(d.getUTCMonth() + 1) +
    pad(d.getUTCDate()) +
    pad(d.getUTCHours()) +
    pad(d.getUTCMinutes()) +
    pad(d.getUTCSeconds())
  );
}

function fmtDate(d: string | null | undefined): string {
  if (!d) return "";
  // keep ISO yyyy-mm-dd
  return String(d).slice(0, 10);
}

// ─────────────────────────────────────────────────────────────
// Build preview rows for a file (used by dialog and exporter)
// ─────────────────────────────────────────────────────────────
async function _buildBookingRows(
  supabase: any,
  fileId: string,
): Promise<{
  rows: Record<string, any>[];
  file_number: string;
}> {
  const { data: file, error } = await supabase
    .from("files")
    .select(
      "id,file_number,customer_name,lessee_order,origin_locn,dest_locn,dest_subregion,planned_departure_date,planned_arrival_date,department_id,sales_person_id,departments(code,name),sales_person:sales_persons!files_sales_person_id_fkey(full_name)",
    )
    .eq("id", fileId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!file) throw new Error("File not found");

  const { data: cts } = await supabase
    .from("file_container_types")
    .select(
      "container_type,planned_qty,grade,daily_rate,repl_value,free_min_days,charge1_code,charge1_amount,charge2_code,charge2_amount,charge3_code,charge3_amount,charge4_code,charge4_amount,cost1_code,cost1_currency,cost1_amount,cost1_supplier_accno,cost2_code,cost2_currency,cost2_amount,cost2_supplier_accno",
    )
    .eq("file_id", fileId)
    .order("container_type");

  // Resolve location descriptions
  const locnCodes = [file.origin_locn, file.dest_locn].filter(Boolean);
  const locnNames: Record<string, string> = {};
  if (locnCodes.length) {
    const { data: locs } = await supabase
      .from("eqs_ext_locations_subregions")
      .select("locn_id,locn_desc")
      .in("locn_id", locnCodes);
    for (const l of locs ?? []) {
      if (l.locn_id && l.locn_desc) locnNames[l.locn_id] = l.locn_desc;
    }
  }

  // Destination subregion description
  let destSubregionDesc = "";
  if (file.dest_subregion) {
    const { data: sr } = await supabase
      .from("eqs_ext_locations_subregions")
      .select("subregion_desc")
      .eq("subregion_id", file.dest_subregion)
      .limit(1)
      .maybeSingle();
    destSubregionDesc = sr?.subregion_desc ?? file.dest_subregion;
  }

  // Equipment type map
  const isoCodes = (cts ?? []).map((c: any) => c.container_type);
  const eqMap: Record<string, string> = {};
  if (isoCodes.length) {
    const { data: m } = await supabase
      .from("eqs_equipment_type_map")
      .select("iso_code,label")
      .in("iso_code", isoCodes);
    for (const row of m ?? []) eqMap[row.iso_code] = row.label;
  }

  const baseRow = {
    office_dept: file.departments?.code ?? "",
    company: "",
    customer: file.customer_name ?? "",
    contact: "",
    sales_person: file.sales_person?.full_name ?? "",
    site_detail: file.file_number,
    lessee_order: file.lessee_order ?? "",
    epu_date: fmtDate(file.planned_departure_date),
    edo_date: fmtDate(file.planned_arrival_date),
    lessee_type: "ST",
    ct: "No",
    destination: destSubregionDesc,
    pickup_location: file.origin_locn ? (locnNames[file.origin_locn] ?? file.origin_locn) : "",
    internal_ref: "",
    drop_location: file.dest_locn ? (locnNames[file.dest_locn] ?? file.dest_locn) : "",
    drop_depot: "",
  };

  const rows: Record<string, any>[] = (cts ?? []).map((c: any) => ({
    ...baseRow,
    equipment_type: eqMap[c.container_type] ?? c.container_type,
    units_booked: Number(c.planned_qty ?? 0),
    drop_quantity: Number(c.planned_qty ?? 0),
    daily_rate: c.daily_rate ?? "",
    free_min_days: c.free_min_days ?? "",
    grade: c.grade ?? "",
    repl_value: c.repl_value ?? "",
    charge1_code: c.charge1_code ?? "",
    charge1_amount: c.charge1_amount ?? "",
    charge2_code: c.charge2_code ?? "",
    charge2_amount: c.charge2_amount ?? "",
    charge3_code: c.charge3_code ?? "",
    charge3_amount: c.charge3_amount ?? "",
    charge4_code: c.charge4_code ?? "",
    charge4_amount: c.charge4_amount ?? "",
    cost1_code: c.cost1_code ?? "",
    cost1_currency: c.cost1_currency ?? "",
    cost1_amount: c.cost1_amount ?? "",
    cost1_supplier_accno: c.cost1_supplier_accno ?? "",
    cost2_code: c.cost2_code ?? "",
    cost2_currency: c.cost2_currency ?? "",
    cost2_amount: c.cost2_amount ?? "",
    cost2_supplier_accno: c.cost2_supplier_accno ?? "",
  }));

  if (rows.length === 0) {
    // No container types — still emit one row with empty qty
    rows.push({ ...baseRow, equipment_type: "", units_booked: 0, drop_quantity: 0 });
  }

  return { rows, file_number: file.file_number };
}

// ─────────────────────────────────────────────────────────────
// Preview (used by the dialog)
// ─────────────────────────────────────────────────────────────
export const previewEqsBooking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ file_id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const r = await _buildBookingRows(context.supabase, data.file_id);
    return { columns: COLUMNS, ...r };
  });

// ─────────────────────────────────────────────────────────────
// Export — generate xlsx, store in eqs-outbox, queue for relay
// ─────────────────────────────────────────────────────────────
const RowOverrideSchema = z.record(z.string(), z.union([z.string(), z.number(), z.null()]));

export const exportFileToEqs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        file_id: z.string().uuid(),
        rows: z.array(RowOverrideSchema).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const built = await _buildBookingRows(context.supabase, data.file_id);
    const rows = data.rows && data.rows.length ? data.rows : built.rows;

    // Generate xlsx
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet("booking_input");
    ws.addRow([...COLUMNS]);
    for (const r of rows) {
      ws.addRow(COLUMNS.map((c) => (r[c] ?? "")));
    }
    const buf = await wb.xlsx.writeBuffer();

    const stamp = tsStamp();
    const filename = `EQS_files_${built.file_number}_${stamp}.xlsx`;
    const payloadPath = `${built.file_number}/${filename}`;

    const { error: upErr } = await context.supabase.storage
      .from("eqs-outbox")
      .upload(payloadPath, new Uint8Array(buf as ArrayBuffer), {
        contentType:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        upsert: true,
      });
    if (upErr) throw new Error("Upload failed: " + upErr.message);

    const { data: exp, error: insErr } = await context.supabase
      .from("eqs_booking_exports")
      .insert({
        file_id: data.file_id,
        file_number: built.file_number,
        filename,
        payload_path: payloadPath,
        status: "pending",
        payload: { rows },
        created_by: context.userId,
      })
      .select("id")
      .single();
    if (insErr) throw new Error(insErr.message);

    await context.supabase
      .from("files")
      .update({
        eqs_booking_state: "awaiting_id",
        eqs_booking_id: null,
        eqs_booking_error: null,
        eqs_booking_sent_at: new Date().toISOString(),
        eqs_booking_received_at: null,
      })
      .eq("id", data.file_id);

    return { ok: true, export_id: exp.id, filename };
  });

// ─────────────────────────────────────────────────────────────
// History
// ─────────────────────────────────────────────────────────────
export const getEqsExportHistory = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ file_id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { data: items, error } = await context.supabase
      .from("eqs_booking_exports")
      .select(
        "id,filename,payload_path,response_filename,response_path,status,eqs_booking_id,error,created_at,sent_at,acknowledged_at",
      )
      .eq("file_id", data.file_id)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { items: items ?? [] };
  });

export const getEqsExportDownloadUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        bucket: z.enum(["eqs-outbox", "eqs-inbox"]),
        path: z.string().min(1),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: signed, error } = await context.supabase.storage
      .from(data.bucket)
      .createSignedUrl(data.path, 60 * 10);
    if (error) throw new Error(error.message);
    return { url: signed.signedUrl };
  });

export const retryEqsExport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ file_id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    // Just re-run export; reuses existing rows
    return await exportFileToEqs({ data: { file_id: data.file_id } });
  });

// ─────────────────────────────────────────────────────────────
// SFTP settings
// ─────────────────────────────────────────────────────────────
export const getEqsSftpSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("eqs_sftp_settings")
      .select("*")
      .eq("id", 1)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return data;
  });

export const saveEqsSftpSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        host: z.string().max(255).nullable().optional(),
        port: z.number().int().min(1).max(65535).optional(),
        username: z.string().max(120).nullable().optional(),
        outbox_remote_path: z.string().max(500).nullable().optional(),
        processed_remote_path: z.string().max(500).nullable().optional(),
        errors_remote_path: z.string().max(500).nullable().optional(),
        incomplete_remote_path: z.string().max(500).nullable().optional(),
        enabled: z.boolean().optional(),
        use_tls: z.boolean().optional(),
        poll_interval_seconds: z.number().int().min(10).max(3600).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("eqs_sftp_settings")
      .update({ ...data, updated_at: new Date().toISOString() })
      .eq("id", 1);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listRecentEqsExports = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("eqs_booking_exports")
      .select(
        "id,file_id,file_number,filename,payload_path,response_filename,response_path,status,eqs_booking_id,error,created_at,sent_at,acknowledged_at",
      )
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return { items: data ?? [] };
  });

export const probeEqsFtp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const url = `${process.env.SUPABASE_URL}/functions/v1/eqs-sftp-relay?diag=ls`;
    const res = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
        apikey: process.env.SUPABASE_PUBLISHABLE_KEY ?? "",
      },
    });
    const text = await res.text();
    try { return { ok: res.ok, data: JSON.parse(text) }; }
    catch { return { ok: res.ok, raw: text }; }
  });

export const runEqsRelayNow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const url = `${process.env.SUPABASE_URL}/functions/v1/eqs-sftp-relay`;
    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
        apikey: process.env.SUPABASE_PUBLISHABLE_KEY ?? "",
      },
    });
    const text = await res.text();
    try { return { ok: res.ok, data: JSON.parse(text) }; }
    catch { return { ok: res.ok, raw: text }; }
  });

// ─────────────────────────────────────────────────────────────
// Equipment type map
// ─────────────────────────────────────────────────────────────
export const listEqsEquipmentTypeMap = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("eqs_equipment_type_map")
      .select("iso_code,label,updated_at")
      .order("iso_code");
    if (error) throw new Error(error.message);
    return { items: data ?? [] };
  });

export const upsertEqsEquipmentType = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        iso_code: z.string().trim().min(1).max(20),
        label: z.string().trim().min(1).max(120),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("eqs_equipment_type_map")
      .upsert({ iso_code: data.iso_code.toUpperCase(), label: data.label });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteEqsEquipmentType = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ iso_code: z.string().min(1) }).parse(input))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("eqs_equipment_type_map")
      .delete()
      .eq("iso_code", data.iso_code);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
