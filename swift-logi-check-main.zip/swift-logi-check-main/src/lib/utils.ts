import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Compact label combining container type, optional grade, and quantity.
 * Examples:
 *   formatContainerLine("40HC", "CW", 10) -> "40HC CW×10"
 *   formatContainerLine("40HC", null, 10) -> "40HC×10"
 *   formatContainerLine("40HC", "CW")     -> "40HC CW"
 */
export function formatContainerLine(
  type: string | null | undefined,
  grade: string | null | undefined,
  qty?: number | null,
): string {
  const t = (type ?? "—").toString();
  const g = grade ? ` ${grade}` : "";
  const q = qty != null && qty !== undefined ? `×${qty}` : "";
  return `${t}${g}${q}`;
}
