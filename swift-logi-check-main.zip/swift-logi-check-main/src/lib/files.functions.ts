import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Direction = z.enum(["IMPORT", "EXPORT", "TRIANGLE"]);

const _normalizeSourceType = (t: string | null | undefined): string => {
  if (!t) return "";
  const s = String(t).toLowerCase();
  if (s === "incoming" || s === "cost" || s === "costtype") return "CostType";
  if (s === "outgoing" || s === "charge" || s === "chargetype") return "ChargeType";
  return t;
};

const isStatementTimeout = (error: unknown): boolean => {
  const message =
    error instanceof Error
      ? error.message
      : typeof error === "object" && error && "message" in error
        ? String((error as { message?: unknown }).message ?? "")
        : String(error ?? "");
  return /timeout|canceling statement/i.test(message);
};

async function queryDataOrEmpty<T>(query: PromiseLike<{ data: T[] | null; error: unknown }>): Promise<T[]> {
  try {
    const { data, error } = await query;
    if (error) {
      if (isStatementTimeout(error)) return [];
      throw new Error(error instanceof Error ? error.message : String((error as any)?.message ?? error));
    }
    return data ?? [];
  } catch (error) {
    if (isStatementTimeout(error)) return [];
    throw error;
  }
}

/**
 * Batched forecast computation that mirrors getBudgetFact file_gpm + revenue.
 * Returns Map<file_id, Map<currency, { gpm, rev }>> in native currency (signed).
 * gpm = sum of (booked+accrued+expected_rt+budgeted) across ALL cells.
 * rev = same but restricted to REVENUE-kind cells.
 */
async function computeForecastForFiles(
  supabase: any,
  fileIds: string[],
): Promise<Map<string, Map<string, { gpm: number; rev: number }>>> {
  const out = new Map<string, Map<string, { gpm: number; rev: number }>>();
  if (fileIds.length === 0) return out;


  const PP_CODES = new Set(["PURC", "RCTP"]);

  const [assignsRes, fflRes, rtRes, planRes, ctRes, mapRes] = await Promise.all([
    supabase
      .from("file_unit_assignments")
      .select("file_id,unit_no,unit_type,effective_date_from,effective_date_to")
      .in("file_id", fileIds)
      .eq("is_active", true),
    supabase
      .from("file_finance_lines")
      .select("file_id,unit_no,source_finance_id,source_type,source_code,article_id,amount,currency,invoice_no,invoice_date,dte_acct")
      .in("file_id", fileIds),
    supabase
      .from("file_rt_charges")
      .select("file_id,unit_no,charge_code,amount,currency")
      .in("file_id", fileIds),
    supabase
      .from("file_budget_plan_lines")
      .select("file_id,article_id,currency,total_amount,amount_per_unit,planned_qty,container_type")
      .in("file_id", fileIds),
    supabase
      .from("file_container_types")
      .select("file_id,container_type,planned_qty")
      .in("file_id", fileIds),
    supabase
      .from("cost_charge_type_mapping")
      .select("source_type,source_code,article_id"),
  ]);

  // Group assignments by file_id; collect all unit_nos
  const assignsByFile = new Map<string, any[]>();
  const allUnits = new Set<string>();
  for (const a of assignsRes.data ?? []) {
    const fid = (a as any).file_id;
    const list = assignsByFile.get(fid) ?? [];
    list.push(a);
    assignsByFile.set(fid, list);
    if ((a as any).unit_no) allUnits.add((a as any).unit_no);
  }

  // Ext finance lines: keyed by unit_no, fetch in batch
  type ExtRow = {
    id: string;
    unit_no: string;
    source_type: string | null;
    source_code: string | null;
    amount: number;
    currency: string | null;
    invoice_no: string | null;
    invoice_date: string | null;
    dte_acct: string | null;
  };
  const extByUnit = new Map<string, ExtRow[]>();
  if (allUnits.size > 0) {
    const { data: extRows } = await supabase
      .from("eqs_ext_finance_lines")
      .select("id,unit_no,source_type,source_code,amount,currency,invoice_no,invoice_date,dte_acct")
      .in("unit_no", Array.from(allUnits));
    for (const r of (extRows ?? []) as any[]) {
      const list = extByUnit.get(r.unit_no) ?? [];
      list.push(r);
      extByUnit.set(r.unit_no, list);
    }
  }

  // Mapping & article kinds
  const articleIds = new Set<string>();
  for (const m of mapRes.data ?? []) if ((m as any).article_id) articleIds.add((m as any).article_id);
  for (const p of planRes.data ?? []) if ((p as any).article_id) articleIds.add((p as any).article_id);
  for (const f of fflRes.data ?? []) if ((f as any).article_id) articleIds.add((f as any).article_id);
  const articleKind = new Map<string, string | null>();
  if (articleIds.size > 0) {
    const { data: aRows } = await supabase
      .from("budget_articles")
      .select("id,kind")
      .in("id", Array.from(articleIds));
    for (const a of (aRows ?? []) as any[]) articleKind.set(a.id, a.kind);
  }
  const mapping = new Map<string, string>();
  for (const m of (mapRes.data ?? []) as any[]) {
    mapping.set(`${m.source_type}::${m.source_code}`, m.article_id);
  }

  // Group fflin/rt/plan/ct by file
  const fflByFile = new Map<string, any[]>();
  for (const r of (fflRes.data ?? []) as any[]) {
    const list = fflByFile.get(r.file_id) ?? [];
    list.push(r);
    fflByFile.set(r.file_id, list);
  }
  const rtByFile = new Map<string, any[]>();
  for (const r of (rtRes.data ?? []) as any[]) {
    const list = rtByFile.get(r.file_id) ?? [];
    list.push(r);
    rtByFile.set(r.file_id, list);
  }
  const planByFile = new Map<string, any[]>();
  for (const r of (planRes.data ?? []) as any[]) {
    const list = planByFile.get(r.file_id) ?? [];
    list.push(r);
    planByFile.set(r.file_id, list);
  }
  const ctByFile = new Map<string, Map<string, number>>();
  for (const r of (ctRes.data ?? []) as any[]) {
    const m = ctByFile.get(r.file_id) ?? new Map<string, number>();
    m.set(r.container_type, Number(r.planned_qty) || 0);
    ctByFile.set(r.file_id, m);
  }

  // Per-file aggregation
  for (const fid of fileIds) {
    const assigns = assignsByFile.get(fid) ?? [];
    const ffl = fflByFile.get(fid) ?? [];
    const rt = rtByFile.get(fid) ?? [];
    const plan = planByFile.get(fid) ?? [];
    const qtyByType = ctByFile.get(fid) ?? new Map<string, number>();

    // Build effective intervals per unit for this file
    const unitIntervals = new Map<string, { from: string | null; to: string | null }[]>();
    const unitType = new Map<string, string | null>();
    for (const a of assigns) {
      if (!a.unit_no) continue;
      const list = unitIntervals.get(a.unit_no) ?? [];
      list.push({ from: a.effective_date_from, to: a.effective_date_to });
      unitIntervals.set(a.unit_no, list);
      if (!unitType.has(a.unit_no)) unitType.set(a.unit_no, a.unit_type ?? null);
    }
    const inInterval = (unit: string | null, dateStr: string | null) => {
      if (!unit) return true;
      const ivs = unitIntervals.get(unit);
      if (!ivs || ivs.length === 0) return false;
      if (!dateStr) return ivs.some((i) => !i.to);
      const d = dateStr.slice(0, 10);
      return ivs.some(
        (i) => (!i.from || d >= i.from) && (!i.to || d <= i.to),
      );
    };

    // (article_id|null, currency) cells: { booked, accrued, expected_rt }
    type Cell = {
      article_id: string | null;
      currency: string;
      booked: number;
      accrued: number;
      expected_rt: number;
      plan_per_unit: number;
      kind: string | null;
    };
    const cells = new Map<string, Cell>();
    const ck = (aid: string | null, cur: string) => `${aid ?? "_"}::${cur}`;
    const ensureCell = (aid: string | null, cur: string): Cell => {
      const k = ck(aid, cur);
      let c = cells.get(k);
      if (!c) {
        c = {
          article_id: aid,
          currency: cur,
          booked: 0,
          accrued: 0,
          expected_rt: 0,
          plan_per_unit: 0,
          kind: aid ? articleKind.get(aid) ?? null : null,
        };
        cells.set(k, c);
      }
      return c;
    };

    // 1) file_finance_lines
    const seenSourceIds = new Set<string>();
    for (const r of ffl) {
      if (r.source_finance_id) seenSourceIds.add(r.source_finance_id);
      const isPP = PP_CODES.has(String(r.source_code ?? ""));
      if (!isPP && !inInterval(r.unit_no, r.dte_acct ?? r.invoice_date)) continue;
      const cur = r.currency ?? "USD";
      const c = ensureCell(r.article_id ?? null, cur);
      const amt = Number(r.amount ?? 0);
      if (r.invoice_no) c.booked += amt;
      else c.accrued += amt;
    }

    // 2) ext finance lines for assigned units, mapped via cost_charge_type_mapping
    for (const u of unitIntervals.keys()) {
      for (const r of extByUnit.get(u) ?? []) {
        if (seenSourceIds.has(r.id)) continue;
        const isPP = PP_CODES.has(String(r.source_code ?? ""));
        if (!isPP && !inInterval(r.unit_no, r.dte_acct ?? r.invoice_date)) continue;
        const normType = _normalizeSourceType(r.source_type);
        const article_id = mapping.get(`${normType}::${r.source_code}`) ?? null;
        const cur = r.currency ?? "USD";
        const c = ensureCell(article_id, cur);
        const amt = Number(r.amount ?? 0);
        if (r.invoice_no) c.booked += amt;
        else c.accrued += amt;
      }
    }

    // 3) RT charges → expected revenue
    for (const r of rt) {
      const article_id = mapping.get(`ChargeType::${r.charge_code}`) ?? null;
      const cur = r.currency ?? "USD";
      const c = ensureCell(article_id, cur);
      c.expected_rt += Number(r.amount ?? 0);
    }

    // 4) Plan: capture plan_per_unit and budget per-unit/slot explosion
    // First record plan_per_unit per cell
    for (const p of plan) {
      const cur = p.currency ?? "USD";
      const c = ensureCell(p.article_id ?? null, cur);
      if (Number(p.amount_per_unit ?? 0) !== 0) c.plan_per_unit = Number(p.amount_per_unit);
    }

    // type → assigned units
    const typeUnits = new Map<string, string[]>();
    const seenTypeUnit = new Set<string>();
    for (const a of assigns) {
      if (!a.unit_no || !a.unit_type) continue;
      const k = `${a.unit_type}::${a.unit_no}`;
      if (seenTypeUnit.has(k)) continue;
      seenTypeUnit.add(k);
      const list = typeUnits.get(a.unit_type) ?? [];
      list.push(a.unit_no);
      typeUnits.set(a.unit_type, list);
    }

    // Per-unit executed (excluding budget)
    const execByUnitKey = new Map<string, number>(); // aid::cur::unit
    const execByArtCurNoUnit = new Map<string, number>(); // aid::cur (NULL unit)
    const addExec = (aid: string | null, cur: string, unit: string | null, amt: number) => {
      const a = aid ?? "_";
      if (unit) {
        const k = `${a}::${cur}::${unit}`;
        execByUnitKey.set(k, (execByUnitKey.get(k) ?? 0) + amt);
      } else {
        const k = `${a}::${cur}`;
        execByArtCurNoUnit.set(k, (execByArtCurNoUnit.get(k) ?? 0) + amt);
      }
    };
    for (const r of ffl) {
      const isPP = PP_CODES.has(String(r.source_code ?? ""));
      if (!isPP && !inInterval(r.unit_no, r.dte_acct ?? r.invoice_date)) continue;
      addExec(r.article_id ?? null, r.currency ?? "USD", r.unit_no ?? null, Number(r.amount ?? 0));
    }
    for (const u of unitIntervals.keys()) {
      for (const r of extByUnit.get(u) ?? []) {
        if (seenSourceIds.has(r.id)) continue;
        const isPP = PP_CODES.has(String(r.source_code ?? ""));
        if (!isPP && !inInterval(r.unit_no, r.dte_acct ?? r.invoice_date)) continue;
        const normType = _normalizeSourceType(r.source_type);
        const article_id = mapping.get(`${normType}::${r.source_code}`) ?? null;
        addExec(article_id, r.currency ?? "USD", r.unit_no ?? null, Number(r.amount ?? 0));
      }
    }
    for (const r of rt) {
      const article_id = mapping.get(`ChargeType::${r.charge_code}`) ?? null;
      addExec(article_id, r.currency ?? "USD", r.unit_no ?? null, Number(r.amount ?? 0));
    }

    // Budgeted per cell
    const budgetedByCell = new Map<string, number>();
    for (const p of plan) {
      const cur = p.currency ?? "USD";
      const aid: string | null = p.article_id ?? null;
      const kind = aid ? articleKind.get(aid) ?? null : null;
      const sign = kind === "COST" ? -1 : 1;
      const planPer = Number(p.amount_per_unit ?? 0);
      const planPerMag = Math.abs(planPer);
      if (planPer === 0 && !p.total_amount) continue;
      const k = ck(aid, cur);
      let bg = budgetedByCell.get(k) ?? 0;

      if (p.container_type) {
        const ct: string = p.container_type;
        const units = typeUnits.get(ct) ?? [];
        const planned = qtyByType.get(ct) ?? Number(p.planned_qty ?? 0);
        for (const u of units) {
          const exec = execByUnitKey.get(`${aid ?? "_"}::${cur}::${u}`) ?? 0;
          const remaining = planPerMag - Math.abs(exec);
          if (remaining <= 0.0001) continue;
          bg += remaining * sign;
        }
        const slots = Math.max(0, planned - units.length);
        bg += slots * planPerMag * sign;
      } else {
        const planTotal = Math.abs(Number(p.total_amount ?? planPer * Number(p.planned_qty ?? 0)));
        const exec = execByArtCurNoUnit.get(`${aid ?? "_"}::${cur}`) ?? 0;
        const remaining = planTotal - Math.abs(exec);
        if (remaining > 0.0001) bg += remaining * sign;
      }
      budgetedByCell.set(k, bg);
    }

    // Aggregate forecast = (booked + accrued + expected_rt) + budgeted
    // GPM mirrors detail page (getBudgetFact file_gpm): sum across ALL cells regardless of kind.
    // Revenue line tracks REVENUE-kind cells only.
    const byCur = new Map<string, { gpm: number; rev: number }>();
    for (const [k, c] of cells) {
      const executed = c.booked + c.accrued + c.expected_rt;
      const budgeted = budgetedByCell.get(k) ?? 0;
      const fcast = executed + budgeted;
      const bucket = byCur.get(c.currency) ?? { gpm: 0, rev: 0 };
      bucket.gpm += fcast;
      if (c.kind === "REVENUE") bucket.rev += fcast;
      byCur.set(c.currency, bucket);
    }
    // Budget-only cells (no exec, no cells entry)
    for (const [k, bg] of budgetedByCell) {
      if (cells.has(k)) continue;
      const [aid, cur] = k.split("::");
      const kind = aid !== "_" ? articleKind.get(aid) ?? null : null;
      const bucket = byCur.get(cur) ?? { gpm: 0, rev: 0 };
      bucket.gpm += bg;
      if (kind === "REVENUE") bucket.rev += bg;
      byCur.set(cur, bucket);
    }
    if (byCur.size > 0) out.set(fid, byCur);
  }


  return out;
}


export const listFiles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        status: z.enum(["DR", "OP", "RP", "RCL", "CL", "CN"]).optional(),
        q: z.string().max(120).optional(),
        originSubregion: z.string().max(20).optional(),
        destSubregion: z.string().max(20).optional(),
        include_cancelled: z.boolean().optional().default(false),
        op_date: z.string().optional(),
        department_id: z.string().uuid().optional(),
        container_type: z.string().max(20).optional(),
        hide_draft: z.boolean().optional().default(false),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    let qb = context.supabase
      .from("files")
      .select(
        "id,file_number,status,department_id,customer_accno,customer_name,origin_subregion,dest_subregion,origin_locn,dest_locn,planned_departure_date,planned_arrival_date,fx_rate_eur_usd,sales_manager_id,sales_person_id,created_at,departments(name,code),sales_manager:profiles!files_sales_manager_id_fkey(id,full_name,email),sales_person:sales_persons!files_sales_person_id_fkey(id,full_name)",
      )
      .order("created_at", { ascending: false })
      .limit(200);
    if (data.status) qb = qb.eq("status", data.status);
    else if (!data.include_cancelled) qb = qb.neq("status", "CN");
    if (data.hide_draft) qb = qb.neq("status", "DR");
    if (data.originSubregion) qb = qb.eq("origin_subregion", data.originSubregion);
    if (data.destSubregion) qb = qb.eq("dest_subregion", data.destSubregion);
    if (data.op_date) qb = qb.or(`status.eq.DR,op_date.gte.${data.op_date}`);
    if (data.department_id) qb = qb.eq("department_id", data.department_id);
    if (data.container_type) {
      const { data: fids } = await context.supabase
        .from("file_container_types")
        .select("file_id")
        .eq("container_type", data.container_type);
      const ids = Array.from(new Set((fids ?? []).map((r: any) => r.file_id)));
      if (ids.length === 0) return { items: [] };
      qb = qb.in("id", ids);
    }
    if (data.q && data.q.trim()) {
      const q = `%${data.q.trim()}%`;
      qb = qb.or(`file_number.ilike.${q},customer_name.ilike.${q},customer_accno.ilike.${q}`);
    }
    const { data: rows, error } = await qb;
    if (error) throw new Error(error.message);

    // Resolve subregion + locn descriptions in one batch
    const subIds = new Set<string>();
    const locIds = new Set<string>();
    for (const r of rows ?? []) {
      if ((r as any).origin_subregion) subIds.add((r as any).origin_subregion);
      if ((r as any).dest_subregion) subIds.add((r as any).dest_subregion);
      if ((r as any).origin_locn) locIds.add((r as any).origin_locn);
      if ((r as any).dest_locn) locIds.add((r as any).dest_locn);
    }
    const subDesc = new Map<string, string>();
    const locDesc = new Map<string, string>();
    if (subIds.size > 0 || locIds.size > 0) {
      const orFilter: string[] = [];
      if (subIds.size > 0) orFilter.push(`subregion_id.in.(${Array.from(subIds).join(",")})`);
      if (locIds.size > 0) orFilter.push(`locn_id.in.(${Array.from(locIds).join(",")})`);
      const { data: locs } = await context.supabase
        .from("eqs_ext_locations_subregions")
        .select("subregion_id,subregion_desc,locn_id,locn_desc")
        .or(orFilter.join(","));
      for (const l of (locs ?? []) as any[]) {
        if (l.subregion_id && !subDesc.has(l.subregion_id)) subDesc.set(l.subregion_id, l.subregion_desc ?? l.subregion_id);
        if (l.locn_id && !locDesc.has(l.locn_id)) locDesc.set(l.locn_id, l.locn_desc ?? l.locn_id);
      }
    }

    // Batch-load container types per file for badges in list view
    const idsAll = (rows ?? []).map((r: any) => r.id);
    const ctByFile = new Map<string, Array<{ container_type: string; grade: string | null; planned_qty: number; attached_qty: number }>>();
    const hasBookingByFile = new Set<string>();
    const attachedByFile = new Map<string, Map<string, number>>();
    if (idsAll.length > 0) {
      const [ctRes, bkRes, uaRes] = await Promise.all([
        context.supabase
          .from("file_container_types")
          .select("file_id,container_type,grade,planned_qty")
          .in("file_id", idsAll)
          .order("container_type", { ascending: true }),
        context.supabase
          .from("file_booking_assignments")
          .select("file_id")
          .in("file_id", idsAll)
          .eq("is_active", true),
        context.supabase
          .from("file_unit_assignments")
          .select("file_id,unit_type,grade")
          .in("file_id", idsAll)
          .eq("is_active", true),
      ]);
      for (const b of ((bkRes as any).data ?? []) as any[]) {
        if (b.file_id) hasBookingByFile.add(b.file_id);
      }
      for (const u of ((uaRes as any).data ?? []) as any[]) {
        if (!u.file_id || !u.unit_type) continue;
        const m = attachedByFile.get(u.file_id) ?? new Map<string, number>();
        const wildKey = `${u.unit_type}|*`;
        m.set(wildKey, (m.get(wildKey) ?? 0) + 1);
        const exactKey = `${u.unit_type}|${u.grade ?? ""}`;
        m.set(exactKey, (m.get(exactKey) ?? 0) + 1);
        attachedByFile.set(u.file_id, m);
      }
      for (const c of (((ctRes as any).data ?? []) as any[])) {
        const arr = ctByFile.get(c.file_id) ?? [];
        const m = attachedByFile.get(c.file_id);
        const attached = c.grade
          ? m?.get(`${c.container_type}|${c.grade}`) ?? 0
          : m?.get(`${c.container_type}|*`) ?? 0;
        arr.push({
          container_type: c.container_type,
          grade: c.grade ?? null,
          planned_qty: c.planned_qty ?? 0,
          attached_qty: attached,
        });
        ctByFile.set(c.file_id, arr);
      }
    }


    // Forecast = sum of Budget Fact "forecast" column (executed signed + budgeted signed),
    // using the same rules as getBudgetFact: per-unit explosion, ext finance lines,
    // extra (unplanned) articles, RT charges, and active-only assignments.
    const ids = (rows ?? []).map((r: any) => r.id);
    type ForecastBucket = { rev_usd: number; gpm_usd: number; rev_eur: number; gpm_eur: number };
    const forecast = new Map<string, ForecastBucket>();
    if (ids.length > 0) {
      const fxByFile = new Map<string, number>();
      for (const r of rows ?? []) fxByFile.set((r as any).id, Number((r as any).fx_rate_eur_usd) || 1);
      const perFile = await computeForecastForFiles(context.supabase, ids);
      for (const [fid, byCur] of perFile) {
        const fx = fxByFile.get(fid) ?? 1;
        const b: ForecastBucket = { rev_usd: 0, gpm_usd: 0, rev_eur: 0, gpm_eur: 0 };
        for (const [cur, v] of byCur) {
          const usdRev = cur === "EUR" ? v.rev * fx : v.rev;
          const usdGpm = cur === "EUR" ? v.gpm * fx : v.gpm;
          b.rev_usd += usdRev;
          b.gpm_usd += usdGpm;
          b.rev_eur += fx ? usdRev / fx : 0;
          b.gpm_eur += fx ? usdGpm / fx : 0;
        }
        forecast.set(fid, b);
      }
    }
    const items = (rows ?? []).map((r: any) => {
      const t = forecast.get(r.id) ?? { rev_usd: 0, gpm_usd: 0, rev_eur: 0, gpm_eur: 0 };
      return {
        ...r,
        origin_subregion_desc: r.origin_subregion ? subDesc.get(r.origin_subregion) ?? null : null,
        dest_subregion_desc: r.dest_subregion ? subDesc.get(r.dest_subregion) ?? null : null,
        origin_locn_desc: r.origin_locn ? locDesc.get(r.origin_locn) ?? null : null,
        dest_locn_desc: r.dest_locn ? locDesc.get(r.dest_locn) ?? null : null,
        revenue_usd: t.rev_usd,
        cost_usd: t.gpm_usd - t.rev_usd,
        gpm_usd: t.gpm_usd,
        revenue_eur: t.rev_eur,
        cost_eur: t.gpm_eur - t.rev_eur,
        gpm_eur: t.gpm_eur,
        container_types: ctByFile.get(r.id) ?? [],
        has_booking: hasBookingByFile.has(r.id),
        sm_name:
          r.sales_manager?.full_name ??
          r.sales_manager?.email ??
          r.sales_person?.full_name ??
          null,
        dept_code: r.departments?.code ?? null,
      };
    });

    return { items };
  });

// Distinct origin/destination subregion options for filters (built from ALL files, not filtered).
export const getFilesFilterOptions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: rows } = await context.supabase
      .from("files")
      .select("origin_subregion,dest_subregion,department_id,departments(id,code,name)")
      .limit(5000);
    const oSet = new Set<string>();
    const dSet = new Set<string>();
    const deptMap = new Map<string, string>(); // id -> label
    for (const r of (rows ?? []) as any[]) {
      if (r.origin_subregion) oSet.add(r.origin_subregion);
      if (r.dest_subregion) dSet.add(r.dest_subregion);
      if (r.department_id && !deptMap.has(r.department_id)) {
        const code = r.departments?.code ?? "—";
        const name = r.departments?.name ?? "";
        deptMap.set(r.department_id, name ? `${code} — ${name}` : code);
      }
    }
    const all = Array.from(new Set([...oSet, ...dSet]));
    const descMap = new Map<string, string>();
    if (all.length > 0) {
      const { data: locs } = await context.supabase
        .from("eqs_ext_locations_subregions")
        .select("subregion_id,subregion_desc")
        .in("subregion_id", all);
      for (const l of (locs ?? []) as any[]) {
        if (!descMap.has(l.subregion_id)) descMap.set(l.subregion_id, l.subregion_desc ?? l.subregion_id);
      }
    }
    const toOpts = (set: Set<string>) =>
      Array.from(set)
        .map((id) => ({ id, label: descMap.get(id) ?? id }))
        .sort((a, b) => a.label.localeCompare(b.label));
    const departmentOptions = Array.from(deptMap.entries())
      .map(([id, label]) => ({ id, label }))
      .sort((a, b) => a.label.localeCompare(b.label));
    const { data: ctRows } = await context.supabase
      .from("file_container_types")
      .select("container_type")
      .limit(10000);
    const ctSet = new Set<string>();
    for (const r of (ctRows ?? []) as any[]) {
      if (r.container_type) ctSet.add(r.container_type);
    }
    const containerTypeOptions = Array.from(ctSet)
      .sort()
      .map((id) => ({ id, label: id }));
    return {
      originOptions: toOpts(oSet),
      destOptions: toOpts(dSet),
      departmentOptions,
      containerTypeOptions,
    };
  });


export const getFile = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { data: file, error } = await context.supabase
      .from("files")
      .select(
        "id,file_number,status,budget_unlocked,department_id,customer_accno,customer_name,lessee_order,origin_country_code,dest_country_code,origin_subregion,dest_subregion,origin_locn,dest_locn,planned_departure_date,planned_arrival_date,business_date,fx_rate_eur_usd,sales_manager_id,sales_person_id,notes,opened_at,closed_at,op_date,rp_date,rcl_date,cl_date,cn_date,created_at,eqs_booking_state,eqs_booking_id,eqs_booking_error,eqs_booking_sent_at,eqs_booking_received_at,departments(id,name,code),sales_manager:profiles!files_sales_manager_id_fkey(id,full_name,email),sales_person:sales_persons!files_sales_person_id_fkey(id,full_name,department:departments(id,name,code))",
      )
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!file) throw new Error("Not found");
    const { data: lines } = await context.supabase
      .from("file_budget_plan_lines")
      .select(
        "id,article_id,currency,container_type,planned_qty,amount_per_unit,total_amount,amount_usd,amount_eur,source_type,notes,budget_articles(code,name,kind)",
      )
      .eq("file_id", data.id)
      .order("created_at", { ascending: true });
    const { data: cts } = await context.supabase
      .from("file_container_types")
      .select(
        "id,container_type,planned_qty,grade,daily_rate,repl_value,free_min_days,charge1_code,charge1_amount,charge2_code,charge2_amount,charge3_code,charge3_amount,charge4_code,charge4_amount,cost1_code,cost1_currency,cost1_amount,cost1_supplier_accno,cost2_code,cost2_currency,cost2_amount,cost2_supplier_accno",
      )
      .eq("file_id", data.id)
      .order("container_type", { ascending: true });
    const { count: unitsCount } = await context.supabase
      .from("file_unit_assignments")
      .select("id", { count: "exact", head: true })
      .eq("file_id", data.id)
      .eq("is_active", true);

    const locIds = [file.origin_locn, file.dest_locn].filter(
      (v): v is string => !!v,
    );
    let origin_locn_desc: string | null = null;
    let dest_locn_desc: string | null = null;
    if (locIds.length > 0) {
      const { data: locs } = await context.supabase
        .from("eqs_ext_locations_subregions")
        .select("locn_id,locn_desc")
        .in("locn_id", locIds);
      const m = new Map<string, string>();
      for (const l of locs ?? []) {
        if (l.locn_id) m.set(l.locn_id, l.locn_desc ?? l.locn_id);
      }
      origin_locn_desc = file.origin_locn ? m.get(file.origin_locn) ?? null : null;
      dest_locn_desc = file.dest_locn ? m.get(file.dest_locn) ?? null : null;
    }

    return {
      file: { ...file, origin_locn_desc, dest_locn_desc },
      budgetLines: lines ?? [],
      containerTypes: cts ?? [],
      unitsCount: unitsCount ?? 0,
    };
  });

export const createFile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        department_id: z.string().uuid(),
        customer_accno: z.string().max(40).optional().nullable(),
        customer_name: z.string().max(255).optional().nullable(),
        lessee_order: z.string().max(120).optional().nullable(),
        origin_country_code: z.string().max(8).optional().nullable(),
        dest_country_code: z.string().max(8).optional().nullable(),
        origin_subregion: z.string().max(20).optional().nullable(),
        dest_subregion: z.string().max(20).optional().nullable(),
        origin_locn: z.string().max(20).optional().nullable(),
        dest_locn: z.string().max(20).optional().nullable(),
        planned_departure_date: z.string().optional().nullable(),
        planned_arrival_date: z.string().optional().nullable(),
        business_date: z.string().optional().nullable(),
        sales_person_id: z.string().uuid().optional().nullable(),
        container_types: z
          .array(
            z.object({
              container_type: z.string().min(1).max(20),
              planned_qty: z.number().int().min(1).max(9999),
              grade: z.string().max(40).nullable().optional(),
              daily_rate: z.number().nullable().optional(),
              repl_value: z.number().nullable().optional(),
              free_min_days: z.number().int().nullable().optional(),
              charge1_code: z.string().max(40).nullable().optional(),
              charge1_amount: z.number().nullable().optional(),
              charge2_code: z.string().max(40).nullable().optional(),
              charge2_amount: z.number().nullable().optional(),
              charge3_code: z.string().max(40).nullable().optional(),
              charge3_amount: z.number().nullable().optional(),
              charge4_code: z.string().max(40).nullable().optional(),
              charge4_amount: z.number().nullable().optional(),
              cost1_code: z.string().max(40).nullable().optional(),
              cost1_currency: z.string().max(8).nullable().optional(),
              cost1_amount: z.number().nullable().optional(),
              cost1_supplier_accno: z.string().max(40).nullable().optional(),
              cost2_code: z.string().max(40).nullable().optional(),
              cost2_currency: z.string().max(8).nullable().optional(),
              cost2_amount: z.number().nullable().optional(),
              cost2_supplier_accno: z.string().max(40).nullable().optional(),
            }),
          )
          .max(20)
          .optional(),
        notes: z.string().max(2000).optional().nullable(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: id, error } = await context.supabase.rpc("fn_create_file", {
      p_department_id: data.department_id,
      p_direction: "EXPORT",
      p_customer_accno: data.customer_accno ?? undefined,
      p_customer_name: data.customer_name ?? undefined,
      p_origin_subregion: data.origin_subregion ?? undefined,
      p_dest_subregion: data.dest_subregion ?? undefined,
      p_origin_locn: data.origin_locn ?? undefined,
      p_dest_locn: data.dest_locn ?? undefined,
      p_planned_departure_date: data.planned_departure_date || undefined,
      p_planned_arrival_date: data.planned_arrival_date || undefined,
      p_notes: data.notes ?? undefined,
    });
    if (error) throw new Error(error.message);
    const fileId = id as unknown as string;

    const patch: {
      sales_person_id?: string;
      business_date?: string;
      origin_country_code?: string;
      dest_country_code?: string;
      lessee_order?: string | null;
    } = {};
    if (data.sales_person_id) patch.sales_person_id = data.sales_person_id;
    if (data.business_date) patch.business_date = data.business_date;
    if (data.origin_country_code) patch.origin_country_code = data.origin_country_code;
    if (data.dest_country_code) patch.dest_country_code = data.dest_country_code;
    if (data.lessee_order !== undefined) patch.lessee_order = data.lessee_order;
    if (Object.keys(patch).length > 0) {
      const { error: upErr } = await context.supabase
        .from("files")
        .update(patch)
        .eq("id", fileId);
      if (upErr) throw new Error(upErr.message);
    }

    if (data.container_types && data.container_types.length) {
      const rows = data.container_types.map((ct) => ({
        file_id: fileId,
        ...ct,
      }));
      const { error: ctErr } = await context.supabase
        .from("file_container_types")
        .insert(rows as never);
      if (ctErr) throw new Error(ctErr.message);
    }

    return { id: fileId };
  });

export const changeFileDepartment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid(),
        department_id: z.string().uuid(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: newNum, error } = await context.supabase.rpc(
      "fn_change_file_department",
      { p_file_id: data.id, p_new_department_id: data.department_id },
    );
    if (error) throw new Error(error.message);
    return { file_number: newNum as unknown as string };
  });

export const listSalesManagers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("profiles")
      .select("id,full_name,email")
      .order("full_name", { ascending: true });
    if (error) throw new Error(error.message);
    return { items: data ?? [] };
  });

const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);

export const openFile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ id: z.string().uuid(), status_date: dateStr.optional() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase.rpc("fn_open_file", {
      p_file_id: data.id,
      p_status_date: data.status_date ?? undefined,
    } as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const closeFile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ id: z.string().uuid(), notes: z.string().max(500).optional(), status_date: dateStr.optional() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase.rpc("fn_close_file", {
      p_file_id: data.id,
      p_notes: data.notes ?? undefined,
      p_status_date: data.status_date ?? undefined,
    } as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const confirmRp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ id: z.string().uuid(), notes: z.string().max(500).optional(), status_date: dateStr.optional() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase.rpc("fn_confirm_rp", {
      p_file_id: data.id,
      p_notes: data.notes ?? undefined,
      p_status_date: data.status_date ?? undefined,
    } as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setReadyForCl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ id: z.string().uuid(), notes: z.string().max(500).optional(), status_date: dateStr.optional() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase.rpc("fn_set_ready_for_cl", {
      p_file_id: data.id,
      p_notes: data.notes ?? undefined,
      p_status_date: data.status_date ?? undefined,
    } as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const cancelFile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ id: z.string().uuid(), reason: z.string().max(500).optional(), status_date: dateStr.optional() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase.rpc("fn_cancel_file", {
      p_file_id: data.id,
      p_reason: data.reason ?? undefined,
      p_status_date: data.status_date ?? undefined,
    } as any);
    if (error) throw new Error(error.message);

    // Auto-unlink all active unit assignments on this file
    const { data: active } = await context.supabase
      .from("file_unit_assignments")
      .select("unit_no")
      .eq("file_id", data.id)
      .eq("is_active", true);
    const units = ((active ?? []) as { unit_no: string }[]).map((r) => r.unit_no);

    if (units.length) {
      const { error: uErr } = await context.supabase
        .from("file_unit_assignments")
        .update({
          is_active: false,
          unlinked_at: new Date().toISOString(),
          effective_date_to: new Date().toISOString().slice(0, 10),
        })
        .eq("file_id", data.id)
        .eq("is_active", true);
      if (uErr) throw new Error(uErr.message);

      await context.supabase.from("file_unit_assignment_history").insert(
        units.map((u) => ({ file_id: data.id, unit_no: u, action: "unlinked" })),
      );

      // Drop synthetic per-unit fact rows (e.g. planned container purchases)
      // for the cancelled units; aggregate fact rows (unit_no IS NULL) are kept.
      await context.supabase
        .from("file_budget_fact_lines")
        .delete()
        .eq("file_id", data.id)
        .in("unit_no", units);


      await Promise.all([
        context.supabase.rpc("fn_refresh_file_finance_lines", { p_file_id: data.id }),
        recomputeAllAssignmentsEffectiveTo(context.supabase, data.id),
      ]);
    }

    return { ok: true };
  });

export const setFileStatusDates = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      id: z.string().uuid(),
      op_date: dateStr.nullable().optional(),
      rp_date: dateStr.nullable().optional(),
      rcl_date: dateStr.nullable().optional(),
      cl_date: dateStr.nullable().optional(),
      cn_date: dateStr.nullable().optional(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase.rpc("fn_set_file_status_dates", {
      p_file_id: data.id,
      p_op: data.op_date ?? undefined,
      p_rp: data.rp_date ?? undefined,
      p_rcl: data.rcl_date ?? undefined,
      p_cl: data.cl_date ?? undefined,
      p_cn: data.cn_date ?? undefined,
    } as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const revertFileStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ id: z.string().uuid(), notes: z.string().max(500).optional() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: newStatus, error } = await context.supabase.rpc("fn_revert_file_status", {
      p_file_id: data.id,
      p_notes: data.notes ?? undefined,
    });
    if (error) throw new Error(error.message);
    return { ok: true, new_status: newStatus as string };
  });


export const getFileStatusHistory = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { data: rows, error } = await context.supabase
      .from("file_status_history")
      .select("id,from_status,to_status,notes,changed_by,changed_at")
      .eq("file_id", data.id)
      .order("changed_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { items: rows ?? [] };
  });

export const getFileEvents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const [statusRes, unitRes, auditRes] = await Promise.all([
      context.supabase
        .from("file_status_history")
        .select("id,from_status,to_status,notes,changed_by,changed_at")
        .eq("file_id", data.id),
      context.supabase
        .from("file_unit_assignment_history")
        .select("id,unit_no,action,acted_by,acted_at")
        .eq("file_id", data.id),
      context.supabase
        .from("file_audit_log")
        .select("id,action,details,actor_id,created_at")
        .eq("file_id", data.id),
    ]);
    if (statusRes.error) throw new Error(statusRes.error.message);
    if (unitRes.error) throw new Error(unitRes.error.message);
    if (auditRes.error) throw new Error(auditRes.error.message);

    const events: any[] = [];
    for (const r of statusRes.data ?? []) {
      events.push({
        id: r.id,
        type: "status",
        at: r.changed_at,
        from_status: r.from_status,
        to_status: r.to_status,
        notes: r.notes,
        actor_id: r.changed_by,
      });
    }
    for (const r of unitRes.data ?? []) {
      events.push({
        id: r.id,
        type: r.action === "unlinked" ? "unit_unlinked" : "unit_assigned",
        at: r.acted_at,
        unit_no: r.unit_no,
        actor_id: r.acted_by,
      });
    }
    for (const r of auditRes.data ?? []) {
      const d = (r.details ?? {}) as any;
      events.push({
        id: r.id,
        type: r.action ?? "audit",
        at: r.created_at,
        actor_id: r.actor_id,
        changes: d.changes ?? null,
        after_rp: !!d.after_rp,
        status_at_change: d.status_at_change ?? null,
      });
    }

    const actorIds = Array.from(
      new Set(events.map((e) => e.actor_id).filter((x): x is string => !!x)),
    );
    const actors = new Map<string, { full_name: string | null; email: string | null }>();
    if (actorIds.length > 0) {
      const { data: profs } = await context.supabase
        .from("profiles")
        .select("id,full_name,email")
        .in("id", actorIds);
      for (const p of profs ?? []) actors.set(p.id, { full_name: p.full_name, email: p.email });
    }
    for (const e of events) {
      const a = e.actor_id ? actors.get(e.actor_id) : undefined;
      e.actor_name = a?.full_name ?? a?.email ?? null;
    }

    events.sort((a, b) => (b.at ?? "").localeCompare(a.at ?? ""));
    return { items: events };
  });


export const getFileWarnings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { data: rows, error } = await context.supabase
      .from("file_warnings")
      .select("*")
      .eq("file_id", data.id)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { items: rows ?? [] };
  });

async function recomputeUnitWarnings(supabase: any, fileId: string) {
  await supabase
    .from("file_warnings")
    .delete()
    .eq("file_id", fileId)
    .in("code", ["UNIT_ORIGIN_MISMATCH", "UNIT_TYPE_MISMATCH"]);

  const { data: file } = await supabase
    .from("files")
    .select("origin_locn,origin_country_code")
    .eq("id", fileId)
    .maybeSingle();

  const { data: ct } = await supabase
    .from("file_container_types")
    .select("container_type")
    .eq("file_id", fileId);
  const types = new Set((ct ?? []).map((r: any) => r.container_type));

  const { data: units } = await supabase
    .from("file_unit_assignments")
    .select("unit_no,booking_no,locn_pol,unit_type")
    .eq("file_id", fileId)
    .eq("is_active", true);

  const codes = Array.from(
    new Set(
      [file?.origin_locn, ...((units ?? []).map((u: any) => u.locn_pol))].filter(
        (c: any): c is string => !!c,
      ),
    ),
  );
  const cc: Record<string, string> = {};
  if (codes.length) {
    const { data: locs } = await supabase
      .from("eqs_ext_locations_subregions")
      .select("locn_id,country_code")
      .in("locn_id", codes);
    for (const l of locs ?? []) {
      if (l.locn_id && l.country_code) cc[l.locn_id] = l.country_code;
    }
  }
  const fileCountry =
    file?.origin_country_code ?? (file?.origin_locn ? cc[file.origin_locn] ?? null : null);

  const warnings: any[] = [];
  for (const u of units ?? []) {
    if (u.locn_pol && file?.origin_locn && u.locn_pol !== file.origin_locn) {
      const polCountry = cc[u.locn_pol] ?? null;
      const matchByCountry = !!fileCountry && !!polCountry && polCountry === fileCountry;
      if (!matchByCountry) {
        warnings.push({
          file_id: fileId,
          severity: "warning",
          code: "UNIT_ORIGIN_MISMATCH",
          message: `Unit ${u.unit_no} booked from ${u.locn_pol} does not match file origin ${file.origin_locn} (booking ${u.booking_no ?? "-"})`,
        });
      }
    }
    if (u.unit_type && types.size > 0 && !types.has(u.unit_type)) {
      warnings.push({
        file_id: fileId,
        severity: "warning",
        code: "UNIT_TYPE_MISMATCH",
        message: `Unit ${u.unit_no} type ${u.unit_type} does not match any container type declared in file`,
      });
    }
  }
  if (warnings.length) {
    await supabase.from("file_warnings").insert(warnings);
  }
}


/**
 * Recompute effective_date_to for a single (file, unit) using the latest
 * "active" sale invoice from eqs_ext_finance_lines.
 *
 * "Active" = sale invoice whose Σ amount > Σ |compensating credit notes|
 * (matched by original_inv_no). Spec calls for InvDtl.DteRel; the imported
 * CSVs do not carry that column, so we fall back to invoice_date — which the
 * data-model spec explicitly allows.
 *
 * Also fills effective_from_source for rows where it is null:
 *   - 'onhire' if effective_date_from = onhire_date
 *   - 'manual' otherwise
 */
async function recomputeUnitEffectiveTo(
  supabase: any,
  fileId: string,
  unitNo: string,
) {
  const { data: lines } = await supabase
    .from("eqs_ext_finance_lines")
    .select("source_area,source_code,invoice_no,invoice_date,amount,original_inv_no")
    .eq("unit_no", unitNo)
    .in("source_area", ["sale", "credit_note"]);

  type InvAgg = { date: string | null; sale: number; credit: number };
  const byInv = new Map<string, InvAgg>();
  for (const l of (lines ?? []) as any[]) {
    if (l.source_code === "Sale" && l.invoice_no) {
      const r = byInv.get(l.invoice_no) ?? { date: null, sale: 0, credit: 0 };
      const d = l.invoice_date ? String(l.invoice_date).slice(0, 10) : null;
      if (d && (!r.date || d > r.date)) r.date = d;
      r.sale += Number(l.amount ?? 0);
      byInv.set(l.invoice_no, r);
    } else if (l.source_code === "SaleCredit" && l.original_inv_no) {
      const r = byInv.get(l.original_inv_no) ?? { date: null, sale: 0, credit: 0 };
      r.credit += Math.abs(Number(l.amount ?? 0));
      byInv.set(l.original_inv_no, r);
    }
  }

  let latest: string | null = null;
  for (const [, v] of byInv) {
    if (v.sale - v.credit <= 0.0001) continue;
    if (v.date && (!latest || v.date > latest)) latest = v.date;
  }

  const { data: rows } = await supabase
    .from("file_unit_assignments")
    .select("id,onhire_date,effective_date_from,effective_from_source")
    .eq("file_id", fileId)
    .eq("unit_no", unitNo)
    .eq("is_active", true);

  for (const r of (rows ?? []) as any[]) {
    const fromSrc =
      r.effective_from_source ??
      (r.onhire_date && r.effective_date_from === r.onhire_date ? "onhire" : "manual");
    await supabase
      .from("file_unit_assignments")
      .update({
        effective_date_to: latest,
        effective_to_source: latest ? "sale_invoice_date" : null,
        effective_from_source: fromSrc,
      })
      .eq("id", r.id);
  }
}

async function recomputeAllAssignmentsEffectiveTo(supabase: any, fileId: string) {
  const { data: assigns } = await supabase
    .from("file_unit_assignments")
    .select("id,unit_no,onhire_date,effective_date_from,effective_from_source")
    .eq("file_id", fileId)
    .eq("is_active", true);
  const rows = (assigns ?? []) as any[];
  if (rows.length === 0) return;

  const unitNos = Array.from(new Set(rows.map((r) => r.unit_no).filter(Boolean)));
  if (unitNos.length === 0) return;

  const { data: lines } = await supabase
    .from("eqs_ext_finance_lines")
    .select("unit_no,source_area,source_code,invoice_no,invoice_date,amount,original_inv_no")
    .in("unit_no", unitNos)
    .in("source_area", ["sale", "credit_note"]);

  type InvAgg = { date: string | null; sale: number; credit: number };
  const byUnit = new Map<string, Map<string, InvAgg>>();
  for (const l of (lines ?? []) as any[]) {
    const u = l.unit_no as string;
    if (!u) continue;
    let inv = byUnit.get(u);
    if (!inv) { inv = new Map(); byUnit.set(u, inv); }
    if (l.source_code === "Sale" && l.invoice_no) {
      const r = inv.get(l.invoice_no) ?? { date: null, sale: 0, credit: 0 };
      const d = l.invoice_date ? String(l.invoice_date).slice(0, 10) : null;
      if (d && (!r.date || d > r.date)) r.date = d;
      r.sale += Number(l.amount ?? 0);
      inv.set(l.invoice_no, r);
    } else if (l.source_code === "SaleCredit" && l.original_inv_no) {
      const r = inv.get(l.original_inv_no) ?? { date: null, sale: 0, credit: 0 };
      r.credit += Math.abs(Number(l.amount ?? 0));
      inv.set(l.original_inv_no, r);
    }
  }

  const latestByUnit = new Map<string, string | null>();
  for (const [u, inv] of byUnit) {
    let latest: string | null = null;
    for (const [, v] of inv) {
      if (v.sale - v.credit <= 0.0001) continue;
      if (v.date && (!latest || v.date > latest)) latest = v.date;
    }
    latestByUnit.set(u, latest);
  }

  await Promise.all(rows.map((r) => {
    const latest = latestByUnit.get(r.unit_no) ?? null;
    const fromSrc =
      r.effective_from_source ??
      (r.onhire_date && r.effective_date_from === r.onhire_date ? "onhire" : "manual");
    return supabase
      .from("file_unit_assignments")
      .update({
        effective_date_to: latest,
        effective_to_source: latest ? "sale_invoice_date" : null,
        effective_from_source: fromSrc,
      })
      .eq("id", r.id);
  }));
}


export const listFileUnitAssignments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    // effective_date_to is maintained by mutation paths (assign/unlink/refresh).
    const { data: rows, error } = await context.supabase
      .from("file_unit_assignments")
      .select("id,unit_no,booking_no,onhire_date,locn_pol,locn_pod,unit_type,grade,is_active,assigned_at,unlinked_at,effective_date_from,effective_date_to,effective_from_source,effective_to_source")
      .eq("file_id", data.id)
      .order("assigned_at", { ascending: false });
    if (error) throw new Error(error.message);
    // Purchase price: prefer latest PURC/RCTP from eqs_ext_finance_lines (per unit),
    // fallback to eqs_ext_units.amt_ppb when no such finance line exists.
    const unitNos = Array.from(new Set((rows ?? []).map((r: any) => r.unit_no).filter(Boolean)));
    const ppMap = new Map<string, number | null>();
    if (unitNos.length > 0) {
      const [extFinRes, extURes] = await Promise.all([
        context.supabase
          .from("eqs_ext_finance_lines")
          .select("unit_no,amount,dte_acct,invoice_date,source_code")
          .in("unit_no", unitNos)
          .in("source_code", ["PURC", "RCTP"]),
        context.supabase
          .from("eqs_ext_units")
          .select("unit_no,amt_ppb")
          .in("unit_no", unitNos),
      ]);
      // Latest PURC/RCTP per unit
      const latest = new Map<string, { date: string; amount: number }>();
      for (const r of extFinRes.data ?? []) {
        const u = (r as any).unit_no as string;
        const d = ((r as any).dte_acct ?? (r as any).invoice_date ?? "") as string;
        const cur = latest.get(u);
        if (!cur || d > cur.date) latest.set(u, { date: d, amount: Math.abs(Number((r as any).amount ?? 0)) });
      }
      for (const u of unitNos) {
        if (latest.has(u)) ppMap.set(u, latest.get(u)!.amount);
      }
      for (const u of extURes.data ?? []) {
        if (!ppMap.has((u as any).unit_no)) {
          const v = (u as any).amt_ppb;
          ppMap.set((u as any).unit_no, v != null ? Number(v) : null);
        }
      }
    }
    const items = (rows ?? []).map((r: any) => ({ ...r, amt_ppb: ppMap.get(r.unit_no) ?? null }));
    return { items };
  });

export const searchRecentUnits = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        file_id: z.string().uuid(),
        q: z.string().max(64).optional(),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    const { data: file } = await context.supabase
      .from("files")
      .select("origin_locn,origin_country_code")
      .eq("id", data.file_id)
      .maybeSingle();
    const origin = file?.origin_locn ?? null;
    const originCountry = file?.origin_country_code ?? null;

    const ctRows = await queryDataOrEmpty<{ container_type: string | null }>(context.supabase
      .from("file_container_types")
      .select("container_type")
      .eq("file_id", data.file_id));
    const fileTypes = new Set((ctRows ?? []).map((r) => r.container_type));

    // Limit the scan to the last ~180 days so the (onhire_date DESC) index
    // returns a small, bounded range even under concurrent bulk inserts into
    // eqs_ext_recent_units. Avoids occasional 8s statement_timeout.
    const sinceIso = new Date(Date.now() - 180 * 24 * 60 * 60 * 1000)
      .toISOString()
      .slice(0, 10);
    let qb = context.supabase
      .from("eqs_ext_recent_units")
      .select("unit_no,booking_no,onhire_date,locn_pol,locn_pod,do_locn")
      .gte("onhire_date", sinceIso)
      .order("onhire_date", { ascending: false })
      .limit(200);


    const term = (data.q ?? "").trim();
    if (term) {
      const safe = term.replace(/[,()]/g, "");
      if (safe) {
        const like = `%${safe}%`;
        qb = qb.or(
          `unit_no.ilike.${like},booking_no.ilike.${like},locn_pol.ilike.${like},locn_pod.ilike.${like}`,
        );
      }
    }

    // Retry on statement_timeout: the recent_units table is periodically
    // rewritten by the SFTP sync (TRUNCATE + bulk INSERT) which can briefly
    // block reads. Back off across the typical sync window (~2-3s).
    let rows: any[] = [];
    let lastErr: unknown = null;
    const delays = [0, 600, 1500, 3000];
    for (const d of delays) {
      if (d) await new Promise((r) => setTimeout(r, d));
      try {
        const res = await qb;
        if (!res.error) { rows = (res.data ?? []) as any[]; lastErr = null; break; }
        lastErr = res.error;
        if (!isStatementTimeout(res.error)) break;
      } catch (error) {
        lastErr = error;
        if (!isStatementTimeout(error)) break;
      }
    }
    // On persistent timeout, degrade gracefully to an empty list instead of 500.
    if (lastErr && !isStatementTimeout(lastErr)) {
      throw new Error(lastErr instanceof Error ? lastErr.message : String((lastErr as any)?.message ?? lastErr));
    }
    if (lastErr) rows = [];



    const assigned = await queryDataOrEmpty<{ unit_no: string | null }>(context.supabase
      .from("file_unit_assignments")
      .select("unit_no")
      .eq("file_id", data.file_id)
      .eq("is_active", true));
    const assignedSet = new Set((assigned ?? []).map((r) => r.unit_no));

    const filtered = (rows ?? []).filter((r) => !assignedSet.has(r.unit_no));

    // Lookup iso_code for these units
    const unitNos = Array.from(new Set(filtered.map((r) => r.unit_no)));
    const isoMap: Record<string, string> = {};
    if (unitNos.length) {
      const us = await queryDataOrEmpty<{ unit_no: string | null; iso_code: string | null }>(context.supabase
        .from("eqs_ext_units")
        .select("unit_no,iso_code")
        .in("unit_no", unitNos));
      for (const u of us ?? []) {
        if (u.unit_no && u.iso_code) isoMap[u.unit_no] = u.iso_code;
      }
    }

    // Lookup location names + country codes
    const codes = Array.from(
      new Set(
        filtered
          .flatMap((r) => [r.locn_pol, r.locn_pod, r.do_locn, origin])
          .filter((c): c is string => !!c),
      ),
    );
    const nameMap: Record<string, string> = {};
    const countryMap: Record<string, string> = {};
    if (codes.length > 0) {
      const locs = await queryDataOrEmpty<{ locn_id: string | null; locn_desc: string | null; country_code: string | null }>(context.supabase
        .from("eqs_ext_locations_subregions")
        .select("locn_id,locn_desc,country_code")
        .in("locn_id", codes));
      for (const l of locs ?? []) {
        if (l.locn_id && l.locn_desc) nameMap[l.locn_id] = l.locn_desc;
        if (l.locn_id && l.country_code) countryMap[l.locn_id] = l.country_code;
      }
    }

    const fileCountry = originCountry ?? (origin ? countryMap[origin] ?? null : null);

    const items = filtered.map((r) => {
      const iso = isoMap[r.unit_no] ?? null;
      const polCountry = r.locn_pol ? countryMap[r.locn_pol] ?? null : null;
      const originMatch =
        !!origin && r.locn_pol === origin
          ? true
          : !!fileCountry && !!polCountry && polCountry === fileCountry;
      return {
        ...r,
        iso_code: iso,
        locn_pol_name: r.locn_pol ? nameMap[r.locn_pol] ?? null : null,
        locn_pod_name: r.locn_pod ? nameMap[r.locn_pod] ?? null : null,
        do_locn_name: r.do_locn ? nameMap[r.do_locn] ?? null : null,
        locn_pol_country: polCountry,
        origin_match: originMatch,
        type_match: fileTypes.size === 0 ? true : !!iso && fileTypes.has(iso),
      };
    });

    items.sort((a, b) => {
      const am = (a.origin_match ? 1 : 0) + (a.type_match ? 1 : 0);
      const bm = (b.origin_match ? 1 : 0) + (b.type_match ? 1 : 0);
      if (am !== bm) return bm - am;
      return (b.onhire_date ?? "").localeCompare(a.onhire_date ?? "");
    });

    return {
      items,
      file_origin: origin,
      file_origin_name: origin ? nameMap[origin] ?? null : null,
      file_origin_country: fileCountry,
      file_container_types: Array.from(fileTypes),
    };
  });



export const assignUnit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        file_id: z.string().uuid(),
        unit_no: z.string().min(1).max(40),
        booking_no: z.string().min(1).max(40).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase.rpc("fn_assign_unit_with_check", {
      p_file_id: data.file_id,
      p_unit_no: data.unit_no.trim().toUpperCase(),
      p_booking_no: data.booking_no ?? undefined,
    });
    if (error) throw new Error(error.message);
    if (data.booking_no) {
      await context.supabase.rpc("fn_assign_booking", {
        p_file_id: data.file_id,
        p_booking_no: data.booking_no,
        p_source: "auto_from_unit",
      });
    }
    await Promise.all([
      recomputeUnitWarnings(context.supabase, data.file_id),
      context.supabase.rpc("fn_refresh_file_finance_lines", { p_file_id: data.file_id }),
      recomputeAllAssignmentsEffectiveTo(context.supabase, data.file_id),
    ]);
    return { ok: true };
  });


export const assignBooking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        file_id: z.string().uuid(),
        booking_no: z.string().min(1).max(40),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: rows, error } = await context.supabase
      .from("eqs_ext_recent_units")
      .select("unit_no")
      .eq("booking_no", data.booking_no);
    if (error) throw new Error(error.message);

    // Ensure booking link exists even if 0 new units
    await context.supabase.rpc("fn_assign_booking", {
      p_file_id: data.file_id,
      p_booking_no: data.booking_no,
      p_source: "manual",
    });

    const { data: assigned } = await context.supabase
      .from("file_unit_assignments")
      .select("unit_no")
      .eq("file_id", data.file_id)
      .eq("is_active", true);
    const assignedSet = new Set((assigned ?? []).map((r) => r.unit_no));

    const units = Array.from(
      new Set((rows ?? []).map((r) => r.unit_no).filter((u) => u && !assignedSet.has(u))),
    );
    let count = 0;
    for (const unit_no of units) {
      const { error: e } = await context.supabase.rpc("fn_assign_unit_with_check", {
        p_file_id: data.file_id,
        p_unit_no: unit_no.trim().toUpperCase(),
        p_booking_no: data.booking_no,
      });
      if (e) throw new Error(e.message);
      count++;
    }
    await Promise.all([
      recomputeUnitWarnings(context.supabase, data.file_id),
      context.supabase.rpc("fn_refresh_file_finance_lines", { p_file_id: data.file_id }),
      recomputeAllAssignmentsEffectiveTo(context.supabase, data.file_id),
    ]);
    return { ok: true, count };
  });


export const unlinkUnit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        assignment_id: z.string().uuid(),
        file_id: z.string().uuid().optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    let fileId = data.file_id ?? null;
    if (!fileId) {
      const { data: row } = await context.supabase
        .from("file_unit_assignments")
        .select("file_id")
        .eq("id", data.assignment_id)
        .maybeSingle();
      fileId = row?.file_id ?? null;
    }
    const { error } = await context.supabase.rpc("fn_unlink_unit", {
      p_assignment_id: data.assignment_id,
    });
    if (error) throw new Error(error.message);
    if (fileId) {
      await Promise.all([
        recomputeUnitWarnings(context.supabase, fileId),
        context.supabase.rpc("fn_refresh_file_finance_lines", { p_file_id: fileId }),
        recomputeAllAssignmentsEffectiveTo(context.supabase, fileId),
      ]);
    }
    return { ok: true };
  });


export const upsertBudgetPlanLine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid().optional(),
        file_id: z.string().uuid(),
        article_id: z.string().uuid(),
        container_type: z.string().max(20).optional().nullable(),
        planned_qty: z.number().int().min(0).max(100000),
        amount_per_unit: z.number().min(-1e12).max(1e12),
        currency: z.string().length(3),
        amount_usd: z.number().min(-1e12).max(1e12).optional().nullable(),
        amount_eur: z.number().min(-1e12).max(1e12).optional().nullable(),
        
        source_type: z.enum(["MANUAL", "TEMPLATE", "IMPORT"]).default("MANUAL"),
        notes: z.string().max(500).optional().nullable(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    // Lock check: DR allows mutations; otherwise require budget_unlocked
    const { data: f } = await context.supabase
      .from("files")
      .select("status,budget_unlocked")
      .eq("id", data.file_id)
      .maybeSingle();
    if (!f) throw new Error("File not found");
    if (f.status !== "DR" && !(f as any).budget_unlocked) throw new Error("Budget plan is locked (file already opened)");

    const payload = {
      article_id: data.article_id,
      container_type: data.container_type ?? null,
      planned_qty: data.planned_qty,
      amount_per_unit: data.amount_per_unit,
      currency: data.currency.toUpperCase(),
      amount_usd: data.amount_usd ?? null,
      amount_eur: data.amount_eur ?? null,
      source_type: data.source_type,
      notes: data.notes ?? null,
    };
    if (data.id) {
      const { error } = await context.supabase
        .from("file_budget_plan_lines")
        .update(payload)
        .eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await context.supabase
      .from("file_budget_plan_lines")
      .insert({ ...payload, file_id: data.file_id })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const deleteBudgetPlanLine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { data: row } = await context.supabase
      .from("file_budget_plan_lines")
      .select("file_id, files!inner(status,budget_unlocked)")
      .eq("id", data.id)
      .maybeSingle();
    if (row && (row as any).files?.status !== "DR" && !(row as any).files?.budget_unlocked) {
      throw new Error("Budget plan is locked (file already opened)");
    }
    const { error } = await context.supabase
      .from("file_budget_plan_lines")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listBudgetArticles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({ scope: z.enum(["SALES", "FINANCE"]).optional() })
      .parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    let qb = context.supabase
      .from("budget_articles")
      .select("id,code,name,kind,sort_order,scope")
      .order("kind", { ascending: true })
      .order("sort_order", { ascending: true });
    if (data.scope) qb = qb.eq("scope", data.scope);
    const { data: rows, error } = await qb;
    if (error) throw new Error(error.message);
    return { items: rows ?? [] };
  });

// ============= Budget Articles CRUD (settings) =============
export const upsertBudgetArticle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid().optional(),
        code: z.string().min(1).max(40),
        name: z.string().min(1).max(200),
        kind: z.enum(["REVENUE", "COST"]),
        scope: z.enum(["SALES", "FINANCE"]).optional(),
        sort_order: z.number().int().optional(),
        is_fallback: z.boolean().optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const scope = data.scope ?? "SALES";
    if (data.id) {
      const { error } = await context.supabase
        .from("budget_articles")
        .update({
          code: data.code,
          name: data.name,
          kind: data.kind,
          scope,
          sort_order: data.sort_order ?? 0,
          is_fallback: data.is_fallback ?? false,
        })
        .eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await context.supabase
      .from("budget_articles")
      .insert({
        code: data.code,
        name: data.name,
        kind: data.kind,
        scope,
        sort_order: data.sort_order ?? 0,
        is_fallback: data.is_fallback ?? false,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const deleteBudgetArticle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("budget_articles")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============= Cost/Charge → Article mapping =============
// Finance lines store source_type as 'incoming'/'outgoing'; the mapping table
// (and ref dictionary eqs_ext_cost_charge_types) use 'CostType'/'ChargeType'.
// Normalize before building lookup keys.
const normalizeSourceType = (t: string | null | undefined): string => {
  if (!t) return "";
  const s = String(t).toLowerCase();
  if (s === "incoming" || s === "cost" || s === "costtype") return "CostType";
  if (s === "outgoing" || s === "charge" || s === "chargetype") return "ChargeType";
  return t;
};
export const listMapping = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: mapRows, error } = await context.supabase
      .from("cost_charge_type_mapping")
      .select(
        "id,source_type,source_code,article_id,finance_article_id," +
          "budget_articles!cost_charge_type_mapping_article_id_fkey(code,name,kind,scope)," +
          "finance_budget_articles:budget_articles!cost_charge_type_mapping_finance_article_id_fkey(code,name,kind,scope)",
      )
      .order("source_type", { ascending: true })
      .order("source_code", { ascending: true });
    if (error) throw new Error(error.message);

    // Usage counts from file_finance_lines, keyed by normalized type::code
    const counts = new Map<string, number>();
    let from = 0;
    const PAGE = 1000;
    while (true) {
      const { data: page, error: cErr } = await context.supabase
        .from("file_finance_lines")
        .select("source_type,source_code")
        .range(from, from + PAGE - 1);
      if (cErr) throw new Error(cErr.message);
      if (!page || page.length === 0) break;
      for (const r of page) {
        if (!r.source_type || !r.source_code) continue;
        const key = `${normalizeSourceType(r.source_type)}::${r.source_code}`;
        counts.set(key, (counts.get(key) ?? 0) + 1);
      }
      if (page.length < PAGE) break;
      from += PAGE;
    }

    // Name dictionary
    const { data: nameRows } = await context.supabase
      .from("eqs_ext_cost_charge_types")
      .select("source_type,source_code,source_name");
    const names = new Map<string, string>();
    for (const n of nameRows ?? []) {
      if (!n.source_type || !n.source_code) continue;
      names.set(
        `${normalizeSourceType(n.source_type)}::${n.source_code}`,
        n.source_name ?? "",
      );
    }

    const enrich = (st: string, sc: string) => {
      const key = `${normalizeSourceType(st)}::${sc}`;
      return { usage_count: counts.get(key) ?? 0, source_name: names.get(key) ?? "" };
    };

    const items = (mapRows ?? []).map((m: any) => ({
      ...m,
      ...enrich(m.source_type, m.source_code),
    }));

    // distinct (source_type, source_code) from ext finance lines that are not yet mapped
    const mappedKeys = new Set(
      (mapRows ?? []).map((m: any) => `${m.source_type}::${m.source_code}`),
    );
    const { data: extRows } = await context.supabase
      .from("eqs_ext_finance_lines")
      .select("source_type,source_code")
      .limit(5000);
    const unmapped = new Map<
      string,
      { source_type: string; source_code: string; usage_count: number; source_name: string }
    >();
    for (const r of extRows ?? []) {
      if (!r.source_type || !r.source_code) continue;
      const normType = normalizeSourceType(r.source_type);
      const key = `${normType}::${r.source_code}`;
      if (mappedKeys.has(key) || unmapped.has(key)) continue;
      unmapped.set(key, {
        source_type: normType,
        source_code: r.source_code,
        ...enrich(normType, r.source_code),
      });
    }
    return {
      items,
      unmapped: Array.from(unmapped.values()),
    };
  });

export const upsertMapping = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid().optional(),
        source_type: z.string().min(1).max(40),
        source_code: z.string().min(1).max(40),
        article_id: z.string().uuid(),
        finance_article_id: z.string().uuid().nullable().optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const financeId =
      data.finance_article_id === undefined ? undefined : data.finance_article_id;

    // Server-side validation: if finance article is set, its kind must match source_type.
    // CostType -> COST, ChargeType -> REVENUE. Article must be scope=FINANCE.
    if (financeId) {
      const { data: fa, error: faErr } = await context.supabase
        .from("budget_articles")
        .select("id,kind,scope")
        .eq("id", financeId)
        .single();
      if (faErr || !fa) throw new Error("Finance article not found");
      if (fa.scope !== "FINANCE")
        throw new Error("Selected article is not a Finance Budget Article");
      const expected = data.source_type === "CostType" ? "COST" : "REVENUE";
      if (fa.kind !== expected) {
        throw new Error(
          `Finance article kind ${fa.kind} does not match source ${data.source_type} (expected ${expected})`,
        );
      }
    }

    if (data.id) {
      const patch: { article_id: string; finance_article_id?: string | null } = {
        article_id: data.article_id,
      };
      if (financeId !== undefined) patch.finance_article_id = financeId;
      const { error } = await context.supabase
        .from("cost_charge_type_mapping")
        .update(patch)
        .eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }

    const { data: row, error } = await context.supabase
      .from("cost_charge_type_mapping")
      .insert({
        source_type: data.source_type,
        source_code: data.source_code,
        article_id: data.article_id,
        finance_article_id: financeId ?? null,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const deleteMapping = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("cost_charge_type_mapping")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });


export const searchBuyers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ q: z.string().max(120).optional() }).parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    const qTrim = data.q?.trim();
    const orFilter = qTrim
      ? `accno.ilike.%${qTrim}%,customer_name.ilike.%${qTrim}%`
      : null;

    let buyersQb = context.supabase
      .from("eqs_ext_container_buyers_5y")
      .select("accno,customer_name,country_code,sale_count,last_sale_date")
      .order("sale_count", { ascending: false, nullsFirst: false })
      .limit(50);
    if (orFilter) buyersQb = buyersQb.or(orFilter);

    let lesseesQb = context.supabase
      .from("eqs_ext_container_lessees_5y")
      .select("accno,customer_name,country_code,booking_count,last_booking_date")
      .order("booking_count", { ascending: false, nullsFirst: false })
      .limit(50);
    if (orFilter) lesseesQb = lesseesQb.or(orFilter);

    const [buyersRes, lesseesRes] = await Promise.all([buyersQb, lesseesQb]);
    if (buyersRes.error) throw new Error(buyersRes.error.message);
    if (lesseesRes.error) throw new Error(lesseesRes.error.message);

    type Merged = {
      accno: string;
      customer_name: string | null;
      country_code: string | null;
      sale_count: number;
      last_sale_date: string | null;
      source: "buyer" | "lessee" | "both";
    };
    const map = new Map<string, Merged>();
    for (const b of buyersRes.data ?? []) {
      map.set(b.accno, {
        accno: b.accno,
        customer_name: b.customer_name ?? null,
        country_code: b.country_code ?? null,
        sale_count: Number(b.sale_count ?? 0),
        last_sale_date: b.last_sale_date ?? null,
        source: "buyer",
      });
    }
    for (const l of lesseesRes.data ?? []) {
      const existing = map.get(l.accno);
      const lCount = Number(l.booking_count ?? 0);
      const lDate = l.last_booking_date ?? null;
      if (existing) {
        existing.source = "both";
        existing.sale_count += lCount;
        if (!existing.customer_name) existing.customer_name = l.customer_name ?? null;
        if (!existing.country_code) existing.country_code = l.country_code ?? null;
        if (lDate && (!existing.last_sale_date || lDate > existing.last_sale_date)) {
          existing.last_sale_date = lDate;
        }
      } else {
        map.set(l.accno, {
          accno: l.accno,
          customer_name: l.customer_name ?? null,
          country_code: l.country_code ?? null,
          sale_count: lCount,
          last_sale_date: lDate,
          source: "lessee",
        });
      }
    }
    const items = Array.from(map.values())
      .sort((a, b) => b.sale_count - a.sale_count)
      .slice(0, 50);
    return { items };
  });

export const searchLocations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        q: z.string().max(120).optional(),
        country_code: z.string().max(8).optional(),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    let qb = context.supabase
      .from("eqs_ext_locations_subregions")
      .select("locn_id,locn_desc,subregion_id,subregion_desc,country_code,country_name")
      .order("locn_id", { ascending: true })
      .limit(50);
    if (data.country_code) qb = qb.eq("country_code", data.country_code);
    if (data.q && data.q.trim()) {
      const q = `%${data.q.trim()}%`;
      qb = qb.or(
        `locn_id.ilike.${q},locn_desc.ilike.${q},subregion_id.ilike.${q},subregion_desc.ilike.${q}`,
      );
    }
    const { data: rows, error } = await qb;
    if (error) throw new Error(error.message);
    return { items: rows ?? [] };
  });

export const listCountries = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    // Page through all rows so distinct countries aren't cut off by row limit.
    const seen = new Set<string>();
    const items: { country_code: string; country_name: string }[] = [];
    const PAGE = 1000;
    for (let from = 0; from < 20000; from += PAGE) {
      const { data, error } = await context.supabase
        .from("eqs_ext_locations_subregions")
        .select("country_code,country_name")
        .order("country_code", { ascending: true })
        .range(from, from + PAGE - 1);
      if (error) throw new Error(error.message);
      if (!data || data.length === 0) break;
      for (const r of data) {
        if (!r.country_code || seen.has(r.country_code)) continue;
        seen.add(r.country_code);
        items.push({
          country_code: r.country_code,
          country_name: r.country_name ?? r.country_code,
        });
      }
      if (data.length < PAGE) break;
    }
    items.sort((a, b) => a.country_name.localeCompare(b.country_name));
    return { items };
  });

export const updateFile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid(),
        customer_accno: z.string().max(40).nullable().optional(),
        customer_name: z.string().max(255).nullable().optional(),
        lessee_order: z.string().max(120).nullable().optional(),
        origin_country_code: z.string().max(8).nullable().optional(),
        dest_country_code: z.string().max(8).nullable().optional(),
        origin_locn: z.string().max(20).nullable().optional(),
        dest_locn: z.string().max(20).nullable().optional(),
        origin_subregion: z.string().max(20).nullable().optional(),
        dest_subregion: z.string().max(20).nullable().optional(),
        planned_departure_date: z.string().nullable().optional(),
        planned_arrival_date: z.string().nullable().optional(),
        business_date: z.string().nullable().optional(),
        fx_rate_eur_usd: z.number().nullable().optional(),
        sales_manager_id: z.string().uuid().nullable().optional(),
        sales_person_id: z.string().uuid().nullable().optional(),
        notes: z.string().max(2000).nullable().optional(),
        container_types: z
          .array(
            z.object({
              container_type: z.string().min(1).max(20),
              planned_qty: z.number().int().min(1).max(9999),
              grade: z.string().max(40).nullable().optional(),
              daily_rate: z.number().nullable().optional(),
              repl_value: z.number().nullable().optional(),
              free_min_days: z.number().int().nullable().optional(),
              charge1_code: z.string().max(40).nullable().optional(),
              charge1_amount: z.number().nullable().optional(),
              charge2_code: z.string().max(40).nullable().optional(),
              charge2_amount: z.number().nullable().optional(),
              charge3_code: z.string().max(40).nullable().optional(),
              charge3_amount: z.number().nullable().optional(),
              charge4_code: z.string().max(40).nullable().optional(),
              charge4_amount: z.number().nullable().optional(),
              cost1_code: z.string().max(40).nullable().optional(),
              cost1_currency: z.string().max(8).nullable().optional(),
              cost1_amount: z.number().nullable().optional(),
              cost1_supplier_accno: z.string().max(40).nullable().optional(),
              cost2_code: z.string().max(40).nullable().optional(),
              cost2_currency: z.string().max(8).nullable().optional(),
              cost2_amount: z.number().nullable().optional(),
              cost2_supplier_accno: z.string().max(40).nullable().optional(),
            }),
          )
          .max(20)
          .optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { id, container_types, ...patch } = data;

    // Load current values for diff + status
    const { data: before, error: bErr } = await context.supabase
      .from("files")
      .select(
        "status,customer_accno,customer_name,lessee_order,origin_country_code,dest_country_code,origin_locn,dest_locn,origin_subregion,dest_subregion,planned_departure_date,planned_arrival_date,business_date,fx_rate_eur_usd,sales_manager_id,sales_person_id,notes",
      )
      .eq("id", id)
      .maybeSingle();
    if (bErr) throw new Error(bErr.message);
    if (!before) throw new Error("Not found");

    const cleaned: Record<string, string | number | null> = {};
    const changes: Record<string, { old: unknown; new: unknown }> = {};
    for (const [k, v] of Object.entries(patch)) {
      if (v === undefined) continue;
      cleaned[k] = v as string | number | null;
      const oldV = (before as any)[k] ?? null;
      const newV = v ?? null;
      if (oldV !== newV) changes[k] = { old: oldV, new: newV };
    }

    if (Object.keys(cleaned).length > 0) {
      const { error } = await context.supabase
        .from("files")
        .update(cleaned as never)
        .eq("id", id);
      if (error) throw new Error(error.message);
    }

    if (container_types) {
      // Capture old container types for diff
      const { data: oldCts } = await context.supabase
        .from("file_container_types")
        .select("container_type,planned_qty")
        .eq("file_id", id);
      const oldKey = (oldCts ?? [])
        .map((c: any) => `${c.container_type}×${c.planned_qty}`)
        .sort()
        .join(", ");
      const newKey = container_types
        .map((c) => `${c.container_type}×${c.planned_qty}`)
        .sort()
        .join(", ");
      if (oldKey !== newKey) {
        changes.container_types = { old: oldKey || null, new: newKey || null };
      }
      const { error: delErr } = await context.supabase
        .from("file_container_types")
        .delete()
        .eq("file_id", id);
      if (delErr) throw new Error(delErr.message);
      if (container_types.length > 0) {
        const { error: insErr } = await context.supabase
          .from("file_container_types")
          .insert(
            container_types.map((c) => ({
              file_id: id,
              ...c,
            })) as never,
          );
        if (insErr) throw new Error(insErr.message);
      }
    }

    if (Object.keys(changes).length > 0) {
      const status = (before as any).status as string;
      const after_rp = ["RP", "RCL", "CL"].includes(status);
      await context.supabase.from("file_audit_log").insert({
        file_id: id,
        actor_id: context.userId,
        action: "file_updated",
        details: { changes, status_at_change: status, after_rp },
      } as never);
    }

    return { ok: true };
  });


// ============= Budget Fact =============
export const getBudgetFact = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    // Active + previously linked assignments with effective intervals
    // Active (linked) assignments only — unlinked units do NOT contribute to budget fact.
    const { data: assigns, error: aErr } = await context.supabase
      .from("file_unit_assignments")
      .select("unit_no,unit_type,effective_date_from,effective_date_to,is_active")
      .eq("file_id", data.id)
      .eq("is_active", true);

    if (aErr) throw new Error(aErr.message);

    const unitIntervals = new Map<
      string,
      { from: string | null; to: string | null }[]
    >();
    const unitDisplayInterval = new Map<string, { from: string | null; to: string | null }>();
    for (const a of assigns ?? []) {
      if (!a.unit_no) continue;
      const list = unitIntervals.get(a.unit_no) ?? [];
      list.push({ from: a.effective_date_from, to: a.effective_date_to });
      unitIntervals.set(a.unit_no, list);
      if (!unitDisplayInterval.has(a.unit_no)) {
        unitDisplayInterval.set(a.unit_no, {
          from: a.effective_date_from,
          to: a.effective_date_to,
        });
      }
    }
    const unitNos = Array.from(unitIntervals.keys());

    const inInterval = (unit: string | null, dateStr: string | null) => {
      if (!unit) return true;
      const ivs = unitIntervals.get(unit);
      if (!ivs || ivs.length === 0) return false;
      if (!dateStr) return ivs.some((i) => !i.to);
      const d = dateStr.slice(0, 10);
      return ivs.some(
        (i) => (!i.from || d >= i.from) && (!i.to || d <= i.to),
      );
    };

    const unitType = new Map<string, string | null>();
    for (const a of assigns ?? []) {
      if (a.unit_no && !unitType.has(a.unit_no)) {
        unitType.set(a.unit_no, (a as any).unit_type ?? null);
      }
    }

    // ============ Sources ============

    // 1) file_finance_lines (already attributed to the file)
    const { data: ffl, error: fErr } = await context.supabase
      .from("file_finance_lines")
      .select(
        "id,file_id,unit_no,source_finance_id,source_type,source_code,article_id,amount,currency,invoice_no,invoice_date,dte_acct,is_unmapped",
      )
      .eq("file_id", data.id);
    if (fErr) throw new Error(fErr.message);

    // 2) ext finance lines for assigned units, filtered by effective interval.
    //    Exception: Purchase Price events (PURC/RCTP) for the unit are kept
    //    regardless of effective interval, since the purchase often predates
    //    the file's effective_date_from but is still a fact for this file.
    const PP_CODES = new Set(["PURC", "RCTP"]);
    let ext: any[] = [];
    const extById = new Map<
      string,
      { accno: string | null; booking_no: string | null; party_accname: string | null }
    >();
    if (unitNos.length > 0) {
      const seenSourceIds = new Set(
        (ffl ?? [])
          .map((r: any) => r.source_finance_id)
          .filter((x: any): x is string => !!x),
      );
      const { data: extRows, error: eErr } = await context.supabase
        .from("eqs_ext_finance_lines")
        .select(
          "id,unit_no,booking_no,accno,party_accname,party_accno,source_type,source_code,source_area,amount,currency,invoice_no,invoice_date,dte_acct,source_table",
        )
        .in("unit_no", unitNos);
      if (eErr) throw new Error(eErr.message);
      for (const r of extRows ?? []) {
        extById.set(r.id, {
          accno: r.accno ?? null,
          booking_no: r.booking_no ?? null,
          party_accname: (r as any).party_accname ?? null,
        });
      }
      ext = (extRows ?? []).filter(
        (r: any) =>
          !seenSourceIds.has(r.id) &&
          (PP_CODES.has(r.source_code) ||
            inInterval(r.unit_no, r.dte_acct ?? r.invoice_date)),
      );
    }

    // Contact resolution: take party_accname from the finance line directly.
    // No fallback to bookings / buyers reference. Empty -> null -> UI "—".
    const resolveContact = (party_accname: string | null): string | null => {
      const v = (party_accname ?? "").trim();
      return v ? v : null;
    };


    // 3) file_rt_charges (RT billing expected revenue)
    const { data: rtRows, error: rtErr } = await context.supabase
      .from("file_rt_charges")
      .select("id,unit_no,charge_code,amount,currency,charge_date")
      .eq("file_id", data.id);
    if (rtErr) throw new Error(rtErr.message);

    // ============ Mapping ============
    const { data: mapRows } = await context.supabase
      .from("cost_charge_type_mapping")
      .select("source_type,source_code,article_id");
    const mapping = new Map<string, string>();
    for (const m of mapRows ?? []) {
      mapping.set(`${m.source_type}::${m.source_code}`, m.article_id);
    }

    type SourceKind = "booked_finance" | "cost_accrual" | "billing_expected_revenue" | "budgeted";
    type FactLine = {
      origin: "file" | "ext" | "rt" | "budget";
      source_kind: SourceKind;
      id: string;
      unit_no: string | null;
      booking_no: string | null;
      contact: string | null;
      source_type: string | null;
      source_code: string | null;
      article_id: string | null;
      amount: number;
      currency: string | null;
      invoice_no: string | null;
      business_date: string | null;
      effective_from: string | null;
      effective_to: string | null;
      is_unmapped: boolean;
    };
    const lines: FactLine[] = [];

    const effOf = (unit: string | null) => {
      if (!unit) return { effective_from: null, effective_to: null };
      const iv = unitDisplayInterval.get(unit);
      return { effective_from: iv?.from ?? null, effective_to: iv?.to ?? null };
    };



    for (const r of ffl ?? []) {
      const ex = (r as any).source_finance_id ? extById.get((r as any).source_finance_id) : null;
      const isPP = PP_CODES.has(String(r.source_code ?? ""));
      if (!isPP && !inInterval(r.unit_no, (r as any).dte_acct ?? r.invoice_date)) continue;
      const kind: SourceKind = r.invoice_no ? "booked_finance" : "cost_accrual";
      lines.push({
        origin: "file",
        source_kind: kind,
        id: r.id,
        unit_no: r.unit_no,
        booking_no: ex?.booking_no ?? null,
        contact: resolveContact(ex?.party_accname ?? null),
        source_type: r.source_type,
        source_code: r.source_code,
        article_id: r.article_id,
        amount: Number(r.amount ?? 0),
        currency: r.currency,
        invoice_no: r.invoice_no,
        business_date: ((r as any).dte_acct ?? r.invoice_date) ?? null,
        ...effOf(r.unit_no),
        is_unmapped: !!r.is_unmapped || !r.article_id,
      });
    }

    for (const r of ext) {
      const normType = normalizeSourceType(r.source_type);
      const key = `${normType}::${r.source_code}`;
      const article_id = mapping.get(key) ?? null;
      const kind: SourceKind = r.invoice_no ? "booked_finance" : "cost_accrual";
      lines.push({
        origin: "ext",
        source_kind: kind,
        id: r.id,
        unit_no: r.unit_no,
        booking_no: r.booking_no ?? null,
        contact: resolveContact((r as any).party_accname ?? null),
        source_type: normType,
        source_code: r.source_code,
        article_id,
        amount: Number(r.amount ?? 0),
        currency: r.currency,
        invoice_no: r.invoice_no,
        business_date: (r.dte_acct ?? r.invoice_date) ?? null,
        ...effOf(r.unit_no),
        is_unmapped: !article_id,
      });
    }

    for (const r of rtRows ?? []) {
      const key = `ChargeType::${r.charge_code}`;
      const article_id = mapping.get(key) ?? null;
      lines.push({
        origin: "rt",
        source_kind: "billing_expected_revenue",
        id: r.id,
        unit_no: r.unit_no,
        booking_no: null,
        contact: null,
        source_type: "ChargeType",
        source_code: r.charge_code,
        article_id,
        amount: Number(r.amount ?? 0),
        currency: r.currency,
        invoice_no: null,
        business_date: r.charge_date ?? null,
        ...effOf(r.unit_no),
        is_unmapped: !article_id,
      });
    }

    // 4) Synthetic fact rows (file_budget_fact_lines) — e.g. planned container
    //    purchases inserted at file creation. Suppressed per (unit_no, article_id)
    //    once a real PURC/RCTP finance line for that unit lands in file_finance_lines
    //    or eqs_ext_finance_lines, to avoid double-counting.
    const realPpKeys = new Set<string>();
    for (const r of (ffl ?? []) as any[]) {
      if (PP_CODES.has(String(r.source_code ?? "")) && r.unit_no && r.article_id) {
        realPpKeys.add(`${r.unit_no}::${r.article_id}`);
      }
    }
    for (const r of ext as any[]) {
      if (!PP_CODES.has(String(r.source_code ?? "")) || !r.unit_no) continue;
      const normType = normalizeSourceType(r.source_type);
      const aid = mapping.get(`${normType}::${r.source_code}`);
      if (aid) realPpKeys.add(`${r.unit_no}::${aid}`);
    }
    const { data: bfRows, error: bfErr } = await context.supabase
      .from("file_budget_fact_lines")
      .select("id,unit_no,article_id,amount,currency,created_at")
      .eq("file_id", data.id)
      .not("unit_no", "is", null);

    if (bfErr) throw new Error(bfErr.message);
    for (const r of (bfRows ?? []) as any[]) {
      if (r.unit_no && r.article_id && realPpKeys.has(`${r.unit_no}::${r.article_id}`)) continue;
      lines.push({
        origin: "budget",
        source_kind: "cost_accrual",
        id: r.id,
        unit_no: r.unit_no ?? null,
        booking_no: null,
        contact: null,
        source_type: null,
        source_code: null,
        article_id: r.article_id ?? null,
        amount: Number(r.amount ?? 0),
        currency: r.currency ?? "USD",
        invoice_no: null,
        business_date: r.created_at ? String(r.created_at).slice(0, 10) : null,
        ...effOf(r.unit_no ?? null),
        is_unmapped: !r.article_id,
      });
    }



    // ============ Plan ============
    const { data: planRows, error: pErr } = await context.supabase
      .from("file_budget_plan_lines")
      .select("article_id,currency,total_amount,amount_per_unit,planned_qty,container_type")
      .eq("file_id", data.id);
    if (pErr) throw new Error(pErr.message);

    // File-level planned qty per container_type (used to scale per-unit plan lines to file total)
    const { data: ctRows } = await context.supabase
      .from("file_container_types")
      .select("container_type,planned_qty")
      .eq("file_id", data.id);
    const qtyByType = new Map<string, number>();
    for (const c of ctRows ?? []) {
      qtyByType.set((c as any).container_type, Number((c as any).planned_qty) || 0);
    }

    const articleIds = Array.from(
      new Set([
        ...lines.map((l) => l.article_id).filter((x): x is string => !!x),
        ...(planRows ?? []).map((r: any) => r.article_id).filter((x: any): x is string => !!x),
      ]),
    );
    const articles = new Map<string, { code: string; name: string; kind: string | null }>();
    if (articleIds.length > 0) {
      const { data: aRows } = await context.supabase
        .from("budget_articles")
        .select("id,code,name,kind")
        .in("id", articleIds);
      for (const a of aRows ?? []) articles.set(a.id, { code: a.code, name: a.name, kind: a.kind });
    }

    // ============ Per-(article, currency) summary ============
    type Agg = {
      article_id: string | null;
      currency: string;
      plan: number;
      plan_per_unit: number; // amount_per_unit (last seen) * sign; used to size budgeted lines
      booked: number;
      accrued: number;
      expected_rt: number;
      budgeted: number;
    };
    const aggMap = new Map<string, Agg>();
    const ak = (aid: string | null, cur: string) => `${aid ?? "_"}::${cur}`;
    const ensureAgg = (aid: string | null, cur: string) => {
      const k = ak(aid, cur);
      let a = aggMap.get(k);
      if (!a) {
        a = {
          article_id: aid,
          currency: cur,
          plan: 0,
          plan_per_unit: 0,
          booked: 0,
          accrued: 0,
          expected_rt: 0,
          budgeted: 0,
        };
        aggMap.set(k, a);
      }
      return a;
    };
    for (const p of planRows ?? []) {
      const cur = p.currency ?? "USD";
      // total_amount is already amount_per_unit * planned_qty for the container type,
      // so the per-type plan total — do NOT multiply by file-level qty again.
      const planTotal = Number(
        p.total_amount ?? Number(p.amount_per_unit ?? 0) * Number(p.planned_qty ?? 0),
      );
      const a = ensureAgg(p.article_id ?? null, cur);
      a.plan += planTotal;
      if (Number(p.amount_per_unit ?? 0) !== 0) {
        a.plan_per_unit = Number(p.amount_per_unit);
      }
    }

    for (const l of lines) {
      const cur = l.currency ?? "USD";
      const a = ensureAgg(l.article_id, cur);
      if (l.source_kind === "booked_finance") a.booked += l.amount;
      else if (l.source_kind === "cost_accrual") a.accrued += l.amount;
      else if (l.source_kind === "billing_expected_revenue") a.expected_rt += l.amount;
    }

    // ============ Budgeted (per-container) ============
    // Plan rows that scope to a container_type are exploded per assigned unit
    // (remaining = plan_per_unit - |executed_per_unit|) plus one synthetic
    // "not assigned" row per still-missing container slot.
    // Plan rows without container_type fall back to a single aggregate row.
    const execByUnitKey = new Map<string, number>(); // aid::cur::unit
    const execByArtCurNoUnit = new Map<string, number>(); // aid::cur (sum where unit_no IS NULL)
    for (const l of lines) {
      if (l.source_kind === "budgeted") continue;
      const cur = l.currency ?? "USD";
      const aid = l.article_id ?? "_";
      if (l.unit_no) {
        const k = `${aid}::${cur}::${l.unit_no}`;
        execByUnitKey.set(k, (execByUnitKey.get(k) ?? 0) + l.amount);
      } else {
        const k = `${aid}::${cur}`;
        execByArtCurNoUnit.set(k, (execByArtCurNoUnit.get(k) ?? 0) + l.amount);
      }
    }

    // type → assigned units (active or unlinked, distinct)
    const typeUnits = new Map<string, string[]>();
    const seenTypeUnit = new Set<string>();
    for (const a of (assigns ?? []) as any[]) {
      if (!a.unit_no || !a.unit_type) continue;
      const k = `${a.unit_type}::${a.unit_no}`;
      if (seenTypeUnit.has(k)) continue;
      seenTypeUnit.add(k);
      const list = typeUnits.get(a.unit_type) ?? [];
      list.push(a.unit_no);
      typeUnits.set(a.unit_type, list);
    }

    for (const p of (planRows ?? []) as any[]) {
      const cur = p.currency ?? "USD";
      const aid: string | null = p.article_id ?? null;
      const art = aid ? articles.get(aid) : undefined;
      const sign = art?.kind === "COST" ? -1 : 1;
      const planPer = Number(p.amount_per_unit ?? 0);
      // amount_per_unit is stored signed (negative for COST). The budgeted
      // remainder math below works with magnitudes and re-applies `sign`.
      const planPerMag = Math.abs(planPer);
      if (planPer === 0 && !p.total_amount) continue;
      const a = ensureAgg(aid, cur);

      if (p.container_type) {
        const ct: string = p.container_type;
        const units = typeUnits.get(ct) ?? [];
        const planned = qtyByType.get(ct) ?? Number(p.planned_qty ?? 0);

        for (const u of units) {
          const exec = execByUnitKey.get(`${aid ?? "_"}::${cur}::${u}`) ?? 0;
          const remaining = planPerMag - Math.abs(exec);
          if (remaining <= 0.0001) continue;
          const amt = remaining * sign;
          a.budgeted += amt;
          lines.push({
            origin: "budget",
            source_kind: "budgeted",
            id: `budget::${aid ?? "_"}::${cur}::${u}`,
            unit_no: u,
            booking_no: null,
            contact: null,
            source_type: null,
            source_code: null,
            article_id: aid,
            amount: amt,
            currency: cur,
            invoice_no: null,
            business_date: null,
            ...effOf(u),
            is_unmapped: aid == null,
          });
        }

        const slots = Math.max(0, planned - units.length);
        for (let i = 0; i < slots; i++) {
          const amt = planPerMag * sign;
          a.budgeted += amt;
          lines.push({
            origin: "budget",
            source_kind: "budgeted",
            id: `budget::${aid ?? "_"}::${cur}::__slot::${ct}::${i}`,
            unit_no: null,
            booking_no: null,
            contact: null,
            source_type: null,
            source_code: null,
            article_id: aid,
            amount: amt,
            currency: cur,
            invoice_no: null,
            business_date: null,
            effective_from: null,
            effective_to: null,
            is_unmapped: aid == null,
          });
        }
      } else {
        // Aggregate: plan total vs executed-without-unit (general charges)
        const planTotal = Math.abs(
          Number(p.total_amount ?? planPerMag * Number(p.planned_qty ?? 0)),
        );
        const exec = execByArtCurNoUnit.get(`${aid ?? "_"}::${cur}`) ?? 0;
        const remaining = planTotal - Math.abs(exec);
        if (remaining <= 0.0001) continue;
        const amt = remaining * sign;
        a.budgeted += amt;
        lines.push({
          origin: "budget",
          source_kind: "budgeted",
          id: `budget::${aid ?? "_"}::${cur}::__agg`,
          unit_no: null,
          booking_no: null,
          contact: null,
          source_type: null,
          source_code: null,
          article_id: aid,
          amount: amt,
          currency: cur,
          invoice_no: null,
          business_date: null,
          effective_from: null,
          effective_to: null,
          is_unmapped: aid == null,
        });
      }
    }


    const summary = Array.from(aggMap.values()).map((a) => {
      const art = a.article_id ? articles.get(a.article_id) : undefined;
      const is_unmapped = a.article_id == null;
      const executed = a.booked + a.accrued + a.expected_rt;
      const is_extra = !is_unmapped && a.plan === 0 && executed !== 0;
      return {
        article_id: a.article_id,
        article_code: art?.code ?? null,
        article_name: art?.name ?? (a.article_id ? null : "(Unmapped)"),
        kind: art?.kind ?? null,
        currency: a.currency,
        plan: a.plan,
        booked: a.booked,
        accrued: a.accrued,
        expected_rt: a.expected_rt,
        budgeted: a.budgeted,
        executed,
        // Forecast (current best estimate for the file): executed (signed) + budgeted (signed)
        forecast: executed + a.budgeted,
        delta: executed - a.plan,
        is_unmapped,
        is_extra,
      };
    });
    summary.sort((x, y) => {
      if ((x.article_code ?? "") === (y.article_code ?? ""))
        return x.currency.localeCompare(y.currency);
      return (x.article_code ?? "zzz").localeCompare(y.article_code ?? "zzz");
    });

    // ============ File-level GPM total (Σ revenue + Σ cost), revenue + cost(signed) ============
    // Fact lines are signed (cost negative). For each currency, GPM = Σ amount over revenue + cost articles + budgeted.
    const gpmByCur = new Map<string, number>();
    for (const a of aggMap.values()) {
      const cur = a.currency;
      const total = a.booked + a.accrued + a.expected_rt + a.budgeted;
      gpmByCur.set(cur, (gpmByCur.get(cur) ?? 0) + total);
    }
    const file_gpm = Object.fromEntries(gpmByCur);

    const enrichedLines = lines.map((l) => {
      const art = l.article_id ? articles.get(l.article_id) : undefined;
      return {
        ...l,
        article_code: art?.code ?? null,
        article_name: art?.name ?? null,
        article_kind: art?.kind ?? null,
        container_type: l.unit_no ? unitType.get(l.unit_no) ?? null : null,
      };
    });

    return { summary, lines: enrichedLines, file_gpm };
  });

export const setBudgetUnlocked = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ file_id: z.string().uuid(), unlocked: z.boolean() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: before } = await context.supabase
      .from("files")
      .select("status,budget_unlocked")
      .eq("id", data.file_id)
      .maybeSingle();
    if (!before) throw new Error("File not found");
    const { error } = await context.supabase
      .from("files")
      .update({ budget_unlocked: data.unlocked })
      .eq("id", data.file_id);
    if (error) throw new Error(error.message);
    const status = (before as any).status as string;
    const after_rp = ["RP", "RCL", "CL"].includes(status);
    await context.supabase.from("file_audit_log").insert({
      file_id: data.file_id,
      actor_id: context.userId,
      action: data.unlocked ? "budget_unlocked" : "budget_locked",
      details: {
        changes: {
          budget_unlocked: {
            old: (before as any).budget_unlocked ?? false,
            new: data.unlocked,
          },
        },
        status_at_change: status,
        after_rp,
      },
    } as never);

    return { ok: true };
  });


// ============================================================================
// Recent Units global view + create-file-from-booking flow
// ============================================================================

const PP_ARTICLE_CODE = "pp";
const SP_ARTICLE_CODE = "selling_price";

async function _resolveLocnNames(
  supabase: any,
  codes: (string | null | undefined)[],
): Promise<{
  nameMap: Record<string, string>;
  countryMap: Record<string, string>;
  subregionMap: Record<string, string>;
  subregionDescMap: Record<string, string>;
}> {
  const uniq = Array.from(new Set(codes.filter((c): c is string => !!c)));
  if (uniq.length === 0)
    return { nameMap: {}, countryMap: {}, subregionMap: {}, subregionDescMap: {} };
  const { data: locs } = await supabase
    .from("eqs_ext_locations_subregions")
    .select("locn_id,locn_desc,country_code,subregion_id,subregion_desc")
    .in("locn_id", uniq);
  const nameMap: Record<string, string> = {};
  const countryMap: Record<string, string> = {};
  const subregionMap: Record<string, string> = {};
  const subregionDescMap: Record<string, string> = {};
  for (const l of locs ?? []) {
    if (l.locn_id && l.locn_desc) nameMap[l.locn_id] = l.locn_desc;
    if (l.locn_id && l.country_code) countryMap[l.locn_id] = l.country_code;
    if (l.locn_id && l.subregion_id) subregionMap[l.locn_id] = l.subregion_id;
    if (l.locn_id && l.subregion_desc) subregionDescMap[l.locn_id] = l.subregion_desc;
  }
  return { nameMap, countryMap, subregionMap, subregionDescMap };
}

export const listRecentUnitsGlobal = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        q: z.string().max(64).optional(),
        only_unlinked: z.boolean().optional(),
        only_linked: z.boolean().optional(),
        status: z.array(z.string()).optional(),
        iso_codes: z.array(z.string()).optional(),
        customers: z.array(z.string()).optional(),
        from_locn: z.array(z.string()).optional(),
        from_subregion: z.array(z.string()).optional(),
        to_locn: z.array(z.string()).optional(),
        to_subregion: z.array(z.string()).optional(),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    const term = (data.q ?? "").trim();
    const safe = term.replace(/[,()]/g, "");
    const like = safe ? `%${safe}%` : null;

    const CHUNK = 1000;
    const fetchAllChunks = async <T = any>(
      build: (from: number, to: number) => any,
    ): Promise<T[]> => {
      const out: T[] = [];
      for (let from = 0; from < 500000; from += CHUNK) {
        const { data: chunk, error } = await build(from, from + CHUNK - 1);
        if (error) throw new Error(error.message);
        if (!chunk?.length) break;
        out.push(...(chunk as T[]));
        if (chunk.length < CHUNK) break;
      }
      return out;
    };

    // 1. Pre-filter unit_no by status/iso via eqs_ext_units
    let requireUnits: Set<string> | null = null;
    if ((data.status?.length ?? 0) > 0 || (data.iso_codes?.length ?? 0) > 0) {
      const rows = await fetchAllChunks<{ unit_no: string | null }>((from, to) => {
        let uq = context.supabase.from("eqs_ext_units").select("unit_no");
        if (data.status?.length) uq = uq.in("status", data.status);
        if (data.iso_codes?.length) uq = uq.in("iso_code", data.iso_codes);
        return uq.order("unit_no", { ascending: true }).range(from, to);
      });
      requireUnits = new Set(rows.map((r) => r.unit_no).filter(Boolean) as string[]);
      if (requireUnits.size === 0) return { items: [] };
    }

    // 2. Apply linked / unlinked filter via file_unit_assignments
    let linkedSet: Set<string> | null = null;
    if (data.only_linked || data.only_unlinked) {
      const rows = await fetchAllChunks<{ unit_no: string | null }>((from, to) =>
        context.supabase
          .from("file_unit_assignments")
          .select("unit_no")
          .eq("is_active", true)
          .order("unit_no", { ascending: true })
          .range(from, to),
      );
      linkedSet = new Set(rows.map((r) => r.unit_no).filter(Boolean) as string[]);
      if (data.only_linked) {
        requireUnits = requireUnits
          ? new Set([...requireUnits].filter((u) => linkedSet!.has(u)))
          : new Set(linkedSet);
        if (requireUnits.size === 0) return { items: [] };
      } else if (data.only_unlinked && requireUnits) {
        requireUnits = new Set([...requireUnits].filter((u) => !linkedSet!.has(u)));
        if (requireUnits.size === 0) return { items: [] };
      }
    }

    // 3. Expand subregion ids to locn lists
    const expandSub = async (subs: string[] | undefined): Promise<string[]> => {
      if (!subs?.length) return [];
      const { data: rows, error } = await context.supabase
        .from("eqs_ext_locations_subregions")
        .select("locn_id")
        .in("subregion_id", subs);
      if (error) throw new Error(error.message);
      return ((rows ?? []) as any[]).map((r) => r.locn_id).filter(Boolean);
    };
    const fromLocns = Array.from(
      new Set([...(data.from_locn ?? []), ...(await expandSub(data.from_subregion))]),
    );
    const toLocns = Array.from(
      new Set([...(data.to_locn ?? []), ...(await expandSub(data.to_subregion))]),
    );

    const applyFilters = (qb: any) => {
      if (like)
        qb = qb.or(
          `unit_no.ilike.${like},booking_no.ilike.${like},locn_pol.ilike.${like},locn_pod.ilike.${like},customer.ilike.${like},internal_ref.ilike.${like},accno.ilike.${like}`,
        );
      if (fromLocns.length) qb = qb.in("locn_pol", fromLocns);
      if (toLocns.length) {
        const list = toLocns.map((c) => `"${c}"`).join(",");
        qb = qb.or(`do_locn.in.(${list}),and(do_locn.is.null,locn_pod.in.(${list}))`);
      }
      if (data.customers?.length) qb = qb.in("customer", data.customers);
      return qb;
    };

    const RECENT_SELECT =
      "unit_no,booking_no,onhire_date,locn_pol,locn_pod,do_locn,accno,customer,internal_ref";

    let items: any[] = [];
    if (requireUnits) {
      const unitList = Array.from(requireUnits);
      const IN_CHUNK = 500;
      const all: any[] = [];
      for (let i = 0; i < unitList.length; i += IN_CHUNK) {
        const slice = unitList.slice(i, i + IN_CHUNK);
        let qb = context.supabase
          .from("eqs_ext_recent_units")
          .select(RECENT_SELECT)
          .in("unit_no", slice);
        qb = applyFilters(qb);
        qb = qb.order("onhire_date", { ascending: false }).limit(500);
        const { data: rows, error } = await qb;
        if (error) throw new Error(error.message);
        all.push(...(rows ?? []));
      }
      all.sort((a, b) =>
        (a.onhire_date ?? "") < (b.onhire_date ?? "") ? 1 : (a.onhire_date ?? "") > (b.onhire_date ?? "") ? -1 : 0,
      );
      items = all.slice(0, 500);
    } else {
      let qb = context.supabase
        .from("eqs_ext_recent_units")
        .select(RECENT_SELECT)
        .order("onhire_date", { ascending: false })
        .limit(500);
      qb = applyFilters(qb);
      const { data: rows, error } = await qb;
      if (error) throw new Error(error.message);
      items = rows ?? [];
    }

    // For only_linked: include units linked to a file but missing from eqs_ext_recent_units
    if (data.only_linked && requireUnits) {
      const presentSet = new Set(items.map((r: any) => r.unit_no));
      const missing = Array.from(requireUnits).filter((u) => !presentSet.has(u));
      const anyContentFilter =
        !!like || fromLocns.length > 0 || toLocns.length > 0 || (data.customers?.length ?? 0) > 0;
      if (!anyContentFilter && missing.length) {
        const IN_CHUNK = 500;
        const extra: any[] = [];
        for (let i = 0; i < missing.length; i += IN_CHUNK) {
          const slice = missing.slice(i, i + IN_CHUNK);
          const { data: rows, error } = await context.supabase
            .from("file_unit_assignments")
            .select("unit_no,booking_no")
            .in("unit_no", slice)
            .eq("is_active", true);
          if (error) throw new Error(error.message);
          for (const r of (rows ?? []) as any[]) {
            extra.push({
              unit_no: r.unit_no,
              booking_no: r.booking_no,
              onhire_date: null,
              locn_pol: null,
              locn_pod: null,
              do_locn: null,
              accno: null,
              customer: null,
              internal_ref: null,
            });
          }
        }
        items = [...items, ...extra];
        items.sort((a, b) =>
          (a.onhire_date ?? "") < (b.onhire_date ?? "") ? 1 : (a.onhire_date ?? "") > (b.onhire_date ?? "") ? -1 : 0,
        );
        items = items.slice(0, 500);
      }
    }

    const unitNos = Array.from(new Set(items.map((r) => r.unit_no).filter(Boolean))) as string[];

    const [unitsRes, assignsRes, locResolved] = await Promise.all([
      unitNos.length
        ? context.supabase
            .from("eqs_ext_units")
            .select("unit_no,iso_code,status,amt_ppb,sale_amt_b")
            .in("unit_no", unitNos)
        : Promise.resolve({ data: [] as any[] }),
      unitNos.length
        ? context.supabase
            .from("file_unit_assignments")
            .select("unit_no,booking_no,file_id,is_active,files(file_number,status)")
            .in("unit_no", unitNos)
            .eq("is_active", true)
        : Promise.resolve({ data: [] as any[] }),
      _resolveLocnNames(
        context.supabase,
        items.flatMap((r) => [r.locn_pol, r.locn_pod, r.do_locn]),
      ),
    ]);

    const unitMap = new Map<string, any>();
    for (const u of (unitsRes as any).data ?? []) unitMap.set(u.unit_no, u);
    const assignMap = new Map<string, any>();
    for (const a of (assignsRes as any).data ?? []) {
      if (a.unit_no) assignMap.set(a.unit_no, a);
    }

    const enriched = items.map((r) => {
      const u = unitMap.get(r.unit_no) ?? {};
      const a = assignMap.get(r.unit_no);
      return {
        unit_no: r.unit_no,
        booking_no: r.booking_no,
        onhire_date: r.onhire_date,
        locn_pol: r.locn_pol,
        locn_pod: r.locn_pod,
        do_locn: r.do_locn,
        iso_code: u.iso_code ?? null,
        status: u.status ?? null,
        amt_ppb: u.amt_ppb ?? null,
        sale_amt_b: u.sale_amt_b ?? null,
        locn_pol_name: r.locn_pol ? locResolved.nameMap[r.locn_pol] ?? null : null,
        locn_pod_name: r.locn_pod ? locResolved.nameMap[r.locn_pod] ?? null : null,
        do_locn_name: r.do_locn ? locResolved.nameMap[r.do_locn] ?? null : null,
        linked_file_id: a?.file_id ?? null,
        linked_file_number: a?.files?.file_number ?? null,
        linked_file_status: a?.files?.status ?? null,
        accno: (r as any).accno ?? null,
        accname: (r as any).customer ?? null,
        internal_ref: (r as any).internal_ref ?? null,
      };
    });

    return { items: enriched };
  });

export const getRecentUnitsFilterOptions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const CHUNK = 1000;
    const statuses = new Set<string>();
    const isoCodes = new Set<string>();
    for (let from = 0; from < 200000; from += CHUNK) {
      const { data: chunk, error } = await context.supabase
        .from("eqs_ext_units")
        .select("status,iso_code")
        .order("unit_no", { ascending: true })
        .range(from, from + CHUNK - 1);
      if (error) throw new Error(error.message);
      if (!chunk?.length) break;
      for (const r of chunk) {
        if (r.status) statuses.add(r.status);
        if (r.iso_code) isoCodes.add(r.iso_code);
      }
      if (chunk.length < CHUNK) break;
    }
    const customers = new Set<string>();
    for (let from = 0; from < 500000; from += CHUNK) {
      const { data: chunk, error } = await context.supabase
        .from("eqs_ext_recent_units")
        .select("customer")
        .order("unit_no", { ascending: true })
        .range(from, from + CHUNK - 1);
      if (error) throw new Error(error.message);
      if (!chunk?.length) break;
      for (const r of chunk) {
        if ((r as any).customer) customers.add((r as any).customer);
      }
      if (chunk.length < CHUNK) break;
    }
    return {
      statuses: Array.from(statuses).sort(),
      isoCodes: Array.from(isoCodes).sort(),
      customers: Array.from(customers).sort(),
    };
  });


export const previewBookingFile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ booking_no: z.string().min(1).max(40) }).parse(input))
  .handler(async ({ context, data }) => {
    const booking_no = data.booking_no;
    const CHARGE_COLS = ["charge1", "charge2", "charge3", "charge4"] as const;
    const COST_COLS = ["cost1", "cost2"] as const;
    const recentSelect =
      "unit_no,booking_no,onhire_date,locn_pol,locn_pod,do_locn,accno,customer,internal_ref,department," +
      CHARGE_COLS.map((c) => `${c}_code,${c}_name,${c}_amount,${c}_currency`).join(",") +
      "," +
      COST_COLS.map((c) => `${c}_code,${c}_name,${c}_amount,${c}_currency`).join(",");
    const [recentRes, deptsRes, articlesRes] = await Promise.all([
      context.supabase
        .from("eqs_ext_recent_units")
        .select(recentSelect)
        .eq("booking_no", booking_no),
      context.supabase.from("departments").select("id,code,name").order("code"),
      context.supabase
        .from("budget_articles")
        .select("id,code,name,kind,sort_order")
        .order("kind")
        .order("sort_order"),
    ]);
    const recent = (recentRes as any).data ?? [];
    if (recent.length === 0) throw new Error(`No units found for booking ${booking_no}`);
    const booking = {
      booking_no,
      accno: (recent[0]?.accno ?? null) as string | null,
      customer: (recent[0]?.customer ?? null) as string | null,
      internal_ref: (recent[0]?.internal_ref ?? null) as string | null,
      locn_pol: recent[0]?.locn_pol ?? null,
      locn_pod: recent[0]?.locn_pod ?? null,
      do_locn: recent[0]?.do_locn ?? null,
    };

    const unitNos = Array.from(new Set(recent.map((r: any) => r.unit_no).filter(Boolean))) as string[];
    const [unitsRes, assignsRes, locResolved] = await Promise.all([
      context.supabase
        .from("eqs_ext_units")
        .select("unit_no,iso_code,amt_ppb,sale_amt_b,status")
        .in("unit_no", unitNos),
      context.supabase
        .from("file_unit_assignments")
        .select("unit_no,file_id,files(file_number)")
        .in("unit_no", unitNos)
        .eq("is_active", true),
      _resolveLocnNames(context.supabase, [
        booking.locn_pol,
        booking.locn_pod,
        booking.do_locn,
        ...recent.map((r: any) => r.locn_pol),
        ...recent.map((r: any) => r.locn_pod),
        ...recent.map((r: any) => r.do_locn),
      ]),
    ]);
    const unitMap = new Map<string, any>();
    for (const u of (unitsRes as any).data ?? []) unitMap.set(u.unit_no, u);
    const assignMap = new Map<string, any>();
    for (const a of (assignsRes as any).data ?? []) assignMap.set(a.unit_no, a);

    const units = recent.map((r: any) => {
      const u = unitMap.get(r.unit_no) ?? {};
      const a = assignMap.get(r.unit_no);
      return {
        unit_no: r.unit_no,
        iso_code: u.iso_code ?? null,
        onhire_date: r.onhire_date,
        amt_ppb: u.amt_ppb == null ? null : Number(u.amt_ppb),
        sale_amt_b: u.sale_amt_b == null ? null : Number(u.sale_amt_b),
        status: u.status ?? null,
        already_linked_file_id: a?.file_id ?? null,
        already_linked_file_number: a?.files?.file_number ?? null,
      };
    });

    // Per-type min/max (purchase = min>0, sale = max), based on units NOT already linked
    const typeAgg = new Map<string, { qty: number; min_ppb: number | null; max_sale: number | null }>();
    for (const u of units) {
      if (u.already_linked_file_id) continue;
      const t = u.iso_code ?? "UNK";
      if (!typeAgg.has(t)) typeAgg.set(t, { qty: 0, min_ppb: null, max_sale: null });
      const a = typeAgg.get(t)!;
      a.qty++;
      const p = u.amt_ppb;
      if (p != null && p > 0) a.min_ppb = a.min_ppb == null ? p : Math.min(a.min_ppb, p);
      const s = u.sale_amt_b;
      if (s != null) a.max_sale = a.max_sale == null ? s : Math.max(a.max_sale, s);
    }
    const container_types = Array.from(typeAgg.entries()).map(([container_type, a]) => ({
      container_type,
      qty: a.qty,
      default_purchase: a.min_ppb,
      default_sale: a.max_sale,
      // kept for backwards-compat with older UI code
      avg_purchase: a.min_ppb,
      avg_sale: a.max_sale,
      missing_purchase: a.min_ppb == null ? a.qty : 0,
      missing_sale: a.max_sale == null ? a.qty : 0,
    }));

    // Booking charges/costs summary by (source_code, currency)
    type ChargeAgg = {
      source_code: string;
      name: string | null;
      currency: string;
      kind: "revenue" | "cost";
      qty: number;
      sum_amount: number;
      per_unit: { unit_no: string; amount: number }[];
    };
    const chargeMap = new Map<string, ChargeAgg>();
    const pushCharge = (
      unit_no: string,
      kind: "revenue" | "cost",
      code: string | null,
      name: string | null,
      amount: number | null,
      currency: string | null,
    ) => {
      if (!code || amount == null || amount === 0) return;
      const cur = currency ?? "USD";
      const key = `${kind}::${code}::${cur}`;
      if (!chargeMap.has(key)) {
        chargeMap.set(key, {
          source_code: code,
          name: name ?? null,
          currency: cur,
          kind,
          qty: 0,
          sum_amount: 0,
          per_unit: [],
        });
      }
      const a = chargeMap.get(key)!;
      a.qty++;
      a.sum_amount += Number(amount);
      a.per_unit.push({ unit_no, amount: Number(amount) });
    };
    for (const r of recent as any[]) {
      const linked = assignMap.get(r.unit_no);
      if (linked) continue;
      for (const c of CHARGE_COLS) {
        pushCharge(r.unit_no, "revenue", r[`${c}_code`], r[`${c}_name`], r[`${c}_amount`], r[`${c}_currency`]);
      }
      for (const c of COST_COLS) {
        pushCharge(r.unit_no, "cost", r[`${c}_code`], r[`${c}_name`], r[`${c}_amount`], r[`${c}_currency`]);
      }
    }
    const chargeCodes = Array.from(new Set(Array.from(chargeMap.values()).map((c) => c.source_code)));
    let mapByCode = new Map<string, { article_id: string; article_code: string | null; article_name: string | null }>();
    if (chargeCodes.length) {
      const { data: m } = await context.supabase
        .from("cost_charge_type_mapping")
        .select("source_code,article_id,budget_articles(code,name)")
        .in("source_code", chargeCodes);
      for (const row of (m ?? []) as any[]) {
        if (row.source_code && row.article_id) {
          mapByCode.set(row.source_code, {
            article_id: row.article_id,
            article_code: row.budget_articles?.code ?? null,
            article_name: row.budget_articles?.name ?? null,
          });
        }
      }
    }
    const booking_charges = Array.from(chargeMap.values()).map((c) => {
      const mapped = mapByCode.get(c.source_code) ?? null;
      return {
        source_code: c.source_code,
        name: c.name,
        currency: c.currency,
        kind: c.kind,
        qty: c.qty,
        sum_amount: c.sum_amount,
        mapped_article_id: mapped?.article_id ?? null,
        mapped_article_code: mapped?.article_code ?? null,
        mapped_article_name: mapped?.article_name ?? null,
      };
    });

    const minOnhire = units
      .map((u: any) => u.onhire_date)
      .filter(Boolean)
      .sort()[0] ?? null;

    return {
      booking_no,
      customer_accno: booking.accno,
      customer_name: booking.customer,
      internal_ref: booking.internal_ref,
      origin_locn: booking.locn_pol ?? null,
      origin_locn_name: booking.locn_pol ? locResolved.nameMap[booking.locn_pol] ?? null : null,
      origin_subregion: booking.locn_pol ? locResolved.subregionMap[booking.locn_pol] ?? null : null,
      origin_subregion_desc: booking.locn_pol ? locResolved.subregionDescMap[booking.locn_pol] ?? null : null,
      origin_country_code: booking.locn_pol ? locResolved.countryMap[booking.locn_pol] ?? null : null,
      dest_locn: booking.do_locn ?? booking.locn_pod ?? null,
      dest_locn_name: (() => {
        const c = booking.do_locn ?? booking.locn_pod;
        return c ? locResolved.nameMap[c] ?? null : null;
      })(),
      dest_subregion: (() => {
        const c = booking.do_locn ?? booking.locn_pod;
        return c ? locResolved.subregionMap[c] ?? null : null;
      })(),
      dest_subregion_desc: (() => {
        const c = booking.do_locn ?? booking.locn_pod;
        return c ? locResolved.subregionDescMap[c] ?? null : null;
      })(),
      dest_country_code: (() => {
        const c = booking.do_locn ?? booking.locn_pod;
        return c ? locResolved.countryMap[c] ?? null : null;
      })(),
      planned_departure_date: minOnhire,
      units,
      container_types,
      departments: (deptsRes as any).data ?? [],
      suggested_department_code: (() => {
        const counts = new Map<string, number>();
        for (const r of recent) {
          const c = (r as any).department;
          if (c) counts.set(c, (counts.get(c) ?? 0) + 1);
        }
        let best: string | null = null; let bestN = 0;
        for (const [c, n] of counts) if (n > bestN) { best = c; bestN = n; }
        return best;
      })(),
      suggested_department_id: (() => {
        const counts = new Map<string, number>();
        for (const r of recent) {
          const c = (r as any).department;
          if (c) counts.set(c, (counts.get(c) ?? 0) + 1);
        }
        let best: string | null = null; let bestN = 0;
        for (const [c, n] of counts) if (n > bestN) { best = c; bestN = n; }
        if (!best) return null;
        const d = ((deptsRes as any).data ?? []).find((x: any) => x.code === best);
        return d?.id ?? null;
      })(),
      available_articles: (articlesRes as any).data ?? [],
      booking_charges,
    };
  });


export const createFileFromBooking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        booking_no: z.string().min(1).max(40),
        department_id: z.string().uuid(),
        currency: z.enum(["USD", "EUR"]).default("USD"),
        type_overrides: z
          .array(
            z.object({
              container_type: z.string().min(1).max(20),
              purchase_per_unit: z.number().optional().nullable(),
              sale_per_unit: z.number().optional().nullable(),
            }),
          )
          .optional(),
        excluded_units: z.array(z.string().min(1).max(40)).optional(),
        extra_plan_lines: z
          .array(
            z.object({
              article_id: z.string().uuid(),
              container_type: z.string().min(1).max(20).optional().nullable(),
              amount_per_unit: z.number(),
              currency: z.enum(["USD", "EUR"]).default("USD"),
            }),
          )
          .optional(),
        booking_charges: z
          .array(
            z.object({
              source_code: z.string().min(1).max(40),
              currency: z.string().min(1).max(8),
              article_id: z.string().uuid(),
              kind: z.enum(["revenue", "cost"]),
            }),
          )
          .optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const CHARGE_COLS = ["charge1", "charge2", "charge3", "charge4"] as const;
    const COST_COLS = ["cost1", "cost2"] as const;
    const recentSelect =
      "unit_no,booking_no,onhire_date,locn_pol,locn_pod,do_locn,accno,customer,internal_ref,lessee_order,grade,daily_rate,repl_value,free_min_days," +
      CHARGE_COLS.map((c) => `${c}_code,${c}_amount,${c}_currency`).join(",") +
      "," +
      COST_COLS.map((c) => `${c}_code,${c}_amount,${c}_currency,${c}_supplier_accno`).join(",");
    const { data: recent } = await context.supabase
      .from("eqs_ext_recent_units")
      .select(recentSelect)
      .eq("booking_no", data.booking_no);
    const recentRows = (recent ?? []) as any[];
    if (recentRows.length === 0) throw new Error("No units for booking");
    const firstWith = <K extends string>(key: K): any =>
      recentRows.find((r: any) => r[key] != null && r[key] !== "")?.[key] ?? null;
    const booking = {
      booking_no: data.booking_no,
      accno: (recentRows[0]?.accno ?? null) as string | null,
      customer: (recentRows[0]?.customer ?? null) as string | null,
      internal_ref: (recentRows[0]?.internal_ref ?? null) as string | null,
      lessee_order: firstWith("lessee_order") as string | null,
      locn_pol: recentRows[0]?.locn_pol ?? null,
      locn_pod: recentRows[0]?.locn_pod ?? null,
      do_locn: recentRows[0]?.do_locn ?? null,
    };

    const unitNos = Array.from(new Set(recentRows.map((r: any) => r.unit_no).filter(Boolean))) as string[];
    const [unitsRes, assignsRes] = await Promise.all([
      context.supabase
        .from("eqs_ext_units")
        .select("unit_no,iso_code,amt_ppb,sale_amt_b")
        .in("unit_no", unitNos),
      context.supabase
        .from("file_unit_assignments")
        .select("unit_no")
        .in("unit_no", unitNos)
        .eq("is_active", true),
    ]);
    const unitMap = new Map<string, any>();
    for (const u of (unitsRes as any).data ?? []) unitMap.set(u.unit_no, u);
    const alreadyLinked = new Set<string>(
      ((assignsRes as any).data ?? []).map((r: any) => r.unit_no),
    );
    const excluded = new Set<string>((data.excluded_units ?? []).map((u) => u.trim().toUpperCase()));

    const isIncluded = (unit_no: string) =>
      !alreadyLinked.has(unit_no) && !excluded.has(unit_no.trim().toUpperCase());

    // Per-type min/max: purchase = min>0, sale = max (excluded units skipped)
    const typeAgg = new Map<string, { qty: number; min_ppb: number | null; max_sale: number | null }>();
    for (const r of recentRows) {
      if (!isIncluded(r.unit_no)) continue;
      const u = unitMap.get(r.unit_no) ?? {};
      const t = (u.iso_code as string) ?? "UNK";
      if (!typeAgg.has(t)) typeAgg.set(t, { qty: 0, min_ppb: null, max_sale: null });
      const a = typeAgg.get(t)!;
      a.qty++;
      const p = u.amt_ppb == null ? null : Number(u.amt_ppb);
      if (p != null && p > 0) a.min_ppb = a.min_ppb == null ? p : Math.min(a.min_ppb, p);
      const s = u.sale_amt_b == null ? null : Number(u.sale_amt_b);
      if (s != null) a.max_sale = a.max_sale == null ? s : Math.max(a.max_sale, s);
    }
    if (typeAgg.size === 0)
      throw new Error("No units selected for this booking");

    const overridesByType = new Map<string, { purchase?: number | null; sale?: number | null }>();
    for (const o of data.type_overrides ?? []) {
      overridesByType.set(o.container_type, { purchase: o.purchase_per_unit, sale: o.sale_per_unit });
    }

    const planRows: Array<{ container_type: string; qty: number; purchase: number; sale: number }> = [];
    for (const [t, a] of typeAgg) {
      const ov = overridesByType.get(t);
      const purchase = ov?.purchase != null && Number.isFinite(ov.purchase)
        ? Number(ov.purchase)
        : a.min_ppb != null
          ? a.min_ppb
          : NaN;
      const sale = ov?.sale != null && Number.isFinite(ov.sale)
        ? Number(ov.sale)
        : a.max_sale != null
          ? a.max_sale
          : NaN;
      if (!Number.isFinite(purchase))
        throw new Error(`Purchase price required for container type ${t}`);
      if (!Number.isFinite(sale))
        throw new Error(`Sale price required for container type ${t}`);
      planRows.push({ container_type: t, qty: a.qty, purchase, sale });
    }
    const qtyByType = new Map<string, number>(planRows.map((r) => [r.container_type, r.qty]));
    const totalQty = planRows.reduce((s, r) => s + r.qty, 0);

    // Resolve subregions/countries via locations
    const { nameMap: _nm, countryMap, subregionMap } = await _resolveLocnNames(
      context.supabase,
      [booking.locn_pol, booking.locn_pod, booking.do_locn],
    );
    const destLocn = booking.do_locn ?? booking.locn_pod;

    const planned_dep = recentRows
      .filter((r: any) => isIncluded(r.unit_no))
      .map((r: any) => r.onhire_date)
      .filter(Boolean)
      .sort()[0] ?? null;

    const notesParts = [`Auto-created from booking ${data.booking_no}`];
    if (booking.internal_ref) notesParts.push(`Internal ref: ${booking.internal_ref}`);

    // Create the file
    const { data: idRet, error: cErr } = await context.supabase.rpc("fn_create_file", {
      p_department_id: data.department_id,
      p_direction: "EXPORT",
      p_customer_accno: booking.accno ?? undefined,
      p_customer_name: booking.customer ?? undefined,
      p_origin_subregion: booking.locn_pol ? subregionMap[booking.locn_pol] ?? undefined : undefined,
      p_dest_subregion: destLocn ? subregionMap[destLocn] ?? undefined : undefined,
      p_origin_locn: booking.locn_pol ?? undefined,
      p_dest_locn: destLocn ?? undefined,
      p_planned_departure_date: planned_dep ?? undefined,
      p_planned_arrival_date: undefined,
      p_notes: notesParts.join(" | "),
    });
    if (cErr) throw new Error(cErr.message);
    const fileId = idRet as unknown as string;

    // Patch country codes + lessee_order
    const patch: any = {};
    if (booking.locn_pol && countryMap[booking.locn_pol])
      patch.origin_country_code = countryMap[booking.locn_pol];
    if (destLocn && countryMap[destLocn]) patch.dest_country_code = countryMap[destLocn];
    if (booking.lessee_order) patch.lessee_order = booking.lessee_order;
    if (Object.keys(patch).length) {
      await context.supabase.from("files").update(patch).eq("id", fileId);
    }

    // Persist explicit file ↔ booking link
    await context.supabase.rpc("fn_assign_booking", {
      p_file_id: fileId,
      p_booking_no: data.booking_no,
      p_source: "create_from_booking",
    });



    // Container types — prefill grade/rates/charges/costs from the first included unit of each type
    const firstRecentForType = new Map<string, any>();
    for (const r of recentRows) {
      if (!isIncluded(r.unit_no)) continue;
      const u = unitMap.get(r.unit_no) ?? {};
      const t = (u.iso_code as string) ?? "UNK";
      if (!firstRecentForType.has(t)) firstRecentForType.set(t, r);
    }
    const ctRows = planRows.map((r) => {
      const src = firstRecentForType.get(r.container_type) ?? {};
      return {
        file_id: fileId,
        container_type: r.container_type,
        planned_qty: r.qty,
        grade: src.grade ?? null,
        daily_rate: src.daily_rate ?? null,
        repl_value: src.repl_value ?? null,
        free_min_days: src.free_min_days ?? null,
        charge1_code: src.charge1_code ?? null,
        charge1_amount: src.charge1_amount ?? null,
        charge2_code: src.charge2_code ?? null,
        charge2_amount: src.charge2_amount ?? null,
        charge3_code: src.charge3_code ?? null,
        charge3_amount: src.charge3_amount ?? null,
        charge4_code: src.charge4_code ?? null,
        charge4_amount: src.charge4_amount ?? null,
        cost1_code: src.cost1_code ?? null,
        cost1_currency: src.cost1_currency ?? null,
        cost1_amount: src.cost1_amount ?? null,
        cost1_supplier_accno: src.cost1_supplier_accno ?? null,
        cost2_code: src.cost2_code ?? null,
        cost2_currency: src.cost2_currency ?? null,
        cost2_amount: src.cost2_amount ?? null,
        cost2_supplier_accno: src.cost2_supplier_accno ?? null,
      };
    });
    if (ctRows.length) {
      const { error: ctErr } = await context.supabase
        .from("file_container_types")
        .insert(ctRows as never);
      if (ctErr) throw new Error(ctErr.message);
    }

    // Assign units (only included)
    for (const r of recentRows) {
      if (!isIncluded(r.unit_no)) continue;
      const { error: aErr } = await context.supabase.rpc("fn_assign_unit_with_check", {
        p_file_id: fileId,
        p_unit_no: r.unit_no.trim().toUpperCase(),
        p_booking_no: data.booking_no,
      });
      if (aErr) throw new Error(aErr.message);
    }
    await context.supabase.rpc("fn_refresh_file_finance_lines", { p_file_id: fileId });

    // Resolve PP + SP article ids
    const { data: arts } = await context.supabase
      .from("budget_articles")
      .select("id,code")
      .in("code", [PP_ARTICLE_CODE, SP_ARTICLE_CODE]);
    const artByCode = new Map<string, string>();
    for (const a of arts ?? []) artByCode.set(a.code, a.id);
    const ppId = artByCode.get(PP_ARTICLE_CODE);
    const spId = artByCode.get(SP_ARTICLE_CODE);

    const planLines: any[] = [];
    const factLines: any[] = [];
    for (const r of planRows) {
      if (ppId) {
        planLines.push({
          file_id: fileId,
          article_id: ppId,
          container_type: r.container_type,
          planned_qty: r.qty,
          amount_per_unit: -Math.abs(r.purchase),
          currency: data.currency,
          source_type: "IMPORT",
        });
      }
      if (spId) {
        planLines.push({
          file_id: fileId,
          article_id: spId,
          container_type: r.container_type,
          planned_qty: r.qty,
          amount_per_unit: Math.abs(r.sale),
          currency: data.currency,
          source_type: "IMPORT",
        });
      }
    }

    // Container purchase → one fact row per included unit
    if (ppId) {
      const purchaseByType = new Map<string, number>(
        planRows.map((r) => [r.container_type, r.purchase]),
      );
      for (const r of recentRows) {
        if (!isIncluded(r.unit_no)) continue;
        const u = unitMap.get(r.unit_no) ?? {};
        const t = (u.iso_code as string) ?? "UNK";
        const p = purchaseByType.get(t);
        if (p == null || !Number.isFinite(p)) continue;
        factLines.push({
          file_id: fileId,
          article_id: ppId,
          unit_no: r.unit_no,
          amount: -Math.abs(p),
          currency: data.currency,
          source_finance_line_id: null,
        });

      }
    }

    // Extra plan lines (manual articles from form)
    for (const e of data.extra_plan_lines ?? []) {
      const ct = e.container_type ?? null;
      const qty = ct ? qtyByType.get(ct) ?? 0 : totalQty;
      if (qty <= 0) continue;
      planLines.push({
        file_id: fileId,
        article_id: e.article_id,
        container_type: ct,
        planned_qty: qty,
        amount_per_unit: e.amount_per_unit,
        currency: e.currency,
        source_type: "MANUAL",
      });
    }

    // Booking charges → plan (per container type) + fact (per unit)
    if ((data.booking_charges ?? []).length) {
      const wantedKeys = new Map<string, { article_id: string; kind: "revenue" | "cost" }>();
      for (const bc of data.booking_charges ?? []) {
        wantedKeys.set(`${bc.source_code}::${bc.currency}`, { article_id: bc.article_id, kind: bc.kind });
      }
      // Aggregate per source_code::currency::container_type
      type Agg = {
        qty: number;
        sum: number;
        article_id: string;
        kind: "revenue" | "cost";
        currency: string;
        container_type: string;
      };
      const agg = new Map<string, Agg>();
      const consume = (
        unit_no: string,
        kind: "revenue" | "cost",
        code: string | null,
        amount: number | null,
        currency: string | null,
      ) => {
        if (!code || amount == null || amount === 0) return;
        const cur = currency ?? "USD";
        const wantKey = `${code}::${cur}`;
        const want = wantedKeys.get(wantKey);
        if (!want || want.kind !== kind) return;
        const u = unitMap.get(unit_no) ?? {};
        const ct = (u.iso_code as string) ?? "UNK";
        const aggKey = `${code}::${cur}::${ct}`;
        if (!agg.has(aggKey))
          agg.set(aggKey, { qty: 0, sum: 0, article_id: want.article_id, kind, currency: cur, container_type: ct });
        const a = agg.get(aggKey)!;
        a.qty++;
        a.sum += Number(amount);
        // Booking-charge facts intentionally NOT inserted into file_budget_fact_lines:
        // real PUF/etc. revenue arrives later as actual finance lines. The plan row
        // (added below) already represents the expected amount.
      };

      for (const r of recentRows) {
        if (!isIncluded(r.unit_no)) continue;
        for (const c of CHARGE_COLS) {
          consume(r.unit_no, "revenue", r[`${c}_code`], r[`${c}_amount`], r[`${c}_currency`]);
        }
        for (const c of COST_COLS) {
          consume(r.unit_no, "cost", r[`${c}_code`], r[`${c}_amount`], r[`${c}_currency`]);
        }
      }
      for (const [, a] of agg) {
        if (a.qty <= 0) continue;
        const avg = a.sum / a.qty;
        const signed = a.kind === "cost" ? -Math.abs(avg) : Math.abs(avg);
        planLines.push({
          file_id: fileId,
          article_id: a.article_id,
          container_type: a.container_type,
          planned_qty: a.qty,
          amount_per_unit: signed,
          currency: a.currency,
          source_type: "IMPORT",
        });
      }
    }


    if (planLines.length) {
      const { error: plErr } = await context.supabase
        .from("file_budget_plan_lines")
        .insert(planLines);
      if (plErr) throw new Error(plErr.message);
    }
    if (factLines.length) {
      const { error: flErr } = await context.supabase
        .from("file_budget_fact_lines")
        .insert(factLines);
      if (flErr) throw new Error(flErr.message);
    }

    return { id: fileId };
  });


export const getLocationsForFilter = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const CHUNK = 1000;
    const MAX = 50000;
    const locs: { locn_id: string; locn_desc: string | null; subregion_id: string | null; subregion_desc: string | null }[] = [];
    for (let from = 0; from < MAX; from += CHUNK) {
      const { data, error } = await context.supabase
        .from("eqs_ext_locations_subregions")
        .select("locn_id,locn_desc,subregion_id,subregion_desc")
        .range(from, from + CHUNK - 1);
      if (error) throw new Error(error.message);
      if (!data?.length) break;
      for (const r of data) {
        if (r.locn_id) locs.push(r as any);
      }
      if (data.length < CHUNK) break;
    }
    return { locations: locs };
  });

// ============================================================================
// Finance tab: list invoices linked to a file with drill-down to cost types
// and containers (units). Returns aggregated structure + invoice totals from
// eqs_ext_finance_totals (invoice headers).
// ============================================================================
export const getFileFinance = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { data: ffl, error: fErr } = await context.supabase
      .from("file_finance_lines")
      .select(
        "unit_no,source_type,source_code,article_id,amount,currency,invoice_no,invoice_date,dte_acct",
      )
      .eq("file_id", data.id);

    if (fErr) throw new Error(fErr.message);

    const { data: articles } = await context.supabase
      .from("budget_articles")
      .select("id,kind");
    const kindById = new Map<string, string>();
    for (const a of articles ?? []) {
      if ((a as any).id) kindById.set((a as any).id, (a as any).kind);
    }

    const lines = (ffl ?? []) as any[];
    const invoiceNos = Array.from(
      new Set(lines.map((l) => l.invoice_no).filter(Boolean)),
    ) as string[];

    const totalsByKey = new Map<
      string,
      {
        total_amount_local: number | null;
        document_date: string | null;
        party_name: string | null;
        document_type: string | null;
      }
    >();
    if (invoiceNos.length > 0) {
      const { data: totals } = await context.supabase
        .from("eqs_ext_finance_totals")
        .select(
          "document_no,currency,total_amount_local,document_date,party_name,document_type",
        )
        .in("document_no", invoiceNos);
      for (const t of totals ?? []) {
        const key = `${(t as any).document_no}::${(t as any).currency ?? ""}`;
        totalsByKey.set(key, {
          total_amount_local:
            (t as any).total_amount_local == null
              ? null
              : Number((t as any).total_amount_local),
          document_date: (t as any).document_date ?? null,
          party_name: (t as any).party_name ?? null,
          document_type: (t as any).document_type ?? null,
        });
      }
    }

    // Aggregate: invoice -> cost_type -> unit
    type UnitAgg = { unit_no: string | null; amount_on_file: number };
    type CostTypeAgg = {
      source_code: string | null;
      amount_on_file: number;
      units: Map<string, UnitAgg>;
    };
    type InvoiceAgg = {
      invoice_no: string;
      is_synthetic: boolean;
      currency: string;
      invoice_date: string | null;
      amount_on_file: number;
      booked_amount: number;
      accrued_amount: number;
      kinds: Set<"revenue" | "cost">;
      cost_types: Map<string, CostTypeAgg>;
    };

    const lineKindOf = (l: any): "revenue" | "cost" | null => {
      const k = l.article_id ? kindById.get(l.article_id) : null;
      if (k === "REVENUE") return "revenue";
      if (k === "COST") return "cost";
      const st = String(l.source_type ?? "").toLowerCase();
      if (st.includes("charge")) return "revenue";
      if (st.includes("cost")) return "cost";
      return null;
    };

    const invMap = new Map<string, InvoiceAgg>();
    for (const l of lines) {
      const currency = (l.currency ?? "USD") as string;
      const hasInv = !!l.invoice_no;
      const invKey = hasInv
        ? `${l.invoice_no}::${currency}`
        : `__syn__::${l.source_code ?? "—"}::${currency}`;
      const displayInvNo = hasInv ? l.invoice_no : (l.source_code ?? "—");
      const rowDate = l.invoice_date ?? l.dte_acct ?? null;
      let inv = invMap.get(invKey);
      if (!inv) {
        inv = {
          invoice_no: displayInvNo,
          is_synthetic: !hasInv,
          currency,
          invoice_date: rowDate,
          amount_on_file: 0,
          booked_amount: 0,
          accrued_amount: 0,
          kinds: new Set(),
          cost_types: new Map(),
        };
        invMap.set(invKey, inv);
      } else if (rowDate && (!inv.invoice_date || rowDate > inv.invoice_date)) {
        inv.invoice_date = rowDate;
      }

      const kind = lineKindOf(l);
      const raw = Number(l.amount ?? 0);
      // Preserve original sign for revenue (so credit notes stay negative);
      // normalize cost to negative regardless of how the accrual was stored.
      const amt = kind === "cost" ? -Math.abs(raw) : raw;
      if (kind) inv.kinds.add(kind);

      inv.amount_on_file += amt;
      if (inv.is_synthetic) inv.accrued_amount += amt;
      else inv.booked_amount += amt;

      const ctKey = l.source_code ?? "—";
      let ct = inv.cost_types.get(ctKey);
      if (!ct) {
        ct = { source_code: l.source_code ?? null, amount_on_file: 0, units: new Map() };
        inv.cost_types.set(ctKey, ct);
      }
      ct.amount_on_file += amt;

      const uKey = l.unit_no ?? "—";
      let u = ct.units.get(uKey);
      if (!u) {
        u = { unit_no: l.unit_no ?? null, amount_on_file: 0 };
        ct.units.set(uKey, u);
      }
      u.amount_on_file += amt;
    }

    const invoices = Array.from(invMap.values())
      .map((inv) => {
        const header = inv.is_synthetic
          ? null
          : totalsByKey.get(`${inv.invoice_no}::${inv.currency}`);
        const kind =
          inv.kinds.size === 0
            ? null
            : inv.kinds.size > 1
              ? "mixed"
              : (Array.from(inv.kinds)[0] as "revenue" | "cost");
        return {
          invoice_no: inv.invoice_no,
          is_synthetic: inv.is_synthetic,
          status: inv.is_synthetic ? ("accrual" as const) : ("booked" as const),
          currency: inv.currency,
          invoice_date: inv.invoice_date,
          party_name: header?.party_name ?? null,
          document_type: header?.document_type ?? null,
          kind,
          invoice_total:
            header?.total_amount_local == null
              ? null
              : kind === "cost"
                ? -Math.abs(header.total_amount_local)
                : header.total_amount_local,
          amount_on_file: inv.amount_on_file,
          booked_amount: inv.booked_amount,
          accrued_amount: inv.accrued_amount,
          cost_types: Array.from(inv.cost_types.values())
            .map((ct) => ({
              source_code: ct.source_code,
              amount_on_file: ct.amount_on_file,
              units: Array.from(ct.units.values()).sort((a, b) =>
                (a.unit_no ?? "").localeCompare(b.unit_no ?? ""),
              ),
            }))
            .sort((a, b) =>
              (a.source_code ?? "").localeCompare(b.source_code ?? ""),
            ),
        };
      })
      .sort((a, b) => {
        const da = a.invoice_date ?? "";
        const db = b.invoice_date ?? "";
        if (da !== db) return db.localeCompare(da);
        return a.invoice_no.localeCompare(b.invoice_no);
      });


    return { invoices };
  });

export const refreshFileFinance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ file_id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const [refreshRes] = await Promise.all([
      context.supabase.rpc("fn_refresh_file_finance_lines", { p_file_id: data.file_id }),
      recomputeAllAssignmentsEffectiveTo(context.supabase, data.file_id),
    ]);
    if (refreshRes.error) throw new Error(refreshRes.error.message);
    return { ok: true, count: refreshRes.data ?? 0 };
  });

// =========================================================================
// Booking ↔ File link management
// =========================================================================

export const listFileBookings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ file_id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { data: rows, error } = await context.supabase
      .from("file_booking_assignments")
      .select("id,booking_no,source,assigned_at,assigned_by,is_active,unlinked_at")
      .eq("file_id", data.file_id)
      .eq("is_active", true)
      .order("assigned_at", { ascending: true });
    if (error) throw new Error(error.message);

    const bookings = (rows ?? []) as any[];
    const bookingNos = bookings.map((b) => b.booking_no);

    // Linked unit counts
    const linkedCounts = new Map<string, number>();
    if (bookingNos.length) {
      const { data: linked } = await context.supabase
        .from("file_unit_assignments")
        .select("booking_no,unit_no")
        .eq("file_id", data.file_id)
        .eq("is_active", true)
        .in("booking_no", bookingNos);
      for (const r of (linked ?? []) as any[]) {
        linkedCounts.set(r.booking_no, (linkedCounts.get(r.booking_no) ?? 0) + 1);
      }
    }

    // Available-but-not-linked units per booking
    const pending: Record<string, Array<{ unit_no: string; iso_code: string | null; onhire_date: string | null; locn_pol: string | null; locn_pod: string | null }>> = {};
    if (bookingNos.length) {
      const { data: recent } = await context.supabase
        .from("eqs_ext_recent_units")
        .select("unit_no,booking_no,iso_code,onhire_date,locn_pol,locn_pod")
        .in("booking_no", bookingNos);
      const { data: linkedAll } = await context.supabase
        .from("file_unit_assignments")
        .select("unit_no")
        .eq("file_id", data.file_id)
        .eq("is_active", true);
      const linkedUnitSet = new Set(((linkedAll ?? []) as any[]).map((r) => r.unit_no));
      for (const bk of bookingNos) pending[bk] = [];
      for (const r of (recent ?? []) as any[]) {
        if (!r.unit_no || linkedUnitSet.has(r.unit_no)) continue;
        (pending[r.booking_no] ??= []).push({
          unit_no: r.unit_no,
          iso_code: r.iso_code ?? null,
          onhire_date: r.onhire_date ?? null,
          locn_pol: r.locn_pol ?? null,
          locn_pod: r.locn_pod ?? null,
        });
      }
    }

    return {
      bookings: bookings.map((b) => ({
        id: b.id,
        booking_no: b.booking_no,
        source: b.source,
        assigned_at: b.assigned_at,
        linked_units: linkedCounts.get(b.booking_no) ?? 0,
        pending_units: pending[b.booking_no] ?? [],
      })),
    };
  });

export const assignFileBooking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ file_id: z.string().uuid(), booking_no: z.string().min(1).max(40) }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const booking_no = data.booking_no.trim();
    // Verify booking exists in either recent units or bookings reference; do not hard-fail.
    const [{ data: ru, error: ruErr }, { data: bk, error: bkErr }] = await Promise.all([
      context.supabase
        .from("eqs_ext_recent_units")
        .select("unit_no")
        .eq("booking_no", booking_no)
        .limit(1),
      context.supabase
        .from("eqs_ext_bookings")
        .select("booking_no")
        .eq("booking_no", booking_no)
        .limit(1),
    ]);
    if (ruErr) throw new Error(ruErr.message);
    if (bkErr) throw new Error(bkErr.message);
    const foundInExt = (ru?.length ?? 0) > 0 || (bk?.length ?? 0) > 0;

    const { error } = await context.supabase.rpc("fn_assign_booking", {
      p_file_id: data.file_id,
      p_booking_no: booking_no,
      p_source: "manual",
    });
    if (error) throw new Error(error.message);
    return { ok: true, found_in_ext: foundInExt };
  });

export const unlinkFileBooking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ assignment_id: z.string().uuid(), file_id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: unlinked, error } = await context.supabase.rpc("fn_unlink_booking", {
      p_assignment_id: data.assignment_id,
    });
    if (error) throw new Error(error.message);
    await Promise.all([
      recomputeUnitWarnings(context.supabase, data.file_id),
      context.supabase.rpc("fn_refresh_file_finance_lines", { p_file_id: data.file_id }),
      recomputeAllAssignmentsEffectiveTo(context.supabase, data.file_id),
    ]);
    return { ok: true, unlinked_units: (unlinked as unknown as number) ?? 0 };
  });

export const syncFileBookingUnits = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ file_id: z.string().uuid(), booking_no: z.string().min(1).max(40) }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: added, error } = await context.supabase.rpc("fn_sync_booking_units", {
      p_file_id: data.file_id,
      p_booking_no: data.booking_no,
    });
    if (error) throw new Error(error.message);
    await Promise.all([
      recomputeUnitWarnings(context.supabase, data.file_id),
      context.supabase.rpc("fn_refresh_file_finance_lines", { p_file_id: data.file_id }),
      recomputeAllAssignmentsEffectiveTo(context.supabase, data.file_id),
    ]);
    return { ok: true, added: (added as unknown as number) ?? 0 };
  });

export const refreshFileFromExt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ file_id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { data: res, error } = await context.supabase.rpc("fn_refresh_file_from_ext", {
      p_file_id: data.file_id,
    });
    if (error) throw new Error(error.message);
    await Promise.all([
      recomputeUnitWarnings(context.supabase, data.file_id),
      recomputeAllAssignmentsEffectiveTo(context.supabase, data.file_id),
    ]);
    const r = (res ?? {}) as { added_units?: number; finance_rows?: number };
    return { ok: true, added_units: r.added_units ?? 0, finance_rows: r.finance_rows ?? 0 };
  });

export const refreshFilesFromExt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        file_ids: z.array(z.string().uuid()).optional(),
        scope: z.enum(["open", "all_visible"]).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    let fileIds = data.file_ids ?? [];
    if (fileIds.length === 0) {
      // default: all non-terminal files
      const { data: rows, error } = await context.supabase
        .from("files")
        .select("id,status")
        .in("status", ["DR", "OP", "RP"]);
      if (error) throw new Error(error.message);
      fileIds = ((rows ?? []) as any[]).map((r) => r.id);
    } else if (data.scope === "open") {
      const { data: rows, error } = await context.supabase
        .from("files")
        .select("id,status")
        .in("id", fileIds)
        .in("status", ["DR", "OP", "RP"]);
      if (error) throw new Error(error.message);
      fileIds = ((rows ?? []) as any[]).map((r) => r.id);
    }

    let added = 0;
    let finance = 0;
    let processed = 0;
    const errors: Array<{ file_id: string; message: string }> = [];

    for (const fid of fileIds) {
      try {
        const { data: res, error } = await context.supabase.rpc("fn_refresh_file_from_ext", {
          p_file_id: fid,
        });
        if (error) throw new Error(error.message);
        const r = (res ?? {}) as { added_units?: number; finance_rows?: number };
        added += r.added_units ?? 0;
        finance += r.finance_rows ?? 0;
        processed += 1;
        await Promise.all([
          recomputeUnitWarnings(context.supabase, fid),
          recomputeAllAssignmentsEffectiveTo(context.supabase, fid),
        ]);
      } catch (e: any) {
        errors.push({ file_id: fid, message: e?.message ?? String(e) });
      }
    }
    return { ok: true, processed, added_units: added, finance_rows: finance, errors };
  });


// ============================================================
// Reporting: File financial report
// ============================================================
export const getFileFinancialReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        status: z.enum(["DR", "OP", "RP", "RCL", "CL", "CN"]),
        date_from: z.string(),
        date_to: z.string(),
        current_status: z.enum(["DR", "OP", "RP", "RCL", "CL", "CN"]).nullable().optional(),
        include_cancelled: z.boolean().optional().default(false),
        add_accruals: z.boolean().optional().default(false),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const dateCol: Record<string, string> = {
      DR: "created_at",
      OP: "op_date",
      RP: "rp_date",
      RCL: "rcl_date",
      CL: "cl_date",
      CN: "cn_date",
    };
    const col = dateCol[data.status];

    let q = context.supabase
      .from("files")
      .select(
        "id,file_number,status,customer_accno,customer_name,department_id,sales_manager_id,sales_person_id,created_at,fx_rate_eur_usd,op_date,rp_date,rcl_date,cl_date,cn_date," +
          "departments(id,code,name)," +
          "sales_manager:profiles!files_sales_manager_id_fkey(id,full_name,email)," +
          "sales_person:sales_persons!files_sales_person_id_fkey(id,full_name)",
      )
      .gte(col, data.date_from)
      .lte(col, data.date_to);

    if (data.current_status) q = q.eq("status", data.current_status);
    if (!data.include_cancelled && data.status !== "CN") q = q.neq("status", "CN");

    const { data: files, error: fErr } = await q;
    if (fErr) throw new Error(fErr.message);

    const fileIds = (files ?? []).map((f: any) => f.id);
    if (fileIds.length === 0) return { rows: [] as any[] };

    const toUsd = (amt: number, currency: string | null | undefined, fx: number): number => {
      const cur = String(currency ?? "USD").toUpperCase();
      if (cur === "EUR" && fx > 0) return amt * fx;
      return amt;
    };

    // Active units per file + (unit_type -> units) per file
    const { data: assigns } = await context.supabase
      .from("file_unit_assignments")
      .select("file_id,unit_no,unit_type,is_active")
      .in("file_id", fileIds);
    const unitsByFile = new Map<string, number>();
    const typeUnitsByFile = new Map<string, Map<string, Set<string>>>();
    for (const a of assigns ?? []) {
      const fid = (a as any).file_id as string;
      if ((a as any).is_active) {
        unitsByFile.set(fid, (unitsByFile.get(fid) ?? 0) + 1);
      }
      const u = (a as any).unit_no as string | null;
      const t = (a as any).unit_type as string | null;
      if (u && t) {
        let m = typeUnitsByFile.get(fid);
        if (!m) {
          m = new Map();
          typeUnitsByFile.set(fid, m);
        }
        let s = m.get(t);
        if (!s) {
          s = new Set();
          m.set(t, s);
        }
        s.add(u);
      }
    }

    // Container types per file (planned qty)
    const { data: ctRows } = await context.supabase
      .from("file_container_types")
      .select("file_id,container_type,planned_qty")
      .in("file_id", fileIds);
    const ctQtyByFile = new Map<string, Map<string, number>>();
    for (const c of ctRows ?? []) {
      const fid = (c as any).file_id as string;
      let m = ctQtyByFile.get(fid);
      if (!m) {
        m = new Map();
        ctQtyByFile.set(fid, m);
      }
      m.set((c as any).container_type, Number((c as any).planned_qty) || 0);
    }

    const { data: planLines } = await context.supabase
      .from("file_budget_plan_lines")
      .select("file_id,article_id,currency,total_amount,amount_per_unit,planned_qty,container_type")
      .in("file_id", fileIds);

    const { data: ffl } = await context.supabase
      .from("file_finance_lines")
      .select("file_id,unit_no,source_type,source_code,article_id,amount,currency,invoice_no")
      .in("file_id", fileIds);

    const { data: bfl } = await context.supabase
      .from("file_budget_fact_lines")
      .select("file_id,unit_no,article_id,amount,currency")
      .in("file_id", fileIds)
      .not("unit_no", "is", null);

    const { data: mapRows } = await context.supabase
      .from("cost_charge_type_mapping")
      .select("source_type,source_code,article_id");
    const sourceToArticle = new Map<string, string>();
    for (const m of mapRows ?? []) {
      sourceToArticle.set(
        `${(m as any).source_type}::${(m as any).source_code}`,
        (m as any).article_id,
      );
    }

    const allArticleIds = new Set<string>();
    for (const r of planLines ?? []) if ((r as any).article_id) allArticleIds.add((r as any).article_id);
    for (const r of ffl ?? []) if ((r as any).article_id) allArticleIds.add((r as any).article_id);
    for (const r of bfl ?? []) if ((r as any).article_id) allArticleIds.add((r as any).article_id);
    for (const aid of sourceToArticle.values()) allArticleIds.add(aid);
    const articleKind = new Map<string, "REVENUE" | "COST" | null>();
    if (allArticleIds.size > 0) {
      const { data: aRows } = await context.supabase
        .from("budget_articles")
        .select("id,kind")
        .in("id", Array.from(allArticleIds));
      for (const a of aRows ?? []) articleKind.set((a as any).id, (a as any).kind ?? null);
    }

    const groupBy = <T extends { file_id: string }>(rows: T[]) => {
      const m = new Map<string, T[]>();
      for (const r of rows) {
        const arr = m.get(r.file_id) ?? [];
        arr.push(r);
        m.set(r.file_id, arr);
      }
      return m;
    };
    const fflByFile = groupBy((ffl ?? []) as any[]);
    const bflByFile = groupBy((bfl ?? []) as any[]);
    const planByFile = groupBy((planLines ?? []) as any[]);

    const PP_CODES = new Set(["PURC", "RCTP"]);

    const actBudgByFile = new Map<string, { rev: number; cost: number }>();
    const financeByFile = new Map<string, { rev: number; cost: number }>();

    for (const f of (files ?? []) as any[]) {
      const fid = f.id as string;
      const fx = Number(f.fx_rate_eur_usd ?? 0);
      const fileFfl = fflByFile.get(fid) ?? [];
      const fileBfl = bflByFile.get(fid) ?? [];
      const filePlan = planByFile.get(fid) ?? [];
      const typeUnits = typeUnitsByFile.get(fid) ?? new Map<string, Set<string>>();
      const qtyByType = ctQtyByFile.get(fid) ?? new Map<string, number>();

      // Resolve article_id via mapping for finance lines missing it
      const fflResolved = fileFfl.map((r: any) => {
        let aid: string | null = r.article_id ?? null;
        if (!aid) aid = sourceToArticle.get(`${r.source_type}::${r.source_code}`) ?? null;
        return { ...r, _aid: aid };
      });

      const realPpKeys = new Set<string>();
      for (const r of fflResolved) {
        if (PP_CODES.has(String(r.source_code ?? "")) && r.unit_no && r._aid) {
          realPpKeys.add(`${r.unit_no}::${r._aid}`);
        }
      }

      // Executed per (aid, cur, unit) — for plan budgeted-remainder math
      const execByKey = new Map<string, number>();
      const addExec = (aid: string | null, cur: string, unit: string | null, amt: number) => {
        const k = `${aid ?? "_"}::${cur}::${unit ?? ""}`;
        execByKey.set(k, (execByKey.get(k) ?? 0) + amt);
      };
      // Executed per (aid, cur) signed — for forecast
      const executedByArtCur = new Map<string, number>();
      const addExecAC = (aid: string | null, cur: string, amt: number) => {
        const k = `${aid ?? "_"}::${cur}`;
        executedByArtCur.set(k, (executedByArtCur.get(k) ?? 0) + amt);
      };

      const finance = { rev: 0, cost: 0 };

      for (const r of fflResolved) {
        const amt = Number(r.amount ?? 0);
        const cur = String(r.currency ?? "USD").toUpperCase();
        const aid = r._aid as string | null;
        addExec(aid, cur, r.unit_no ?? null, amt);
        addExecAC(aid, cur, amt);

        const kind = aid ? articleKind.get(aid) : null;
        if (kind) {
          const include = !!r.invoice_no || data.add_accruals;
          if (include) {
            const usd = toUsd(amt, cur, fx);
            if (kind === "REVENUE") finance.rev += usd;
            else if (kind === "COST") finance.cost += Math.abs(usd);
          }
        }
      }

      for (const r of fileBfl) {
        if (r.unit_no && r.article_id && realPpKeys.has(`${r.unit_no}::${r.article_id}`)) continue;
        const amt = Number(r.amount ?? 0);
        const cur = String(r.currency ?? "USD").toUpperCase();
        addExec(r.article_id ?? null, cur, r.unit_no ?? null, amt);
        addExecAC(r.article_id ?? null, cur, amt);
      }

      // Budgeted remainder from plan
      const budgetedByArtCur = new Map<string, number>();
      const addBg = (aid: string | null, cur: string, amt: number) => {
        const k = `${aid ?? "_"}::${cur}`;
        budgetedByArtCur.set(k, (budgetedByArtCur.get(k) ?? 0) + amt);
      };

      for (const p of filePlan) {
        const aid: string | null = (p as any).article_id ?? null;
        const cur = String((p as any).currency ?? "USD").toUpperCase();
        const kind = aid ? articleKind.get(aid) : null;
        const sign = kind === "COST" ? -1 : 1;
        const planPer = Number((p as any).amount_per_unit ?? 0);
        const planPerMag = Math.abs(planPer);
        if (planPer === 0 && !(p as any).total_amount) continue;

        if ((p as any).container_type) {
          const ct: string = (p as any).container_type;
          const units = Array.from(typeUnits.get(ct) ?? new Set<string>());
          const planned = qtyByType.get(ct) ?? Number((p as any).planned_qty ?? 0);
          for (const u of units) {
            const exec = execByKey.get(`${aid ?? "_"}::${cur}::${u}`) ?? 0;
            const remaining = planPerMag - Math.abs(exec);
            if (remaining <= 0.0001) continue;
            addBg(aid, cur, remaining * sign);
          }
          const slots = Math.max(0, planned - units.length);
          if (slots > 0) addBg(aid, cur, slots * planPerMag * sign);
        } else {
          const planTotal = Math.abs(
            Number((p as any).total_amount ?? planPerMag * Number((p as any).planned_qty ?? 0)),
          );
          const exec = execByKey.get(`${aid ?? "_"}::${cur}::`) ?? 0;
          const remaining = planTotal - Math.abs(exec);
          if (remaining <= 0.0001) continue;
          addBg(aid, cur, remaining * sign);
        }
      }

      // Forecast = executed + budgeted per (aid, cur)
      const actBudg = { rev: 0, cost: 0 };
      const allKeys = new Set<string>([
        ...executedByArtCur.keys(),
        ...budgetedByArtCur.keys(),
      ]);
      for (const k of allKeys) {
        const sep = k.indexOf("::");
        const aidStr = k.slice(0, sep);
        const cur = k.slice(sep + 2);
        const aid = aidStr === "_" ? null : aidStr;
        const kind = aid ? articleKind.get(aid) : null;
        if (!kind) continue;
        const forecast = (executedByArtCur.get(k) ?? 0) + (budgetedByArtCur.get(k) ?? 0);
        const usd = toUsd(forecast, cur, fx);
        if (kind === "REVENUE") actBudg.rev += usd;
        else if (kind === "COST") actBudg.cost += Math.abs(usd);
      }

      actBudgByFile.set(fid, actBudg);
      financeByFile.set(fid, finance);
    }

    const rows = (files ?? []).map((f: any) => {
      const b = actBudgByFile.get(f.id) ?? { rev: 0, cost: 0 };
      const fin = financeByFile.get(f.id) ?? { rev: 0, cost: 0 };
      const sm =
        f.sales_manager?.full_name ??
        f.sales_manager?.email ??
        f.sales_person?.full_name ??
        null;
      return {
        file_id: f.id,
        file_number: f.file_number,
        status: f.status,
        customer: f.customer_name ?? f.customer_accno ?? null,
        department_id: f.department_id,
        department: f.departments?.name ?? f.departments?.code ?? null,
        sales_manager_id: f.sales_manager_id ?? f.sales_person_id ?? null,
        sales_manager: sm,
        creation_date: f.created_at ? String(f.created_at).slice(0, 10) : null,
        op_date: f.op_date ? String(f.op_date).slice(0, 10) : null,
        rp_date: f.rp_date ? String(f.rp_date).slice(0, 10) : null,
        total_units: unitsByFile.get(f.id) ?? 0,
        revenue_budget: b.rev,
        cost_budget: b.cost,
        revenue_finance: fin.rev,
        cost_finance: fin.cost,
        revenue_diff: fin.rev - b.rev,
        cost_diff: fin.cost - b.cost,
        gpm_budget: b.rev - b.cost,
        gpm_finance: fin.rev - fin.cost,
      };
    });

    return { rows };
  });

// ============================================================
// Reporting: Financial result adjustment
// Same source data + math as getFileFinancialReport, but aggregated by
// finance budget article (or cost/charge type) instead of by file.
// Column totals must match the file financial report for the same filters.
// ============================================================
export const getFinancialResultAdjustment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        status: z.enum(["DR", "OP", "RP", "RCL", "CL", "CN"]),
        date_from: z.string(),
        date_to: z.string(),
        current_status: z.enum(["DR", "OP", "RP", "RCL", "CL", "CN"]).nullable().optional(),
        include_cancelled: z.boolean().optional().default(false),
        add_accruals: z.boolean().optional().default(false),
        breakdown: z.enum(["ARTICLE", "CHARGE_TYPE"]).default("ARTICLE"),
        group_by_status: z.boolean().optional().default(false),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const dateCol: Record<string, string> = {
      DR: "created_at",
      OP: "op_date",
      RP: "rp_date",
      RCL: "rcl_date",
      CL: "cl_date",
      CN: "cn_date",
    };
    const col = dateCol[data.status];

    let q = context.supabase
      .from("files")
      .select("id,status,fx_rate_eur_usd")
      .gte(col, data.date_from)
      .lte(col, data.date_to);
    if (data.current_status) q = q.eq("status", data.current_status);
    if (!data.include_cancelled && data.status !== "CN") q = q.neq("status", "CN");

    const { data: files, error: fErr } = await q;
    if (fErr) throw new Error(fErr.message);
    const fileIds = (files ?? []).map((f: any) => f.id);
    if (fileIds.length === 0) return { rows: [] as any[] };

    const toUsd = (amt: number, currency: string | null | undefined, fx: number): number => {
      const cur = String(currency ?? "USD").toUpperCase();
      if (cur === "EUR" && fx > 0) return amt * fx;
      return amt;
    };

    const { data: assigns } = await context.supabase
      .from("file_unit_assignments")
      .select("file_id,unit_no,unit_type,is_active")
      .in("file_id", fileIds);
    const typeUnitsByFile = new Map<string, Map<string, Set<string>>>();
    for (const a of assigns ?? []) {
      const fid = (a as any).file_id as string;
      const u = (a as any).unit_no as string | null;
      const t = (a as any).unit_type as string | null;
      if (u && t) {
        let m = typeUnitsByFile.get(fid);
        if (!m) { m = new Map(); typeUnitsByFile.set(fid, m); }
        let s = m.get(t);
        if (!s) { s = new Set(); m.set(t, s); }
        s.add(u);
      }
    }

    const { data: ctRows } = await context.supabase
      .from("file_container_types")
      .select("file_id,container_type,planned_qty")
      .in("file_id", fileIds);
    const ctQtyByFile = new Map<string, Map<string, number>>();
    for (const c of ctRows ?? []) {
      const fid = (c as any).file_id as string;
      let m = ctQtyByFile.get(fid);
      if (!m) { m = new Map(); ctQtyByFile.set(fid, m); }
      m.set((c as any).container_type, Number((c as any).planned_qty) || 0);
    }

    const { data: planLines } = await context.supabase
      .from("file_budget_plan_lines")
      .select("file_id,article_id,currency,total_amount,amount_per_unit,planned_qty,container_type")
      .in("file_id", fileIds);

    const { data: ffl } = await context.supabase
      .from("file_finance_lines")
      .select("file_id,unit_no,source_type,source_code,article_id,amount,currency,invoice_no")
      .in("file_id", fileIds);

    const { data: bfl } = await context.supabase
      .from("file_budget_fact_lines")
      .select("file_id,unit_no,article_id,amount,currency")
      .in("file_id", fileIds)
      .not("unit_no", "is", null);

    // cost/charge type → finance article (for ffl)
    const { data: mapRows } = await context.supabase
      .from("cost_charge_type_mapping")
      .select("source_type,source_code,finance_article_id");
    const sourceToFinance = new Map<string, string>();
    for (const m of mapRows ?? []) {
      const fa = (m as any).finance_article_id as string | null;
      if (!fa) continue;
      sourceToFinance.set(`${(m as any).source_type}::${(m as any).source_code}`, fa);
    }

    // sales article → finance article (for bfl / plan)
    const { data: sfMap } = await context.supabase
      .from("sales_finance_article_map")
      .select("sales_article_id,finance_article_id");
    const salesToFinance = new Map<string, string>();
    for (const m of sfMap ?? []) {
      salesToFinance.set((m as any).sales_article_id, (m as any).finance_article_id);
    }

    // Load finance articles meta (resolved aid is always a finance article id)
    const allArticleIds = new Set<string>();
    for (const v of sourceToFinance.values()) allArticleIds.add(v);
    for (const v of salesToFinance.values()) allArticleIds.add(v);
    const articleKind = new Map<string, "REVENUE" | "COST" | null>();
    const articleName = new Map<string, string>();
    const articleCode = new Map<string, string>();
    const articleSort = new Map<string, number>();
    if (allArticleIds.size > 0) {
      const { data: aRows } = await context.supabase
        .from("budget_articles")
        .select("id,code,name,kind,sort_order")
        .in("id", Array.from(allArticleIds));
      for (const a of aRows ?? []) {
        articleKind.set((a as any).id, (a as any).kind ?? null);
        articleName.set((a as any).id, (a as any).name ?? "");
        articleCode.set((a as any).id, (a as any).code ?? "");
        articleSort.set((a as any).id, Number((a as any).sort_order ?? 0));
      }
    }

    // Collect charge type pairs for name lookup
    const chargePairs = new Set<string>();
    for (const r of ffl ?? []) {
      const st = (r as any).source_type, sc = (r as any).source_code;
      if (st && sc) chargePairs.add(`${st}::${sc}`);
    }
    const chargeName = new Map<string, string>();
    if (chargePairs.size > 0) {
      const sts = new Set<string>(), scs = new Set<string>();
      for (const k of chargePairs) {
        const [st, sc] = k.split("::");
        sts.add(st); scs.add(sc);
      }
      const { data: cct } = await context.supabase
        .from("eqs_ext_cost_charge_types")
        .select("source_type,source_code,source_name")
        .in("source_type", Array.from(sts))
        .in("source_code", Array.from(scs));
      for (const r of cct ?? []) {
        chargeName.set(`${(r as any).source_type}::${(r as any).source_code}`, (r as any).source_name ?? "");
      }
    }

    const groupBy = <T extends { file_id: string }>(rows: T[]) => {
      const m = new Map<string, T[]>();
      for (const r of rows) {
        const arr = m.get(r.file_id) ?? [];
        arr.push(r);
        m.set(r.file_id, arr);
      }
      return m;
    };
    const fflByFile = groupBy((ffl ?? []) as any[]);
    const bflByFile = groupBy((bfl ?? []) as any[]);
    const planByFile = groupBy((planLines ?? []) as any[]);

    const PP_CODES = new Set(["PURC", "RCTP"]);

    // Aggregator: key -> {rev_b, cost_b, rev_f, cost_f}
    type Agg = { rev_b: number; cost_b: number; rev_f: number; cost_f: number };
    const ensure = (m: Map<string, Agg>, k: string): Agg => {
      let v = m.get(k);
      if (!v) { v = { rev_b: 0, cost_b: 0, rev_f: 0, cost_f: 0 }; m.set(k, v); }
      return v;
    };

    // Row meta indexed by row key (without status prefix so meta is stable)
    type Meta = {
      finance_article_id: string | null;
      finance_article_kind: "REVENUE" | "COST" | null;
      finance_article_name: string | null;
      charge_source_type: string | null;
      charge_source_code: string | null;
      charge_type_name: string | null;
    };
    const metaByKey = new Map<string, Meta>();
    const setMeta = (k: string, meta: Meta) => { if (!metaByKey.has(k)) metaByKey.set(k, meta); };

    // breakdown key builder; returns null if row should be skipped
    const bkArticle = (aid: string | null): string | null => {
      if (!aid) return "__UNMAPPED__";
      return `A:${aid}`;
    };
    const bkCharge = (st: string | null, sc: string | null, aid: string | null): string | null => {
      if (st && sc) return `C:${st}::${sc}`;
      // Plan / bfl without charge type → assign to pseudo (Plan, article)
      if (aid) return `C:Plan::${aid}`;
      return "__UNMAPPED__";
    };

    const totals = new Map<string, Map<string, Agg>>(); // status -> key -> agg

    for (const f of (files ?? []) as any[]) {
      const fid = f.id as string;
      const fStatus = f.status as string;
      const fx = Number(f.fx_rate_eur_usd ?? 0);
      const statusKey = data.group_by_status ? fStatus : "__ALL__";
      let statusBucket = totals.get(statusKey);
      if (!statusBucket) { statusBucket = new Map(); totals.set(statusKey, statusBucket); }

      const fileFfl = fflByFile.get(fid) ?? [];
      const fileBfl = bflByFile.get(fid) ?? [];
      const filePlan = planByFile.get(fid) ?? [];
      const typeUnits = typeUnitsByFile.get(fid) ?? new Map<string, Set<string>>();
      const qtyByType = ctQtyByFile.get(fid) ?? new Map<string, number>();

      // Resolve finance article for ffl: prefer charge-type mapping, then sales→finance fallback.
      // Keep sales article from ffl row for de-duping bfl synthetic rows.
      const fflResolved = fileFfl.map((r: any) => {
        const salesAid: string | null = r.article_id ?? null;
        const fromCharge = sourceToFinance.get(`${r.source_type}::${r.source_code}`) ?? null;
        const fromSales = salesAid ? salesToFinance.get(salesAid) ?? null : null;
        const aid = fromCharge ?? fromSales ?? null;
        return { ...r, _aid: aid, _aid_sales: salesAid };
      });

      const realPpKeys = new Set<string>();
      for (const r of fflResolved) {
        if (PP_CODES.has(String(r.source_code ?? "")) && r.unit_no && r._aid_sales) {
          realPpKeys.add(`${r.unit_no}::${r._aid_sales}`);
        }
      }

      // For each row produce (key, kind, currency, exec_signed, finance_usd_inc)
      // Then per (key, currency) compute executed sum (for budgeted-remainder math).
      // Plan budgeted-remainder is keyed by (aid, currency) inside this file.

      // 1) executed by (key, currency) — signed amount in source currency
      const execByKeyCur = new Map<string, number>();
      // 2) executed-per-unit by (aid, currency, unit) — used by plan remainder math
      const execByAidCurUnit = new Map<string, number>();

      const addExecKeyCur = (key: string, cur: string, amt: number) => {
        const k = `${key}::${cur}`;
        execByKeyCur.set(k, (execByKeyCur.get(k) ?? 0) + amt);
      };
      const addExecAU = (aid: string | null, cur: string, unit: string | null, amt: number) => {
        const k = `${aid ?? "_"}::${cur}::${unit ?? ""}`;
        execByAidCurUnit.set(k, (execByAidCurUnit.get(k) ?? 0) + amt);
      };

      // Track per-key kind for forecast classification
      const keyKind = new Map<string, "REVENUE" | "COST" | null>();
      const setKeyKind = (key: string, kind: "REVENUE" | "COST" | null) => {
        if (!keyKind.has(key) && kind) keyKind.set(key, kind);
      };

      // Process finance lines
      for (const r of fflResolved) {
        const amt = Number(r.amount ?? 0);
        const cur = String(r.currency ?? "USD").toUpperCase();
        const aid = r._aid as string | null;
        const kind = aid ? articleKind.get(aid) ?? null : null;

        const key =
          data.breakdown === "ARTICLE"
            ? bkArticle(aid)
            : bkCharge(r.source_type ?? null, r.source_code ?? null, aid);
        if (!key) continue;

        // Meta
        if (data.breakdown === "ARTICLE") {
          setMeta(key, {
            finance_article_id: aid,
            finance_article_kind: kind,
            finance_article_name: aid ? articleName.get(aid) ?? null : null,
            charge_source_type: null,
            charge_source_code: null,
            charge_type_name: null,
          });
        } else {
          const st = r.source_type ?? null;
          const sc = r.source_code ?? null;
          setMeta(key, {
            finance_article_id: aid,
            finance_article_kind: kind,
            finance_article_name: aid ? articleName.get(aid) ?? null : null,
            charge_source_type: st,
            charge_source_code: sc,
            charge_type_name: st && sc ? chargeName.get(`${st}::${sc}`) ?? null : null,
          });
        }
        setKeyKind(key, kind);

        addExecKeyCur(key, cur, amt);
        addExecAU(aid, cur, r.unit_no ?? null, amt);

        // Finance side
        if (kind) {
          const include = !!r.invoice_no || data.add_accruals;
          if (include) {
            const usd = toUsd(amt, cur, fx);
            const agg = ensure(statusBucket, key);
            if (kind === "REVENUE") agg.rev_f += usd;
            else if (kind === "COST") agg.cost_f += Math.abs(usd);
          }
        }
      }

      // Process bfl (synthetic execution) — excluded when duplicated by real PP
      for (const r of fileBfl) {
        if (r.unit_no && r.article_id && realPpKeys.has(`${r.unit_no}::${r.article_id}`)) continue;
        const amt = Number(r.amount ?? 0);
        const cur = String(r.currency ?? "USD").toUpperCase();
        const salesAid: string | null = r.article_id ?? null;
        const aid: string | null = salesAid ? salesToFinance.get(salesAid) ?? null : null;
        const kind = aid ? articleKind.get(aid) ?? null : null;

        const key =
          data.breakdown === "ARTICLE"
            ? bkArticle(aid)
            : bkCharge(null, null, aid);
        if (!key) continue;

        if (data.breakdown === "ARTICLE") {
          setMeta(key, {
            finance_article_id: aid,
            finance_article_kind: kind,
            finance_article_name: aid ? articleName.get(aid) ?? null : null,
            charge_source_type: null,
            charge_source_code: null,
            charge_type_name: null,
          });
        } else {
          setMeta(key, {
            finance_article_id: aid,
            finance_article_kind: kind,
            finance_article_name: aid ? articleName.get(aid) ?? null : null,
            charge_source_type: "Plan",
            charge_source_code: aid ? articleCode.get(aid) ?? null : null,
            charge_type_name: aid ? `Plan: ${articleName.get(aid) ?? ""}` : "Plan",
          });
        }
        setKeyKind(key, kind);

        addExecKeyCur(key, cur, amt);
        addExecAU(aid, cur, r.unit_no ?? null, amt);
      }

      // Budgeted remainder from plan, keyed per article+currency, then routed to bucket
      // We need budgeted remainder broken down per row key. For ARTICLE this maps 1:1.
      // For CHARGE_TYPE plan-side goes to the synthetic ("Plan", article) bucket.
      for (const p of filePlan) {
        const salesAid: string | null = (p as any).article_id ?? null;
        const aid: string | null = salesAid ? salesToFinance.get(salesAid) ?? null : null;
        const cur = String((p as any).currency ?? "USD").toUpperCase();
        const kind = aid ? articleKind.get(aid) ?? null : null;
        const sign = kind === "COST" ? -1 : 1;
        const planPer = Number((p as any).amount_per_unit ?? 0);
        const planPerMag = Math.abs(planPer);
        if (planPer === 0 && !(p as any).total_amount) continue;

        const key =
          data.breakdown === "ARTICLE"
            ? bkArticle(aid)
            : bkCharge(null, null, aid);
        if (!key) continue;

        // Set meta if not already
        if (data.breakdown === "ARTICLE") {
          setMeta(key, {
            finance_article_id: aid,
            finance_article_kind: kind,
            finance_article_name: aid ? articleName.get(aid) ?? null : null,
            charge_source_type: null,
            charge_source_code: null,
            charge_type_name: null,
          });
        } else {
          setMeta(key, {
            finance_article_id: aid,
            finance_article_kind: kind,
            finance_article_name: aid ? articleName.get(aid) ?? null : null,
            charge_source_type: "Plan",
            charge_source_code: aid ? articleCode.get(aid) ?? null : null,
            charge_type_name: aid ? `Plan: ${articleName.get(aid) ?? ""}` : "Plan",
          });
        }
        setKeyKind(key, kind);

        let budgetedSigned = 0; // in source currency, signed (rev +, cost -)

        if ((p as any).container_type) {
          const ct: string = (p as any).container_type;
          const units = Array.from(typeUnits.get(ct) ?? new Set<string>());
          const planned = qtyByType.get(ct) ?? Number((p as any).planned_qty ?? 0);
          for (const u of units) {
            const exec = execByAidCurUnit.get(`${aid ?? "_"}::${cur}::${u}`) ?? 0;
            const remaining = planPerMag - Math.abs(exec);
            if (remaining <= 0.0001) continue;
            budgetedSigned += remaining * sign;
          }
          const slots = Math.max(0, planned - units.length);
          if (slots > 0) budgetedSigned += slots * planPerMag * sign;
        } else {
          const planTotal = Math.abs(
            Number((p as any).total_amount ?? planPerMag * Number((p as any).planned_qty ?? 0)),
          );
          const exec = execByAidCurUnit.get(`${aid ?? "_"}::${cur}::`) ?? 0;
          const remaining = planTotal - Math.abs(exec);
          if (remaining > 0.0001) budgetedSigned += remaining * sign;
        }

        if (budgetedSigned !== 0 && kind) {
          // forecast (actBudg) = executed_at_key + budgeted_remainder
          // But executed component is added below from execByKeyCur. Here only the budgeted piece.
          const usd = toUsd(budgetedSigned, cur, fx);
          const agg = ensure(statusBucket, key);
          if (kind === "REVENUE") agg.rev_b += usd;
          else if (kind === "COST") agg.cost_b += Math.abs(usd);
        }
      }

      // Now add executed component of forecast (actBudg) per (key, currency)
      for (const [k, amt] of execByKeyCur) {
        const sep = k.lastIndexOf("::");
        const key = k.slice(0, sep);
        const cur = k.slice(sep + 2);
        const kind = keyKind.get(key);
        if (!kind) continue;
        const usd = toUsd(amt, cur, fx);
        const agg = ensure(statusBucket, key);
        if (kind === "REVENUE") agg.rev_b += usd;
        else if (kind === "COST") agg.cost_b += Math.abs(usd);
      }
    }

    // Flatten to rows
    const rows: any[] = [];
    for (const [statusKey, bucket] of totals) {
      for (const [key, agg] of bucket) {
        const meta = metaByKey.get(key) ?? {
          finance_article_id: null,
          finance_article_kind: null,
          finance_article_name: null,
          charge_source_type: null,
          charge_source_code: null,
          charge_type_name: null,
        };
        rows.push({
          file_status: data.group_by_status ? statusKey : null,
          ...meta,
          revenue_budget: agg.rev_b,
          cost_budget: agg.cost_b,
          revenue_finance: agg.rev_f,
          cost_finance: agg.cost_f,
          gpm_budget: agg.rev_b - agg.cost_b,
          gpm_finance: agg.rev_f - agg.cost_f,
        });
      }
    }

    rows.sort((a, b) => {
      const s = (a.file_status ?? "").localeCompare(b.file_status ?? "");
      if (s) return s;
      const sa = a.finance_article_id ? (articleSort.get(a.finance_article_id) ?? 0) : Number.MAX_SAFE_INTEGER;
      const sb = b.finance_article_id ? (articleSort.get(b.finance_article_id) ?? 0) : Number.MAX_SAFE_INTEGER;
      if (sa !== sb) return sa - sb;
      const n = (a.finance_article_name ?? "~").localeCompare(b.finance_article_name ?? "~");
      if (n) return n;
      return (a.charge_type_name ?? "").localeCompare(b.charge_type_name ?? "");
    });

    return { rows };
  });


// ============================================================
// Sales ↔ Finance article map: CRUD
// ============================================================

export const listSalesFinanceArticleMap = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: rows, error } = await context.supabase
      .from("sales_finance_article_map")
      .select("sales_article_id,finance_article_id,updated_at");
    if (error) throw new Error(error.message);
    const ids = new Set<string>();
    for (const r of rows ?? []) {
      ids.add((r as any).sales_article_id);
      ids.add((r as any).finance_article_id);
    }
    const articles: any[] = [];
    if (ids.size > 0) {
      const { data: aRows, error: aErr } = await context.supabase
        .from("budget_articles")
        .select("id,code,name,kind,scope")
        .in("id", Array.from(ids));
      if (aErr) throw new Error(aErr.message);
      articles.push(...(aRows ?? []));
    }
    const byId = new Map<string, any>(articles.map((a) => [a.id, a]));
    return {
      rows: (rows ?? []).map((r: any) => ({
        sales_article_id: r.sales_article_id,
        finance_article_id: r.finance_article_id,
        sales: byId.get(r.sales_article_id) ?? null,
        finance: byId.get(r.finance_article_id) ?? null,
        updated_at: r.updated_at,
      })),
    };
  });

export const listBudgetArticlesByScope = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("budget_articles")
      .select("id,code,name,kind,scope,sort_order")
      .order("sort_order", { ascending: true })
      .order("code", { ascending: true });
    if (error) throw new Error(error.message);
    return { rows: data ?? [] };
  });

export const upsertSalesFinanceArticleMap = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        sales_article_id: z.string().uuid(),
        finance_article_id: z.string().uuid(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("sales_finance_article_map")
      .upsert({
        sales_article_id: data.sales_article_id,
        finance_article_id: data.finance_article_id,
        updated_at: new Date().toISOString(),
      });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteSalesFinanceArticleMap = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ sales_article_id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("sales_finance_article_map")
      .delete()
      .eq("sales_article_id", data.sales_article_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });


// ============================================================
// Financial result adjustment — drill-down detail
// ============================================================
export const getFinancialAdjustmentDrilldown = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        status: z.enum(["DR", "OP", "RP", "RCL", "CL", "CN"]),
        date_from: z.string(),
        date_to: z.string(),
        current_status: z.enum(["DR", "OP", "RP", "RCL", "CL", "CN"]).nullable().optional(),
        include_cancelled: z.boolean().optional().default(false),
        add_accruals: z.boolean().optional().default(false),
        breakdown: z.enum(["ARTICLE", "CHARGE_TYPE"]).default("ARTICLE"),
        group_by_status: z.boolean().optional().default(false),
        key_file_status: z.string().nullable().optional(),
        key_finance_article_id: z.string().uuid().nullable().optional(),
        key_charge_source_type: z.string().nullable().optional(),
        key_charge_source_code: z.string().nullable().optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const dateCol: Record<string, string> = {
      DR: "created_at", OP: "op_date", RP: "rp_date", RCL: "rcl_date", CL: "cl_date", CN: "cn_date",
    };
    const col = dateCol[data.status];
    let q = context.supabase
      .from("files")
      .select("id,file_number,status,customer_name,fx_rate_eur_usd")
      .gte(col, data.date_from)
      .lte(col, data.date_to);
    if (data.current_status) q = q.eq("status", data.current_status);
    if (!data.include_cancelled && data.status !== "CN") q = q.neq("status", "CN");
    if (data.group_by_status && data.key_file_status) q = q.eq("status", data.key_file_status as any);
    const { data: files, error: fErr } = await q;
    if (fErr) throw new Error(fErr.message);
    const fileIds = (files ?? []).map((f: any) => f.id);
    if (fileIds.length === 0) return { rows: [] };
    const fileById = new Map<string, any>((files ?? []).map((f: any) => [f.id, f]));

    const toUsd = (amt: number, currency: string | null | undefined, fx: number): number => {
      const cur = String(currency ?? "USD").toUpperCase();
      if (cur === "EUR" && fx > 0) return amt * fx;
      return amt;
    };

    const [{ data: mapRows }, { data: sfMap }, { data: assigns }] = await Promise.all([
      context.supabase.from("cost_charge_type_mapping").select("source_type,source_code,finance_article_id"),
      context.supabase.from("sales_finance_article_map").select("sales_article_id,finance_article_id"),
      context.supabase.from("file_unit_assignments").select("file_id,unit_no,unit_type").in("file_id", fileIds),
    ]);
    const sourceToFinance = new Map<string, string>();
    for (const m of mapRows ?? []) {
      const fa = (m as any).finance_article_id as string | null;
      if (fa) sourceToFinance.set(`${(m as any).source_type}::${(m as any).source_code}`, fa);
    }
    const salesToFinance = new Map<string, string>();
    for (const m of sfMap ?? []) salesToFinance.set((m as any).sales_article_id, (m as any).finance_article_id);
    const unitType = new Map<string, string>();
    for (const a of assigns ?? []) {
      const u = (a as any).unit_no as string | null;
      const t = (a as any).unit_type as string | null;
      if (u && t) unitType.set(`${(a as any).file_id}::${u}`, t);
    }

    const [{ data: ffl }, { data: bfl }, { data: plan }, { data: ctRows }] = await Promise.all([
      context.supabase
        .from("file_finance_lines")
        .select("file_id,unit_no,source_finance_id,source_type,source_code,article_id,amount,currency,invoice_no,invoice_date")
        .in("file_id", fileIds),
      context.supabase
        .from("file_budget_fact_lines")
        .select("file_id,unit_no,article_id,amount,currency")
        .in("file_id", fileIds)
        .not("unit_no", "is", null),
      context.supabase
        .from("file_budget_plan_lines")
        .select("file_id,article_id,currency,total_amount,amount_per_unit,planned_qty,container_type")
        .in("file_id", fileIds),
      context.supabase
        .from("file_container_types")
        .select("file_id,container_type,planned_qty")
        .in("file_id", fileIds),
    ]);

    // Per-file helpers for budgeted-remainder math (mirror getBudgetFact / aggregator).
    const PP_CODES_DD = new Set(["PURC", "RCTP"]);
    // file -> container_type -> set(unit_no)
    const typeUnitsByFile = new Map<string, Map<string, Set<string>>>();
    for (const a of (assigns ?? []) as any[]) {
      const fid = a.file_id as string | null;
      const u = a.unit_no as string | null;
      const t = a.unit_type as string | null;
      if (!fid || !u || !t) continue;
      let m = typeUnitsByFile.get(fid);
      if (!m) { m = new Map(); typeUnitsByFile.set(fid, m); }
      let s = m.get(t);
      if (!s) { s = new Set(); m.set(t, s); }
      s.add(u);
    }
    // file -> container_type -> planned_qty (file-level override)
    const qtyByTypeByFile = new Map<string, Map<string, number>>();
    for (const c of (ctRows ?? []) as any[]) {
      const fid = c.file_id as string;
      let m = qtyByTypeByFile.get(fid);
      if (!m) { m = new Map(); qtyByTypeByFile.set(fid, m); }
      m.set(c.container_type, Number(c.planned_qty) || 0);
    }
    // file -> set("unit_no::sales_article_id") for real PURC/RCTP — suppress synthetic bfl dupes
    const realPpKeysByFile = new Map<string, Set<string>>();
    // executed-by-(finance_aid, cur, unit) per file (signed source currency)
    const execByAidCurUnitByFile = new Map<string, Map<string, number>>();
    const execByAidCurNoUnitByFile = new Map<string, Map<string, number>>();
    const addExecDD = (fid: string, aid: string | null, cur: string, unit: string | null, amt: number) => {
      if (unit) {
        let m = execByAidCurUnitByFile.get(fid);
        if (!m) { m = new Map(); execByAidCurUnitByFile.set(fid, m); }
        const k = `${aid ?? "_"}::${cur}::${unit}`;
        m.set(k, (m.get(k) ?? 0) + amt);
      } else {
        let m = execByAidCurNoUnitByFile.get(fid);
        if (!m) { m = new Map(); execByAidCurNoUnitByFile.set(fid, m); }
        const k = `${aid ?? "_"}::${cur}`;
        m.set(k, (m.get(k) ?? 0) + amt);
      }
    };
    for (const r of (ffl ?? []) as any[]) {
      const fid = r.file_id as string;
      const salesAid: string | null = r.article_id ?? null;
      const fromCharge = sourceToFinance.get(`${r.source_type}::${r.source_code}`) ?? null;
      const fromSales = salesAid ? salesToFinance.get(salesAid) ?? null : null;
      const aid = fromCharge ?? fromSales ?? null;
      const cur = String(r.currency ?? "USD").toUpperCase();
      addExecDD(fid, aid, cur, r.unit_no ?? null, Number(r.amount ?? 0));
      if (PP_CODES_DD.has(String(r.source_code ?? "")) && r.unit_no && salesAid) {
        let s = realPpKeysByFile.get(fid);
        if (!s) { s = new Set(); realPpKeysByFile.set(fid, s); }
        s.add(`${r.unit_no}::${salesAid}`);
      }
    }
    for (const r of (bfl ?? []) as any[]) {
      const fid = r.file_id as string;
      const salesAid: string | null = r.article_id ?? null;
      if (r.unit_no && salesAid && realPpKeysByFile.get(fid)?.has(`${r.unit_no}::${salesAid}`)) continue;
      const aid: string | null = salesAid ? salesToFinance.get(salesAid) ?? null : null;
      const cur = String(r.currency ?? "USD").toUpperCase();
      addExecDD(fid, aid, cur, r.unit_no ?? null, Number(r.amount ?? 0));
    }

    // Load party_accname for ffl rows that link to ext finance
    const extIds = Array.from(
      new Set(
        ((ffl ?? []) as any[])
          .map((r) => r.source_finance_id)
          .filter((x: any): x is string => !!x),
      ),
    );
    const partyByExt = new Map<string, string>();
    if (extIds.length > 0) {
      const { data: extRows } = await context.supabase
        .from("eqs_ext_finance_lines")
        .select("id,party_accname")
        .in("id", extIds);
      for (const r of extRows ?? []) {
        const v = (r as any).party_accname as string | null;
        if (v) partyByExt.set((r as any).id, v);
      }
    }

    // Charge type names
    const chargePairs = new Set<string>();
    for (const r of (ffl ?? []) as any[]) {
      const st = r.source_type, sc = r.source_code;
      if (st && sc) chargePairs.add(`${st}::${sc}`);
    }
    const chargeName = new Map<string, string>();
    if (chargePairs.size > 0) {
      const sts = new Set<string>(), scs = new Set<string>();
      for (const k of chargePairs) {
        const [st, sc] = k.split("::");
        sts.add(st); scs.add(sc);
      }
      const { data: cct } = await context.supabase
        .from("eqs_ext_cost_charge_types")
        .select("source_type,source_code,source_name")
        .in("source_type", Array.from(sts))
        .in("source_code", Array.from(scs));
      for (const r of cct ?? []) {
        const n = (r as any).source_name as string | null;
        if (n) chargeName.set(`${(r as any).source_type}::${(r as any).source_code}`, n);
      }
    }

    const targetAid = data.key_finance_article_id ?? null;
    const isCharge = data.breakdown === "CHARGE_TYPE";
    const wantChargeSt = data.key_charge_source_type ?? null;
    const wantChargeSc = data.key_charge_source_code ?? null;

    // For charge-type plan/synthetic pseudo-bucket: matches when source_type === 'Plan'.
    const wantPlanBucket = isCharge && wantChargeSt === "Plan";

    const out: any[] = [];

    // Article meta for kind/name
    const aIds = new Set<string>();
    if (targetAid) aIds.add(targetAid);
    for (const v of sourceToFinance.values()) aIds.add(v);
    for (const v of salesToFinance.values()) aIds.add(v);
    const articleMeta = new Map<string, { code: string; name: string; kind: string | null }>();
    if (aIds.size > 0) {
      const { data: aRows } = await context.supabase
        .from("budget_articles")
        .select("id,code,name,kind")
        .in("id", Array.from(aIds));
      for (const a of aRows ?? []) articleMeta.set((a as any).id, { code: (a as any).code, name: (a as any).name, kind: (a as any).kind });
    }

    const contribFor = (
      source: "booked" | "accrued" | "budget",
      kind: string | null,
    ): Array<"rev_b" | "rev_f" | "cost_b" | "cost_f"> => {
      if (!kind) return [];
      const isRev = kind === "REVENUE";
      const b = isRev ? "rev_b" : "cost_b";
      const f = isRev ? "rev_f" : "cost_f";
      if (source === "booked") return [b, f];
      if (source === "accrued") return data.add_accruals ? [b, f] : [b];
      return [b]; // budget
    };

    // 1) ffl rows
    for (const r of (ffl ?? []) as any[]) {
      const file = fileById.get(r.file_id);
      if (!file) continue;
      const fx = Number(file.fx_rate_eur_usd ?? 0);
      const salesAid: string | null = r.article_id ?? null;
      const fromCharge = sourceToFinance.get(`${r.source_type}::${r.source_code}`) ?? null;
      const fromSales = salesAid ? salesToFinance.get(salesAid) ?? null : null;
      const aid = fromCharge ?? fromSales ?? null;

      if (isCharge) {
        if (wantPlanBucket) continue;
        if ((r.source_type ?? null) !== wantChargeSt || (r.source_code ?? null) !== wantChargeSc) continue;
      } else {
        if ((aid ?? null) !== (targetAid ?? null)) continue;
      }

      const amt = Number(r.amount ?? 0);
      const cur = String(r.currency ?? "USD").toUpperCase();
      const m = aid ? articleMeta.get(aid) : null;
      const source: "booked" | "accrued" = r.invoice_no ? "booked" : "accrued";
      const party = r.source_finance_id ? partyByExt.get(r.source_finance_id) ?? null : null;
      const ctKey = r.source_type && r.source_code ? `${r.source_type}::${r.source_code}` : null;
      out.push({
        file_id: file.id,
        file_number: file.file_number,
        file_status: file.status,
        third_party: party ?? file.customer_name ?? null,
        unit_no: r.unit_no ?? null,
        container_type: r.unit_no ? unitType.get(`${file.id}::${r.unit_no}`) ?? null : null,
        source,
        doc_no: r.invoice_no ?? null,
        doc_date: r.invoice_date ?? null,
        charge_type_label: ctKey ? chargeName.get(ctKey) ?? r.source_code ?? null : null,
        finance_article_id: aid,
        finance_article_name: m?.name ?? null,
        finance_article_kind: m?.kind ?? null,
        amount: amt,
        currency: cur,
        amount_usd: toUsd(amt, cur, fx),
        contributes: contribFor(source, m?.kind ?? null),
      });
    }

    // 2) bfl rows (synthetic fact) — suppress duplicates of real PURC/RCTP for the same unit+article
    for (const r of (bfl ?? []) as any[]) {
      const file = fileById.get(r.file_id);
      if (!file) continue;
      const fx = Number(file.fx_rate_eur_usd ?? 0);
      const salesAid: string | null = r.article_id ?? null;
      if (r.unit_no && salesAid && realPpKeysByFile.get(file.id)?.has(`${r.unit_no}::${salesAid}`)) continue;
      const aid = salesAid ? salesToFinance.get(salesAid) ?? null : null;

      if (isCharge) {
        if (!wantPlanBucket) continue;
        if ((aid ?? null) !== (targetAid ?? null)) continue;
      } else {
        if ((aid ?? null) !== (targetAid ?? null)) continue;
      }

      const amt = Number(r.amount ?? 0);
      const cur = String(r.currency ?? "USD").toUpperCase();
      const m = aid ? articleMeta.get(aid) : null;
      out.push({
        file_id: file.id,
        file_number: file.file_number,
        file_status: file.status,
        third_party: m?.kind === "COST" ? null : file.customer_name ?? null,
        unit_no: r.unit_no ?? null,
        container_type: r.unit_no ? unitType.get(`${file.id}::${r.unit_no}`) ?? null : null,
        source: "budget",
        doc_no: null,
        doc_date: null,
        charge_type_label: null,
        finance_article_id: aid,
        finance_article_name: m?.name ?? null,
        finance_article_kind: m?.kind ?? null,
        amount: amt,
        currency: cur,
        amount_usd: toUsd(amt, cur, fx),
        contributes: contribFor("budget", m?.kind ?? null),
      });
    }

    // 3) plan rows — budgeted-remainder math, mirrors getBudgetFact / getFinancialResultAdjustment.
    //    For container-scoped plan rows: emit one row per assigned unit (remaining = |amt_per_unit| - |executed|)
    //    plus one synthetic "not assigned" row per unfilled slot (planned_qty - units.length).
    //    For plan rows without container_type: one aggregate row (|total_amount| - |Σ executed without unit|).
    for (const r of (plan ?? []) as any[]) {
      const file = fileById.get(r.file_id);
      if (!file) continue;
      const fx = Number(file.fx_rate_eur_usd ?? 0);
      const salesAid: string | null = r.article_id ?? null;
      const aid: string | null = salesAid ? salesToFinance.get(salesAid) ?? null : null;

      if (isCharge) {
        if (!wantPlanBucket) continue;
        if ((aid ?? null) !== (targetAid ?? null)) continue;
      } else {
        if ((aid ?? null) !== (targetAid ?? null)) continue;
      }

      const cur = String(r.currency ?? "USD").toUpperCase();
      const m = aid ? articleMeta.get(aid) : null;
      const kind = m?.kind ?? null;
      const sign = kind === "COST" ? -1 : 1;
      const planPer = Number(r.amount_per_unit ?? 0);
      const planPerMag = Math.abs(planPer);
      if (planPer === 0 && !r.total_amount) continue;

      const ct: string | null = r.container_type ?? null;
      const pushDetail = (unit: string | null, contType: string | null, amount: number) => {
        out.push({
          file_id: file.id,
          file_number: file.file_number,
          file_status: file.status,
          third_party: kind === "COST" ? null : file.customer_name ?? null,
          unit_no: unit,
          container_type: contType,
          source: "budget",
          doc_no: null,
          doc_date: null,
          charge_type_label: null,
          finance_article_id: aid,
          finance_article_name: m?.name ?? null,
          finance_article_kind: kind,
          amount,
          currency: cur,
          amount_usd: toUsd(amount, cur, fx),
          contributes: contribFor("budget", kind),
        });
      };

      if (ct) {
        const units = Array.from(typeUnitsByFile.get(file.id)?.get(ct) ?? new Set<string>());
        const planned = qtyByTypeByFile.get(file.id)?.get(ct) ?? Number(r.planned_qty ?? 0);
        const execMap = execByAidCurUnitByFile.get(file.id);
        for (const u of units) {
          const exec = execMap?.get(`${aid ?? "_"}::${cur}::${u}`) ?? 0;
          const remaining = planPerMag - Math.abs(exec);
          if (remaining <= 0.0001) continue;
          pushDetail(u, ct, remaining * sign);
        }
        const slots = Math.max(0, planned - units.length);
        for (let i = 0; i < slots; i++) {
          pushDetail(null, ct, planPerMag * sign);
        }
      } else {
        const planTotal = Math.abs(
          Number(r.total_amount ?? planPerMag * Number(r.planned_qty ?? 0)),
        );
        const exec = execByAidCurNoUnitByFile.get(file.id)?.get(`${aid ?? "_"}::${cur}`) ?? 0;
        const remaining = planTotal - Math.abs(exec);
        if (remaining > 0.0001) pushDetail(null, null, remaining * sign);
      }
    }


    out.sort((a, b) => (a.file_number ?? "").localeCompare(b.file_number ?? "") || (a.source ?? "").localeCompare(b.source ?? ""));
    return { rows: out };
  });






// ============================================================
// Copy file (header + container types, optionally planned budget)
// ============================================================

const CT_COPY_FIELDS = [
  "container_type",
  "grade",
  "planned_qty",
  "daily_rate",
  "repl_value",
  "free_min_days",
  "charge1_code",
  "charge1_amount",
  "charge2_code",
  "charge2_amount",
  "charge3_code",
  "charge3_amount",
  "charge4_code",
  "charge4_amount",
  "cost1_code",
  "cost1_currency",
  "cost1_amount",
  "cost1_supplier_accno",
  "cost2_code",
  "cost2_currency",
  "cost2_amount",
  "cost2_supplier_accno",
] as const;

const BPL_COPY_FIELDS = [
  "article_id",
  "currency",
  "notes",
  "container_type",
  "planned_qty",
  "amount_per_unit",
  "amount_usd",
  "amount_eur",
  "source_type",
] as const;

export const getFileCopyPreview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        file_id: z.string().uuid(),
        include_budget: z.boolean().default(false),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: file, error: fErr } = await context.supabase
      .from("files")
      .select(
        "id,file_number,direction,department_id,customer_accno,customer_name,origin_country_code,dest_country_code,origin_subregion,dest_subregion,origin_locn,dest_locn,sales_person_id,sales_manager_id,lessee_order,notes,business_date,planned_departure_date,planned_arrival_date",
      )
      .eq("id", data.file_id)
      .maybeSingle();
    if (fErr) throw new Error(fErr.message);
    if (!file) throw new Error("File not found");

    const { data: cts, error: ctErr } = await context.supabase
      .from("file_container_types")
      .select(`id,${CT_COPY_FIELDS.join(",")}`)
      .eq("file_id", data.file_id)
      .order("created_at", { ascending: true });
    if (ctErr) throw new Error(ctErr.message);

    let budgetLines: any[] = [];
    if (data.include_budget) {
      const { data: bl, error: bErr } = await context.supabase
        .from("file_budget_plan_lines")
        .select(BPL_COPY_FIELDS.join(","))
        .eq("file_id", data.file_id);
      if (bErr) throw new Error(bErr.message);
      budgetLines = bl ?? [];
    }

    return { file, container_types: cts ?? [], budget_lines: budgetLines };
  });

export const copyFile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        file_id: z.string().uuid(),
        mode: z.enum(["plain", "with_budget"]),
        container_qty_overrides: z.record(z.string(), z.number().int().min(1)).optional(),
        planned_departure_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        planned_arrival_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      })
      .refine((v) => v.planned_arrival_date >= v.planned_departure_date, {
        message: "Arrival date must be on or after departure date",
        path: ["planned_arrival_date"],
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: src, error: fErr } = await context.supabase
      .from("files")
      .select(
        "id,direction,department_id,customer_accno,customer_name,origin_country_code,dest_country_code,origin_subregion,dest_subregion,origin_locn,dest_locn,sales_person_id,sales_manager_id,lessee_order,notes,business_date",
      )
      .eq("id", data.file_id)
      .maybeSingle();
    if (fErr) throw new Error(fErr.message);
    if (!src) throw new Error("Source file not found");

    const { data: newIdRaw, error: cErr } = await context.supabase.rpc("fn_create_file", {
      p_department_id: src.department_id,
      p_direction: (src.direction ?? "EXPORT") as any,
      p_customer_accno: src.customer_accno ?? undefined,
      p_customer_name: src.customer_name ?? undefined,
      p_origin_subregion: src.origin_subregion ?? undefined,
      p_dest_subregion: src.dest_subregion ?? undefined,
      p_origin_locn: src.origin_locn ?? undefined,
      p_dest_locn: src.dest_locn ?? undefined,
      p_planned_departure_date: data.planned_departure_date,
      p_planned_arrival_date: data.planned_arrival_date,
      p_notes: src.notes ?? undefined,
    });
    if (cErr) throw new Error(cErr.message);
    const newId = newIdRaw as unknown as string;

    const patch: Record<string, any> = {
      planned_arrival_date: data.planned_arrival_date,
    };
    if (src.sales_person_id) patch.sales_person_id = src.sales_person_id;
    if (src.sales_manager_id) patch.sales_manager_id = src.sales_manager_id;
    if (src.business_date) patch.business_date = src.business_date;
    if (src.origin_country_code) patch.origin_country_code = src.origin_country_code;
    if (src.dest_country_code) patch.dest_country_code = src.dest_country_code;
    if (src.lessee_order != null) patch.lessee_order = src.lessee_order;
    const { error: upErr } = await context.supabase.from("files").update(patch as never).eq("id", newId);
    if (upErr) throw new Error(upErr.message);


    const { data: cts, error: ctErr } = await context.supabase
      .from("file_container_types")
      .select(`id,${CT_COPY_FIELDS.join(",")}`)
      .eq("file_id", data.file_id);
    if (ctErr) throw new Error(ctErr.message);

    const overrides = data.container_qty_overrides ?? {};
    const ctRows = (cts ?? [])
      .map((row: any) => {
        const out: Record<string, any> = { file_id: newId };
        for (const f of CT_COPY_FIELDS) out[f] = row[f];
        const ov = overrides[row.id];
        if (typeof ov === "number" && ov >= 1) out.planned_qty = ov;
        return out;
      })
      .filter((r: any) => Number(r.planned_qty) >= 1);

    if (ctRows.length) {
      const { error: insCtErr } = await context.supabase
        .from("file_container_types")
        .insert(ctRows as never);
      if (insCtErr) throw new Error(insCtErr.message);
    }

    if (data.mode === "with_budget") {
      const oldQtyByType = new Map<string, number>();
      const newQtyByType = new Map<string, number>();
      for (const row of cts ?? []) {
        const ct = (row as any).container_type as string | null;
        if (!ct) continue;
        const oldQty = Number((row as any).planned_qty) || 0;
        const ov = overrides[(row as any).id];
        const newQty = typeof ov === "number" && ov >= 1 ? ov : oldQty;
        oldQtyByType.set(ct, oldQty);
        newQtyByType.set(ct, newQty);
      }

      const { data: bl, error: blErr } = await context.supabase
        .from("file_budget_plan_lines")
        .select(BPL_COPY_FIELDS.join(","))
        .eq("file_id", data.file_id);
      if (blErr) throw new Error(blErr.message);
      const blRows = (bl ?? [])
        .map((row: any) => {
          const out: Record<string, any> = { file_id: newId };
          for (const f of BPL_COPY_FIELDS) out[f] = row[f];
          const ct = row.container_type as string | null;
          if (ct && newQtyByType.has(ct)) {
            const newQty = newQtyByType.get(ct)!;
            if (newQty < 1) return null;
            const oldQty = oldQtyByType.get(ct) ?? 0;
            out.planned_qty = newQty;
            const scale = oldQty > 0 ? newQty / oldQty : null;
            out.amount_usd =
              scale != null && row.amount_usd != null ? Number(row.amount_usd) * scale : null;
            out.amount_eur =
              scale != null && row.amount_eur != null ? Number(row.amount_eur) * scale : null;
          }
          return out;
        })
        .filter((r: any): r is Record<string, any> => r !== null);
      if (blRows.length) {
        const { error: insBlErr } = await context.supabase
          .from("file_budget_plan_lines")
          .insert(blRows as never);
        if (insBlErr) throw new Error(insBlErr.message);
      }
    }

    await context.supabase.from("file_audit_log").insert({
      file_id: newId,
      action: "copied_from",
      details: { source_file_id: data.file_id, mode: data.mode } as any,
      actor_id: context.userId,
    } as never);

    const { data: newFile } = await context.supabase
      .from("files")
      .select("file_number")
      .eq("id", newId)
      .maybeSingle();

    return { id: newId, file_number: newFile?.file_number ?? null };
  });
