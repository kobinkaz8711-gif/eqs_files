import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requirePermission } from "@/lib/permissions";

export const listSalesPersons = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("sales_persons")
      .select("id,full_name,is_active,department_id,departments(id,name,code)")
      .order("is_active", { ascending: false })
      .order("full_name", { ascending: true });
    if (error) throw new Error(error.message);
    return { items: data ?? [] };
  });

export const createSalesPerson = createServerFn({ method: "POST" })
  .middleware([requirePermission("admin.full")])
  .inputValidator((input) =>
    z
      .object({
        full_name: z.string().min(1).max(200),
        department_id: z.string().uuid().nullable().optional(),
        is_active: z.boolean().optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { data: row, error } = await context.supabase
      .from("sales_persons")
      .insert({
        full_name: data.full_name.trim(),
        department_id: data.department_id ?? null,
        is_active: data.is_active ?? true,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const updateSalesPerson = createServerFn({ method: "POST" })
  .middleware([requirePermission("admin.full")])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid(),
        full_name: z.string().min(1).max(200).optional(),
        department_id: z.string().uuid().nullable().optional(),
        is_active: z.boolean().optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { id, ...patch } = data;
    const { error } = await context.supabase
      .from("sales_persons")
      .update(patch)
      .eq("id", id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteSalesPerson = createServerFn({ method: "POST" })
  .middleware([requirePermission("admin.full")])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("sales_persons")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
