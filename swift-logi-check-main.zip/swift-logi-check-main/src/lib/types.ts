export type TransportTypeCode = string;

export interface TransportType {
  code: TransportTypeCode;
  label: string;
}

export interface ChecklistItem {
  id: string;
  label: string;
  hint?: string | null;
  required: boolean;
  critical: boolean;
  sort_order: number;
  depends_on_item_id?: string | null;
}

export interface ChecklistSection {
  id: string;
  title: string;
  sort_order: number;
  items: ChecklistItem[];
}

export interface ChecklistTemplate {
  id: string;
  transport_type_code: TransportTypeCode;
  name: string;
  sections: ChecklistSection[];
}

export type CheckedState = Record<string, boolean>;

export interface MissingItem extends ChecklistItem {
  parent_id?: string | null;
  parent_label?: string | null;
}

export interface ValidationResult {
  total: number;
  checked: number;
  completionPct: number;
  missing: MissingItem[];
  criticalMissing: MissingItem[];
  sectionStatus: Record<
    string,
    { total: number; checked: number; complete: boolean; hasCritical: boolean }
  >;
}

export interface GeneratedEmail {
  subject: string;
  body: string;
  ok: boolean;
}
