import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type ApiKeyPublic = {
  id: string;
  last4: string;
  key_length: number;
  label: string | null;
  created_at: string;
};

export const listApiKeys = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("container_extractor_api_keys_public" as never)
      .select("id, last4, key_length, label, created_at")
      .order("created_at", { ascending: true });
    if (error) throw new Error(error.message);
    return (data ?? []) as ApiKeyPublic[];
  });

export const addApiKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        key: z.string().trim().min(20).max(200),
        label: z.string().trim().max(100).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("container_extractor_api_keys" as never)
      .insert({
        key_value: data.key,
        label: data.label ?? null,
        created_by: userId,
      } as never);
    if (error) {
      if ((error as { code?: string }).code === "23505") {
        throw new Error("Такой ключ уже добавлен");
      }
      throw new Error(error.message);
    }
    return { ok: true as const };
  });

export const deleteApiKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase
      .from("container_extractor_api_keys" as never)
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
