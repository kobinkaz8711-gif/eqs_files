import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const FiltersSchema = z
  .object({
    dateFrom: z.string().optional(),
    dateTo: z.string().optional(),
    buyer: z.string().optional(),
    salesPersons: z.array(z.string()).optional(),
    countries: z.array(z.string()).optional(),
    isoCodes: z.array(z.string()).optional(),
    direction: z.enum(["ALL", "SALE", "CN"]).optional(),
    linkStatus: z.enum(["ALL", "LINKED", "UNLINKED"]).optional(),
  })
  .default({});

export type SalesFilters = z.infer<typeof FiltersSchema>;

export const getSalesDashboard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: SalesFilters) => FiltersSchema.parse(d ?? {}))
  .handler(async ({ data, context }) => {
    const supabase = context.supabase;

    // 1) Build filtered sales query (server-side) — paginate around PostgREST 1000-row cap
    const buildQuery = () => {
      let q = supabase
        .from("eqs_ext_sales")
        .select(
          "id,unit_no,unit_iso,sale_direction,invoice_no,invoice_date,amount,amount_base,currency,buyer_accno,buyer_name,sales_person,sale_locn,sale_subregion",
        );
      if (data.dateFrom) q = q.gte("invoice_date", data.dateFrom);
      if (data.dateTo) q = q.lte("invoice_date", data.dateTo);
      if (data.buyer) {
        const t = data.buyer.trim();
        q = q.or(`buyer_accno.ilike.%${t}%,buyer_name.ilike.%${t}%`);
      }
      if (data.salesPersons?.length) q = q.in("sales_person", data.salesPersons);
      if (data.countries?.length) q = q.in("sale_subregion", data.countries);
      if (data.isoCodes?.length) q = q.in("unit_iso", data.isoCodes);
      if (data.direction === "SALE") q = q.eq("sale_direction", "SALE");
      else if (data.direction === "CN") q = q.eq("sale_direction", "CN");
      return q
        .order("invoice_date", { ascending: false })
        .order("id", { ascending: true });
    };

    const CHUNK = 1000;
    const MAX_ROWS = 100000;
    const sales: any[] = [];
    for (let from = 0; from < MAX_ROWS; from += CHUNK) {
      const { data: chunk, error } = await buildQuery().range(from, from + CHUNK - 1);
      if (error) throw error;
      if (!chunk?.length) break;
      sales.push(...chunk);
      if (chunk.length < CHUNK) break;
    }


    // Location/subregion descriptions — fetch only codes present in sales rows
    const locnCodes = Array.from(
      new Set((sales ?? []).map((s: any) => s.sale_locn).filter(Boolean) as string[]),
    );
    const subCodes = Array.from(
      new Set((sales ?? []).map((s: any) => s.sale_subregion).filter(Boolean) as string[]),
    );
    const locnDesc = new Map<string, string>();
    const subDesc = new Map<string, string>();
    if (locnCodes.length) {
      const { data: locRows } = await supabase
        .from("eqs_ext_locations_subregions")
        .select("locn_id,locn_desc")
        .in("locn_id", locnCodes);
      for (const l of locRows ?? []) {
        if (l.locn_id && l.locn_desc && !locnDesc.has(l.locn_id)) {
          locnDesc.set(l.locn_id, l.locn_desc);
        }
      }
    }
    if (subCodes.length) {
      const { data: subRows } = await supabase
        .from("eqs_ext_locations_subregions")
        .select("subregion_id,subregion_desc")
        .in("subregion_id", subCodes)
        .not("subregion_desc", "is", null);
      for (const l of subRows ?? []) {
        if (l.subregion_id && l.subregion_desc && !subDesc.has(l.subregion_id)) {
          subDesc.set(l.subregion_id, l.subregion_desc);
        }
      }
    }

    // 2) File linking via active file_unit_assignments by unit_no + invoice_date window
    const unitSet = new Set((sales ?? []).map((s: any) => s.unit_no).filter(Boolean));
    type Assn = {
      file_id: string;
      unit_no: string;
      effective_date_from: string | null;
      effective_date_to: string | null;
      file_number?: string | null;
      file_status?: string | null;
    };
    let assignments: Assn[] = [];
    if (unitSet.size > 0) {
      const units = Array.from(unitSet);
      const ASSN_CHUNK = 500;
      for (let i = 0; i < units.length; i += ASSN_CHUNK) {
        const slice = units.slice(i, i + ASSN_CHUNK);
        const { data: a, error: aErr } = await supabase
          .from("file_unit_assignments")
          .select(
            "file_id,unit_no,effective_date_from,effective_date_to,is_active,files(file_number,status)",
          )
          .eq("is_active", true)
          .in("unit_no", slice);
        if (aErr) throw aErr;
        for (const r of a ?? []) {
          assignments.push({
            file_id: (r as any).file_id,
            unit_no: (r as any).unit_no,
            effective_date_from: (r as any).effective_date_from,
            effective_date_to: (r as any).effective_date_to,
            file_number: (r as any).files?.file_number ?? null,
            file_status: (r as any).files?.status ?? null,
          });
        }
      }
    }
    const byUnit = new Map<string, Assn[]>();
    for (const a of assignments) {
      if (!byUnit.has(a.unit_no)) byUnit.set(a.unit_no, []);
      byUnit.get(a.unit_no)!.push(a);
    }

    // 3) Enrich
    const rows = (sales ?? []).map((s: any) => {
      const list = byUnit.get(s.unit_no) ?? [];
      const d = s.invoice_date;
      const match = list.find(
        (a) =>
          (!a.effective_date_from || a.effective_date_from <= d) &&
          (!a.effective_date_to || a.effective_date_to >= d),
      );
      return {
        ...s,
        sale_locn_desc: s.sale_locn ? locnDesc.get(s.sale_locn) ?? s.sale_locn : null,
        sale_subregion_desc: s.sale_subregion
          ? subDesc.get(s.sale_subregion) ?? s.sale_subregion
          : null,
        file_id: match?.file_id ?? null,
        file_number: match?.file_number ?? null,
        file_status: match?.file_status ?? null,
      };
    });

    // 4) Optional link-status filter (post-join)
    const filtered =
      data.linkStatus === "LINKED"
        ? rows.filter((r) => r.file_id)
        : data.linkStatus === "UNLINKED"
          ? rows.filter((r) => !r.file_id)
          : rows;

    // 5) KPI + aggregates (across `filtered`)
    const num = (x: any) => Number(x ?? 0);
    let totalSales = 0,
      totalCN = 0,
      linkedAmt = 0,
      linkedCnt = 0;
    const containersSale = new Set<string>();
    const invoicesSale = new Set<string>();
    const invoicesCN = new Set<string>();
    const buyerAgg = new Map<string, { name: string; amt: number; cnt: number }>();
    const spAgg = new Map<string, { amt: number; cnt: number }>();
    const countryAgg = new Map<
      string,
      { code: string; label: string; amt: number; cnt: number }
    >();
    const isoAgg = new Map<string, { amt: number; cnt: number }>();
    const monthAgg = new Map<string, { sale: number; cn: number }>();

    for (const r of filtered) {
      const amt = num(r.amount_base);
      const isCN = r.sale_direction === "CN" || amt < 0;
      if (isCN) {
        totalCN += amt;
        if (r.invoice_no) invoicesCN.add(r.invoice_no);
      } else {
        totalSales += amt;
        if (r.invoice_no) invoicesSale.add(r.invoice_no);
        if (r.unit_no) containersSale.add(r.unit_no);
      }
      if (r.file_id) {
        linkedAmt += amt;
        linkedCnt += 1;
      }
      if (r.buyer_accno) {
        const e = buyerAgg.get(r.buyer_accno) ?? {
          name: r.buyer_name ?? r.buyer_accno,
          amt: 0,
          cnt: 0,
        };
        e.amt += amt;
        e.cnt += 1;
        buyerAgg.set(r.buyer_accno, e);
      }
      if (r.sales_person) {
        const e = spAgg.get(r.sales_person) ?? { amt: 0, cnt: 0 };
        e.amt += amt;
        e.cnt += 1;
        spAgg.set(r.sales_person, e);
      }
      if (r.sale_subregion) {
        const code = r.sale_subregion;
        const label = r.sale_subregion_desc ?? code;
        const e = countryAgg.get(code) ?? { code, label, amt: 0, cnt: 0 };
        e.amt += amt;
        e.cnt += 1;
        countryAgg.set(code, e);
      }
      if (r.unit_iso) {
        const e = isoAgg.get(r.unit_iso) ?? { amt: 0, cnt: 0 };
        e.amt += amt;
        e.cnt += 1;
        isoAgg.set(r.unit_iso, e);
      }
      if (r.invoice_date) {
        const m = String(r.invoice_date).slice(0, 7);
        const e = monthAgg.get(m) ?? { sale: 0, cn: 0 };
        if (isCN) e.cn += amt;
        else e.sale += amt;
        monthAgg.set(m, e);
      }
    }
    const cntSale = invoicesSale.size;
    const cntCN = invoicesCN.size;

    const topBuyers = Array.from(buyerAgg.entries())
      .map(([accno, v]) => ({ accno, ...v }))
      .sort((a, b) => b.amt - a.amt)
      .slice(0, 10);
    const topSP = Array.from(spAgg.entries())
      .map(([sp, v]) => ({ sp, ...v }))
      .sort((a, b) => b.amt - a.amt);
    const byCountry = Array.from(countryAgg.values())
      .map((v) => ({ country: v.label, code: v.code, amt: v.amt, cnt: v.cnt }))
      .sort((a, b) => b.amt - a.amt);
    const byIso = Array.from(isoAgg.entries())
      .map(([iso, v]) => ({ iso, ...v }))
      .sort((a, b) => b.amt - a.amt);
    const byMonth = Array.from(monthAgg.entries())
      .map(([month, v]) => ({ month, ...v }))
      .sort((a, b) => (a.month < b.month ? -1 : 1));

    const total = filtered.length;
    return {
      rows: filtered,
      kpi: {
        totalSales,
        cntSale,
        containers: containersSale.size,
        avgPrice: containersSale.size ? totalSales / containersSale.size : 0,
        totalCN,
        cntCN,
        linkedAmt,
        linkedCnt,
        unlinkedAmt: totalSales + totalCN - linkedAmt,
        unlinkedCnt: total - linkedCnt,
        linkedPctCnt: total ? (linkedCnt / total) * 100 : 0,
        linkedPctAmt:
          totalSales + totalCN !== 0
            ? (linkedAmt / (totalSales + totalCN)) * 100
            : 0,
        total,
      },
      topBuyers,
      topSP,
      byCountry,
      byIso,
      byMonth,
    };
  });

export const getSalesFilterOptions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const supabase = context.supabase;
    const CHUNK = 1000;
    const MAX_ROWS = 100000;
    const sp = new Set<string>();
    const cn = new Set<string>();
    const iso = new Set<string>();
    for (let from = 0; from < MAX_ROWS; from += CHUNK) {
      const { data: chunk } = await supabase
        .from("eqs_ext_sales")
        .select("sales_person,sale_subregion,unit_iso")
        .order("id", { ascending: true })
        .range(from, from + CHUNK - 1);
      if (!chunk?.length) break;
      for (const r of chunk) {
        if (r.sales_person) sp.add(r.sales_person);
        if (r.sale_subregion) cn.add(r.sale_subregion);
        if (r.unit_iso) iso.add(r.unit_iso);
      }
      if (chunk.length < CHUNK) break;
    }
    const subCodes = Array.from(cn);
    const subDesc = new Map<string, string>();
    if (subCodes.length) {
      const { data: locs } = await supabase
        .from("eqs_ext_locations_subregions")
        .select("subregion_id,subregion_desc")
        .in("subregion_id", subCodes)
        .not("subregion_desc", "is", null);
      for (const l of locs ?? []) {
        if (l.subregion_id && l.subregion_desc && !subDesc.has(l.subregion_id)) {
          subDesc.set(l.subregion_id, l.subregion_desc);
        }
      }
    }
    const countries = subCodes
      .map((code) => ({ code, label: subDesc.get(code) ?? code }))
      .sort((a, b) => a.label.localeCompare(b.label));
    return {
      salesPersons: Array.from(sp).sort(),
      countries,
      isoCodes: Array.from(iso).sort(),
    };
  });
