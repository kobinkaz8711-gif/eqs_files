import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requirePermission } from "@/lib/permissions";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export interface UserListItem {
  id: string;
  email: string;
  full_name: string | null;
  position: string | null;
  department_id: string | null;
  department: { id: string; name: string } | null;
  is_active: boolean;
  created_at: string;
  roles: { id: string; name: string }[];
}

export const listUsers = createServerFn({ method: "GET" })
  .middleware([requirePermission("users.manage")])
  .inputValidator((input: unknown) =>
    z
      .object({
        search: z.string().max(120).optional(),
        roleId: z.string().uuid().optional(),
        status: z.enum(["all", "active", "inactive"]).optional().default("all"),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ data }) => {
    let query = supabaseAdmin
      .from("profiles")
      .select(
        "id,email,full_name,position,department_id,is_active,created_at,department:departments(id,name),user_roles(role:roles(id,name))",
      )
      .order("created_at", { ascending: false });

    if (data.status === "active") query = query.eq("is_active", true);
    if (data.status === "inactive") query = query.eq("is_active", false);
    if (data.search) {
      const s = data.search.replace(/[%_]/g, "");
      query = query.or(`email.ilike.%${s}%,full_name.ilike.%${s}%`);
    }

    const { data: rows, error } = await query;
    if (error) throw new Error(error.message);


    type Row = Omit<UserListItem, "roles"> & {
      user_roles: { role: { id: string; name: string } | null }[];
    };
    let items: UserListItem[] = ((rows ?? []) as unknown as Row[]).map((r) => ({
      id: r.id,
      email: r.email,
      full_name: r.full_name,
      position: r.position,
      department_id: r.department_id,
      department: r.department,
      is_active: r.is_active,
      created_at: r.created_at,
      roles: (r.user_roles ?? [])
        .map((ur) => ur.role)
        .filter((x): x is { id: string; name: string } => !!x),
    }));

    if (data.roleId) {
      items = items.filter((u) => u.roles.some((r) => r.id === data.roleId));
    }
    return { items };
  });

const createSchema = z.object({
  email: z.string().email().max(255),
  password: z.string().min(8).max(72),
  full_name: z.string().min(1).max(255),
  position: z.string().max(255).optional(),
  department_id: z.string().uuid().nullable().optional(),
  role_ids: z.array(z.string().uuid()).default([]),
});

export const createUser = createServerFn({ method: "POST" })
  .middleware([requirePermission("users.manage")])
  .inputValidator((input) => createSchema.parse(input))
  .handler(async ({ data }) => {
    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name: data.full_name },
    });
    if (error) throw new Error(error.message);
    const userId = created.user?.id;
    if (!userId) throw new Error("Не удалось создать пользователя");

    await supabaseAdmin
      .from("profiles")
      .update({
        full_name: data.full_name,
        position: data.position ?? null,
        department_id: data.department_id ?? null,
      })
      .eq("id", userId);

    if (data.role_ids.length) {
      await supabaseAdmin
        .from("user_roles")
        .insert(data.role_ids.map((role_id) => ({ user_id: userId, role_id })));
    }
    return { id: userId, email: data.email };
  });

export const updateUser = createServerFn({ method: "POST" })
  .middleware([requirePermission("users.manage")])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid(),
        full_name: z.string().min(1).max(255).optional(),
        position: z.string().max(255).nullable().optional(),
        department_id: z.string().uuid().nullable().optional(),
        is_active: z.boolean().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { id, ...patch } = data;
    const { error } = await supabaseAdmin.from("profiles").update(patch).eq("id", id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setUserRoles = createServerFn({ method: "POST" })
  .middleware([requirePermission("users.manage")])
  .inputValidator((input) =>
    z
      .object({
        user_id: z.string().uuid(),
        role_ids: z.array(z.string().uuid()),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { error: delErr } = await supabaseAdmin
      .from("user_roles")
      .delete()
      .eq("user_id", data.user_id);
    if (delErr) throw new Error(delErr.message);
    if (data.role_ids.length) {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .insert(data.role_ids.map((role_id) => ({ user_id: data.user_id, role_id })));
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const sendPasswordReset = createServerFn({ method: "POST" })
  .middleware([requirePermission("users.manage")])
  .inputValidator((input) => z.object({ email: z.string().email() }).parse(input))
  .handler(async ({ data }) => {
    const origin = process.env.SITE_URL || "";
    const { error } = await supabaseAdmin.auth.resetPasswordForEmail(data.email, {
      redirectTo: origin ? `${origin}/reset-password` : undefined,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
