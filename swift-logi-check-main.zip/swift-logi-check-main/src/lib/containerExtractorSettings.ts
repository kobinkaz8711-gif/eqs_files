import { useEffect, useState, useCallback } from "react";

export const ALL_FIELDS = [
  "container_number",
  "equipment",
  "supplier",
  "manufacturer",
  "gross_weight",
  "tare_weight",
  "payload",
  "csc_number",
  "csc_valid_to",
  "iso_code",
  "year",
] as const;

export type FieldKey = (typeof ALL_FIELDS)[number];

const KEYS_STORAGE = "cci.apiKeys";
const COLS_STORAGE = "cci.visibleColumns";

function readJSON<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJSON(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}

export function useApiKeys() {
  const [keys, setKeys] = useState<string[]>([]);
  useEffect(() => {
    setKeys(readJSON<string[]>(KEYS_STORAGE, []));
  }, []);
  const save = useCallback((next: string[]) => {
    const cleaned = next.map((k) => k.trim()).filter(Boolean);
    setKeys(cleaned);
    writeJSON(KEYS_STORAGE, cleaned);
  }, []);
  return [keys, save] as const;
}

export function useVisibleColumns() {
  const [cols, setCols] = useState<FieldKey[]>([...ALL_FIELDS]);
  useEffect(() => {
    const stored = readJSON<FieldKey[] | null>(COLS_STORAGE, null);
    if (stored && stored.length) {
      setCols(stored.filter((c) => (ALL_FIELDS as readonly string[]).includes(c)) as FieldKey[]);
    }
  }, []);
  const save = useCallback((next: FieldKey[]) => {
    setCols(next);
    writeJSON(COLS_STORAGE, next);
  }, []);
  return [cols, save] as const;
}
