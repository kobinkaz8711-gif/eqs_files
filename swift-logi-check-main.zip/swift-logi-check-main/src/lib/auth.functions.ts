import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const getMyContext = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const [profileRes, rolesRes, permsRes] = await Promise.all([
      supabase
        .from("profiles")
        .select("id,email,full_name,position,department_id,is_active,department:departments(id,name)")
        .eq("id", userId)
        .maybeSingle(),
      supabase
        .from("user_roles")
        .select("role:roles(id,name)")
        .eq("user_id", userId),
      supabase
        .from("user_roles")
        .select("role:roles(role_permissions(permission:permissions(code)))")
        .eq("user_id", userId),
    ]);

    type ProfileRow = {
      id: string;
      email: string;
      full_name: string | null;
      position: string | null;
      department_id: string | null;
      is_active: boolean;
      department: { id: string; name: string } | null;
    };
    const profile = (profileRes.data as ProfileRow | null) ?? null;
    const roles = (rolesRes.data ?? [])
      .map((r: { role: { id: string; name: string } | null }) => r.role)
      .filter((r): r is { id: string; name: string } => !!r);

    const permSet = new Set<string>();
    type PermRow = {
      role: { role_permissions: { permission: { code: string } | null }[] } | null;
    };
    for (const row of (permsRes.data ?? []) as PermRow[]) {
      const rps = row.role?.role_permissions ?? [];
      for (const rp of rps) {
        if (rp.permission?.code) permSet.add(rp.permission.code);
      }
    }
    return {
      profile,
      roles,
      permissions: Array.from(permSet),
    };
  });
