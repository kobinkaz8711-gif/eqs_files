import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requirePermission } from "@/lib/permissions";

export interface FeatureFlagDTO {
  code: string;
  enabled: boolean;
}

export const FEATURE_FLAGS: { code: string; label: string; description: string }[] = [
  {
    code: "create_files_from_sales_invoices",
    label: "Creating files from sales invoices",
    description:
      "Включает на дашборде продаж выбор строк и создание файла по сейлз-инвойсам. Привязка по booking работает всегда.",
  },
];

export const listFeatureFlags = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("feature_flags")
      .select("code,enabled");
    if (error) throw new Error(error.message);
    const map = new Map<string, boolean>(
      (data ?? []).map((r: { code: string; enabled: boolean }) => [r.code, r.enabled]),
    );
    const items: FeatureFlagDTO[] = FEATURE_FLAGS.map((f) => ({
      code: f.code,
      enabled: map.get(f.code) ?? false,
    }));
    return { items };
  });

export const setFeatureFlag = createServerFn({ method: "POST" })
  .middleware([requirePermission("modules.manage")])
  .inputValidator((input) =>
    z
      .object({ code: z.string().min(1).max(64), enabled: z.boolean() })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("feature_flags")
      .upsert({ code: data.code, enabled: data.enabled }, { onConflict: "code" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
