import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  fileName: z.string().min(1).max(300),
  mimeType: z.string().min(1).max(100),
  base64: z.string().min(10).max(25_000_000),
});

export type ExtractedCertificate = {
  container_number: string | null;
  equipment: string | null;
  supplier: string | null;
  manufacturer: string | null;
  gross_weight: string | null;
  tare_weight: string | null;
  payload: string | null;
  csc_number: string | null;
  csc_valid_to: string | null;
  iso_code: string | null;
  year: string | null;
};

const EXTRACT_PROMPT = `You are an expert at reading container certificates (CSC plates / manufacturer plates / certification documents) for shipping containers.

Extract the following fields from the provided document. Return STRICT JSON only, no prose, no markdown. Use null for any field you cannot confidently read.

Fields:
- container_number (e.g. ABCU1234567)
- equipment (container type, e.g. "40' HC", "20' DC")
- supplier
- manufacturer
- gross_weight (with unit, e.g. "30480 kg")
- tare_weight (with unit)
- payload (with unit)
- csc_number (CSC Safety Approval Number)
- csc_valid_to (next examination / valid until date, ISO if possible: YYYY-MM-DD)
- iso_code (e.g. 45G1)
- year (year of manufacture, 4 digits)

Return JSON shaped exactly:
{"container_number":..,"equipment":..,"supplier":..,"manufacturer":..,"gross_weight":..,"tare_weight":..,"payload":..,"csc_number":..,"csc_valid_to":..,"iso_code":..,"year":..}`;

async function callGemini(apiKey: string, mimeType: string, base64: string) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  const body = {
    contents: [
      {
        role: "user",
        parts: [
          { text: EXTRACT_PROMPT },
          { inlineData: { mimeType, data: base64 } },
        ],
      },
    ],
    generationConfig: { temperature: 0.1, responseMimeType: "application/json" },
  };
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  return { status: res.status, ok: res.ok, text };
}

function isQuotaError(status: number, text: string) {
  if (status === 429 || status === 403) return true;
  const lower = text.toLowerCase();
  return (
    lower.includes("quota") ||
    lower.includes("rate limit") ||
    lower.includes("resource_exhausted") ||
    lower.includes("exceeded")
  );
}

export const extractCertificate = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => InputSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error: keysErr } = await supabaseAdmin
      .from("container_extractor_api_keys")
      .select("key_value")
      .order("created_at", { ascending: true });
    if (keysErr) {
      return { ok: false as const, error: `Failed to load API keys: ${keysErr.message}` };
    }
    const keys = (rows ?? []).map((r) => r.key_value).filter(Boolean);

    if (!keys.length) {
      return {
        ok: false as const,
        error: "No Gemini API key configured. Add keys in module settings.",
      };
    }


    const start = Date.now();
    let lastError = "";
    let lastStatus = 0;
    let usedIndex = -1;

    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      try {
        const { status, ok, text } = await callGemini(key, data.mimeType, data.base64);
        if (ok) {
          usedIndex = i;
          let parsed: ExtractedCertificate | null = null;
          try {
            const json = JSON.parse(text) as {
              candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
            };
            const out = json.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") ?? "";
            const cleaned = out.trim().replace(/^```json\s*/i, "").replace(/```$/g, "").trim();
            parsed = JSON.parse(cleaned) as ExtractedCertificate;
          } catch {
            return {
              ok: false as const,
              error: "Failed to parse Gemini response as JSON.",
              elapsedMs: Date.now() - start,
            };
          }
          return {
            ok: true as const,
            data: parsed,
            elapsedMs: Date.now() - start,
            fileName: data.fileName,
            keyIndex: usedIndex,
          };
        }

        lastStatus = status;
        lastError = `Gemini API error ${status}: ${text.slice(0, 300)}`;
        if (!isQuotaError(status, text)) {
          // Non-quota error — don't waste other keys
          return { ok: false as const, error: lastError, elapsedMs: Date.now() - start };
        }
        // else: continue to next key
      } catch (e) {
        lastError = e instanceof Error ? e.message : "Network error";
        // try next key on network failures too
      }
    }

    return {
      ok: false as const,
      error: `All ${keys.length} key(s) failed. Last: ${lastError || `status ${lastStatus}`}`,
      elapsedMs: Date.now() - start,
    };
  });
