import { toast } from "sonner";

export async function copyText(text: string, successMsg = "Скопировано") {
  try {
    await navigator.clipboard.writeText(text);
    toast.success(successMsg);
  } catch {
    toast.error("Не удалось скопировать");
  }
}
