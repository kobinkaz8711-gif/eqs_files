import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requirePermission } from "@/lib/permissions";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export interface RoleWithPermissions {
  id: string;
  name: string;
  description: string | null;
  is_system: boolean;
  permission_ids: string[];
}

export const listRoles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("roles")
      .select("id,name,description,is_system,role_permissions(permission_id)")
      .order("name");
    if (error) throw new Error(error.message);
    type Row = {
      id: string;
      name: string;
      description: string | null;
      is_system: boolean;
      role_permissions: { permission_id: string }[];
    };
    const items: RoleWithPermissions[] = ((data ?? []) as Row[]).map((r) => ({
      id: r.id,
      name: r.name,
      description: r.description,
      is_system: r.is_system,
      permission_ids: r.role_permissions.map((rp) => rp.permission_id),
    }));
    return { items };
  });

export const listPermissions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("permissions")
      .select("id,code,description")
      .order("code");
    if (error) throw new Error(error.message);
    return { items: data ?? [] };
  });

export const createRole = createServerFn({ method: "POST" })
  .middleware([requirePermission("roles.manage")])
  .inputValidator((input) =>
    z
      .object({
        name: z.string().min(1).max(64).regex(/^[a-zA-Zа-яА-Я0-9 _-]+$/),
        description: z.string().max(500).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { data: row, error } = await supabaseAdmin
      .from("roles")
      .insert({ name: data.name, description: data.description ?? null, is_system: false })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const updateRole = createServerFn({ method: "POST" })
  .middleware([requirePermission("roles.manage")])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid(),
        name: z.string().min(1).max(64).regex(/^[a-zA-Zа-яА-Я0-9 _-]+$/).optional(),
        description: z.string().max(500).nullable().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { id, ...patch } = data;
    const { error } = await supabaseAdmin.from("roles").update(patch).eq("id", id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteRole = createServerFn({ method: "POST" })
  .middleware([requirePermission("roles.manage")])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const { data: role, error: fetchErr } = await supabaseAdmin
      .from("roles")
      .select("is_system")
      .eq("id", data.id)
      .single();
    if (fetchErr) throw new Error(fetchErr.message);
    if (role.is_system) throw new Error("Системную роль нельзя удалить");
    const { error } = await supabaseAdmin.from("roles").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setRolePermissions = createServerFn({ method: "POST" })
  .middleware([requirePermission("roles.manage")])
  .inputValidator((input) =>
    z
      .object({
        role_id: z.string().uuid(),
        permission_ids: z.array(z.string().uuid()),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { error: delErr } = await supabaseAdmin
      .from("role_permissions")
      .delete()
      .eq("role_id", data.role_id);
    if (delErr) throw new Error(delErr.message);
    if (data.permission_ids.length) {
      const { error } = await supabaseAdmin
        .from("role_permissions")
        .insert(
          data.permission_ids.map((permission_id) => ({
            role_id: data.role_id,
            permission_id,
          })),
        );
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });
