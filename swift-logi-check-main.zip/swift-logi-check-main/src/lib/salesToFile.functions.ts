import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const PP_ARTICLE_CODE = "pp";
const SP_ARTICLE_CODE = "selling_price";

async function _resolveLocnNames(
  supabase: any,
  codes: (string | null | undefined)[],
): Promise<{
  nameMap: Record<string, string>;
  countryMap: Record<string, string>;
  subregionMap: Record<string, string>;
  subregionDescMap: Record<string, string>;
}> {
  const uniq = Array.from(new Set(codes.filter((c): c is string => !!c)));
  if (uniq.length === 0)
    return { nameMap: {}, countryMap: {}, subregionMap: {}, subregionDescMap: {} };
  const { data: locs } = await supabase
    .from("eqs_ext_locations_subregions")
    .select("locn_id,locn_desc,country_code,subregion_id,subregion_desc")
    .in("locn_id", uniq);
  const nameMap: Record<string, string> = {};
  const countryMap: Record<string, string> = {};
  const subregionMap: Record<string, string> = {};
  const subregionDescMap: Record<string, string> = {};
  for (const l of locs ?? []) {
    if (l.locn_id && l.locn_desc) nameMap[l.locn_id] = l.locn_desc;
    if (l.locn_id && l.country_code) countryMap[l.locn_id] = l.country_code;
    if (l.locn_id && l.subregion_id) subregionMap[l.locn_id] = l.subregion_id;
    if (l.locn_id && l.subregion_desc) subregionDescMap[l.locn_id] = l.subregion_desc;
  }
  return { nameMap, countryMap, subregionMap, subregionDescMap };
}

function mostFrequent<T>(items: T[]): T | null {
  if (items.length === 0) return null;
  const cnt = new Map<T, number>();
  for (const it of items) cnt.set(it, (cnt.get(it) ?? 0) + 1);
  let best: T | null = null;
  let bestN = -1;
  for (const [k, v] of cnt) if (v > bestN) { best = k; bestN = v; }
  return best;
}

const InputSchema = z.object({
  sale_ids: z.array(z.string().uuid()).min(1).max(2000),
});

async function _resolve(supabase: any, sale_ids: string[]) {
  // Sales rows
  const { data: salesRaw, error: sErr } = await supabase
    .from("eqs_ext_sales")
    .select(
      "id,unit_no,unit_iso,sale_direction,invoice_no,invoice_date,amount,amount_base,currency,buyer_accno,buyer_name,sales_person,sale_locn,sale_subregion",
    )
    .in("id", sale_ids);
  if (sErr) throw new Error(sErr.message);
  const sales = (salesRaw ?? []).filter((r: any) => r.unit_no);
  if (sales.length === 0) throw new Error("No sales lines with units in selection");

  const unitNos = Array.from(new Set(sales.map((s: any) => s.unit_no))) as string[];

  // Units (purchase price + iso), assignments, departments, sales_persons, locations
  const [unitsRes, assignsRes, deptsRes, spRes] = await Promise.all([
    supabase
      .from("eqs_ext_units")
      .select("unit_no,iso_code,amt_ppb,sale_amt_b,status")
      .in("unit_no", unitNos),
    supabase
      .from("file_unit_assignments")
      .select("unit_no,file_id,is_active,files(file_number)")
      .in("unit_no", unitNos)
      .eq("is_active", true),
    supabase.from("departments").select("id,code,name").order("code"),
    supabase.from("sales_persons").select("id,full_name,department_id").eq("is_active", true),
  ]);

  const unitMap = new Map<string, any>();
  for (const u of (unitsRes as any).data ?? []) unitMap.set(u.unit_no, u);
  const assignMap = new Map<string, any>();
  for (const a of (assignsRes as any).data ?? []) assignMap.set(a.unit_no, a);

  // Customer (most-frequent buyer_accno among SALE rows; fall back to all)
  const saleRows = sales.filter((s: any) => s.sale_direction !== "CN");
  const buyerAccno =
    mostFrequent(
      (saleRows.length ? saleRows : sales)
        .map((s: any) => s.buyer_accno)
        .filter(Boolean) as string[],
    ) ?? null;
  const buyerName = (() => {
    const row = sales.find((s: any) => s.buyer_accno === buyerAccno);
    return row?.buyer_name ?? null;
  })();

  // Sales person → department suggestion
  const spName = mostFrequent(
    sales.map((s: any) => s.sales_person).filter(Boolean) as string[],
  );
  const spByName = new Map<string, any>();
  for (const p of (spRes as any).data ?? []) {
    if (p.full_name) spByName.set(p.full_name.toLowerCase(), p);
  }
  const matchedSp = spName ? spByName.get(spName.toLowerCase()) : null;
  const suggestedDeptId = matchedSp?.department_id ?? null;
  const suggestedSpId = matchedSp?.id ?? null;


  // Destination — most-frequent sale_locn / sale_subregion
  const destLocn = mostFrequent(
    sales.map((s: any) => s.sale_locn).filter(Boolean) as string[],
  );
  const destSubregion = mostFrequent(
    sales.map((s: any) => s.sale_subregion).filter(Boolean) as string[],
  );

  const locResolved = await _resolveLocnNames(supabase, [destLocn]);

  // Per-unit sale amount (sum amount_base of selected lines per unit)
  const saleByUnit = new Map<string, number>();
  for (const s of sales) {
    const v = Number(s.amount_base ?? 0);
    saleByUnit.set(s.unit_no, (saleByUnit.get(s.unit_no) ?? 0) + v);
  }

  // Aggregate units list (one per unit_no)
  const units = unitNos.map((un) => {
    const u = unitMap.get(un) ?? {};
    const a = assignMap.get(un);
    // fallback iso from sales row
    const isoFromSales = sales.find((s: any) => s.unit_no === un && s.unit_iso)?.unit_iso;
    return {
      unit_no: un,
      iso_code: u.iso_code ?? isoFromSales ?? null,
      onhire_date: null,
      amt_ppb: u.amt_ppb == null ? null : Number(u.amt_ppb),
      sale_amt_b: saleByUnit.get(un) ?? null,
      status: u.status ?? null,
      already_linked_file_id: a?.file_id ?? null,
      already_linked_file_number: a?.files?.file_number ?? null,
    };
  });

  // Group by type
  const typeAgg = new Map<
    string,
    { qty: number; sum_ppb: number; count_ppb: number; sum_sale: number; count_sale: number }
  >();
  for (const u of units) {
    if (u.already_linked_file_id) continue;
    const t = (u.iso_code as string) ?? "UNK";
    if (!typeAgg.has(t))
      typeAgg.set(t, { qty: 0, sum_ppb: 0, count_ppb: 0, sum_sale: 0, count_sale: 0 });
    const a = typeAgg.get(t)!;
    a.qty++;
    if (u.amt_ppb != null) {
      a.sum_ppb += u.amt_ppb;
      a.count_ppb++;
    }
    if (u.sale_amt_b != null) {
      a.sum_sale += u.sale_amt_b;
      a.count_sale++;
    }
  }
  const container_types = Array.from(typeAgg.entries()).map(([container_type, a]) => ({
    container_type,
    qty: a.qty,
    avg_purchase: a.count_ppb > 0 ? a.sum_ppb / a.count_ppb : null,
    avg_sale: a.count_sale > 0 ? a.sum_sale / a.count_sale : null,
    missing_purchase: a.qty - a.count_ppb,
    missing_sale: a.qty - a.count_sale,
  }));

  const plannedArrival = sales
    .map((s: any) => s.invoice_date)
    .filter(Boolean)
    .sort()[0] ?? null;

  const currency = mostFrequent(
    sales.map((s: any) => s.currency).filter(Boolean) as string[],
  );

  return {
    sales,
    units,
    typeAgg,
    container_types,
    departments: (deptsRes as any).data ?? [],
    customer_accno: buyerAccno,
    customer_name: buyerName,
    sales_person: spName,
    suggested_sales_person_id: suggestedSpId,
    suggested_department_id: suggestedDeptId,

    dest_locn: destLocn,
    dest_locn_name: destLocn ? locResolved.nameMap[destLocn] ?? null : null,
    dest_subregion:
      (destLocn ? locResolved.subregionMap[destLocn] : null) ?? destSubregion ?? null,
    dest_subregion_desc: destLocn ? locResolved.subregionDescMap[destLocn] ?? null : null,
    dest_country_code: destLocn ? locResolved.countryMap[destLocn] ?? null : null,
    planned_departure_date: null as string | null,
    planned_arrival_date: plannedArrival,
    suggested_currency: (currency === "EUR" ? "EUR" : "USD") as "USD" | "EUR",
  };
}

export const previewFileFromSales = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => InputSchema.parse(input))
  .handler(async ({ context, data }) => {
    const r = await _resolve(context.supabase, data.sale_ids);
    return {
      sale_ids: data.sale_ids,
      booking_no: null as string | null,
      customer_accno: r.customer_accno,
      customer_name: r.customer_name,
      sales_person: r.sales_person,
      suggested_sales_person_id: r.suggested_sales_person_id,
      suggested_department_id: r.suggested_department_id,
      suggested_currency: r.suggested_currency,

      origin_locn: null,
      origin_locn_name: null,
      origin_subregion: null,
      origin_subregion_desc: null,
      origin_country_code: null,
      dest_locn: r.dest_locn,
      dest_locn_name: r.dest_locn_name,
      dest_subregion: r.dest_subregion,
      dest_subregion_desc: r.dest_subregion_desc,
      dest_country_code: r.dest_country_code,
      planned_departure_date: r.planned_departure_date,
      planned_arrival_date: r.planned_arrival_date,
      units: r.units,
      container_types: r.container_types,
      departments: r.departments,
    };
  });

const CreateSchema = z.object({
  sale_ids: z.array(z.string().uuid()).min(1).max(2000),
  department_id: z.string().uuid(),
  currency: z.enum(["USD", "EUR"]).default("USD"),
  customer_accno: z.string().trim().min(1).max(50).optional().nullable(),
  customer_name: z.string().trim().min(1).max(200).optional().nullable(),
  sales_person: z.string().trim().max(200).optional().nullable(),
  sales_person_id: z.string().uuid().optional().nullable(),
  origin_locn: z.string().trim().max(20).optional().nullable(),
  origin_subregion: z.string().trim().max(40).optional().nullable(),
  origin_country_code: z.string().trim().max(8).optional().nullable(),
  dest_locn: z.string().trim().max(20).optional().nullable(),
  dest_subregion: z.string().trim().max(40).optional().nullable(),
  dest_country_code: z.string().trim().max(8).optional().nullable(),
  planned_departure_date: z.string().trim().min(1).optional().nullable(),
  planned_arrival_date: z.string().trim().min(1).optional().nullable(),
  notes: z.string().max(2000).optional().nullable(),

  type_overrides: z
    .array(
      z.object({
        container_type: z.string().min(1).max(20),
        qty: z.number().int().positive().optional().nullable(),
        purchase_per_unit: z.number().optional().nullable(),
        sale_per_unit: z.number().optional().nullable(),
      }),
    )
    .optional(),
});

export const createFileFromSales = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => CreateSchema.parse(input))
  .handler(async ({ context, data }) => {
    const r = await _resolve(context.supabase, data.sale_ids);

    const overridesByType = new Map<
      string,
      { qty?: number | null; purchase?: number | null; sale?: number | null }
    >();
    for (const o of data.type_overrides ?? []) {
      overridesByType.set(o.container_type, {
        qty: o.qty,
        purchase: o.purchase_per_unit,
        sale: o.sale_per_unit,
      });
    }

    const planRows: Array<{
      container_type: string;
      qty: number;
      purchase: number;
      sale: number;
    }> = [];
    for (const [t, a] of r.typeAgg) {
      const ov = overridesByType.get(t);
      const qty =
        ov?.qty != null && Number.isFinite(ov.qty) && ov.qty > 0
          ? Math.trunc(Number(ov.qty))
          : a.qty;
      const purchase =
        ov?.purchase != null && Number.isFinite(ov.purchase)
          ? Number(ov.purchase)
          : a.count_ppb > 0
            ? a.sum_ppb / a.count_ppb
            : NaN;
      const sale =
        ov?.sale != null && Number.isFinite(ov.sale)
          ? Number(ov.sale)
          : a.count_sale > 0
            ? a.sum_sale / a.count_sale
            : NaN;
      if (!Number.isFinite(purchase))
        throw new Error(`Purchase price required for container type ${t}`);
      if (!Number.isFinite(sale))
        throw new Error(`Sale price required for container type ${t}`);
      planRows.push({ container_type: t, qty, purchase, sale });
    }
    if (planRows.length === 0)
      throw new Error("All units in this selection are already linked to a file");

    // Resolve overridden locations to subregion/country (prefer explicit overrides)
    const originLocn = data.origin_locn ?? null;
    const destLocn = data.dest_locn ?? r.dest_locn ?? null;
    const locResolved = await _resolveLocnNames(context.supabase, [originLocn, destLocn]);
    const originSubregion =
      data.origin_subregion ??
      (originLocn ? locResolved.subregionMap[originLocn] ?? null : null);
    const destSubregion =
      data.dest_subregion ??
      (destLocn ? locResolved.subregionMap[destLocn] : null) ??
      r.dest_subregion ??
      null;
    const originCountry =
      data.origin_country_code ??
      (originLocn ? locResolved.countryMap[originLocn] ?? null : null);
    const destCountry =
      data.dest_country_code ??
      (destLocn ? locResolved.countryMap[destLocn] : null) ??
      r.dest_country_code ??
      null;

    const customerAccno = data.customer_accno ?? r.customer_accno ?? undefined;
    const customerName = data.customer_name ?? r.customer_name ?? undefined;

    // Create file
    const { data: idRet, error: cErr } = await context.supabase.rpc("fn_create_file", {
      p_department_id: data.department_id,
      p_direction: "EXPORT",
      p_customer_accno: customerAccno,
      p_customer_name: customerName,
      p_origin_subregion: originSubregion ?? undefined,
      p_dest_subregion: destSubregion ?? undefined,
      p_origin_locn: originLocn ?? undefined,
      p_dest_locn: destLocn ?? undefined,
      p_planned_departure_date: data.planned_departure_date ?? r.planned_departure_date ?? undefined,
      p_planned_arrival_date: data.planned_arrival_date ?? r.planned_arrival_date ?? undefined,
      p_notes:
        data.notes ?? `Auto-created from ${data.sale_ids.length} sales line(s)`,
    });
    if (cErr) throw new Error(cErr.message);
    const fileId = idRet as unknown as string;

    const patch: {
      origin_country_code?: string;
      dest_country_code?: string;
      sales_person_id?: string;
    } = {};
    if (originCountry) patch.origin_country_code = originCountry;
    if (destCountry) patch.dest_country_code = destCountry;
    if (data.sales_person_id) patch.sales_person_id = data.sales_person_id;
    if (Object.keys(patch).length) {
      await context.supabase.from("files").update(patch).eq("id", fileId);
    }



    // Container types
    const ctRows = planRows.map((p) => ({
      file_id: fileId,
      container_type: p.container_type,
      planned_qty: p.qty,
    }));
    if (ctRows.length) {
      const { error: ctErr } = await context.supabase
        .from("file_container_types")
        .insert(ctRows);
      if (ctErr) throw new Error(ctErr.message);
    }

    // Assign units (skip already-linked)
    for (const u of r.units) {
      if (u.already_linked_file_id) continue;
      const { error: aErr } = await context.supabase.rpc("fn_assign_unit_with_check", {
        p_file_id: fileId,
        p_unit_no: u.unit_no.trim().toUpperCase(),
        p_booking_no: undefined,
      });
      if (aErr) throw new Error(aErr.message);
    }

    // Plan lines
    const { data: arts } = await context.supabase
      .from("budget_articles")
      .select("id,code")
      .in("code", [PP_ARTICLE_CODE, SP_ARTICLE_CODE]);
    const artByCode = new Map<string, string>();
    for (const a of arts ?? []) artByCode.set(a.code, a.id);
    const ppId = artByCode.get(PP_ARTICLE_CODE);
    const spId = artByCode.get(SP_ARTICLE_CODE);

    const planLines: any[] = [];
    for (const p of planRows) {
      if (ppId) {
        planLines.push({
          file_id: fileId,
          article_id: ppId,
          container_type: p.container_type,
          planned_qty: p.qty,
          amount_per_unit: -Math.abs(p.purchase),
          currency: data.currency,
          source_type: "IMPORT",
        });
      }
      if (spId) {
        planLines.push({
          file_id: fileId,
          article_id: spId,
          container_type: p.container_type,
          planned_qty: p.qty,
          amount_per_unit: Math.abs(p.sale),
          currency: data.currency,
          source_type: "IMPORT",
        });
      }
    }
    if (planLines.length) {
      const { error: plErr } = await context.supabase
        .from("file_budget_plan_lines")
        .insert(planLines);
      if (plErr) throw new Error(plErr.message);
    }

    await context.supabase.from("file_audit_log").insert({
      file_id: fileId,
      action: "create_from_sales",
      details: {
        sale_ids: data.sale_ids,
        sales_person: r.sales_person,
        unit_count: r.units.filter((u) => !u.already_linked_file_id).length,
      },
    });

    return { id: fileId };
  });
