import { createMiddleware } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Composable middleware that requires the user to have at least one of the given permission codes.
 * Always grants access to admin.full.
 */
export function requirePermission(...codes: string[]) {
  return createMiddleware({ type: "function" })
    .middleware([requireSupabaseAuth])
    .server(async ({ next, context }) => {
      const { supabase, userId } = context;
      const { data, error } = await supabase
        .from("user_roles")
        .select("role:roles(role_permissions(permission:permissions(code)))")
        .eq("user_id", userId);
      if (error) throw new Error(error.message);

      const perms = new Set<string>();
      type Row = {
        role: { role_permissions: { permission: { code: string } | null }[] } | null;
      };
      for (const row of (data ?? []) as Row[]) {
        for (const rp of row.role?.role_permissions ?? []) {
          if (rp.permission?.code) perms.add(rp.permission.code);
        }
      }
      if (!perms.has("admin.full") && !codes.some((c) => perms.has(c))) {
        throw new Error("Forbidden: insufficient permissions");
      }
      return next({ context });
    });
}
