import type { EmailTemplateDTO } from "./templates.functions";
import type { GeneratedEmail, ValidationResult } from "./types";

interface Ctx {
  transportTypeCode: string;
  transportTypeLabel: string;
}

function pickTemplate(
  templates: EmailTemplateDTO[],
  kind: "ok" | "missing",
  transportTypeCode: string,
): EmailTemplateDTO | null {
  return (
    templates.find(
      (t) => t.kind === kind && t.transport_type_code === transportTypeCode,
    ) ??
    templates.find((t) => t.kind === kind && t.transport_type_code === null) ??
    null
  );
}

function render(text: string, vars: Record<string, string>): string {
  return text.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, k) => vars[k] ?? "");
}

export function generateEmail(
  v: ValidationResult,
  templates: EmailTemplateDTO[],
  ctx: Ctx,
): GeneratedEmail {
  const kind: "ok" | "missing" =
    v.missing.length === 0 && v.total > 0 ? "ok" : "missing";
  const tpl = pickTemplate(templates, kind, ctx.transportTypeCode);

  const missingList =
    v.missing
      .map((i) => {
        const parent = i.parent_label ? ` [из-за: ${i.parent_label}]` : "";
        return `- ${i.label}${i.critical ? " (критично)" : ""}${parent}`;
      })
      .join("\n") || "- (пункты не определены)";

  const vars = {
    missing_list: missingList,
    transport_type: ctx.transportTypeLabel,
    transport_code: ctx.transportTypeCode,
  };

  if (tpl) {
    return {
      ok: kind === "ok",
      subject: render(tpl.subject, vars),
      body: render(tpl.body, vars),
    };
  }

  // Fallback if no template configured at all
  return {
    ok: kind === "ok",
    subject:
      kind === "ok"
        ? "Заявка принята в работу"
        : "Недостаточно данных для обработки заявки",
    body:
      kind === "ok"
        ? "Заявка проверена и принята в работу."
        : `Не хватает данных:\n${missingList}`,
  };
}
