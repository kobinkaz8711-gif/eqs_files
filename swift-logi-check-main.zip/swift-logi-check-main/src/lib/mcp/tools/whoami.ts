import { defineTool } from "@lovable.dev/mcp-js";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "whoami",
  title: "Who am I",
  description:
    "Return the signed-in user's profile, department and roles in this CMS. Use it to verify the connection and the caller's access.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async (_input, ctx) => {
    if (!ctx.isAuthenticated())
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    const supabase = supabaseForUser(ctx);

    const [profileRes, rolesRes] = await Promise.all([
      supabase
        .from("profiles")
        .select("id,email,full_name,position,is_active,department:departments(id,code,name)")
        .eq("id", ctx.getUserId()!)
        .maybeSingle(),
      supabase.from("user_roles").select("role:roles(id,name)").eq("user_id", ctx.getUserId()!),
    ]);

    if (profileRes.error)
      return { content: [{ type: "text", text: profileRes.error.message }], isError: true };

    const roles = (rolesRes.data ?? [])
      .map((r: { role: { id: string; name: string } | null }) => r.role?.name)
      .filter(Boolean);

    const payload = {
      email: ctx.getUserEmail() ?? profileRes.data?.email ?? null,
      profile: profileRes.data ?? null,
      roles,
    };
    return {
      content: [{ type: "text", text: JSON.stringify(payload, null, 2) }],
      structuredContent: payload,
    };
  },
});
