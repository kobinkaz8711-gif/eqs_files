import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_units",
  title: "List container units",
  description:
    "List container units from the EQS unit register, optionally filtered by unit number, status or ISO/type code.",
  inputSchema: {
    unit_no: z.string().optional().describe("Exact or partial unit number, e.g. L45260259066."),
    status: z.string().optional().describe("Unit status code, e.g. SD."),
    iso_code: z.string().optional().describe("ISO / equipment type code."),
    limit: z.number().int().optional().describe("Max rows to return (default 25, max 200)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ unit_no, status, iso_code, limit }, ctx) => {
    if (!ctx.isAuthenticated())
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    const supabase = supabaseForUser(ctx);

    const take = Math.min(Math.max(limit ?? 25, 1), 200);
    let query = supabase
      .from("eqs_ext_units")
      .select("unit_no,status,iso_code,grade,owner_code,year_built,received_at")
      .order("unit_no")
      .limit(take);

    if (status) query = query.eq("status", status);
    if (iso_code) query = query.eq("iso_code", iso_code);
    if (unit_no?.trim()) query = query.ilike("unit_no", `%${unit_no.trim()}%`);

    const { data, error } = await query;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };

    return {
      content: [{ type: "text", text: JSON.stringify(data ?? [], null, 2) }],
      structuredContent: { count: data?.length ?? 0, units: data ?? [] },
    };
  },
});
