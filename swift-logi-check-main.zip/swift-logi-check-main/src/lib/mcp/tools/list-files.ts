import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_files",
  title: "List EQS files",
  description:
    "Search and list EQS operational files visible to the signed-in user. Filter by status, customer, route or free text, and limit how many rows come back.",
  inputSchema: {
    search: z
      .string()
      .optional()
      .describe("Free text matched against file number and customer name."),
    status: z
      .string()
      .optional()
      .describe("File status, e.g. draft, open, rp, ready_for_cl, closed, cancelled."),
    op_date_from: z.string().optional().describe("Only files with op_date on/after this ISO date."),
    limit: z.number().int().optional().describe("Max rows to return (default 25, max 200)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ search, status, op_date_from, limit }, ctx) => {
    if (!ctx.isAuthenticated())
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    const supabase = supabaseForUser(ctx);

    const take = Math.min(Math.max(limit ?? 25, 1), 200);
    let query = supabase
      .from("files")
      .select(
        "id,file_number,status,op_date,customer_name,customer_accno,origin_locn,dest_locn,eqs_booking_id,updated_at",
      )
      .order("op_date", { ascending: false, nullsFirst: false })
      .limit(take);

    if (status) query = query.eq("status", status as never);
    if (op_date_from) query = query.gte("op_date", op_date_from);
    if (search?.trim()) {
      const term = `%${search.trim()}%`;
      query = query.or(`file_number.ilike.${term},customer_name.ilike.${term}`);
    }

    const { data, error } = await query;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };

    return {
      content: [{ type: "text", text: JSON.stringify(data ?? [], null, 2) }],
      structuredContent: { count: data?.length ?? 0, files: data ?? [] },
    };
  },
});
