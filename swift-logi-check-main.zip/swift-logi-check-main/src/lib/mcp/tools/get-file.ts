import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "get_file",
  title: "Get EQS file",
  description:
    "Return the full detail of one EQS file by its file number (e.g. EQ26MIA000003) or id: header data, planned container types and assigned units.",
  inputSchema: {
    file_number: z.string().optional().describe("File number such as EQ26MIA000003."),
    file_id: z.string().optional().describe("File UUID, if the number is unknown."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ file_number, file_id }, ctx) => {
    if (!ctx.isAuthenticated())
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    if (!file_number && !file_id)
      return {
        content: [{ type: "text", text: "Provide file_number or file_id." }],
        isError: true,
      };
    const supabase = supabaseForUser(ctx);

    let head = supabase.from("files").select("*").limit(1);
    head = file_id ? head.eq("id", file_id) : head.eq("file_number", file_number!);
    const { data: file, error } = await head.maybeSingle();
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    if (!file) return { content: [{ type: "text", text: "File not found." }], isError: true };

    const [typesRes, unitsRes] = await Promise.all([
      supabase
        .from("file_container_types")
        .select("container_type,qty,daily_rate")
        .eq("file_id", file.id),
      supabase
        .from("file_unit_assignments")
        .select("unit_no,unit_type,is_active,effective_date_from,effective_date_to")
        .eq("file_id", file.id)
        .eq("is_active", true),
    ]);

    const payload = {
      file,
      container_types: typesRes.data ?? [],
      assigned_units: unitsRes.data ?? [],
    };
    return {
      content: [{ type: "text", text: JSON.stringify(payload, null, 2) }],
      structuredContent: payload,
    };
  },
});
