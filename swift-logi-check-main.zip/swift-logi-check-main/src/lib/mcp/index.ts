import { auth, defineMcp } from "@lovable.dev/mcp-js";
import whoamiTool from "./tools/whoami";
import listFilesTool from "./tools/list-files";
import getFileTool from "./tools/get-file";
import listUnitsTool from "./tools/list-units";

// The OAuth issuer must be the direct Supabase host; the project ref is the only
// Supabase value that survives publish unchanged and is inlined by Vite.
const projectRef = import.meta.env["VITE_SUPABASE_PROJECT_ID"] ?? "project-ref-unset";

export default defineMcp({
  name: "cms",
  title: "CMS",
  version: "0.1.0",
  instructions:
    "Read-only tools for the CMS logistics app. Use `whoami` to check the connected user, `list_files` to find EQS operational files, `get_file` for one file's header, planned container types and assigned units, and `list_units` to look up container units. All data is scoped to the signed-in user's permissions.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [whoamiTool, listFilesTool, getFileTool, listUnitsTool],
});
