import type { CheckedState, ChecklistItem, ChecklistTemplate, MissingItem, ValidationResult } from "./types";

/**
 * Item is "active" only when its dependency chain is satisfied:
 * either it has no dependency, or its parent item is checked AND its parent is active.
 */
export function isItemActive(
  item: ChecklistItem,
  itemsById: Map<string, ChecklistItem>,
  checked: CheckedState,
  seen: Set<string> = new Set(),
): boolean {
  if (!item.depends_on_item_id) return true;
  if (seen.has(item.id)) return true; // защита от цикла
  seen.add(item.id);
  const parent = itemsById.get(item.depends_on_item_id);
  if (!parent) return true; // родитель удалён
  if (!checked[parent.id]) return false;
  return isItemActive(parent, itemsById, checked, seen);
}

export function buildItemsIndex(template: ChecklistTemplate | undefined) {
  const map = new Map<string, ChecklistItem>();
  if (!template) return map;
  for (const s of template.sections) for (const i of s.items) map.set(i.id, i);
  return map;
}

export function validate(
  template: ChecklistTemplate | undefined,
  checked: CheckedState,
): ValidationResult {
  const result: ValidationResult = {
    total: 0,
    checked: 0,
    completionPct: 0,
    missing: [],
    criticalMissing: [],
    sectionStatus: {},
  };
  if (!template) return result;

  const itemsById = buildItemsIndex(template);

  for (const section of template.sections) {
    let sTotal = 0;
    let sChecked = 0;
    let hasCritical = false;
    for (const item of section.items) {
      if (!isItemActive(item, itemsById, checked)) continue;
      sTotal++;
      result.total++;
      const isChecked = !!checked[item.id];
      if (isChecked) {
        sChecked++;
        result.checked++;
      } else if (item.required) {
        const parent = item.depends_on_item_id ? itemsById.get(item.depends_on_item_id) : undefined;
        const missingItem: MissingItem = {
          ...item,
          parent_id: parent?.id ?? null,
          parent_label: parent?.label ?? null,
        };
        result.missing.push(missingItem);
        if (item.critical) {
          result.criticalMissing.push(missingItem);
          hasCritical = true;
        }
      }
    }
    result.sectionStatus[section.id] = {
      total: sTotal,
      checked: sChecked,
      complete: sTotal > 0 && sChecked === sTotal,
      hasCritical,
    };
  }
  result.completionPct =
    result.total === 0 ? 0 : Math.round((result.checked / result.total) * 100);
  return result;
}
