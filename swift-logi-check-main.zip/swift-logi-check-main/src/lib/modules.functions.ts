import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requirePermission } from "@/lib/permissions";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export interface ModuleDTO {
  id: string;
  code: string;
  name: string;
  description: string | null;
  route: string | null;
  icon: string | null;
  is_active: boolean;
  sort_order: number;
  department_ids: string[];
}

export const listModules = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("modules")
      .select(
        "id,code,name,description,route,icon,is_active,sort_order,module_departments(department_id)",
      )
      .order("sort_order", { ascending: true })
      .order("name", { ascending: true });
    if (error) throw new Error(error.message);
    type Row = Omit<ModuleDTO, "department_ids"> & {
      module_departments: { department_id: string }[];
    };
    const items: ModuleDTO[] = ((data ?? []) as Row[]).map((m) => ({
      id: m.id,
      code: m.code,
      name: m.name,
      description: m.description,
      route: m.route,
      icon: m.icon,
      is_active: m.is_active,
      sort_order: m.sort_order,
      department_ids: m.module_departments.map((d) => d.department_id),
    }));
    return { items };
  });

const createSchema = z.object({
  code: z.string().min(1).max(64).regex(/^[a-z0-9_-]+$/),
  name: z.string().min(1).max(120),
  description: z.string().max(500).optional(),
  route: z.string().max(255).optional(),
  icon: z.string().max(64).optional(),
  is_active: z.boolean().default(true),
  sort_order: z.number().int().min(0).max(9999).default(0),
});

export const createModule = createServerFn({ method: "POST" })
  .middleware([requirePermission("modules.manage")])
  .inputValidator((input) => createSchema.parse(input))
  .handler(async ({ data }) => {
    const { data: row, error } = await supabaseAdmin
      .from("modules")
      .insert({
        code: data.code,
        name: data.name,
        description: data.description ?? null,
        route: data.route ?? null,
        icon: data.icon ?? null,
        is_active: data.is_active,
        sort_order: data.sort_order,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const updateModule = createServerFn({ method: "POST" })
  .middleware([requirePermission("modules.manage")])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid(),
        name: z.string().min(1).max(120).optional(),
        description: z.string().max(500).nullable().optional(),
        route: z.string().max(255).nullable().optional(),
        icon: z.string().max(64).nullable().optional(),
        is_active: z.boolean().optional(),
        sort_order: z.number().int().min(0).max(9999).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { id, ...patch } = data;
    const { error } = await supabaseAdmin.from("modules").update(patch).eq("id", id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteModule = createServerFn({ method: "POST" })
  .middleware([requirePermission("modules.manage")])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const { error } = await supabaseAdmin.from("modules").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setModuleDepartments = createServerFn({ method: "POST" })
  .middleware([requirePermission("modules.manage")])
  .inputValidator((input) =>
    z
      .object({
        module_id: z.string().uuid(),
        department_ids: z.array(z.string().uuid()),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { error: delErr } = await supabaseAdmin
      .from("module_departments")
      .delete()
      .eq("module_id", data.module_id);
    if (delErr) throw new Error(delErr.message);
    if (data.department_ids.length) {
      const { error } = await supabaseAdmin
        .from("module_departments")
        .insert(
          data.department_ids.map((department_id) => ({
            module_id: data.module_id,
            department_id,
          })),
        );
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });
