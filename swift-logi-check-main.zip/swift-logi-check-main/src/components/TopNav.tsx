import { useRef, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useT } from "@/i18n/i18n";
import { cn } from "@/lib/utils";
import tmsLogo from "@/assets/cms-logo.png";

export function TopNavLogo() {
  const currentPath = useRouterState({ select: (s) => s.location.pathname });
  const isEqs =
    currentPath.startsWith("/eqs-files") ||
    currentPath.startsWith("/recent-units") ||
    currentPath.startsWith("/sales-dashboard") ||
    currentPath.startsWith("/settings/eqs-files");
  return (
    <Link to="/" className="flex items-center gap-2.5 px-2 py-1 group">
      <img
        src={tmsLogo}
        alt="CMS"
        width={32}
        height={32}
        className="size-8 object-contain"
      />
      <span className="text-lg font-bold tracking-[0.18em] uppercase bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent">
        CMS
      </span>
      {isEqs && (
        <>
          <span className="text-lg font-light text-muted-foreground/60">|</span>
          <span className="text-lg font-bold tracking-[0.18em] uppercase bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent">
            EQS Files
          </span>
        </>
      )}
    </Link>
  );
}

export function TopNav() {
  const currentPath = useRouterState({ select: (s) => s.location.pathname });
  const { hasAnyPermission } = useAuth();
  const t = useT();
  const [toolsOpen, setToolsOpen] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const tools = [
    {
      title: t("tools.cci.title"),
      url: "/container-extractor",
      show: true,
    },
    {
      title: t("tools.invoice.title"),
      url: "/invoice-generator",
      show: true,
    },
    {
      title: t("tools.eqs.title"),
      url: "/eqs-files",
      show: true,
    },
    {
      title: "Sales Dashboard",
      url: "/sales-dashboard",
      show: true,
    },
  ].filter((t) => t.show);

  const settingsVisible = hasAnyPermission([
    "users.manage",
    "roles.manage",
    "settings.manage",
    "departments.manage",
    "modules.manage",
    "checklist.manage",
  ]);

  const toolsActive =
    currentPath === "/tools" ||
    tools.some((t) => (t.url === "/" ? currentPath === "/" : currentPath.startsWith(t.url)));

  const openNow = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setToolsOpen(true);
  };
  const closeSoon = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => setToolsOpen(false), 120);
  };

  return (
    <nav className="flex items-center gap-1">


      {tools.length > 0 && (
        <div className="relative" onMouseEnter={openNow} onMouseLeave={closeSoon}>
          <Button
            asChild
            variant="ghost"
            size="sm"
            className={cn(
              "gap-1.5 h-9 uppercase text-xs font-semibold tracking-wide",
              toolsActive && "bg-accent text-accent-foreground",
            )}
          >
            <Link to="/tools">
              {t("nav.tools")}
              <ChevronDown
                className={cn(
                  "size-3.5 opacity-60 transition-transform",
                  toolsOpen && "rotate-180",
                )}
              />
            </Link>
          </Button>

          {toolsOpen && (
            <div
              className="absolute left-0 top-full pt-1 z-50 min-w-56"
              onMouseEnter={openNow}
              onMouseLeave={closeSoon}
            >
              <div className="rounded-md border bg-popover text-popover-foreground shadow-md p-1 animate-in fade-in-0 zoom-in-95">
                {tools.map((item) => (
                  <Link
                    key={item.url}
                    to={item.url}
                    onClick={() => setToolsOpen(false)}
                    className="flex items-center gap-2 rounded-sm px-2 py-1.5 text-sm hover:bg-accent hover:text-accent-foreground cursor-pointer"
                  >
                    <span>{item.title}</span>
                  </Link>
                ))}
                <div className="h-px my-1 -mx-1 bg-border" />
                <Link
                  to="/tools"
                  onClick={() => setToolsOpen(false)}
                  className="flex items-center gap-2 rounded-sm px-2 py-1.5 text-xs text-muted-foreground hover:bg-accent hover:text-accent-foreground cursor-pointer"
                >
                  {t("nav.toolsAll")}
                </Link>
              </div>
            </div>
          )}
        </div>
      )}

      {settingsVisible && (
        <Button
          asChild
          variant="ghost"
          size="sm"
          className={cn(
            "gap-2 h-9 uppercase text-xs font-semibold tracking-wide",
            currentPath.startsWith("/settings") && "bg-accent text-accent-foreground",
          )}
        >
          <Link to="/settings">
            {t("nav.settings")}
          </Link>
        </Button>
      )}
    </nav>
  );
}
