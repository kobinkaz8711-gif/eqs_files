import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, Settings, ChevronsLeft, ChevronsRight } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { useAuth } from "@/hooks/useAuth";
import { useT } from "@/i18n/i18n";

export function AppSidebar() {
  const currentPath = useRouterState({ select: (s) => s.location.pathname });
  const { hasAnyPermission } = useAuth();
  const t = useT();
  const { toggleSidebar, state } = useSidebar();
  const collapsed = state === "collapsed";

  const isActive = (path: string) =>
    path === "/" ? currentPath === "/" : currentPath.startsWith(path);

  const mainItems: { title: string; url: string; icon: typeof LayoutDashboard; show: boolean }[] =
    [
      { title: t("nav.dashboard"), url: "/dashboard", icon: LayoutDashboard, show: false },
    ];

  const settingsVisible = hasAnyPermission([
    "users.manage",
    "roles.manage",
    "settings.manage",
    "departments.manage",
    "modules.manage",
    "checklist.manage",
  ]);

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border">
        <div className="flex items-center gap-2 px-2 py-2">
          <div className="size-7 rounded-md bg-primary flex items-center justify-center shrink-0">
            <div className="size-2.5 rounded-full bg-primary-foreground" />
          </div>
          <span className="text-sm font-semibold tracking-tight uppercase group-data-[collapsible=icon]:hidden">
            Logis<span className="text-primary">.</span>
          </span>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainItems
                .filter((i) => i.show)
                .map((item) => (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive(item.url)}
                      tooltip={item.title}
                    >
                      <Link to={item.url}>
                        <item.icon className="size-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        <SidebarMenu>
          {settingsVisible ? (
            <SidebarMenuItem>
              <SidebarMenuButton
                asChild
                isActive={isActive("/settings")}
                tooltip={t("nav.settings")}
              >
                <Link to="/settings">
                  <Settings className="size-4" />
                  <span>{t("nav.settings")}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ) : null}
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={toggleSidebar}
              tooltip={collapsed ? t("nav.expand") : t("nav.collapse")}
            >
              {collapsed ? (
                <ChevronsRight className="size-4" />
              ) : (
                <ChevronsLeft className="size-4" />
              )}
              <span>{t("nav.collapse")}</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
