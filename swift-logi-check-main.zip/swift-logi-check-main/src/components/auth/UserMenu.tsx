import { useNavigate } from "@tanstack/react-router";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, LogOut, Mail, User as UserIcon } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useT } from "@/i18n/i18n";

export function UserMenu() {
  const { me, user, signOut } = useAuth();
  const t = useT();
  const navigate = useNavigate();

  const name = me?.profile?.full_name ?? user?.email ?? t("user.employee");
  const initials = name
    .split(" ")
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="flex items-center gap-1">
      <Button
        variant="ghost"
        size="icon"
        className="size-9 rounded-md relative"
        aria-label={t("user.notifications")}
        title={t("user.notifications")}
      >
        <Bell className="size-4" />
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="size-9 rounded-md p-0 hover:bg-accent"
            aria-label={t("user.profile")}
          >
            <span className="size-8 rounded-md bg-primary text-primary-foreground text-[12px] font-semibold grid place-items-center">
              {initials || <UserIcon className="size-4" />}
            </span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-72 p-0 overflow-hidden">
          <div className="p-4 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-b">
            <div className="flex items-center gap-3">
              <span className="size-11 rounded-md bg-primary text-primary-foreground text-sm font-semibold grid place-items-center shrink-0">
                {initials || <UserIcon className="size-5" />}
              </span>
              <div className="min-w-0 flex-1">
                <div className="font-semibold text-sm truncate">{name}</div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5 truncate">
                  <Mail className="size-3 shrink-0" />
                  <span className="truncate">{user?.email}</span>
                </div>
              </div>
            </div>
            {me?.profile?.department?.name && (
              <div className="text-xs text-muted-foreground mt-3">
                {me.profile.department.name}
                {me.profile.position ? ` · ${me.profile.position}` : ""}
              </div>
            )}
            {me?.roles?.length ? (
              <div className="flex flex-wrap gap-1 mt-3">
                {me.roles.map((r) => (
                  <Badge key={r.id} variant="secondary" className="text-[10px] font-medium">
                    {r.name}
                  </Badge>
                ))}
              </div>
            ) : null}
          </div>
          <div className="p-1">
            <DropdownMenuItem
              onClick={async () => {
                await signOut();
                navigate({ to: "/login" });
              }}
              className="text-destructive focus:text-destructive cursor-pointer"
            >
              <LogOut className="size-4" />
              {t("user.signOut")}
            </DropdownMenuItem>
          </div>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
