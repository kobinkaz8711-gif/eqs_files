import type { ReactNode } from "react";
import { useAuth } from "@/hooks/useAuth";

interface CanProps {
  permission?: string;
  anyPermission?: string[];
  role?: string;
  fallback?: ReactNode;
  children: ReactNode;
}

export function Can({ permission, anyPermission, role, fallback = null, children }: CanProps) {
  const { hasPermission, hasAnyPermission, hasRole } = useAuth();
  const ok =
    (permission ? hasPermission(permission) : true) &&
    (anyPermission ? hasAnyPermission(anyPermission) : true) &&
    (role ? hasRole(role) : true);
  return <>{ok ? children : fallback}</>;
}
