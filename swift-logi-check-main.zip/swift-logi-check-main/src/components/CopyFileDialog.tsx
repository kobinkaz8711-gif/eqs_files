import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { copyFile, getFileCopyPreview } from "@/lib/files.functions";

type Mode = "plain" | "with_budget";

interface Props {
  fileId: string | null;
  mode: Mode;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function CopyFileDialog({ fileId, mode, open, onOpenChange }: Props) {
  const previewFn = useServerFn(getFileCopyPreview);
  const copyFn = useServerFn(copyFile);
  const navigate = useNavigate();
  const qc = useQueryClient();

  const q = useQuery({
    queryKey: ["file-copy-preview", fileId, mode],
    queryFn: () =>
      previewFn({ data: { file_id: fileId!, include_budget: mode === "with_budget" } }),
    enabled: !!fileId && open,
  });

  const [qtyOverrides, setQtyOverrides] = useState<Record<string, number>>({});
  const [departureDate, setDepartureDate] = useState<string>("");
  const [arrivalDate, setArrivalDate] = useState<string>("");

  useEffect(() => {
    if (q.data?.container_types) {
      const init: Record<string, number> = {};
      for (const ct of q.data.container_types as any[]) {
        init[ct.id] = Number(ct.planned_qty) || 1;
      }
      setQtyOverrides(init);
    }
  }, [q.data]);

  useEffect(() => {
    if (!open) {
      setQtyOverrides({});
      setDepartureDate("");
      setArrivalDate("");
    }
  }, [open]);

  const datesValid =
    !!departureDate && !!arrivalDate && arrivalDate >= departureDate;

  const mut = useMutation({
    mutationFn: () =>
      copyFn({
        data: {
          file_id: fileId!,
          mode,
          container_qty_overrides: qtyOverrides,
          planned_departure_date: departureDate,
          planned_arrival_date: arrivalDate,
        },
      }),
    onSuccess: (r: any) => {
      toast.success(`Copied as ${r?.file_number ?? "new file"}`);
      qc.invalidateQueries({ queryKey: ["files"] });
      onOpenChange(false);
      if (r?.id) navigate({ to: "/eqs-files/$id", params: { id: r.id } });
    },
    onError: (e: any) => toast.error(e?.message ?? "Copy failed"),
  });

  const file = q.data?.file as any;
  const cts = (q.data?.container_types ?? []) as any[];
  const budgetLines = (q.data?.budget_lines ?? []) as any[];

  const title = mode === "with_budget" ? "Copy file with planned budget" : "Copy file";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            Creates a new Draft file with the same header
            {mode === "with_budget" ? " and planned budget" : ""}. Units, finance and EQS bookings are not copied.
          </DialogDescription>
        </DialogHeader>

        {q.isLoading && (
          <div className="py-6 text-sm text-muted-foreground">Loading…</div>
        )}
        {q.error && (
          <div className="py-6 text-sm text-destructive">{(q.error as Error).message}</div>
        )}

        {q.data && file && (
          <div className="space-y-4">
            <div className="text-xs text-muted-foreground">
              Source: <span className="font-mono">{file.file_number ?? "—"}</span>
              {file.customer_name ? ` · ${file.customer_name}` : ""}
            </div>

            <div>
              <Label className="text-xs">Container types &amp; planned quantities</Label>
              <div className="mt-2 rounded-md border overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-muted/40 text-muted-foreground">
                    <tr>
                      <th className="text-left px-2 py-1.5 font-medium">Type</th>
                      <th className="text-left px-2 py-1.5 font-medium">Grade</th>
                      <th className="text-right px-2 py-1.5 font-medium w-[120px]">Planned qty</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cts.length === 0 && (
                      <tr>
                        <td colSpan={3} className="p-3 text-center text-muted-foreground">
                          No container types in source.
                        </td>
                      </tr>
                    )}
                    {cts.map((ct) => (
                      <tr key={ct.id} className="border-t">
                        <td className="px-2 py-1 font-mono">{ct.container_type}</td>
                        <td className="px-2 py-1 font-mono">{ct.grade ?? "—"}</td>
                        <td className="px-2 py-1 text-right">
                          <Input
                            type="number"
                            min={1}
                            value={qtyOverrides[ct.id] ?? ct.planned_qty ?? 1}
                            onChange={(e) => {
                              const v = parseInt(e.target.value || "0", 10);
                              setQtyOverrides((p) => ({
                                ...p,
                                [ct.id]: Number.isFinite(v) && v > 0 ? v : 1,
                              }));
                            }}
                            className="h-7 text-right font-mono text-xs w-[100px] ml-auto"
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {mode === "with_budget" && (
              <div className="text-xs text-muted-foreground">
                {budgetLines.length === 0
                  ? "Source has no planned budget lines."
                  : `${budgetLines.length} planned budget line(s) will be copied.`}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="copy-departure" className="text-xs">
                  Planned departure <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="copy-departure"
                  type="date"
                  value={departureDate}
                  onChange={(e) => setDepartureDate(e.target.value)}
                  className="h-8 mt-1"
                  required
                />
              </div>
              <div>
                <Label htmlFor="copy-arrival" className="text-xs">
                  Planned arrival <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="copy-arrival"
                  type="date"
                  value={arrivalDate}
                  onChange={(e) => setArrivalDate(e.target.value)}
                  min={departureDate || undefined}
                  className="h-8 mt-1"
                  required
                />
              </div>
              {departureDate && arrivalDate && arrivalDate < departureDate && (
                <div className="col-span-2 text-xs text-destructive">
                  Arrival must be on or after departure.
                </div>
              )}
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={mut.isPending}>
            Cancel
          </Button>
          <Button onClick={() => mut.mutate()} disabled={!q.data || !datesValid || mut.isPending}>
            {mut.isPending ? "Creating…" : "Create copy"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
