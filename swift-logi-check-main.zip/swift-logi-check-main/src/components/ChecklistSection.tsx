import { useState, useEffect } from "react";
import { ChevronDown, Check, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { CheckedState, ChecklistSection, ValidationResult } from "@/lib/types";
import { ChecklistItemRow } from "./ChecklistItemRow";

interface Props {
  section: ChecklistSection;
  checked: CheckedState;
  onToggle: (id: string, value: boolean) => void;
  status: ValidationResult["sectionStatus"][string] | undefined;
  isItemActive: (itemId: string) => boolean;
}

export function ChecklistSectionView({ section, checked, onToggle, status, isItemActive }: Props) {
  const complete = !!status?.complete;
  const hasCritical = !!status?.hasCritical;
  const [open, setOpen] = useState(!complete);
  const [userToggled, setUserToggled] = useState(false);

  useEffect(() => {
    if (!userToggled) setOpen(!complete);
  }, [complete, userToggled]);

  return (
    <section
      className={cn(
        "rounded-md border bg-card transition-colors",
        hasCritical ? "border-destructive/35" : "border-border",
      )}
    >
      <button
        type="button"
        onClick={() => {
          setUserToggled(true);
          setOpen((v) => !v);
        }}
        className="w-full flex items-center justify-between gap-4 px-4 py-2.5 text-left hover:bg-muted/40 transition-colors"
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <span
            className={cn(
              "inline-flex items-center justify-center size-4 rounded-sm shrink-0",
              complete
                ? "bg-success/15 text-success"
                : hasCritical
                  ? "bg-destructive/10 text-destructive"
                  : "border border-border bg-muted",
            )}
          >
            {complete ? (
              <Check className="size-3" strokeWidth={3} />
            ) : hasCritical ? (
              <AlertTriangle className="size-3" />
            ) : null}
          </span>
          <h2 className="text-sm font-semibold tracking-tight truncate">{section.title}</h2>
          <span className="text-[11px] tabular-nums text-muted-foreground">
            {status?.checked ?? 0}/{status?.total ?? section.items.length}
          </span>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          {hasCritical && (
            <span className="text-[10px] font-semibold uppercase tracking-wider text-destructive">
              крит.
            </span>
          )}
          {complete && (
            <span className="text-[10px] font-semibold uppercase tracking-wider text-success">
              готово
            </span>
          )}
          <ChevronDown
            className={cn(
              "size-3.5 text-muted-foreground transition-transform",
              open && "rotate-180",
            )}
          />
        </div>
      </button>

      {open && (
        <div className="border-t border-border divide-y divide-border">
          {section.items.map((item) => {
            if (!isItemActive(item.id)) return null;
            const isDependent = !!item.depends_on_item_id;
            return (
              <div
                key={item.id}
                className={cn(
                  isDependent && "pl-6 border-l-2 border-primary/30 bg-accent/10",
                )}
              >
                <ChecklistItemRow
                  item={item}
                  checked={!!checked[item.id]}
                  onToggle={(v) => onToggle(item.id, v)}
                />
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
