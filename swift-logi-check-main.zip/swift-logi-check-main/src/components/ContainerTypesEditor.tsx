import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, X, ChevronDown, ChevronRight } from "lucide-react";
import { useState } from "react";

export type CTRow = {
  container_type: string;
  planned_qty: number;
  grade?: string | null;
  daily_rate?: number | null;
  repl_value?: number | null;
  free_min_days?: number | null;
  charge1_code?: string | null;
  charge1_amount?: number | null;
  charge2_code?: string | null;
  charge2_amount?: number | null;
  charge3_code?: string | null;
  charge3_amount?: number | null;
  charge4_code?: string | null;
  charge4_amount?: number | null;
  cost1_code?: string | null;
  cost1_currency?: string | null;
  cost1_amount?: number | null;
  cost1_supplier_accno?: string | null;
  cost2_code?: string | null;
  cost2_currency?: string | null;
  cost2_amount?: number | null;
  cost2_supplier_accno?: string | null;
};

const NUM = (v: string): number | null => {
  if (v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};
const STR = (v: string): string | null => (v === "" ? null : v);

export function ContainerTypesEditor({
  rows,
  setRows,
  containerTypeOptions,
  grades,
  required,
  allowEmpty,
}: {
  rows: CTRow[];
  setRows: (rows: CTRow[]) => void;
  containerTypeOptions: string[];
  grades: { code: string; label: string }[];
  required?: boolean;
  allowEmpty?: boolean;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium">
          Container Types{required ? " *" : ""}
        </span>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() =>
            setRows([...rows, { container_type: "40HC", planned_qty: 1 }])
          }
        >
          <Plus className="size-4 mr-1" /> Add
        </Button>
      </div>
      <div className="space-y-3">
        {rows.map((ct, i) => (
          <CTRowEditor
            key={i}
            row={ct}
            containerTypeOptions={containerTypeOptions}
            grades={grades}
            onChange={(next) => {
              const arr = [...rows];
              arr[i] = next;
              setRows(arr);
            }}
            onRemove={
              rows.length > 1 || allowEmpty
                ? () => setRows(rows.filter((_, j) => j !== i))
                : undefined
            }
          />
        ))}
        {rows.length === 0 && (
          <div className="text-sm text-muted-foreground">No container types.</div>
        )}
      </div>
    </div>
  );
}

function CTRowEditor({
  row,
  containerTypeOptions,
  grades,
  onChange,
  onRemove,
}: {
  row: CTRow;
  containerTypeOptions: string[];
  grades: { code: string; label: string }[];
  onChange: (next: CTRow) => void;
  onRemove?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const update = (patch: Partial<CTRow>) => onChange({ ...row, ...patch });

  return (
    <div className="rounded-lg border border-border p-3 space-y-3 bg-background/40">
      <div className="flex flex-wrap gap-2 items-end">
        <Field label="Type" w="w-28">
          <Select
            value={row.container_type}
            onValueChange={(v) => update({ container_type: v })}
          >
            <SelectTrigger className="w-28 h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {containerTypeOptions.map((o) => (
                <SelectItem key={o} value={o}>
                  {o}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Grade" w="w-32">
          <Select
            value={row.grade ?? "__none"}
            onValueChange={(v) => update({ grade: v === "__none" ? null : v })}
          >
            <SelectTrigger className="w-32 h-9">
              <SelectValue placeholder="—" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">—</SelectItem>
              {grades.map((g) => (
                <SelectItem key={g.code} value={g.code}>
                  {g.code}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Qty" w="w-20">
          <Input
            type="number"
            min={1}
            className="w-20 h-9"
            value={row.planned_qty}
            onChange={(e) =>
              update({ planned_qty: parseInt(e.target.value || "0", 10) })
            }
          />
        </Field>
        <Field label="Daily rate" w="w-24">
          <Input
            type="number"
            step="0.01"
            className="w-24 h-9"
            value={row.daily_rate ?? ""}
            onChange={(e) => update({ daily_rate: NUM(e.target.value) })}
          />
        </Field>
        <Field label="Repl Value" w="w-28">
          <Input
            type="number"
            step="0.01"
            className="w-28 h-9"
            value={row.repl_value ?? ""}
            onChange={(e) => update({ repl_value: NUM(e.target.value) })}
          />
        </Field>
        <Field label="Free min/days" w="w-24">
          <Input
            type="number"
            min={0}
            className="w-24 h-9"
            value={row.free_min_days ?? ""}
            onChange={(e) =>
              update({
                free_min_days:
                  e.target.value === ""
                    ? null
                    : parseInt(e.target.value, 10) || 0,
              })
            }
          />
        </Field>
        <div className="ml-auto flex items-center gap-1">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? (
              <ChevronDown className="size-4 mr-1" />
            ) : (
              <ChevronRight className="size-4 mr-1" />
            )}
            Charges / Costs
          </Button>
          {onRemove && (
            <Button type="button" variant="ghost" size="icon" onClick={onRemove}>
              <X className="size-4" />
            </Button>
          )}
        </div>
      </div>

      {open && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-border">
          <div className="space-y-2">
            <div className="text-xs font-medium text-muted-foreground">
              Charges 1–4
            </div>
            {[1, 2, 3, 4].map((n) => {
              const codeKey = `charge${n}_code` as keyof CTRow;
              const amtKey = `charge${n}_amount` as keyof CTRow;
              return (
                <div key={n} className="flex gap-2">
                  <Input
                    placeholder={`Charge ${n} code`}
                    className="h-8 flex-1"
                    value={(row[codeKey] as string) ?? ""}
                    onChange={(e) =>
                      update({ [codeKey]: STR(e.target.value) } as Partial<CTRow>)
                    }
                  />
                  <Input
                    placeholder="amount"
                    type="number"
                    step="0.01"
                    className="h-8 w-28"
                    value={(row[amtKey] as number | null) ?? ""}
                    onChange={(e) =>
                      update({ [amtKey]: NUM(e.target.value) } as Partial<CTRow>)
                    }
                  />
                </div>
              );
            })}
          </div>
          <div className="space-y-2">
            <div className="text-xs font-medium text-muted-foreground">
              Costs 1–2
            </div>
            {[1, 2].map((n) => {
              const codeKey = `cost${n}_code` as keyof CTRow;
              const curKey = `cost${n}_currency` as keyof CTRow;
              const amtKey = `cost${n}_amount` as keyof CTRow;
              const supKey = `cost${n}_supplier_accno` as keyof CTRow;
              return (
                <div key={n} className="space-y-1">
                  <div className="flex gap-2">
                    <Input
                      placeholder={`Cost ${n} code`}
                      className="h-8 flex-1"
                      value={(row[codeKey] as string) ?? ""}
                      onChange={(e) =>
                        update({ [codeKey]: STR(e.target.value) } as Partial<CTRow>)
                      }
                    />
                    <Input
                      placeholder="cur"
                      className="h-8 w-16"
                      value={(row[curKey] as string) ?? ""}
                      onChange={(e) =>
                        update({ [curKey]: STR(e.target.value) } as Partial<CTRow>)
                      }
                    />
                    <Input
                      placeholder="amount"
                      type="number"
                      step="0.01"
                      className="h-8 w-24"
                      value={(row[amtKey] as number | null) ?? ""}
                      onChange={(e) =>
                        update({ [amtKey]: NUM(e.target.value) } as Partial<CTRow>)
                      }
                    />
                  </div>
                  <Input
                    placeholder={`Cost ${n} supplier accno`}
                    className="h-8"
                    value={(row[supKey] as string) ?? ""}
                    onChange={(e) =>
                      update({ [supKey]: STR(e.target.value) } as Partial<CTRow>)
                    }
                  />
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function Field({
  label,
  w,
  children,
}: {
  label: string;
  w?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={`flex flex-col ${w ?? ""}`}>
      <span className="text-[10px] uppercase tracking-wide text-muted-foreground mb-0.5">
        {label}
      </span>
      {children}
    </div>
  );
}
