import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ChecklistItem } from "@/lib/types";

interface Props {
  item: ChecklistItem;
  checked: boolean;
  onToggle: (v: boolean) => void;
}

export function ChecklistItemRow({ item, checked, onToggle }: Props) {
  const missingCritical = !checked && item.critical;
  return (
    <label
      className={cn(
        "group flex items-center gap-3 px-4 py-2 cursor-pointer transition-colors select-none",
        checked
          ? "hover:bg-muted/40"
          : missingCritical
            ? "bg-destructive/[0.035] hover:bg-destructive/[0.07]"
            : "hover:bg-muted/40",
      )}
    >
      <button
        type="button"
        role="checkbox"
        aria-checked={checked}
        onClick={(e) => {
          e.preventDefault();
          onToggle(!checked);
        }}
        className={cn(
          "shrink-0 size-4 rounded border flex items-center justify-center transition-colors",
          checked
            ? "border-primary bg-primary text-primary-foreground"
            : missingCritical
              ? "border-destructive/50 bg-background"
              : "border-border-strong bg-background group-hover:border-foreground/50",
        )}
      >
        {checked && <Check className="size-2.5" strokeWidth={4} />}
      </button>
      <div className="min-w-0 flex-1 flex items-center gap-2">
        <p
          className={cn(
            "text-sm leading-tight",
            checked && "text-muted-foreground",
            missingCritical && "text-foreground",
          )}
        >
          {item.label}
        </p>
        {item.critical && !checked && (
          <span className="text-[10px] font-semibold uppercase tracking-wider px-1 py-px rounded bg-destructive/10 text-destructive border border-destructive/20">
            крит.
          </span>
        )}
        {!item.required && (
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
            опц.
          </span>
        )}
        {item.hint && (
          <span className="text-xs text-muted-foreground truncate ml-auto pl-3">
            {item.hint}
          </span>
        )}
      </div>
    </label>
  );
}
