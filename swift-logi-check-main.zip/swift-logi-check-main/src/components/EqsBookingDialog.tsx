import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { previewEqsBooking, exportFileToEqs } from "@/lib/eqs-booking.functions";

interface Props {
  fileId: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSent?: () => void;
}

export function EqsBookingDialog({ fileId, open, onOpenChange, onSent }: Props) {
  const preview = useServerFn(previewEqsBooking);
  const send = useServerFn(exportFileToEqs);

  const q = useQuery({
    queryKey: ["eqs-booking-preview", fileId],
    queryFn: () => preview({ data: { file_id: fileId } }),
    enabled: open,
  });

  const [rows, setRows] = useState<Record<string, any>[]>([]);
  useEffect(() => {
    if (q.data) setRows(q.data.rows.map((r) => ({ ...r })));
  }, [q.data]);

  const columns = q.data?.columns ?? [];

  const sendMut = useMutation({
    mutationFn: () => send({ data: { file_id: fileId, rows } }),
    onSuccess: (res) => {
      toast.success(`Sent to EQS: ${res.filename}. Awaiting Booking ID…`);
      onOpenChange(false);
      onSent?.();
    },
    onError: (e: any) => toast.error(e?.message ?? "Send failed"),
  });

  const updateCell = (rowIdx: number, col: string, val: string) => {
    setRows((prev) => {
      const next = [...prev];
      next[rowIdx] = { ...next[rowIdx], [col]: val };
      return next;
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl">
        <DialogHeader>
          <DialogTitle>Create Booking in EQS</DialogTitle>
        </DialogHeader>
        {q.isLoading && <div className="py-6 text-sm text-muted-foreground">Loading…</div>}
        {q.error && (
          <div className="py-6 text-sm text-destructive">{(q.error as Error).message}</div>
        )}
        {q.data && (
          <div className="overflow-auto max-h-[60vh] border rounded">
            <table className="text-xs">
              <thead className="bg-muted/40 sticky top-0">
                <tr>
                  {columns.map((c) => (
                    <th key={c} className="text-left p-1.5 font-medium whitespace-nowrap border-r last:border-r-0">
                      {c}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r, idx) => (
                  <tr key={idx} className="border-t">
                    {columns.map((c) => (
                      <td key={c} className="p-0.5 border-r last:border-r-0">
                        <Input
                          value={r[c] ?? ""}
                          onChange={(e) => updateCell(idx, c, e.target.value)}
                          className="h-7 text-xs min-w-[110px]"
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            onClick={() => sendMut.mutate()}
            disabled={sendMut.isPending || !q.data || rows.length === 0}
          >
            {sendMut.isPending ? "Sending…" : "Send to EQS"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
