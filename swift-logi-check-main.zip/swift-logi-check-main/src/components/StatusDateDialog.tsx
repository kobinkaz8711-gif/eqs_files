import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export type StatusKey = "OP" | "RP" | "RCL" | "CL" | "CN";

const LABEL: Record<StatusKey, string> = {
  OP: "Open",
  RP: "Reporting Period",
  RCL: "Ready for Close",
  CL: "Closed",
  CN: "Cancelled",
};

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

/* -------- Set-status dialog -------- */

interface SetProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  status: StatusKey;
  /** show optional reason/notes input */
  withReason?: boolean;
  reasonLabel?: string;
  reasonRequired?: boolean;
  defaultDate?: string;
  pending?: boolean;
  onConfirm: (args: { date: string; reason?: string }) => void;
}

export function SetStatusDateDialog({
  open,
  onOpenChange,
  status,
  withReason,
  reasonLabel = "Reason",
  reasonRequired,
  defaultDate,
  pending,
  onConfirm,
}: SetProps) {
  const [date, setDate] = useState<string>(defaultDate ?? todayStr());
  const [reason, setReason] = useState<string>("");

  useEffect(() => {
    if (open) {
      setDate(defaultDate ?? todayStr());
      setReason("");
    }
  }, [open, defaultDate]);

  const valid = !!date && (!reasonRequired || reason.trim().length > 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Set status: {LABEL[status]}</DialogTitle>
          <DialogDescription>
            Дата установки статуса. По умолчанию — сегодня; можно изменить.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label htmlFor="status-date" className="text-xs">Date</Label>
            <Input
              id="status-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="h-9 mt-1"
              autoFocus
            />
          </div>
          {withReason && (
            <div>
              <Label htmlFor="status-reason" className="text-xs">
                {reasonLabel}{reasonRequired ? " *" : ""}
              </Label>
              <Input
                id="status-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="h-9 mt-1"
              />
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={pending}>
            Cancel
          </Button>
          <Button
            onClick={() => onConfirm({ date, reason: withReason ? reason : undefined })}
            disabled={!valid || pending}
          >
            {pending ? "Saving…" : "Confirm"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* -------- Edit-all dialog (admin) -------- */

export type StatusDates = {
  op_date?: string | null;
  rp_date?: string | null;
  rcl_date?: string | null;
  cl_date?: string | null;
  cn_date?: string | null;
};

interface EditProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  initial: StatusDates;
  /** Which status the file has reached (controls which fields are editable) */
  currentStatus: string;
  pending?: boolean;
  onConfirm: (patch: StatusDates) => void;
}

const ORDER: Array<{ key: keyof StatusDates; status: StatusKey }> = [
  { key: "op_date", status: "OP" },
  { key: "rp_date", status: "RP" },
  { key: "rcl_date", status: "RCL" },
  { key: "cl_date", status: "CL" },
  { key: "cn_date", status: "CN" },
];

export function EditStatusDatesDialog({
  open,
  onOpenChange,
  initial,
  currentStatus,
  pending,
  onConfirm,
}: EditProps) {
  const [vals, setVals] = useState<StatusDates>(initial);

  useEffect(() => {
    if (open) setVals(initial);
  }, [open, initial]);

  // Editable: a status field is visible if the file already has a date for it.
  // CN is always editable when the file is cancelled.
  const editable = (key: keyof StatusDates) => !!initial[key];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Set status dates</DialogTitle>
          <DialogDescription>
            Скорректировать даты установки уже пройденных статусов.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2">
          {ORDER.filter((o) => editable(o.key)).map((o) => (
            <div key={o.key} className="grid grid-cols-[110px_1fr] items-center gap-2">
              <Label htmlFor={`sd-${o.key}`} className="text-xs">{LABEL[o.status]}</Label>
              <Input
                id={`sd-${o.key}`}
                type="date"
                value={(vals[o.key] as string) ?? ""}
                onChange={(e) =>
                  setVals((p) => ({ ...p, [o.key]: e.target.value || null }))
                }
                className="h-8"
              />
            </div>
          ))}
          {ORDER.every((o) => !editable(o.key)) && (
            <div className="text-xs text-muted-foreground">
              У файла пока нет пройденных статусов.
            </div>
          )}
          <div className="text-[11px] text-muted-foreground pt-1">
            Current status: {currentStatus}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={pending}>
            Cancel
          </Button>
          <Button onClick={() => onConfirm(vals)} disabled={pending}>
            {pending ? "Saving…" : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
