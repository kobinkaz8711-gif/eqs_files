import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { copyText } from "@/lib/copy";
import type { GeneratedEmail } from "@/lib/types";

interface Props {
  email: GeneratedEmail;
  onReset: () => void;
}

export function EmailPreview({ email }: Props) {
  return (
    <div className="space-y-3">
      <div className="rounded border border-border bg-surface/60 overflow-hidden">
        <div className="px-3 py-2 border-b border-border bg-card flex items-center gap-2">
          <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground w-10">
            Тема
          </span>
          <p className="text-xs font-medium leading-snug truncate">{email.subject}</p>
        </div>
        <div className="px-3 py-2.5 max-h-[280px] overflow-y-auto">
          <pre className="text-xs leading-relaxed whitespace-pre-wrap font-sans text-foreground">
            {email.body}
          </pre>
        </div>
      </div>

      {!email.ok && (
        <div className="flex items-start gap-2 p-2 rounded bg-warning/15 border border-warning/30">
          <AlertTriangle className="size-3.5 text-warning-foreground shrink-0 mt-0.5" />
          <p className="text-[11px] text-warning-foreground leading-snug">
            Письмо содержит пометку «требуются данные» — закройте критичные пункты перед передачей.
          </p>
        </div>
      )}

      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          className="flex-1 h-9 gap-2"
          onClick={() => copyText(email.subject, "Тема скопирована")}
        >
          Скопировать тему
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="flex-1 h-9 gap-2"
          onClick={() => copyText(email.body, "Тело скопировано")}
        >
          Скопировать тело
        </Button>
      </div>
    </div>
  );
}
