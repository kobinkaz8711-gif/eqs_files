import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface Props {
  onFile: (file: File) => void;
  label?: string;
}

export function FilePicker({ onFile, label = "Документ" }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept="application/pdf"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          if (f.type !== "application/pdf") {
            toast.error("Поддерживается только PDF");
            e.target.value = "";
            return;
          }
          onFile(f);
          e.target.value = "";
        }}
      />
      <Button
        variant="ghost"
        size="sm"
        className="h-9 text-muted-foreground"
        onClick={() => inputRef.current?.click()}
      >
        {label}
      </Button>
    </>
  );
}
