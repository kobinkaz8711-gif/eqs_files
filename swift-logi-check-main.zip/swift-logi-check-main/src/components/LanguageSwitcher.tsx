import { Button } from "@/components/ui/button";
import { useI18n } from "@/i18n/i18n";

export function LanguageSwitcher() {
  const { locale, setLocale } = useI18n();

  return (
    <Button
      variant="ghost"
      size="sm"
      className="h-9 px-2 text-xs font-semibold uppercase tracking-wide"
      onClick={() => setLocale(locale === "ru" ? "en" : "ru")}
    >
      {locale === "ru" ? "RU" : "EN"}
    </Button>
  );
}
