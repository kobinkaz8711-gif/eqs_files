import { useMemo, useState } from "react";
import { Plus, Trash2, GripVertical, ChevronDown, Link2 } from "lucide-react";
import {
  DndContext,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import type { ChecklistItem, ChecklistSection, ChecklistTemplate } from "@/lib/types";

interface Props {
  template: ChecklistTemplate;
  onChange: (next: ChecklistTemplate) => void;
}

interface Props {
  template: ChecklistTemplate;
  onChange: (next: ChecklistTemplate) => void;
}

const newId = () =>
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `id-${Math.random().toString(36).slice(2, 10)}`;

export function TemplateEditor({ template, onChange }: Props) {
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  // Flat list of all items in the template with section title — for "depends on" picker.
  const allItems = useMemo(
    () =>
      template.sections.flatMap((s) =>
        s.items.map((it) => ({
          id: it.id,
          label: it.label,
          sectionTitle: s.title,
        })),
      ),
    [template],
  );

  // Build descendants set for each item (to forbid cycles in the picker).
  const descendantsOf = useMemo(() => {
    const childrenByParent = new Map<string, string[]>();
    for (const s of template.sections) {
      for (const it of s.items) {
        if (it.depends_on_item_id) {
          const arr = childrenByParent.get(it.depends_on_item_id) ?? [];
          arr.push(it.id);
          childrenByParent.set(it.depends_on_item_id, arr);
        }
      }
    }
    const cache = new Map<string, Set<string>>();
    const collect = (id: string, acc: Set<string>, seen: Set<string>) => {
      if (seen.has(id)) return;
      seen.add(id);
      for (const c of childrenByParent.get(id) ?? []) {
        acc.add(c);
        collect(c, acc, seen);
      }
    };
    for (const { id } of allItems) {
      const acc = new Set<string>();
      collect(id, acc, new Set());
      cache.set(id, acc);
    }
    return cache;
  }, [template, allItems]);

  const updateSection = (sectionId: string, patch: Partial<ChecklistSection>) => {
    onChange({
      ...template,
      sections: template.sections.map((s) => (s.id === sectionId ? { ...s, ...patch } : s)),
    });
  };

  const deleteSection = (sectionId: string) => {
    if (!confirm("Удалить секцию вместе со всеми пунктами?")) return;
    onChange({
      ...template,
      sections: template.sections.filter((s) => s.id !== sectionId),
    });
  };

  const addSection = () => {
    onChange({
      ...template,
      sections: [
        ...template.sections,
        {
          id: newId(),
          title: "Новая секция",
          sort_order: template.sections.length,
          items: [],
        },
      ],
    });
  };

  const handleSectionDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIdx = template.sections.findIndex((s) => s.id === active.id);
    const newIdx = template.sections.findIndex((s) => s.id === over.id);
    const reordered = arrayMove(template.sections, oldIdx, newIdx).map((s, i) => ({
      ...s,
      sort_order: i,
    }));
    onChange({ ...template, sections: reordered });
  };

  return (
    <div className="space-y-4">
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleSectionDragEnd}>
        <SortableContext
          items={template.sections.map((s) => s.id)}
          strategy={verticalListSortingStrategy}
        >
          {template.sections
            .slice()
            .sort((a, b) => a.sort_order - b.sort_order)
            .map((section) => (
              <SortableSection
                key={section.id}
                section={section}
                onUpdate={(patch) => updateSection(section.id, patch)}
                onDelete={() => deleteSection(section.id)}
                allItems={allItems}
                descendantsOf={descendantsOf}
              />
            ))}
        </SortableContext>
      </DndContext>

      <Button variant="outline" className="w-full" onClick={addSection}>
        <Plus className="size-4" />
        Добавить секцию
      </Button>
    </div>
  );
}

function SortableSection({
  section,
  onUpdate,
  onDelete,
  allItems,
  descendantsOf,
}: {
  section: ChecklistSection;
  onUpdate: (patch: Partial<ChecklistSection>) => void;
  onDelete: () => void;
  allItems: { id: string; label: string; sectionTitle: string }[];
  descendantsOf: Map<string, Set<string>>;
}) {
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: section.id,
  });
  const [open, setOpen] = useState(true);

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const updateItem = (itemId: string, patch: Partial<ChecklistItem>) => {
    onUpdate({
      items: section.items.map((i) => (i.id === itemId ? { ...i, ...patch } : i)),
    });
  };

  const deleteItem = (itemId: string) => {
    onUpdate({ items: section.items.filter((i) => i.id !== itemId) });
  };

  const addItem = () => {
    onUpdate({
      items: [
        ...section.items,
        {
          id: newId(),
          label: "Новый пункт",
          required: true,
          critical: false,
          sort_order: section.items.length,
        },
      ],
    });
  };

  const handleItemDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIdx = section.items.findIndex((i) => i.id === active.id);
    const newIdx = section.items.findIndex((i) => i.id === over.id);
    const reordered = arrayMove(section.items, oldIdx, newIdx).map((i, idx) => ({
      ...i,
      sort_order: idx,
    }));
    onUpdate({ items: reordered });
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="rounded-md border border-border bg-card overflow-hidden"
    >
      <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-muted/30">
        <button
          {...attributes}
          {...listeners}
          className="size-7 grid place-items-center text-muted-foreground hover:text-foreground cursor-grab active:cursor-grabbing"
        >
          <GripVertical className="size-4" />
        </button>
        <Input
          value={section.title}
          onChange={(e) => onUpdate({ title: e.target.value })}
          className="h-8 flex-1 font-medium"
        />
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setOpen((v) => !v)}
          className="text-muted-foreground"
        >
          <ChevronDown className={cn("size-4 transition-transform", open && "rotate-180")} />
          {section.items.length} {pluralize(section.items.length)}
        </Button>
        <Button variant="ghost" size="icon" onClick={onDelete} className="text-muted-foreground hover:text-destructive">
          <Trash2 className="size-4" />
        </Button>
      </div>

      {open && (
        <div className="p-2 space-y-1">
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleItemDragEnd}
          >
            <SortableContext
              items={section.items.map((i) => i.id)}
              strategy={verticalListSortingStrategy}
            >
              {section.items
                .slice()
                .sort((a, b) => a.sort_order - b.sort_order)
                .map((item) => (
                  <SortableItem
                    key={item.id}
                    item={item}
                    onUpdate={(patch) => updateItem(item.id, patch)}
                    onDelete={() => deleteItem(item.id)}
                    allItems={allItems}
                    forbiddenIds={descendantsOf.get(item.id) ?? new Set()}
                  />
                ))}
            </SortableContext>
          </DndContext>
          <Button variant="ghost" className="w-full text-muted-foreground" onClick={addItem}>
            <Plus className="size-4" />
            Добавить пункт
          </Button>
        </div>
      )}
    </div>
  );
}

function SortableItem({
  item,
  onUpdate,
  onDelete,
  allItems,
  forbiddenIds,
}: {
  item: ChecklistItem;
  onUpdate: (patch: Partial<ChecklistItem>) => void;
  onDelete: () => void;
  allItems: { id: string; label: string; sectionTitle: string }[];
  forbiddenIds: Set<string>;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: item.id,
  });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const dep = item.depends_on_item_id ?? null;
  const NONE = "__none__";
  const pickable = allItems.filter(
    (i) => i.id !== item.id && !forbiddenIds.has(i.id),
  );

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "flex items-center gap-2 px-2 py-1.5 rounded hover:bg-muted/40 border border-transparent hover:border-border",
        dep && "bg-accent/20",
      )}
    >
      <button
        {...attributes}
        {...listeners}
        className="size-6 grid place-items-center text-muted-foreground hover:text-foreground cursor-grab active:cursor-grabbing shrink-0"
      >
        <GripVertical className="size-3.5" />
      </button>
      <Input
        value={item.label}
        onChange={(e) => onUpdate({ label: e.target.value })}
        className="h-8 flex-1"
      />

      <div className="flex items-center gap-1 shrink-0">
        <Link2
          className={cn(
            "size-3.5",
            dep ? "text-primary" : "text-muted-foreground/50",
          )}
        />
        <Select
          value={dep ?? NONE}
          onValueChange={(v) =>
            onUpdate({ depends_on_item_id: v === NONE ? null : v })
          }
        >
          <SelectTrigger className="h-8 w-[180px] text-xs">
            <SelectValue placeholder="Безусловный" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={NONE}>— Безусловный —</SelectItem>
            {pickable.map((opt) => (
              <SelectItem key={opt.id} value={opt.id}>
                <span className="text-muted-foreground">{opt.sectionTitle}:</span>{" "}
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <label className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground select-none px-2 cursor-pointer">
        <Checkbox
          checked={item.required}
          onCheckedChange={(v) => onUpdate({ required: !!v })}
        />
        обяз.
      </label>
      <label className="flex items-center gap-1.5 text-xs font-medium text-destructive select-none px-2 cursor-pointer">
        <Checkbox
          checked={item.critical}
          onCheckedChange={(v) => onUpdate({ critical: !!v })}
        />
        критич.
      </label>
      <Button
        variant="ghost"
        size="icon"
        onClick={onDelete}
        className="text-muted-foreground hover:text-destructive shrink-0"
      >
        <Trash2 className="size-4" />
      </Button>
    </div>
  );
}

function pluralize(n: number) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return "пункт";
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return "пункта";
  return "пунктов";
}
