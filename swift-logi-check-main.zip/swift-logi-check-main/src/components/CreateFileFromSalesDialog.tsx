import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  previewFileFromSales,
  createFileFromSales,
} from "@/lib/salesToFile.functions";
import {
  searchBuyers,
  searchLocations,
  listCountries,
} from "@/lib/files.functions";
import { listSalesPersons } from "@/lib/salesPersons.functions";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const CONTAINER_TYPE_OPTIONS = [
  "20DV", "20DC", "20HC", "20RF", "20OT", "20FR", "20TK",
  "40DV", "40DC", "40HC", "40RF", "40HR", "40OT", "40FR", "40NOR",
  "45HC", "45HR",
];

export function CreateFileFromSalesDialog({
  saleIds,
  onClose,
  onCreated,
}: {
  saleIds: string[];
  onClose: () => void;
  onCreated: (fileId: string) => void;
}) {
  const preview = useServerFn(previewFileFromSales);
  const create = useServerFn(createFileFromSales);
  const fetchBuyers = useServerFn(searchBuyers);
  const fetchLocations = useServerFn(searchLocations);
  const fetchCountries = useServerFn(listCountries);
  const fetchSPs = useServerFn(listSalesPersons);

  const prevQ = useQuery({
    queryKey: ["preview-sales-file", saleIds],
    queryFn: () => preview({ data: { sale_ids: saleIds } }),
  });
  const sps = useQuery({
    queryKey: ["sales-persons"],
    queryFn: () => fetchSPs(),
  });
  const countries = useQuery({
    queryKey: ["countries"],
    queryFn: () => fetchCountries(),
  });

  const [departmentId, setDepartmentId] = useState<string>("");
  const [currency, setCurrency] = useState<"USD" | "EUR">("USD");
  const [customerAccno, setCustomerAccno] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerCountry, setCustomerCountry] = useState<string>("");
  const [salesPersonId, setSalesPersonId] = useState<string>("");
  const [originCountry, setOriginCountry] = useState("");
  const [originSubregion, setOriginSubregion] = useState("");
  const [originLocn, setOriginLocn] = useState("");
  const [destCountry, setDestCountry] = useState("");
  const [destSubregion, setDestSubregion] = useState("");
  const [destLocn, setDestLocn] = useState("");
  const [plannedDeparture, setPlannedDeparture] = useState("");
  const [plannedArrival, setPlannedArrival] = useState("");
  const [notes, setNotes] = useState("");

  const [buyerQ, setBuyerQ] = useState("");
  const [originQ, setOriginQ] = useState("");
  const [destQ, setDestQ] = useState("");

  const [overrides, setOverrides] = useState<
    Record<string, { qty?: string; purchase?: string; sale?: string }>
  >({});
  const [seeded, setSeeded] = useState(false);

  useEffect(() => {
    const d = prevQ.data as any;
    if (!d || seeded) return;
    setDepartmentId(d.suggested_department_id ?? d.departments?.[0]?.id ?? "");
    if (d.suggested_currency) setCurrency(d.suggested_currency);
    setCustomerAccno(d.customer_accno ?? "");
    setCustomerName(d.customer_name ?? "");
    setSalesPersonId(d.suggested_sales_person_id ?? "");
    setOriginCountry(d.origin_country_code ?? "");
    setOriginSubregion(d.origin_subregion ?? "");
    setOriginLocn(d.origin_locn ?? "");
    setDestCountry(d.dest_country_code ?? "");
    setDestSubregion(d.dest_subregion ?? "");
    setDestLocn(d.dest_locn ?? "");
    setPlannedDeparture(d.planned_departure_date ?? "");
    setPlannedArrival(d.planned_arrival_date ?? "");
    setSeeded(true);
  }, [prevQ.data, seeded]);

  const buyers = useQuery({
    queryKey: ["buyers", buyerQ],
    queryFn: () => fetchBuyers({ data: { q: buyerQ } }),
    enabled: buyerQ.length >= 2,
  });
  const origins = useQuery({
    queryKey: ["loc", "o", originQ, originCountry],
    queryFn: () =>
      fetchLocations({
        data: { q: originQ, country_code: originCountry || undefined },
      }),
    enabled: originQ.length >= 1,
  });
  const dests = useQuery({
    queryKey: ["loc", "d", destQ, destCountry],
    queryFn: () =>
      fetchLocations({
        data: { q: destQ, country_code: destCountry || undefined },
      }),
    enabled: destQ.length >= 1,
  });

  const createMut = useMutation({
    mutationFn: () => {
      const types = ((prevQ.data as any)?.container_types ?? []) as any[];
      const type_overrides = types.map((t: any) => {
        const ov = overrides[t.container_type] ?? {};
        const num = (v: string | undefined, fb: number | null) =>
          v != null && v !== "" ? Number(v) : (fb as number);
        return {
          container_type: t.container_type,
          qty:
            ov.qty != null && ov.qty !== ""
              ? Math.max(1, Math.trunc(Number(ov.qty)))
              : t.qty,
          purchase_per_unit: num(ov.purchase, t.avg_purchase),
          sale_per_unit: num(ov.sale, t.avg_sale),
        };
      });
      return create({
        data: {
          sale_ids: saleIds,
          department_id: departmentId,
          currency,
          customer_accno: customerAccno || null,
          customer_name: customerName || null,
          sales_person_id: salesPersonId || null,
          origin_locn: originLocn || null,
          origin_subregion: originSubregion || null,
          origin_country_code: originCountry || null,
          dest_locn: destLocn || null,
          dest_subregion: destSubregion || null,
          dest_country_code: destCountry || null,
          planned_departure_date: plannedDeparture || null,
          planned_arrival_date: plannedArrival || null,
          notes: notes || null,
          type_overrides,
        },
      });
    },
    onSuccess: (r: any) => {
      toast.success("File created");
      onCreated(r.id);
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  const data = prevQ.data as any;

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>Create file from {saleIds.length} sales line(s)</DialogTitle>
        </DialogHeader>
        {prevQ.isLoading && (
          <div className="p-4 text-sm text-muted-foreground">Loading…</div>
        )}
        {prevQ.error && (
          <div className="p-4 text-sm text-destructive">
            {(prevQ.error as any)?.message ?? "Failed to load"}
          </div>
        )}
        {data && (
          <div className="space-y-4 text-sm">
            {/* Customer */}
            <div>
              <Label>Customer</Label>
              <Input
                placeholder="Search by accno or name (min 2 chars)"
                value={buyerQ}
                onChange={(e) => setBuyerQ(e.target.value)}
                className="h-8"
              />
              {customerAccno && (
                <div className="text-xs mt-1 text-muted-foreground">
                  Selected:{" "}
                  <span className="font-mono">{customerAccno}</span> —{" "}
                  {customerName}
                  {customerCountry ? ` (${customerCountry})` : ""}
                </div>
              )}
              {buyers.data && buyerQ.length >= 2 && (
                <div className="mt-2 max-h-40 overflow-auto border border-border rounded">
                  {buyers.data.items.map((b: any) => (
                    <button
                      key={b.accno}
                      type="button"
                      className="w-full text-left px-3 py-2 hover:bg-muted text-xs border-b border-border last:border-0"
                      onClick={() => {
                        setCustomerAccno(b.accno);
                        setCustomerName(b.customer_name);
                        setCustomerCountry(b.country_code ?? "");
                        setBuyerQ("");
                      }}
                    >
                      <span className="font-mono">{b.accno}</span> —{" "}
                      {b.customer_name}{" "}
                      <span className="text-muted-foreground">
                        ({b.country_code}, {b.sale_count}{" "}
                        {b.source === "lessee" ? "leases" : b.source === "both" ? "sales+leases" : "sales"})
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Department / Sales Person */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Department</Label>
                <Select value={departmentId} onValueChange={setDepartmentId}>
                  <SelectTrigger className="h-8">
                    <SelectValue placeholder="Pick department" />
                  </SelectTrigger>
                  <SelectContent>
                    {(data.departments ?? []).map((d: any) => (
                      <SelectItem key={d.id} value={d.id}>
                        {d.code} — {d.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Sales person</Label>
                <Select
                  value={salesPersonId}
                  onValueChange={setSalesPersonId}
                >
                  <SelectTrigger className="h-8">
                    <SelectValue placeholder="Select…" />
                  </SelectTrigger>
                  <SelectContent>
                    {(sps.data?.items ?? [])
                      .filter((s: any) => s.is_active)
                      .map((s: any) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.full_name}
                          {s.departments?.code ? ` — ${s.departments.code}` : ""}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Origin / Destination */}
            <div className="grid grid-cols-2 gap-3">
              <CountryLocationField
                title="Origin"
                countries={countries.data?.items ?? []}
                country={originCountry}
                onCountry={(c) => setOriginCountry(c)}
                locnQ={originQ}
                setLocnQ={setOriginQ}
                locnValue={originLocn}
                results={origins.data?.items ?? []}
                onPickLoc={(loc) => {
                  setOriginCountry(originCountry || loc.country_code || "");
                  setOriginLocn(loc.locn_id);
                  setOriginSubregion(loc.subregion_id ?? "");
                }}
                onClearLoc={() => {
                  setOriginLocn("");
                  setOriginSubregion("");
                }}
              />
              <CountryLocationField
                title="Destination"
                countries={countries.data?.items ?? []}
                country={destCountry}
                onCountry={(c) => setDestCountry(c)}
                locnQ={destQ}
                setLocnQ={setDestQ}
                locnValue={destLocn}
                results={dests.data?.items ?? []}
                onPickLoc={(loc) => {
                  setDestCountry(destCountry || loc.country_code || "");
                  setDestLocn(loc.locn_id);
                  setDestSubregion(loc.subregion_id ?? "");
                }}
                onClearLoc={() => {
                  setDestLocn("");
                  setDestSubregion("");
                }}
              />
            </div>

            {/* Dates / Currency */}
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label>Planned departure</Label>
                <Input
                  type="date"
                  value={plannedDeparture}
                  onChange={(e) => setPlannedDeparture(e.target.value)}
                  className="h-8"
                />
              </div>
              <div>
                <Label>Planned arrival</Label>
                <Input
                  type="date"
                  value={plannedArrival}
                  onChange={(e) => setPlannedArrival(e.target.value)}
                  className="h-8"
                />
              </div>
              <div>
                <Label>Plan currency</Label>
                <Select value={currency} onValueChange={(v) => setCurrency(v as any)}>
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Notes</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={`Auto-created from ${saleIds.length} sales line(s)`}
                rows={2}
              />
            </div>

            {/* Container types */}
            <div>
              <div className="font-medium mb-2">Container types &amp; prices</div>
              <div className="text-xs text-muted-foreground mb-2">
                Sale defaults from invoice amounts; purchase from{" "}
                <span className="font-mono">amt_ppb</span>. All fields editable.
              </div>
              <table className="w-full text-xs border border-border rounded">
                <thead className="bg-muted/40">
                  <tr>
                    <th className="text-left p-2">Type</th>
                    <th className="text-right p-2">Qty</th>
                    <th className="text-right p-2">Purchase / unit</th>
                    <th className="text-right p-2">Sale / unit</th>
                  </tr>
                </thead>
                <tbody>
                  {(data.container_types ?? []).map((t: any) => {
                    const ov = overrides[t.container_type] ?? {};
                    const purchasePh =
                      t.avg_purchase != null ? Number(t.avg_purchase).toFixed(2) : "required";
                    const salePh =
                      t.avg_sale != null ? Number(t.avg_sale).toFixed(2) : "required";
                    const setField = (k: "qty" | "purchase" | "sale", v: string) =>
                      setOverrides((s) => ({
                        ...s,
                        [t.container_type]: { ...s[t.container_type], [k]: v },
                      }));
                    const setType = (v: string) =>
                      setOverrides((s) => {
                        const next = { ...s };
                        const prev = next[t.container_type] ?? {};
                        delete next[t.container_type];
                        next[v] = { ...(next[v] ?? {}), ...prev };
                        return next;
                      });
                    return (
                      <tr key={t.container_type} className="border-t border-border">
                        <td className="p-2">
                          <Select
                            value={t.container_type}
                            onValueChange={(v) => {
                              t.container_type = v;
                              setType(v);
                            }}
                          >
                            <SelectTrigger className="h-8 w-28">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {CONTAINER_TYPE_OPTIONS.map((o) => (
                                <SelectItem key={o} value={o}>
                                  {o}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="p-2">
                          <Input
                            type="number"
                            min={1}
                            step={1}
                            placeholder={String(t.qty)}
                            value={ov.qty ?? ""}
                            onChange={(e) => setField("qty", e.target.value)}
                            className="h-8 text-right font-mono"
                          />
                        </td>
                        <td className="p-2">
                          <Input
                            type="number"
                            placeholder={purchasePh}
                            value={ov.purchase ?? ""}
                            onChange={(e) => setField("purchase", e.target.value)}
                            className={`h-8 text-right ${t.avg_purchase == null ? "border-amber-500" : ""}`}
                          />
                        </td>
                        <td className="p-2">
                          <Input
                            type="number"
                            placeholder={salePh}
                            value={ov.sale ?? ""}
                            onChange={(e) => setField("sale", e.target.value)}
                            className={`h-8 text-right ${t.avg_sale == null ? "border-amber-500" : ""}`}
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div>
              <div className="font-medium mb-2">
                Units ({data.units?.length ?? 0})
                {data.units?.some((u: any) => u.already_linked_file_id) && (
                  <span className="ml-2 text-xs text-amber-600">
                    (some already linked — will be skipped)
                  </span>
                )}
              </div>
              <div className="max-h-40 overflow-auto border border-border rounded">
                <table className="w-full text-xs">
                  <thead className="bg-muted/40 sticky top-0">
                    <tr>
                      <th className="text-left p-2">Unit</th>
                      <th className="text-left p-2">Type</th>
                      <th className="text-right p-2">PpB</th>
                      <th className="text-right p-2">Sale ∑</th>
                      <th className="text-left p-2">Linked file</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(data.units ?? []).map((u: any) => (
                      <tr key={u.unit_no} className="border-t border-border">
                        <td className="p-2 font-mono">{u.unit_no}</td>
                        <td className="p-2 font-mono">{u.iso_code ?? "—"}</td>
                        <td className="p-2 text-right font-mono">
                          {u.amt_ppb != null ? Number(u.amt_ppb).toFixed(2) : "—"}
                        </td>
                        <td className="p-2 text-right font-mono">
                          {u.sale_amt_b != null ? Number(u.sale_amt_b).toFixed(2) : "—"}
                        </td>
                        <td className="p-2">
                          {u.already_linked_file_number ? (
                            <span className="font-mono text-amber-600">
                              {u.already_linked_file_number}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={onClose}>
                Cancel
              </Button>
              <Button
                onClick={() => createMut.mutate()}
                disabled={!departmentId || createMut.isPending}
              >
                {createMut.isPending ? "Creating…" : "Create file"}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function CountryLocationField({
  title,
  countries,
  country,
  onCountry,
  locnQ,
  setLocnQ,
  locnValue,
  results,
  onPickLoc,
  onClearLoc,
}: {
  title: string;
  countries: { country_code: string; country_name: string }[];
  country: string;
  onCountry: (c: string) => void;
  locnQ: string;
  setLocnQ: (s: string) => void;
  locnValue: string;
  results: any[];
  onPickLoc: (loc: any) => void;
  onClearLoc: () => void;
}) {
  return (
    <div className="rounded-lg border border-border p-3 space-y-2">
      <div className="text-xs font-medium">{title}</div>
      <div>
        <Label className="text-xs">Country</Label>
        <Select value={country} onValueChange={onCountry}>
          <SelectTrigger className="h-8">
            <SelectValue placeholder="Select country…" />
          </SelectTrigger>
          <SelectContent className="max-h-72">
            {countries.map((c) => (
              <SelectItem key={c.country_code} value={c.country_code}>
                {c.country_name} ({c.country_code})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label className="text-xs">Location</Label>
        <Input
          placeholder="Search location"
          value={locnQ}
          onChange={(e) => setLocnQ(e.target.value)}
          className="h-8"
        />
        {locnValue && (
          <div className="text-xs mt-1 flex items-center gap-2">
            <span className="text-muted-foreground">
              Selected: <span className="font-mono">{locnValue}</span>
            </span>
            <button
              type="button"
              className="text-xs underline text-muted-foreground"
              onClick={() => {
                onClearLoc();
                setLocnQ("");
              }}
            >
              clear
            </button>
          </div>
        )}
        {locnQ.length >= 1 && results.length > 0 && (
          <div className="mt-2 max-h-40 overflow-auto border border-border rounded">
            {results.map((l: any) => (
              <button
                key={l.locn_id}
                type="button"
                className="w-full text-left px-3 py-2 hover:bg-muted text-xs border-b border-border last:border-0"
                onClick={() => {
                  onPickLoc(l);
                  setLocnQ("");
                }}
              >
                <span className="font-mono">{l.locn_id}</span> — {l.locn_desc}{" "}
                <span className="text-muted-foreground">
                  ({l.country_code} · {l.subregion_id})
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
