import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { TransportTypeDTO } from "@/lib/templates.functions";

interface Props {
  value: string;
  onChange: (v: string) => void;
  types: TransportTypeDTO[];
  includeInactive?: boolean;
}

export function TransportTypeSelect({ value, onChange, types, includeInactive }: Props) {
  const list = includeInactive ? types : types.filter((t) => t.is_active);
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-full min-w-[200px] h-9 font-medium">
        <SelectValue placeholder="Выберите тип" />
      </SelectTrigger>
      <SelectContent>
        {list.map((t) => (
          <SelectItem key={t.code} value={t.code}>
            <span className="font-mono text-xs text-muted-foreground mr-2">{t.code}</span>
            <span>{t.label.replace(`${t.code} — `, "")}</span>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
