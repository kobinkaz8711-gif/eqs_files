import { useState, useMemo, useEffect, Fragment } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import {
  listRecentUnitsGlobal,
  previewBookingFile,
  createFileFromBooking,
} from "@/lib/files.functions";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Loader2, ExternalLink } from "lucide-react";

export function RecentUnitsDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const navigate = useNavigate();
  const list = useServerFn(listRecentUnitsGlobal);
  const [q, setQ] = useState("");
  const [onlyUnlinked, setOnlyUnlinked] = useState(false);
  const [createForBooking, setCreateForBooking] = useState<string | null>(null);

  const recentQ = useQuery({
    queryKey: ["recent-units-global", q, onlyUnlinked],
    queryFn: () => list({ data: { q: q || undefined, only_unlinked: onlyUnlinked } }),
    enabled: open,
  });

  const grouped = useMemo(() => {
    const items = (recentQ.data?.items ?? []) as any[];
    const map = new Map<string, any[]>();
    for (const it of items) {
      const k = it.booking_no ?? "—";
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(it);
    }
    return map;
  }, [recentQ.data]);

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>Recent Units</DialogTitle>
          </DialogHeader>
          <div className="flex gap-2 items-center">
            <Input
              placeholder="Filter by unit, booking, customer, internal ref, location…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="flex-1"
            />
            <Button
              size="sm"
              variant={onlyUnlinked ? "default" : "outline"}
              onClick={() => setOnlyUnlinked((v) => !v)}
            >
              {onlyUnlinked ? "Unlinked only" : "All units"}
            </Button>
          </div>
          <div className="flex-1 overflow-auto border border-border rounded-md">
            {recentQ.isLoading && (
              <div className="p-6 text-center text-muted-foreground text-sm">Loading…</div>
            )}
            {!recentQ.isLoading && grouped.size === 0 && (
              <div className="p-6 text-center text-muted-foreground text-sm">
                No units found.
              </div>
            )}
            {grouped.size > 0 && (
              <table className="w-full text-xs">
                <thead className="bg-muted/40 sticky top-0">
                  <tr>
                    <th className="text-left p-2 font-medium">Unit</th>
                    <th className="text-left p-2 font-medium">Type</th>
                    <th className="text-left p-2 font-medium">OnHire</th>
                    <th className="text-left p-2 font-medium">From</th>
                    <th className="text-left p-2 font-medium">To</th>
                    <th className="text-left p-2 font-medium">Status</th>
                    <th className="text-left p-2 font-medium">File</th>
                    <th className="p-2" />
                  </tr>
                </thead>
                <tbody>
                  {Array.from(grouped.entries()).map(([bk, units]) => {
                    const first = units[0];
                    const linkedCount = units.filter((u: any) => u.linked_file_id).length;
                    const allLinked = linkedCount === units.length;
                    return (
                      <Fragment key={`group-${bk}`}>
                        <tr key={`bk-${bk}`} className="border-t border-border bg-muted/20">
                          <td colSpan={7} className="p-2">
                            <span className="font-semibold">Booking </span>
                            <span className="font-mono">{bk}</span>
                            <span className="text-muted-foreground ml-2">
                              · {first.locn_pol_name ?? first.locn_pol ?? "—"} →{" "}
                              {first.do_locn_name ?? first.do_locn ?? first.locn_pod_name ?? first.locn_pod ?? "—"}
                            </span>
                            {first.accname && (
                              <span className="ml-2 text-muted-foreground">· {first.accname}{first.accno ? ` (${first.accno})` : ""}</span>
                            )}
                            {first.internal_ref && (
                              <span className="ml-2 text-muted-foreground">· ref {first.internal_ref}</span>
                            )}

                            <span className="ml-2 text-muted-foreground">
                              ({units.length} unit{units.length === 1 ? "" : "s"}
                              {linkedCount > 0 ? `, ${linkedCount} linked` : ""})
                            </span>
                          </td>
                          <td className="p-2 text-right">
                            {!allLinked && bk !== "—" && (
                              <Button
                                size="sm"
                                variant="secondary"
                                onClick={() => setCreateForBooking(bk)}
                              >
                                <Plus className="h-3 w-3 mr-1" />
                                Create file from booking
                              </Button>
                            )}
                          </td>
                        </tr>
                        {units.map((u: any) => (
                          <tr key={`${u.unit_no}-${bk}`} className="border-t border-border">
                            <td className="p-2 font-mono">{u.unit_no}</td>
                            <td className="p-2 font-mono">{u.iso_code ?? "—"}</td>
                            <td className="p-2 font-mono">{u.onhire_date ?? "—"}</td>
                            <td className="p-2">
                              {u.locn_pol_name ?? "—"}
                              {u.locn_pol && (
                                <span className="ml-1 font-mono text-muted-foreground">
                                  ({u.locn_pol})
                                </span>
                              )}
                            </td>
                            <td className="p-2">
                              {u.do_locn_name ?? u.locn_pod_name ?? "—"}
                              {(u.do_locn ?? u.locn_pod) && (
                                <span className="ml-1 font-mono text-muted-foreground">
                                  ({u.do_locn ?? u.locn_pod})
                                </span>
                              )}
                            </td>
                            <td className="p-2">{u.status ?? "—"}</td>
                            <td className="p-2">
                              {u.linked_file_number ? (
                                <button
                                  className="text-primary hover:underline font-mono inline-flex items-center gap-1"
                                  onClick={() => {
                                    onOpenChange(false);
                                    navigate({
                                      to: "/eqs-files/$id",
                                      params: { id: u.linked_file_id },
                                    });
                                  }}
                                >
                                  {u.linked_file_number}
                                  <ExternalLink className="h-3 w-3" />
                                </button>
                              ) : (
                                <span className="text-muted-foreground">—</span>
                              )}
                            </td>
                            <td />
                          </tr>
                        ))}
                      </Fragment>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {createForBooking && (
        <CreateFileFromBookingDialog
          bookingNo={createForBooking}
          onClose={() => setCreateForBooking(null)}
          onCreated={(fileId) => {
            setCreateForBooking(null);
            onOpenChange(false);
            navigate({ to: "/eqs-files/$id", params: { id: fileId } });
          }}
        />
      )}
    </>
  );
}

export function CreateFileFromBookingDialog({
  bookingNo,
  onClose,
  onCreated,
}: {
  bookingNo: string;
  onClose: () => void;
  onCreated: (fileId: string) => void;
}) {
  const preview = useServerFn(previewBookingFile);
  const create = useServerFn(createFileFromBooking);
  const prevQ = useQuery({
    queryKey: ["preview-booking", bookingNo],
    queryFn: () => preview({ data: { booking_no: bookingNo } }),
  });

  const [departmentId, setDepartmentId] = useState<string>("");
  const [currency, setCurrency] = useState<"USD" | "EUR">("USD");
  const [overrides, setOverrides] = useState<
    Record<string, { purchase?: string; sale?: string }>
  >({});
  const [excluded, setExcluded] = useState<Set<string>>(new Set());
  const [extraLines, setExtraLines] = useState<
    Array<{
      key: string;
      article_id: string;
      container_type: string;
      amount_per_unit: string;
      currency: "USD" | "EUR";
    }>
  >([]);
  const [chargeSel, setChargeSel] = useState<
    Record<string, { included: boolean; article_id: string | null }>
  >({});

  useEffect(() => {
    if (departmentId) return;
    const suggested = (prevQ.data as any)?.suggested_department_id;
    if (suggested) { setDepartmentId(suggested); return; }
    const d = (prevQ.data as any)?.departments?.[0];
    if (d) setDepartmentId(d.id);
  }, [prevQ.data, departmentId]);

  // Initialize charge selection defaults when data arrives
  useEffect(() => {
    const charges = ((prevQ.data as any)?.booking_charges ?? []) as any[];
    if (charges.length === 0) return;
    setChargeSel((prev) => {
      if (Object.keys(prev).length > 0) return prev;
      const next: typeof prev = {};
      for (const c of charges) {
        const key = `${c.source_code}::${c.currency}`;
        next[key] = {
          included: !!c.mapped_article_id,
          article_id: c.mapped_article_id ?? null,
        };
      }
      return next;
    });
  }, [prevQ.data]);

  const data = prevQ.data as any;
  const allUnits = (data?.units ?? []) as any[];
  const availableArticles = (data?.available_articles ?? []) as any[];

  // Derived: per-type recompute (min purchase>0 / max sale) considering excluded
  const recomputedTypes = useMemo(() => {
    const map = new Map<
      string,
      { qty: number; min_ppb: number | null; max_sale: number | null }
    >();
    for (const u of allUnits) {
      if (u.already_linked_file_id) continue;
      if (excluded.has(u.unit_no)) continue;
      const t = u.iso_code ?? "UNK";
      if (!map.has(t)) map.set(t, { qty: 0, min_ppb: null, max_sale: null });
      const a = map.get(t)!;
      a.qty++;
      const p = u.amt_ppb == null ? null : Number(u.amt_ppb);
      if (p != null && p > 0) a.min_ppb = a.min_ppb == null ? p : Math.min(a.min_ppb, p);
      const s = u.sale_amt_b == null ? null : Number(u.sale_amt_b);
      if (s != null) a.max_sale = a.max_sale == null ? s : Math.max(a.max_sale, s);
    }
    return Array.from(map.entries()).map(([container_type, a]) => ({
      container_type,
      qty: a.qty,
      default_purchase: a.min_ppb,
      default_sale: a.max_sale,
    }));
  }, [allUnits, excluded]);

  const includedCount = useMemo(
    () => allUnits.filter((u) => !u.already_linked_file_id && !excluded.has(u.unit_no)).length,
    [allUnits, excluded],
  );

  const toggleUnit = (unit_no: string) => {
    setExcluded((s) => {
      const next = new Set(s);
      if (next.has(unit_no)) next.delete(unit_no);
      else next.add(unit_no);
      return next;
    });
  };

  const createMut = useMutation({
    mutationFn: () => {
      const type_overrides = recomputedTypes.map((t: any) => {
        const ov = overrides[t.container_type] ?? {};
        const purchase = ov.purchase != null && ov.purchase !== "" ? Number(ov.purchase) : t.default_purchase;
        const sale = ov.sale != null && ov.sale !== "" ? Number(ov.sale) : t.default_sale;
        return {
          container_type: t.container_type,
          purchase_per_unit: purchase,
          sale_per_unit: sale,
        };
      });
      const extra_plan_lines = extraLines
        .filter((l) => l.article_id && l.amount_per_unit !== "" && Number.isFinite(Number(l.amount_per_unit)))
        .map((l) => ({
          article_id: l.article_id,
          container_type: l.container_type === "__all__" ? null : l.container_type || null,
          amount_per_unit: Number(l.amount_per_unit),
          currency: l.currency,
        }));
      const booking_charges = (((data?.booking_charges ?? []) as any[])
        .map((c: any) => {
          const key = `${c.source_code}::${c.currency}`;
          const sel = chargeSel[key];
          if (!sel?.included || !sel.article_id) return null;
          return {
            source_code: c.source_code,
            currency: c.currency,
            article_id: sel.article_id,
            kind: c.kind as "revenue" | "cost",
          };
        })
        .filter(Boolean)) as Array<{
        source_code: string;
        currency: string;
        article_id: string;
        kind: "revenue" | "cost";
      }>;
      return create({
        data: {
          booking_no: bookingNo,
          department_id: departmentId,
          currency,
          type_overrides,
          excluded_units: Array.from(excluded),
          extra_plan_lines,
          booking_charges,
        },
      });
    },
    onSuccess: (r: any) => {
      toast.success("File created");
      onCreated(r.id);
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed"),
  });

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>Create file from booking {bookingNo}</DialogTitle>
        </DialogHeader>
        {prevQ.isLoading && (
          <div className="p-4 text-sm text-muted-foreground">Loading…</div>
        )}
        {prevQ.error && (
          <div className="p-4 text-sm text-destructive">
            {(prevQ.error as any)?.message ?? "Failed to load"}
          </div>
        )}
        {data && (
          <div className="space-y-4 text-sm">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="text-xs text-muted-foreground">Customer</div>
                <div>
                  {data.customer_name ?? "—"}{" "}
                  <span className="font-mono text-muted-foreground">
                    {data.customer_accno ?? ""}
                  </span>
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Internal ref</div>
                <div className="font-mono">{data.internal_ref ?? "—"}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Departure (min onhire)</div>
                <div>{data.planned_departure_date ?? "—"}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">From → To</div>
                <div>
                  {data.origin_locn_name ?? data.origin_locn ?? "—"} →{" "}
                  {data.dest_locn_name ?? data.dest_locn ?? "—"}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="text-xs text-muted-foreground mb-1">Department</div>
                <Select value={departmentId} onValueChange={setDepartmentId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pick department" />
                  </SelectTrigger>
                  <SelectContent>
                    {(data.departments ?? []).map((d: any) => (
                      <SelectItem key={d.id} value={d.id}>
                        {d.code} — {d.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1">Plan currency</div>
                <Select value={currency} onValueChange={(v) => setCurrency(v as any)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <div className="font-medium mb-2">Container types & prices</div>
              <div className="text-xs text-muted-foreground mb-2">
                Defaults: purchase = <span className="font-mono">min(amt_ppb &gt; 0)</span>, sale ={" "}
                <span className="font-mono">max(sale_amt_b)</span>. Fill missing values below.
              </div>
              <table className="w-full text-xs border border-border rounded">
                <thead className="bg-muted/40">
                  <tr>
                    <th className="text-left p-2">Type</th>
                    <th className="text-right p-2">Qty</th>
                    <th className="text-right p-2">Purchase / unit</th>
                    <th className="text-right p-2">Sale / unit</th>
                  </tr>
                </thead>
                <tbody>
                  {recomputedTypes.map((t) => {
                    const ov = overrides[t.container_type] ?? {};
                    const purchasePh = t.default_purchase != null ? t.default_purchase.toFixed(2) : "required";
                    const salePh = t.default_sale != null ? t.default_sale.toFixed(2) : "required";
                    return (
                      <tr key={t.container_type} className="border-t border-border">
                        <td className="p-2 font-mono">{t.container_type}</td>
                        <td className="p-2 text-right font-mono">{t.qty}</td>
                        <td className="p-2">
                          <Input
                            type="number"
                            placeholder={purchasePh}
                            value={ov.purchase ?? ""}
                            onChange={(e) =>
                              setOverrides((s) => ({
                                ...s,
                                [t.container_type]: { ...s[t.container_type], purchase: e.target.value },
                              }))
                            }
                            className={`h-8 text-right ${t.default_purchase == null ? "border-amber-500" : ""}`}
                          />
                        </td>
                        <td className="p-2">
                          <Input
                            type="number"
                            placeholder={salePh}
                            value={ov.sale ?? ""}
                            onChange={(e) =>
                              setOverrides((s) => ({
                                ...s,
                                [t.container_type]: { ...s[t.container_type], sale: e.target.value },
                              }))
                            }
                            className={`h-8 text-right ${t.default_sale == null ? "border-amber-500" : ""}`}
                          />
                        </td>
                      </tr>
                    );
                  })}
                  {recomputedTypes.length === 0 && (
                    <tr>
                      <td colSpan={4} className="p-3 text-center text-muted-foreground">
                        No units selected.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div>
              <div className="font-medium mb-2">
                Units ({includedCount} selected of {allUnits.length})
              </div>
              <div className="max-h-48 overflow-auto border border-border rounded">
                <table className="w-full text-xs">
                  <thead className="bg-muted/40 sticky top-0">
                    <tr>
                      <th className="p-2 w-8"></th>
                      <th className="text-left p-2">Unit</th>
                      <th className="text-left p-2">Type</th>
                      <th className="text-left p-2">OnHire</th>
                      <th className="text-left p-2">Status</th>
                      <th className="text-right p-2">PpB</th>
                      <th className="text-right p-2">SaleAmtB</th>
                      <th className="text-left p-2">Linked file</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allUnits.map((u: any) => {
                      const isLinked = !!u.already_linked_file_id;
                      const included = !isLinked && !excluded.has(u.unit_no);
                      return (
                        <tr
                          key={u.unit_no}
                          className={`border-t border-border ${isLinked ? "opacity-50" : ""}`}
                        >
                          <td className="p-2 text-center">
                            <input
                              type="checkbox"
                              disabled={isLinked}
                              checked={included}
                              onChange={() => !isLinked && toggleUnit(u.unit_no)}
                            />
                          </td>
                          <td className="p-2 font-mono">{u.unit_no}</td>
                          <td className="p-2 font-mono">{u.iso_code ?? "—"}</td>
                          <td className="p-2 font-mono">{u.onhire_date ?? "—"}</td>
                          <td className="p-2">{u.status ?? "—"}</td>
                          <td className="p-2 text-right font-mono">
                            {u.amt_ppb != null ? Number(u.amt_ppb).toFixed(2) : "—"}
                          </td>
                          <td className="p-2 text-right font-mono">
                            {u.sale_amt_b != null ? Number(u.sale_amt_b).toFixed(2) : "—"}
                          </td>
                          <td className="p-2 font-mono">
                            {u.already_linked_file_number ? (
                              <Badge variant="secondary">{u.already_linked_file_number}</Badge>
                            ) : (
                              "—"
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {((data.booking_charges ?? []) as any[]).length > 0 && (
              <div>
                <div className="font-medium mb-2">Charges &amp; costs from booking</div>
                <div className="text-xs text-muted-foreground mb-2">
                  Pulled from the booking data. Mapped items are included by default and added as
                  both plan and fact lines. Unmapped items need an article to be picked manually.
                </div>
                <table className="w-full text-xs border border-border rounded">
                  <thead className="bg-muted/40">
                    <tr>
                      <th className="p-2 w-8"></th>
                      <th className="text-left p-2">Code</th>
                      <th className="text-left p-2">Name</th>
                      <th className="text-left p-2">Kind</th>
                      <th className="text-right p-2">Qty</th>
                      <th className="text-right p-2">Sum</th>
                      <th className="text-left p-2">Currency</th>
                      <th className="text-left p-2">Article</th>
                    </tr>
                  </thead>
                  <tbody>
                    {((data.booking_charges ?? []) as any[]).map((c) => {
                      const key = `${c.source_code}::${c.currency}`;
                      const sel = chargeSel[key] ?? {
                        included: !!c.mapped_article_id,
                        article_id: c.mapped_article_id ?? null,
                      };
                      return (
                        <tr key={key} className="border-t border-border">
                          <td className="p-2 text-center">
                            <input
                              type="checkbox"
                              checked={sel.included && !!sel.article_id}
                              disabled={!sel.article_id}
                              onChange={(e) =>
                                setChargeSel((s) => ({
                                  ...s,
                                  [key]: { ...sel, included: e.target.checked },
                                }))
                              }
                            />
                          </td>
                          <td className="p-2 font-mono">{c.source_code}</td>
                          <td className="p-2">{c.name ?? "—"}</td>
                          <td className="p-2">
                            <Badge variant={c.kind === "cost" ? "destructive" : "default"}>
                              {c.kind}
                            </Badge>
                          </td>
                          <td className="p-2 text-right font-mono">{c.qty}</td>
                          <td className="p-2 text-right font-mono">{Number(c.sum_amount).toFixed(2)}</td>
                          <td className="p-2 font-mono">{c.currency}</td>
                          <td className="p-2">
                            <Select
                              value={sel.article_id ?? ""}
                              onValueChange={(v) =>
                                setChargeSel((s) => ({
                                  ...s,
                                  [key]: { included: true, article_id: v },
                                }))
                              }
                            >
                              <SelectTrigger className="h-8">
                                <SelectValue placeholder="Pick article…" />
                              </SelectTrigger>
                              <SelectContent>
                                {availableArticles
                                  .filter((a: any) =>
                                    c.kind === "cost" ? a.kind === "COST" : a.kind === "REVENUE",
                                  )
                                  .map((a: any) => (
                                    <SelectItem key={a.id} value={a.id}>
                                      {a.code} — {a.name}
                                    </SelectItem>
                                  ))}
                              </SelectContent>
                            </Select>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            <div>
              <div className="font-medium mb-2 flex items-center justify-between">
                <span>Extra plan articles</span>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() =>
                    setExtraLines((s) => [
                      ...s,
                      {
                        key: `el-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                        article_id: "",
                        container_type: "__all__",
                        amount_per_unit: "",
                        currency,
                      },
                    ])
                  }
                >
                  <Plus className="h-3 w-3 mr-1" /> Add article
                </Button>
              </div>
              {extraLines.length > 0 && (
                <table className="w-full text-xs border border-border rounded">
                  <thead className="bg-muted/40">
                    <tr>
                      <th className="text-left p-2">Article</th>
                      <th className="text-left p-2">Container type</th>
                      <th className="text-right p-2">Amount / unit</th>
                      <th className="text-left p-2">Currency</th>
                      <th className="w-8 p-2"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {extraLines.map((l, idx) => (
                      <tr key={l.key} className="border-t border-border">
                        <td className="p-2">
                          <Select
                            value={l.article_id}
                            onValueChange={(v) =>
                              setExtraLines((s) =>
                                s.map((x, i) => (i === idx ? { ...x, article_id: v } : x)),
                              )
                            }
                          >
                            <SelectTrigger className="h-8">
                              <SelectValue placeholder="Pick article…" />
                            </SelectTrigger>
                            <SelectContent>
                              {availableArticles.map((a: any) => (
                                <SelectItem key={a.id} value={a.id}>
                                  {a.code} — {a.name} ({a.kind})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="p-2">
                          <Select
                            value={l.container_type}
                            onValueChange={(v) =>
                              setExtraLines((s) =>
                                s.map((x, i) => (i === idx ? { ...x, container_type: v } : x)),
                              )
                            }
                          >
                            <SelectTrigger className="h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="__all__">All types</SelectItem>
                              {recomputedTypes.map((t) => (
                                <SelectItem key={t.container_type} value={t.container_type}>
                                  {t.container_type}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="p-2">
                          <Input
                            type="number"
                            value={l.amount_per_unit}
                            onChange={(e) =>
                              setExtraLines((s) =>
                                s.map((x, i) =>
                                  i === idx ? { ...x, amount_per_unit: e.target.value } : x,
                                ),
                              )
                            }
                            className="h-8 text-right"
                            placeholder="e.g. -50 for cost"
                          />
                        </td>
                        <td className="p-2">
                          <Select
                            value={l.currency}
                            onValueChange={(v) =>
                              setExtraLines((s) =>
                                s.map((x, i) =>
                                  i === idx ? { ...x, currency: v as "USD" | "EUR" } : x,
                                ),
                              )
                            }
                          >
                            <SelectTrigger className="h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="USD">USD</SelectItem>
                              <SelectItem value="EUR">EUR</SelectItem>
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="p-2 text-center">
                          <button
                            type="button"
                            className="text-muted-foreground hover:text-destructive"
                            onClick={() =>
                              setExtraLines((s) => s.filter((_, i) => i !== idx))
                            }
                          >
                            ×
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button
                onClick={() => createMut.mutate()}
                disabled={!departmentId || createMut.isPending || includedCount === 0}
              >
                {createMut.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
                Create file
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

