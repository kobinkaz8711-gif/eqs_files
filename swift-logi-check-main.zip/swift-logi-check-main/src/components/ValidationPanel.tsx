import { AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ValidationResult } from "@/lib/types";

interface Props {
  v: ValidationResult;
}

export function ValidationPanel({ v }: Props) {
  const pct = v.completionPct;
  const barColor =
    v.criticalMissing.length > 0
      ? "bg-destructive"
      : v.missing.length > 0
        ? "bg-warning"
        : "bg-success";

  return (
    <div className="space-y-4">
      <div>
        <div className="flex items-baseline justify-between mb-1.5">
          <p className="text-3xl font-semibold tabular-nums tracking-tight">
            {pct}
            <span className="text-base text-muted-foreground font-medium">%</span>
          </p>
          <p className="text-xs text-muted-foreground tabular-nums">
            {v.checked} / {v.total} пунктов
          </p>
        </div>
        <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
          <div
            className={cn("h-full transition-all duration-300", barColor)}
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>

      {v.criticalMissing.length > 0 && (
        <div className="flex items-start gap-2 p-2.5 rounded bg-destructive/[0.06] border border-destructive/20">
          <AlertCircle className="size-3.5 text-destructive shrink-0 mt-0.5" />
          <p className="text-xs text-destructive leading-snug">
            <span className="font-semibold">{v.criticalMissing.length}</span>{" "}
            {v.criticalMissing.length === 1 ? "критический пункт" : "критических пунктов"} не
            заполнено. Письмо не будет отправлено.
          </p>
        </div>
      )}

      {v.missing.length === 0 && v.total > 0 ? (
        <p className="text-xs text-muted-foreground">
          Все пункты отмечены — заявка готова к передаче менеджеру.
        </p>
      ) : (
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              Пропуски
            </p>
            <p className="text-[11px] text-muted-foreground tabular-nums">
              {v.criticalMissing.length} крит. · {v.missing.length - v.criticalMissing.length} опц.
            </p>
          </div>
          <ul className="divide-y divide-border border-y border-border">
            {v.missing.slice(0, 8).map((i) => (
              <li key={i.id} className="flex items-start gap-2 py-1.5 text-xs">
                <span
                  className={cn(
                    "size-1.5 rounded-full shrink-0 mt-1.5",
                    i.critical ? "bg-destructive" : "bg-warning",
                  )}
                />
                <div className="min-w-0 flex-1">
                  <div className={cn("truncate", i.critical ? "text-foreground" : "text-muted-foreground")}>
                    {i.label}
                  </div>
                  {i.parent_label && (
                    <div className="text-[10px] text-muted-foreground truncate">
                      требуется из-за: «{i.parent_label}»
                    </div>
                  )}
                </div>
                {i.critical && (
                  <span className="ml-auto text-[10px] font-semibold uppercase tracking-wider text-destructive mt-0.5">
                    крит.
                  </span>
                )}
              </li>
            ))}
            {v.missing.length > 8 && (
              <li className="py-1.5 text-[11px] text-muted-foreground">
                + ещё {v.missing.length - 8}
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
}
