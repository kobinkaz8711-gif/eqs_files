import { lazy, Suspense } from "react";
import { ClientOnly } from "@tanstack/react-router";

const PdfPreviewClient = lazy(() =>
  import("./PdfPreviewClient").then((m) => ({ default: m.PdfPreview })),
);

interface Props {
  file: File;
  onClose: () => void;
}

export function PdfPreview(props: Props) {
  return (
    <ClientOnly
      fallback={
        <div className="h-full grid place-items-center text-xs text-muted-foreground">
          Загрузка просмотрщика…
        </div>
      }
    >
      <Suspense
        fallback={
          <div className="h-full grid place-items-center text-xs text-muted-foreground">
            Загрузка просмотрщика…
          </div>
        }
      >
        <PdfPreviewClient {...props} />
      </Suspense>
    </ClientOnly>
  );
}
