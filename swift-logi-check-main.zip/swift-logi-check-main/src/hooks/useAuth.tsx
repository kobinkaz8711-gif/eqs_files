import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { useQueryClient } from "@tanstack/react-query";
import { useRouter } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export interface MeContext {
  profile: {
    id: string;
    email: string;
    full_name: string | null;
    position: string | null;
    department_id: string | null;
    department: { id: string; name: string } | null;
    is_active: boolean;
  } | null;
  roles: { id: string; name: string }[];
  permissions: string[];
}

interface AuthContextValue {
  loading: boolean;
  session: Session | null;
  user: User | null;
  me: MeContext | null;
  setMe: (m: MeContext | null) => void;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  hasPermission: (code: string) => boolean;
  hasAnyPermission: (codes: string[]) => boolean;
  hasRole: (name: string) => boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [me, setMe] = useState<MeContext | null>(null);
  const router = useRouter();
  const queryClient = useQueryClient();

  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, s) => {
      setSession(s);
      if (!s) setMe(null);
      if (event === "SIGNED_OUT") {
        queryClient.clear();
        router.invalidate();
      } else if (event === "SIGNED_IN" || event === "USER_UPDATED") {
        router.invalidate();
        queryClient.invalidateQueries();
      }
    });

    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [router, queryClient]);

  const value = useMemo<AuthContextValue>(() => {
    const permissions = me?.permissions ?? [];
    const roles = me?.roles ?? [];
    const isAdmin = permissions.includes("admin.full") || roles.some((r) => r.name === "Admin");
    return {
      loading,
      session,
      user: session?.user ?? null,
      me,
      setMe,
      hasPermission: (code) => isAdmin || permissions.includes(code),
      hasAnyPermission: (codes) => isAdmin || codes.some((c) => permissions.includes(c)),
      hasRole: (name) => roles.some((r) => r.name === name),
      isAdmin,
      signIn: async (email, password) => {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        return { error: error?.message ?? null };
      },
      signOut: async () => {
        await supabase.auth.signOut();
        setMe(null);
      },
    };
  }, [loading, session, me]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
