Добавить два новых состояния подсветки плашек типов контейнеров в списке файлов EQS.

## Текущая логика

В `src/routes/_authenticated/eqs-files.index.tsx` функция `badgeClsFor(has_booking, planned_qty, attached_qty)`:
- нет букинга → нейтральный
- attached > planned → красный
- attached === planned → зелёный
- attached < planned → оранжевый

## Изменения

### `src/lib/files.functions.ts`
В `listFiles` уже строится `hasBookingByFile` и `attachedByFile`. Нужно также передать признак «есть привязанные юниты» для случая, когда букинга нет. Добавить поле `attached_qty` корректно учитывает только записи, у которых есть запись в `file_container_types`. Для бордовой подсветки нужно знать: есть ли вообще активные `file_unit_assignments` по этому `file_id` + `unit_type` (+ `grade`), даже если строки в `file_container_types` нет.

Решение: оставить текущее `attached_qty` как есть (по plan-строкам), а признак «юниты без букинга» считать на уровне UI по тем же plan-строкам — если `has_booking=false` и `attached_qty>0`, подсвечивать бордовым. Это покрывает случай: план есть, юниты привязаны, букинг не привязан.

(Случай «юнит привязан к типу, которого нет в плане» — отдельный, в текущем UI такие плашки не рендерятся; в рамках этой задачи не трогаем.)

### `src/routes/_authenticated/eqs-files.index.tsx`
Расширить `badgeClsFor(has_booking, planned_qty, attached_qty)`:

```text
has_booking = true:
  attached === 0          → синий   (border-sky-500 text-sky-700 bg-sky-50)
  attached < planned      → оранжевый (как сейчас)
  attached === planned    → зелёный  (как сейчас)
  attached > planned      → красный  (как сейчас)

has_booking = false:
  attached > 0            → бордовый (border-rose-700 text-rose-800 bg-rose-100)
  иначе                   → нейтральный (как сейчас)
```

Применить и в инлайн-плашках, и в строках tooltip «misc» (как сейчас).

## Технические детали

- Файлы: `src/routes/_authenticated/eqs-files.index.tsx` (только функция `badgeClsFor`). Серверная часть не меняется — `has_booking` и `attached_qty` уже передаются.
- Tailwind-классы для новых цветов:
  - синий: `border-sky-500 text-sky-700 bg-sky-50`
  - бордовый: `border-rose-700 text-rose-800 bg-rose-100`
- Проверка: `bunx tsgo --noEmit`.
