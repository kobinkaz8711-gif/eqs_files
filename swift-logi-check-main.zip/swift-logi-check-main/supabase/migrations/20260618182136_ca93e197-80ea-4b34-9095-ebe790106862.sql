
-- ============================================================
-- EQS Files Step 1: schema, seeds, RLS, RPC
-- ============================================================

-- 0. Departments: ensure 'code' column + seed 16 codes
ALTER TABLE public.departments ADD COLUMN IF NOT EXISTS code text;
CREATE UNIQUE INDEX IF NOT EXISTS departments_code_uidx ON public.departments(code) WHERE code IS NOT NULL;

INSERT INTO public.departments (name, code, is_active, sort_order)
SELECT v.code, v.code, true, v.so
FROM (VALUES
  ('SIN',1),('ALA',2),('SHA',3),('SPB',4),('EKA',5),('TAS',6),('IST',7),('ANR',8),
  ('MIA',9),('AST',10),('MOW',11),('BAK',12),('NOVO',13),('REP',14),('BKK',15),('NZK',16)
) v(code, so)
WHERE NOT EXISTS (SELECT 1 FROM public.departments d WHERE d.code = v.code);

-- 1. ENUMs
CREATE TYPE public.file_status AS ENUM ('DR','OP','RP','RCL','CL','CN');
CREATE TYPE public.file_direction AS ENUM ('EXPORT','IMPORT','TRIANGLE');
CREATE TYPE public.budget_article_kind AS ENUM ('COST','REVENUE');

-- 2. Helper: generic update_updated_at_column already exists in public

-- ============================================================
-- 3. Budget articles + mapping
-- ============================================================
CREATE TABLE public.budget_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  kind public.budget_article_kind NOT NULL,
  is_fallback boolean NOT NULL DEFAULT false,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_articles TO authenticated;
GRANT ALL ON public.budget_articles TO service_role;
ALTER TABLE public.budget_articles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth full" ON public.budget_articles FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER trg_budget_articles_updated BEFORE UPDATE ON public.budget_articles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.budget_articles (code, name, kind, is_fallback, sort_order) VALUES
  ('admin_fee_main','Admin fee','COST',false,10),
  ('trucking','Trucking','COST',false,20),
  ('export_clearance','Export clearance','COST',false,30),
  ('extra_main','Extra','COST',false,40),
  ('pp','Purchase Price','COST',false,50),
  ('depot','Depot','COST',false,60),
  ('repair','Repair','COST',false,70),
  ('puf','Pick-Up Fee (PUF/PUCR)','REVENUE',false,80),
  ('per_diem','Per Diem','REVENUE',false,90),
  ('selling_price','Selling price','REVENUE',false,100),
  ('unmapped_cost','Unmapped costs','COST',true,900),
  ('unmapped_revenue','Unmapped earnings','REVENUE',true,910);

CREATE TABLE public.cost_charge_type_mapping (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_type text NOT NULL CHECK (source_type IN ('CostType','ChargeType')),
  source_code text NOT NULL,
  article_id uuid NOT NULL REFERENCES public.budget_articles(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (source_type, source_code)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cost_charge_type_mapping TO authenticated;
GRANT ALL ON public.cost_charge_type_mapping TO service_role;
ALTER TABLE public.cost_charge_type_mapping ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth full" ON public.cost_charge_type_mapping FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER trg_ccm_updated BEFORE UPDATE ON public.cost_charge_type_mapping FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed mapping for both CostType and ChargeType variants of the same code
WITH codes(article_code, src_code) AS (VALUES
  ('pp','PURC'),('pp','RCTP'),
  ('depot','RENT'),('depot','REN2'),('depot','SUBL'),('depot','MBIL'),('depot','CLRE'),('depot','RCLR'),
  ('depot','HIN'),('depot','HOUT'),('depot','CFUL'),('depot','CHDL'),('depot','HREP'),('depot','STOR'),('depot','CSTO'),
  ('puf','PCKP'),('puf','PUCR'),('puf','PCK2'),('puf','PUC2'),
  ('trucking','TRAN'),('trucking','CTRP'),('trucking','CRAI'),
  ('repair','REPR'),('repair','CRPR'),
  ('per_diem','CDIE'),('per_diem','CDI2'),
  ('selling_price','CTSA'),('selling_price','RCTS'),
  ('admin_fee_main','EQCB')
)
INSERT INTO public.cost_charge_type_mapping (source_type, source_code, article_id)
SELECT st, c.src_code, ba.id
FROM codes c
JOIN public.budget_articles ba ON ba.code = c.article_code
CROSS JOIN (VALUES ('CostType'),('ChargeType')) t(st)
ON CONFLICT (source_type, source_code) DO NOTHING;

-- ============================================================
-- 4. Reporting period control
-- ============================================================
CREATE TABLE public.reporting_period_control (
  id boolean PRIMARY KEY DEFAULT true CHECK (id = true),
  current_closed_date date,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reporting_period_control TO authenticated;
GRANT ALL ON public.reporting_period_control TO service_role;
ALTER TABLE public.reporting_period_control ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth full" ON public.reporting_period_control FOR ALL TO authenticated USING (true) WITH CHECK (true);
INSERT INTO public.reporting_period_control (id, current_closed_date) VALUES (true, NULL);

-- ============================================================
-- 5. EQS Intermediate Layer (eqs_ext_*)
-- ============================================================
CREATE TABLE public.eqs_ext_cost_charge_types (
  source_type text NOT NULL CHECK (source_type IN ('CostType','ChargeType')),
  source_code text NOT NULL,
  source_name text,
  is_active boolean NOT NULL DEFAULT true,
  created_at_source timestamptz,
  updated_at_source timestamptz,
  source_system text,
  source_table text,
  source_key text,
  extracted_at timestamptz,
  received_at timestamptz,
  refresh_run_id text,
  PRIMARY KEY (source_type, source_code)
);
CREATE TABLE public.eqs_ext_locations_subregions (
  locn_id text PRIMARY KEY,
  locn_desc text,
  subregion_id text,
  subregion_desc text,
  country_code text,
  country_name text,
  is_active boolean NOT NULL DEFAULT true,
  created_at_source timestamptz,
  updated_at_source timestamptz,
  source_system text, source_table text, source_key text,
  extracted_at timestamptz, received_at timestamptz, refresh_run_id text
);
CREATE INDEX eqs_ext_locations_subregion_idx ON public.eqs_ext_locations_subregions(subregion_id);
CREATE INDEX eqs_ext_locations_country_idx ON public.eqs_ext_locations_subregions(country_code);

CREATE TABLE public.eqs_ext_container_buyers_5y (
  accno text PRIMARY KEY,
  customer_name text,
  first_sale_date timestamptz,
  last_sale_date timestamptz,
  sale_count int,
  last_sale_invoice_no text,
  country_code text,
  country_name text,
  source_system text, source_table text, source_key text,
  extracted_at timestamptz, received_at timestamptz, refresh_run_id text
);
CREATE INDEX eqs_ext_buyers_name_idx ON public.eqs_ext_container_buyers_5y(customer_name);

CREATE TABLE public.eqs_ext_units (
  unit_no text PRIMARY KEY,
  iso_code text, owner_code text, year_built int,
  source_system text, source_table text, source_key text,
  extracted_at timestamptz, received_at timestamptz, refresh_run_id text
);
CREATE TABLE public.eqs_ext_unit_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_no text NOT NULL,
  event_date timestamptz, event_type text, event_code text,
  locn_id text, accno text, booking_no text,
  source_system text, source_table text, source_key text,
  extracted_at timestamptz, received_at timestamptz, refresh_run_id text
);
CREATE INDEX ON public.eqs_ext_unit_history(unit_no, event_date);

CREATE TABLE public.eqs_ext_bookings (
  booking_no text PRIMARY KEY,
  accno text, locn_pol text, locn_pod text, vessel text, voyage text,
  source_system text, source_table text, source_key text,
  extracted_at timestamptz, received_at timestamptz, refresh_run_id text
);
CREATE TABLE public.eqs_ext_finance_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_no text, accno text, booking_no text,
  source_type text, source_code text,
  amount numeric(18,2), currency text,
  invoice_no text, invoice_date timestamptz, dte_acct date,
  source_system text, source_table text, source_key text,
  extracted_at timestamptz, received_at timestamptz, refresh_run_id text
);
CREATE INDEX ON public.eqs_ext_finance_lines(unit_no);
CREATE INDEX ON public.eqs_ext_finance_lines(accno);

CREATE TABLE public.eqs_ext_rt_charges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_no text, accno text, charge_code text,
  amount numeric(18,2), currency text, charge_date timestamptz,
  source_system text, source_table text, source_key text,
  extracted_at timestamptz, received_at timestamptz, refresh_run_id text
);
CREATE TABLE public.eqs_ext_refresh_runs (
  refresh_run_id text PRIMARY KEY,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  status text,
  rows_loaded int,
  notes text
);
CREATE TABLE public.eqs_ext_unit_refresh_status (
  unit_no text PRIMARY KEY,
  last_refresh_at timestamptz,
  last_refresh_run_id text,
  is_stale boolean NOT NULL DEFAULT true
);

-- Grants + RLS for eqs_ext_*
DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'eqs_ext_cost_charge_types','eqs_ext_locations_subregions','eqs_ext_container_buyers_5y',
    'eqs_ext_units','eqs_ext_unit_history','eqs_ext_bookings','eqs_ext_finance_lines',
    'eqs_ext_rt_charges','eqs_ext_refresh_runs','eqs_ext_unit_refresh_status'
  ]) LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON public.%I TO authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY "auth full" ON public.%I FOR ALL TO authenticated USING (true) WITH CHECK (true)', t);
  END LOOP;
END $$;

-- ============================================================
-- 6. Files core
-- ============================================================
CREATE TABLE public.files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_number text UNIQUE,
  status public.file_status NOT NULL DEFAULT 'DR',
  direction public.file_direction NOT NULL,
  department_id uuid NOT NULL REFERENCES public.departments(id),
  customer_accno text,
  customer_name text,
  origin_subregion text,
  dest_subregion text,
  origin_locn text,
  dest_locn text,
  planned_departure_date date,
  planned_arrival_date date,
  notes text,
  created_by uuid,
  opened_at timestamptz,
  closed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.files TO authenticated;
GRANT ALL ON public.files TO service_role;
ALTER TABLE public.files ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth full" ON public.files FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER trg_files_updated BEFORE UPDATE ON public.files FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX files_status_idx ON public.files(status);
CREATE INDEX files_dep_idx ON public.files(department_id);
CREATE INDEX files_customer_idx ON public.files(customer_accno);

-- File number generator: EQ{YY}{DEP}{NNNNNN}
CREATE OR REPLACE FUNCTION public.fn_assign_file_number()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
  v_year text;
  v_dep_code text;
  v_seq int;
  v_lock_key bigint;
BEGIN
  IF NEW.file_number IS NOT NULL THEN RETURN NEW; END IF;
  v_year := to_char(now(), 'YY');
  SELECT code INTO v_dep_code FROM public.departments WHERE id = NEW.department_id;
  IF v_dep_code IS NULL THEN
    RAISE EXCEPTION 'Department % has no code', NEW.department_id;
  END IF;
  v_lock_key := hashtextextended(v_year || v_dep_code, 0);
  PERFORM pg_advisory_xact_lock(v_lock_key);
  SELECT COALESCE(MAX(
    CAST(substring(file_number FROM '[0-9]+$') AS int)
  ), 0) + 1 INTO v_seq
  FROM public.files
  WHERE file_number LIKE 'EQ' || v_year || v_dep_code || '%';
  NEW.file_number := 'EQ' || v_year || v_dep_code || lpad(v_seq::text, 6, '0');
  RETURN NEW;
END $$;
CREATE TRIGGER trg_files_assign_number BEFORE INSERT ON public.files
  FOR EACH ROW EXECUTE FUNCTION public.fn_assign_file_number();

-- ============================================================
-- 7. Files satellite tables
-- ============================================================
CREATE TABLE public.file_status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  from_status public.file_status,
  to_status public.file_status NOT NULL,
  changed_by uuid,
  changed_at timestamptz NOT NULL DEFAULT now(),
  notes text
);
CREATE TABLE public.file_unit_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  unit_no text NOT NULL,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  assigned_by uuid,
  unlinked_at timestamptz,
  is_active boolean NOT NULL DEFAULT true
);
CREATE INDEX ON public.file_unit_assignments(file_id);
CREATE INDEX ON public.file_unit_assignments(unit_no);

CREATE TABLE public.file_unit_assignment_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL,
  unit_no text NOT NULL,
  action text NOT NULL,
  acted_by uuid,
  acted_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.file_budget_plan_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  article_id uuid NOT NULL REFERENCES public.budget_articles(id),
  currency text NOT NULL CHECK (currency IN ('EUR','USD')),
  amount numeric(18,2) NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (file_id, article_id, currency)
);
CREATE TRIGGER trg_fbpl_updated BEFORE UPDATE ON public.file_budget_plan_lines FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.file_budget_fact_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  article_id uuid NOT NULL REFERENCES public.budget_articles(id),
  currency text NOT NULL CHECK (currency IN ('EUR','USD')),
  amount numeric(18,2) NOT NULL DEFAULT 0,
  source_finance_line_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON public.file_budget_fact_lines(file_id);

CREATE TABLE public.file_finance_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  unit_no text,
  source_finance_id uuid,
  source_type text, source_code text,
  article_id uuid REFERENCES public.budget_articles(id),
  amount numeric(18,2),
  currency text,
  invoice_no text,
  invoice_date timestamptz,
  dte_acct date,
  is_unmapped boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON public.file_finance_lines(file_id);

CREATE TABLE public.file_rt_charges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  unit_no text,
  charge_code text,
  amount numeric(18,2), currency text,
  charge_date timestamptz,
  source_rt_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.file_rt_billing_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  rule_code text NOT NULL,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.file_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  reason text NOT NULL,
  status_at_snapshot public.file_status,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.file_snapshot_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  snapshot_id uuid NOT NULL REFERENCES public.file_snapshots(id) ON DELETE CASCADE,
  bucket text NOT NULL,
  payload jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Immutability: forbid update/delete on snapshot tables
CREATE OR REPLACE FUNCTION public.fn_snapshot_immutable()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'file_snapshots are immutable';
END $$;
CREATE TRIGGER trg_fs_immut_u BEFORE UPDATE ON public.file_snapshots FOR EACH ROW EXECUTE FUNCTION public.fn_snapshot_immutable();
CREATE TRIGGER trg_fs_immut_d BEFORE DELETE ON public.file_snapshots FOR EACH ROW EXECUTE FUNCTION public.fn_snapshot_immutable();
CREATE TRIGGER trg_fsl_immut_u BEFORE UPDATE ON public.file_snapshot_lines FOR EACH ROW EXECUTE FUNCTION public.fn_snapshot_immutable();
CREATE TRIGGER trg_fsl_immut_d BEFORE DELETE ON public.file_snapshot_lines FOR EACH ROW EXECUTE FUNCTION public.fn_snapshot_immutable();

CREATE TABLE public.file_warnings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  severity text NOT NULL DEFAULT 'warning',
  code text NOT NULL,
  message text,
  is_resolved boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.file_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid REFERENCES public.files(id) ON DELETE CASCADE,
  actor_id uuid,
  action text NOT NULL,
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Grants + RLS for satellite tables
DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'file_status_history','file_unit_assignments','file_unit_assignment_history',
    'file_budget_plan_lines','file_budget_fact_lines','file_finance_lines',
    'file_rt_charges','file_rt_billing_rules','file_snapshots','file_snapshot_lines',
    'file_warnings','file_audit_log'
  ]) LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON public.%I TO authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY "auth full" ON public.%I FOR ALL TO authenticated USING (true) WITH CHECK (true)', t);
  END LOOP;
END $$;

-- ============================================================
-- 8. Views
-- ============================================================
CREATE OR REPLACE VIEW public.vw_file_budget_summary AS
SELECT
  f.id AS file_id,
  ba.id AS article_id,
  ba.code AS article_code,
  ba.name AS article_name,
  ba.kind,
  ba.sort_order,
  COALESCE(SUM(CASE WHEN p.currency='EUR' THEN p.amount END), 0) AS plan_eur,
  COALESCE(SUM(CASE WHEN p.currency='USD' THEN p.amount END), 0) AS plan_usd,
  COALESCE(SUM(CASE WHEN ff.currency='EUR' THEN ff.amount END), 0) AS fact_eur,
  COALESCE(SUM(CASE WHEN ff.currency='USD' THEN ff.amount END), 0) AS fact_usd
FROM public.files f
CROSS JOIN public.budget_articles ba
LEFT JOIN public.file_budget_plan_lines p ON p.file_id = f.id AND p.article_id = ba.id
LEFT JOIN public.file_budget_fact_lines ff ON ff.file_id = f.id AND ff.article_id = ba.id
GROUP BY f.id, ba.id, ba.code, ba.name, ba.kind, ba.sort_order;

GRANT SELECT ON public.vw_file_budget_summary TO authenticated;

CREATE OR REPLACE VIEW public.vw_file_finance_current AS
SELECT
  fua.file_id,
  fl.id AS finance_id,
  fl.unit_no,
  fl.source_type, fl.source_code,
  fl.amount, fl.currency,
  fl.invoice_no, fl.invoice_date, fl.dte_acct
FROM public.file_unit_assignments fua
JOIN public.eqs_ext_finance_lines fl ON fl.unit_no = fua.unit_no
WHERE fua.is_active = true;

GRANT SELECT ON public.vw_file_finance_current TO authenticated;

-- ============================================================
-- 9. RPC
-- ============================================================
CREATE OR REPLACE FUNCTION public.fn_create_file(
  p_department_id uuid,
  p_direction public.file_direction,
  p_customer_accno text DEFAULT NULL,
  p_customer_name text DEFAULT NULL,
  p_origin_subregion text DEFAULT NULL,
  p_dest_subregion text DEFAULT NULL,
  p_origin_locn text DEFAULT NULL,
  p_dest_locn text DEFAULT NULL,
  p_planned_departure_date date DEFAULT NULL,
  p_planned_arrival_date date DEFAULT NULL,
  p_notes text DEFAULT NULL
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_id uuid;
BEGIN
  INSERT INTO public.files (
    direction, department_id, customer_accno, customer_name,
    origin_subregion, dest_subregion, origin_locn, dest_locn,
    planned_departure_date, planned_arrival_date, notes, created_by
  ) VALUES (
    p_direction, p_department_id, p_customer_accno, p_customer_name,
    p_origin_subregion, p_dest_subregion, p_origin_locn, p_dest_locn,
    p_planned_departure_date, p_planned_arrival_date, p_notes, auth.uid()
  ) RETURNING id INTO v_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, changed_by)
  VALUES (v_id, NULL, 'DR', auth.uid());
  RETURN v_id;
END $$;
GRANT EXECUTE ON FUNCTION public.fn_create_file(uuid, public.file_direction, text, text, text, text, text, text, date, date, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.fn_open_file(p_file_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_old public.file_status;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old <> 'DR' THEN RAISE EXCEPTION 'File can be opened only from DR (current: %)', v_old; END IF;
  UPDATE public.files SET status='OP', opened_at=now() WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, changed_by)
  VALUES (p_file_id, v_old, 'OP', auth.uid());
END $$;
GRANT EXECUTE ON FUNCTION public.fn_open_file(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.fn_close_file(p_file_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_old public.file_status;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  UPDATE public.files SET status='CL', closed_at=now() WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, changed_by)
  VALUES (p_file_id, v_old, 'CL', auth.uid());
END $$;
GRANT EXECUTE ON FUNCTION public.fn_close_file(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.fn_create_status_snapshot(p_file_id uuid, p_reason text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_id uuid; v_status public.file_status;
BEGIN
  SELECT status INTO v_status FROM public.files WHERE id = p_file_id;
  INSERT INTO public.file_snapshots (file_id, reason, status_at_snapshot, created_by)
  VALUES (p_file_id, p_reason, v_status, auth.uid()) RETURNING id INTO v_id;
  INSERT INTO public.file_snapshot_lines (snapshot_id, bucket, payload)
  SELECT v_id, 'budget_plan',
    jsonb_agg(jsonb_build_object('article_id', article_id, 'currency', currency, 'amount', amount))
  FROM public.file_budget_plan_lines WHERE file_id = p_file_id;
  RETURN v_id;
END $$;
GRANT EXECUTE ON FUNCTION public.fn_create_status_snapshot(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.fn_assign_unit(p_file_id uuid, p_unit_no text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_id uuid;
BEGIN
  INSERT INTO public.file_unit_assignments (file_id, unit_no, assigned_by)
  VALUES (p_file_id, p_unit_no, auth.uid()) RETURNING id INTO v_id;
  INSERT INTO public.file_unit_assignment_history (file_id, unit_no, action, acted_by)
  VALUES (p_file_id, p_unit_no, 'assigned', auth.uid());
  RETURN v_id;
END $$;
GRANT EXECUTE ON FUNCTION public.fn_assign_unit(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.fn_unlink_unit(p_assignment_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_file uuid; v_unit text;
BEGIN
  UPDATE public.file_unit_assignments
    SET is_active=false, unlinked_at=now()
    WHERE id = p_assignment_id
    RETURNING file_id, unit_no INTO v_file, v_unit;
  INSERT INTO public.file_unit_assignment_history (file_id, unit_no, action, acted_by)
  VALUES (v_file, v_unit, 'unlinked', auth.uid());
END $$;
GRANT EXECUTE ON FUNCTION public.fn_unlink_unit(uuid) TO authenticated;
