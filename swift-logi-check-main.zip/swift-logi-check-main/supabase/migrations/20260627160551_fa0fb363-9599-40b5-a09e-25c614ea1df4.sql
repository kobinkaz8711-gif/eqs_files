
-- 1. file_booking_assignments
CREATE TABLE public.file_booking_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  booking_no text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  assigned_by uuid,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  unlinked_by uuid,
  unlinked_at timestamptz,
  source text NOT NULL DEFAULT 'manual',
  notes text
);

CREATE UNIQUE INDEX file_booking_assignments_active_uq
  ON public.file_booking_assignments(file_id, booking_no) WHERE is_active;
CREATE INDEX file_booking_assignments_file_idx ON public.file_booking_assignments(file_id);
CREATE INDEX file_booking_assignments_booking_idx ON public.file_booking_assignments(booking_no);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.file_booking_assignments TO authenticated;
GRANT ALL ON public.file_booking_assignments TO service_role;
ALTER TABLE public.file_booking_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "authenticated full access" ON public.file_booking_assignments FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.file_booking_assignment_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL,
  booking_no text NOT NULL,
  action text NOT NULL,
  acted_by uuid,
  acted_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.file_booking_assignment_history TO authenticated;
GRANT ALL ON public.file_booking_assignment_history TO service_role;
ALTER TABLE public.file_booking_assignment_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "authenticated full access" ON public.file_booking_assignment_history FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- 2. Functions
CREATE OR REPLACE FUNCTION public.fn_assign_booking(p_file_id uuid, p_booking_no text, p_source text DEFAULT 'manual')
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path='public' AS $$
DECLARE v_id uuid;
BEGIN
  SELECT id INTO v_id FROM public.file_booking_assignments
    WHERE file_id = p_file_id AND booking_no = p_booking_no AND is_active = true
    LIMIT 1;
  IF v_id IS NOT NULL THEN RETURN v_id; END IF;
  INSERT INTO public.file_booking_assignments (file_id, booking_no, source, assigned_by)
    VALUES (p_file_id, p_booking_no, COALESCE(p_source,'manual'), auth.uid())
    RETURNING id INTO v_id;
  INSERT INTO public.file_booking_assignment_history (file_id, booking_no, action, acted_by)
    VALUES (p_file_id, p_booking_no, 'assigned', auth.uid());
  RETURN v_id;
END $$;

CREATE OR REPLACE FUNCTION public.fn_unlink_booking(p_assignment_id uuid)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path='public' AS $$
DECLARE v_file uuid; v_bk text; v_units integer := 0;
BEGIN
  UPDATE public.file_booking_assignments
    SET is_active = false, unlinked_at = now(), unlinked_by = auth.uid()
    WHERE id = p_assignment_id AND is_active = true
    RETURNING file_id, booking_no INTO v_file, v_bk;
  IF v_file IS NULL THEN RETURN 0; END IF;
  INSERT INTO public.file_booking_assignment_history (file_id, booking_no, action, acted_by)
    VALUES (v_file, v_bk, 'unlinked', auth.uid());

  WITH upd AS (
    UPDATE public.file_unit_assignments
      SET is_active = false, unlinked_at = now(), effective_date_to = current_date
      WHERE file_id = v_file AND booking_no = v_bk AND is_active = true
      RETURNING unit_no
  )
  INSERT INTO public.file_unit_assignment_history (file_id, unit_no, action, acted_by)
  SELECT v_file, unit_no, 'unlinked', auth.uid() FROM upd;
  GET DIAGNOSTICS v_units = ROW_COUNT;
  RETURN v_units;
END $$;

CREATE OR REPLACE FUNCTION public.fn_sync_booking_units(p_file_id uuid, p_booking_no text)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path='public' AS $$
DECLARE r record; v_added integer := 0;
BEGIN
  FOR r IN
    SELECT DISTINCT unit_no FROM public.eqs_ext_recent_units
    WHERE booking_no = p_booking_no
      AND unit_no IS NOT NULL
      AND NOT EXISTS (
        SELECT 1 FROM public.file_unit_assignments fua
        WHERE fua.file_id = p_file_id AND fua.unit_no = eqs_ext_recent_units.unit_no AND fua.is_active = true
      )
  LOOP
    PERFORM public.fn_assign_unit_with_check(p_file_id, r.unit_no, p_booking_no);
    v_added := v_added + 1;
  END LOOP;
  RETURN v_added;
END $$;

CREATE OR REPLACE FUNCTION public.fn_refresh_file_from_ext(p_file_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='public' AS $$
DECLARE r record; v_added integer := 0; v_step integer; v_fin integer;
BEGIN
  FOR r IN SELECT booking_no FROM public.file_booking_assignments WHERE file_id = p_file_id AND is_active = true LOOP
    v_step := public.fn_sync_booking_units(p_file_id, r.booking_no);
    v_added := v_added + COALESCE(v_step, 0);
  END LOOP;
  v_fin := public.fn_refresh_file_finance_lines(p_file_id);
  RETURN jsonb_build_object('added_units', v_added, 'finance_rows', v_fin);
END $$;

-- 3. Backfill
INSERT INTO public.file_booking_assignments (file_id, booking_no, source, assigned_at, is_active)
SELECT DISTINCT file_id, booking_no, 'auto_from_unit', MIN(assigned_at), true
FROM public.file_unit_assignments
WHERE booking_no IS NOT NULL AND is_active = true
GROUP BY file_id, booking_no
ON CONFLICT DO NOTHING;
