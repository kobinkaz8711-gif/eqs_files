
-- Tighten profiles SELECT
DROP POLICY IF EXISTS profiles_select_auth ON public.profiles;
CREATE POLICY profiles_select_self_or_manager ON public.profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id OR has_permission(auth.uid(), 'users.manage'));

-- Tighten user_roles SELECT
DROP POLICY IF EXISTS user_roles_select_auth ON public.user_roles;
CREATE POLICY user_roles_select_self_or_manager ON public.user_roles
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR has_permission(auth.uid(), 'users.manage'));

-- Tighten email_templates SELECT
DROP POLICY IF EXISTS et_select ON public.email_templates;
CREATE POLICY et_select_managers ON public.email_templates
  FOR SELECT TO authenticated
  USING (has_permission(auth.uid(), 'checklist.manage'));

-- Revoke EXECUTE on definer helpers from anon (keep authenticated; needed by RLS)
REVOKE EXECUTE ON FUNCTION public.has_permission(uuid, text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.is_admin(uuid) FROM anon, public;
