DROP VIEW IF EXISTS public.container_extractor_api_keys_public;

CREATE VIEW public.container_extractor_api_keys_public AS
SELECT
  id,
  RIGHT(key_value, 4) AS last4,
  LENGTH(key_value) AS key_length,
  label,
  created_at
FROM public.container_extractor_api_keys;

ALTER VIEW public.container_extractor_api_keys_public OWNER TO postgres;

REVOKE ALL ON public.container_extractor_api_keys_public FROM PUBLIC, anon;
GRANT SELECT ON public.container_extractor_api_keys_public TO authenticated;
GRANT ALL ON public.container_extractor_api_keys_public TO service_role;