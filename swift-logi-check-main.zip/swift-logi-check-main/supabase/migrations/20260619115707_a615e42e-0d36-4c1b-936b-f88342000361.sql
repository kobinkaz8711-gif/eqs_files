ALTER TABLE public.file_budget_plan_lines
  DROP CONSTRAINT IF EXISTS file_budget_plan_lines_file_id_article_id_currency_key;

ALTER TABLE public.file_budget_plan_lines
  ADD CONSTRAINT file_budget_plan_lines_file_article_ct_currency_key
  UNIQUE (file_id, article_id, container_type, currency);