CREATE OR REPLACE FUNCTION public.fn_create_status_snapshot(p_file_id uuid, p_reason text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_id uuid; v_status public.file_status;
BEGIN
  SELECT status INTO v_status FROM public.files WHERE id = p_file_id;
  INSERT INTO public.file_snapshots (file_id, reason, status_at_snapshot, created_by)
  VALUES (p_file_id, p_reason, v_status, auth.uid()) RETURNING id INTO v_id;
  INSERT INTO public.file_snapshot_lines (snapshot_id, bucket, payload)
  SELECT v_id, 'budget_plan',
    jsonb_agg(jsonb_build_object(
      'article_id', article_id,
      'container_type', container_type,
      'currency', currency,
      'planned_qty', planned_qty,
      'amount_per_unit', amount_per_unit,
      'total_amount', total_amount,
      'amount_usd', amount_usd,
      'amount_eur', amount_eur
    ))
  FROM public.file_budget_plan_lines WHERE file_id = p_file_id;
  RETURN v_id;
END $function$;