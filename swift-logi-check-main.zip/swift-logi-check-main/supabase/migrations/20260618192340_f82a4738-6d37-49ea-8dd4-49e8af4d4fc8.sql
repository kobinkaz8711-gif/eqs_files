
CREATE OR REPLACE FUNCTION public.fn_cancel_file(p_file_id uuid, p_reason text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_old public.file_status;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old IN ('CL','CN') THEN RAISE EXCEPTION 'File already terminal (%)', v_old; END IF;
  UPDATE public.files SET status='CN', closed_at=now() WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, reason, changed_by)
  VALUES (p_file_id, v_old, 'CN', p_reason, auth.uid());
END $$;

CREATE OR REPLACE FUNCTION public.fn_recall_file(p_file_id uuid, p_reason text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_old public.file_status;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old <> 'CL' THEN RAISE EXCEPTION 'Only closed files can be recalled (current: %)', v_old; END IF;
  UPDATE public.files SET status='RCL', closed_at=NULL WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, reason, changed_by)
  VALUES (p_file_id, v_old, 'RCL', p_reason, auth.uid());
END $$;
