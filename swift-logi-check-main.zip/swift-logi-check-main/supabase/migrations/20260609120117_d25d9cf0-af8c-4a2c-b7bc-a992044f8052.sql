REVOKE ALL ON public.container_extractor_api_keys FROM anon;
REVOKE ALL ON public.container_extractor_api_keys FROM authenticated;
GRANT INSERT, UPDATE, DELETE ON public.container_extractor_api_keys TO authenticated;
GRANT SELECT (id, label, created_at, created_by) ON public.container_extractor_api_keys TO authenticated;