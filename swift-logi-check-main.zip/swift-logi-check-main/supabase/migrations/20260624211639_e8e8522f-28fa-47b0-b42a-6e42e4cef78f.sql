
-- 1. eqs_ext_locations_subregions: unique (locn_id, subregion_id)
CREATE UNIQUE INDEX IF NOT EXISTS eqs_ext_locations_subregions_locn_sub_uk
  ON public.eqs_ext_locations_subregions (locn_id, subregion_id);

-- 2. eqs_ext_recent_units: unique (unit_no, booking_no)
CREATE UNIQUE INDEX IF NOT EXISTS eqs_ext_recent_units_unit_booking_uk
  ON public.eqs_ext_recent_units (unit_no, booking_no);

-- 3. eqs_ext_units: add status + sale_amt_b (amt_ppl already exists)
ALTER TABLE public.eqs_ext_units
  ADD COLUMN IF NOT EXISTS status text,
  ADD COLUMN IF NOT EXISTS sale_amt_b numeric;

-- 4. eqs_ext_finance_lines: external source id from EQS + partial unique index
ALTER TABLE public.eqs_ext_finance_lines
  ADD COLUMN IF NOT EXISTS ext_source_id text;

CREATE UNIQUE INDEX IF NOT EXISTS eqs_ext_finance_lines_ext_source_id_uk
  ON public.eqs_ext_finance_lines (ext_source_id)
  WHERE ext_source_id IS NOT NULL;
