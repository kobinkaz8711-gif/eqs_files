
-- Equipment grades reference
CREATE TABLE IF NOT EXISTS public.equipment_grades (
  code TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.equipment_grades TO authenticated;
GRANT ALL ON public.equipment_grades TO service_role;

ALTER TABLE public.equipment_grades ENABLE ROW LEVEL SECURITY;

CREATE POLICY "grades_select_authenticated"
  ON public.equipment_grades FOR SELECT TO authenticated USING (true);
CREATE POLICY "grades_admin_modify"
  ON public.equipment_grades FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'Admin'))
  WITH CHECK (public.has_role(auth.uid(), 'Admin'));

CREATE TRIGGER update_equipment_grades_updated_at
  BEFORE UPDATE ON public.equipment_grades
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.equipment_grades (code, label, sort_order) VALUES
  ('ASIS','ASIS',10),
  ('CIC','CIC',20),
  ('CW','CW',30),
  ('HTCW','HTCW',40),
  ('HTNEW','HTNEW',50),
  ('IICL5','IICL5',60),
  ('NEW','NEW',70),
  ('NEW(B)','NEW(B)',80),
  ('ORIGINAL','ORIGINAL',90),
  ('UCIRC','UCIRC',100)
ON CONFLICT (code) DO NOTHING;

-- Extend file_container_types
ALTER TABLE public.file_container_types
  ADD COLUMN IF NOT EXISTS grade TEXT REFERENCES public.equipment_grades(code) ON UPDATE CASCADE,
  ADD COLUMN IF NOT EXISTS daily_rate NUMERIC,
  ADD COLUMN IF NOT EXISTS repl_value NUMERIC,
  ADD COLUMN IF NOT EXISTS free_min_days INT,
  ADD COLUMN IF NOT EXISTS charge1_code TEXT,
  ADD COLUMN IF NOT EXISTS charge1_amount NUMERIC,
  ADD COLUMN IF NOT EXISTS charge2_code TEXT,
  ADD COLUMN IF NOT EXISTS charge2_amount NUMERIC,
  ADD COLUMN IF NOT EXISTS charge3_code TEXT,
  ADD COLUMN IF NOT EXISTS charge3_amount NUMERIC,
  ADD COLUMN IF NOT EXISTS charge4_code TEXT,
  ADD COLUMN IF NOT EXISTS charge4_amount NUMERIC,
  ADD COLUMN IF NOT EXISTS cost1_code TEXT,
  ADD COLUMN IF NOT EXISTS cost1_currency TEXT,
  ADD COLUMN IF NOT EXISTS cost1_amount NUMERIC,
  ADD COLUMN IF NOT EXISTS cost1_supplier_accno TEXT,
  ADD COLUMN IF NOT EXISTS cost2_code TEXT,
  ADD COLUMN IF NOT EXISTS cost2_currency TEXT,
  ADD COLUMN IF NOT EXISTS cost2_amount NUMERIC,
  ADD COLUMN IF NOT EXISTS cost2_supplier_accno TEXT;

-- Snapshot grade on unit assignment
ALTER TABLE public.file_unit_assignments
  ADD COLUMN IF NOT EXISTS grade TEXT;

-- Update assignment fn to capture grade
CREATE OR REPLACE FUNCTION public.fn_assign_unit_with_check(p_file_id uuid, p_unit_no text, p_booking_no text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_id uuid;
  v_file_origin text;
  v_ru public.eqs_ext_recent_units;
  v_unit_type text;
  v_type_ok boolean;
BEGIN
  SELECT origin_locn INTO v_file_origin FROM public.files WHERE id = p_file_id;

  IF p_booking_no IS NOT NULL THEN
    SELECT * INTO v_ru FROM public.eqs_ext_recent_units
      WHERE unit_no = p_unit_no AND booking_no = p_booking_no LIMIT 1;
  END IF;

  SELECT iso_code INTO v_unit_type FROM public.eqs_ext_units WHERE unit_no = p_unit_no LIMIT 1;

  INSERT INTO public.file_unit_assignments
    (file_id, unit_no, booking_no, onhire_date, locn_pol, locn_pod, unit_type, grade, assigned_by,
     effective_date_from, effective_date_to)
  VALUES
    (p_file_id, p_unit_no, p_booking_no, v_ru.onhire_date, v_ru.locn_pol, v_ru.locn_pod, v_unit_type, v_ru.grade, auth.uid(),
     v_ru.onhire_date, NULL)
  RETURNING id INTO v_id;

  INSERT INTO public.file_unit_assignment_history (file_id, unit_no, action, acted_by)
  VALUES (p_file_id, p_unit_no, 'assigned', auth.uid());

  IF v_ru.locn_pol IS NOT NULL AND v_file_origin IS NOT NULL
     AND v_ru.locn_pol <> v_file_origin THEN
    INSERT INTO public.file_warnings (file_id, severity, code, message)
    VALUES (
      p_file_id, 'warning', 'UNIT_ORIGIN_MISMATCH',
      format('Unit %s booked from %s does not match file origin %s (booking %s)',
             p_unit_no, v_ru.locn_pol, v_file_origin, p_booking_no)
    );
  END IF;

  IF v_unit_type IS NOT NULL THEN
    SELECT EXISTS (
      SELECT 1 FROM public.file_container_types
      WHERE file_id = p_file_id AND container_type = v_unit_type
    ) INTO v_type_ok;
    IF NOT v_type_ok AND EXISTS (SELECT 1 FROM public.file_container_types WHERE file_id = p_file_id) THEN
      INSERT INTO public.file_warnings (file_id, severity, code, message)
      VALUES (
        p_file_id, 'warning', 'UNIT_TYPE_MISMATCH',
        format('Unit %s type %s does not match any container type declared in file', p_unit_no, v_unit_type)
      );
    END IF;
  END IF;

  RETURN v_id;
END $function$;

-- Snapshot fn: include grade in budget_plan jsonb
CREATE OR REPLACE FUNCTION public.fn_create_status_snapshot(p_file_id uuid, p_reason text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_id uuid; v_status public.file_status;
BEGIN
  SELECT status INTO v_status FROM public.files WHERE id = p_file_id;
  INSERT INTO public.file_snapshots (file_id, reason, status_at_snapshot, created_by)
  VALUES (p_file_id, p_reason, v_status, auth.uid()) RETURNING id INTO v_id;
  INSERT INTO public.file_snapshot_lines (snapshot_id, bucket, payload)
  SELECT v_id, 'budget_plan',
    jsonb_agg(jsonb_build_object(
      'article_id', bpl.article_id,
      'container_type', bpl.container_type,
      'grade', ct.grade,
      'currency', bpl.currency,
      'planned_qty', bpl.planned_qty,
      'amount_per_unit', bpl.amount_per_unit,
      'total_amount', bpl.total_amount,
      'amount_usd', bpl.amount_usd,
      'amount_eur', bpl.amount_eur
    ))
  FROM public.file_budget_plan_lines bpl
  LEFT JOIN public.file_container_types ct
    ON ct.file_id = bpl.file_id AND ct.container_type = bpl.container_type
  WHERE bpl.file_id = p_file_id;
  RETURN v_id;
END $function$;
