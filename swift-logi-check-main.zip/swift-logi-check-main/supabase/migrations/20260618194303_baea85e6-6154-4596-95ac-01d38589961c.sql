
-- A. Fix status transitions per spec (DR -> OP -> RP -> RCL -> CL, + CN)

-- Drop wrong fn_recall_file (recall is not in the spec)
DROP FUNCTION IF EXISTS public.fn_recall_file(uuid, text);

-- Rewrite fn_cancel_file to use existing 'notes' column (no 'reason' column exists)
CREATE OR REPLACE FUNCTION public.fn_cancel_file(p_file_id uuid, p_reason text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_old public.file_status;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old IN ('CL','CN') THEN RAISE EXCEPTION 'File already terminal (%)', v_old; END IF;
  UPDATE public.files SET status='CN', closed_at=now() WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, notes, changed_by)
  VALUES (p_file_id, v_old, 'CN', p_reason, auth.uid());
END $$;

-- Confirm RP: OP -> RP, snapshot
CREATE OR REPLACE FUNCTION public.fn_confirm_rp(p_file_id uuid, p_notes text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_old public.file_status; v_snap uuid;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old <> 'OP' THEN RAISE EXCEPTION 'RP can be confirmed only from OP (current: %)', v_old; END IF;
  UPDATE public.files SET status='RP' WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, notes, changed_by)
  VALUES (p_file_id, v_old, 'RP', p_notes, auth.uid());
  v_snap := public.fn_create_status_snapshot(p_file_id, COALESCE(p_notes, 'RP confirmed'));
  RETURN v_snap;
END $$;

-- Set Ready for CL: RP -> RCL, snapshot
CREATE OR REPLACE FUNCTION public.fn_set_ready_for_cl(p_file_id uuid, p_notes text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_old public.file_status; v_snap uuid;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old <> 'RP' THEN RAISE EXCEPTION 'Ready for CL only from RP (current: %)', v_old; END IF;
  UPDATE public.files SET status='RCL' WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, notes, changed_by)
  VALUES (p_file_id, v_old, 'RCL', p_notes, auth.uid());
  v_snap := public.fn_create_status_snapshot(p_file_id, COALESCE(p_notes, 'Ready for CL'));
  RETURN v_snap;
END $$;

-- Rewrite fn_close_file: only from RCL, with snapshot
CREATE OR REPLACE FUNCTION public.fn_close_file(p_file_id uuid, p_notes text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_old public.file_status; v_snap uuid;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old <> 'RCL' THEN RAISE EXCEPTION 'Close only from RCL (current: %)', v_old; END IF;
  UPDATE public.files SET status='CL', closed_at=now() WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, notes, changed_by)
  VALUES (p_file_id, v_old, 'CL', p_notes, auth.uid());
  v_snap := public.fn_create_status_snapshot(p_file_id, COALESCE(p_notes, 'File closed'));
  RETURN v_snap;
END $$;

-- B. Container types + sales manager
CREATE TABLE IF NOT EXISTS public.file_container_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  container_type text NOT NULL,
  planned_qty integer NOT NULL CHECK (planned_qty > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (file_id, container_type)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.file_container_types TO authenticated;
GRANT ALL ON public.file_container_types TO service_role;
ALTER TABLE public.file_container_types ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth full access file_container_types" ON public.file_container_types
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.files
  ADD COLUMN IF NOT EXISTS sales_manager_id uuid REFERENCES public.profiles(id),
  ADD COLUMN IF NOT EXISTS business_date date;
