
ALTER TABLE public.files
  ADD COLUMN IF NOT EXISTS op_date  date,
  ADD COLUMN IF NOT EXISTS rp_date  date,
  ADD COLUMN IF NOT EXISTS rcl_date date,
  ADD COLUMN IF NOT EXISTS cl_date  date,
  ADD COLUMN IF NOT EXISTS cn_date  date;

WITH agg AS (
  SELECT file_id,
         MAX(CASE WHEN to_status='OP'  THEN changed_at::date END) AS op_date,
         MAX(CASE WHEN to_status='RP'  THEN changed_at::date END) AS rp_date,
         MAX(CASE WHEN to_status='RCL' THEN changed_at::date END) AS rcl_date,
         MAX(CASE WHEN to_status='CL'  THEN changed_at::date END) AS cl_date,
         MAX(CASE WHEN to_status='CN'  THEN changed_at::date END) AS cn_date
  FROM public.file_status_history
  WHERE to_status IN ('OP','RP','RCL','CL','CN')
  GROUP BY file_id
)
UPDATE public.files f
   SET op_date  = COALESCE(f.op_date,  agg.op_date),
       rp_date  = COALESCE(f.rp_date,  agg.rp_date),
       rcl_date = COALESCE(f.rcl_date, agg.rcl_date),
       cl_date  = COALESCE(f.cl_date,  agg.cl_date),
       cn_date  = COALESCE(f.cn_date,  agg.cn_date)
  FROM agg
 WHERE agg.file_id = f.id;

CREATE OR REPLACE FUNCTION public.fn_open_file(p_file_id uuid, p_status_date date DEFAULT current_date)
 RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE v_old public.file_status; v_ts timestamptz;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old <> 'DR' THEN RAISE EXCEPTION 'File can be opened only from DR (current: %)', v_old; END IF;
  v_ts := (COALESCE(p_status_date, current_date))::timestamptz;
  UPDATE public.files SET status='OP', opened_at=v_ts, op_date=COALESCE(p_status_date, current_date) WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, changed_by, changed_at)
  VALUES (p_file_id, v_old, 'OP', auth.uid(), v_ts);
END $function$;

CREATE OR REPLACE FUNCTION public.fn_confirm_rp(p_file_id uuid, p_notes text DEFAULT NULL::text, p_status_date date DEFAULT current_date)
 RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE v_old public.file_status; v_snap uuid; v_ts timestamptz;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old <> 'OP' THEN RAISE EXCEPTION 'RP can be confirmed only from OP (current: %)', v_old; END IF;
  v_ts := (COALESCE(p_status_date, current_date))::timestamptz;
  UPDATE public.files SET status='RP', rp_date=COALESCE(p_status_date, current_date) WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, notes, changed_by, changed_at)
  VALUES (p_file_id, v_old, 'RP', p_notes, auth.uid(), v_ts);
  v_snap := public.fn_create_status_snapshot(p_file_id, COALESCE(p_notes, 'RP confirmed'));
  RETURN v_snap;
END $function$;

CREATE OR REPLACE FUNCTION public.fn_set_ready_for_cl(p_file_id uuid, p_notes text DEFAULT NULL::text, p_status_date date DEFAULT current_date)
 RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE v_old public.file_status; v_snap uuid; v_ts timestamptz;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old <> 'RP' THEN RAISE EXCEPTION 'Ready for CL only from RP (current: %)', v_old; END IF;
  v_ts := (COALESCE(p_status_date, current_date))::timestamptz;
  UPDATE public.files SET status='RCL', rcl_date=COALESCE(p_status_date, current_date) WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, notes, changed_by, changed_at)
  VALUES (p_file_id, v_old, 'RCL', p_notes, auth.uid(), v_ts);
  v_snap := public.fn_create_status_snapshot(p_file_id, COALESCE(p_notes, 'Ready for CL'));
  RETURN v_snap;
END $function$;

CREATE OR REPLACE FUNCTION public.fn_close_file(p_file_id uuid, p_notes text DEFAULT NULL::text, p_status_date date DEFAULT current_date)
 RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE v_old public.file_status; v_snap uuid; v_ts timestamptz;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old <> 'RCL' THEN RAISE EXCEPTION 'Close only from RCL (current: %)', v_old; END IF;
  v_ts := (COALESCE(p_status_date, current_date))::timestamptz;
  UPDATE public.files SET status='CL', closed_at=v_ts, cl_date=COALESCE(p_status_date, current_date) WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, notes, changed_by, changed_at)
  VALUES (p_file_id, v_old, 'CL', p_notes, auth.uid(), v_ts);
  v_snap := public.fn_create_status_snapshot(p_file_id, COALESCE(p_notes, 'File closed'));
  RETURN v_snap;
END $function$;

DROP FUNCTION IF EXISTS public.fn_close_file(uuid);

CREATE OR REPLACE FUNCTION public.fn_cancel_file(p_file_id uuid, p_reason text DEFAULT NULL::text, p_status_date date DEFAULT current_date)
 RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE v_old public.file_status; v_ts timestamptz;
BEGIN
  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;
  IF v_old IN ('CL','CN') THEN RAISE EXCEPTION 'File already terminal (%)', v_old; END IF;
  v_ts := (COALESCE(p_status_date, current_date))::timestamptz;
  UPDATE public.files SET status='CN', closed_at=v_ts, cn_date=COALESCE(p_status_date, current_date) WHERE id=p_file_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, notes, changed_by, changed_at)
  VALUES (p_file_id, v_old, 'CN', p_reason, auth.uid(), v_ts);
END $function$;

CREATE OR REPLACE FUNCTION public.fn_set_file_status_dates(
  p_file_id uuid,
  p_op  date DEFAULT NULL,
  p_rp  date DEFAULT NULL,
  p_rcl date DEFAULT NULL,
  p_cl  date DEFAULT NULL,
  p_cn  date DEFAULT NULL
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE v_pairs record;
BEGIN
  IF NOT public.has_role(auth.uid(), 'Admin') THEN
    RAISE EXCEPTION 'Only administrators can edit status dates';
  END IF;

  UPDATE public.files
     SET op_date  = COALESCE(p_op,  op_date),
         rp_date  = COALESCE(p_rp,  rp_date),
         rcl_date = COALESCE(p_rcl, rcl_date),
         cl_date  = COALESCE(p_cl,  cl_date),
         cn_date  = COALESCE(p_cn,  cn_date),
         opened_at = CASE WHEN p_op IS NOT NULL THEN p_op::timestamptz ELSE opened_at END,
         closed_at = CASE
                       WHEN p_cl IS NOT NULL THEN p_cl::timestamptz
                       WHEN p_cn IS NOT NULL THEN p_cn::timestamptz
                       ELSE closed_at
                     END
   WHERE id = p_file_id;

  FOR v_pairs IN
    SELECT * FROM (VALUES
      ('OP'::public.file_status,  p_op),
      ('RP'::public.file_status,  p_rp),
      ('RCL'::public.file_status, p_rcl),
      ('CL'::public.file_status,  p_cl),
      ('CN'::public.file_status,  p_cn)
    ) AS t(st, dt)
    WHERE dt IS NOT NULL
  LOOP
    UPDATE public.file_status_history h
       SET changed_at = (v_pairs.dt)::timestamptz
     WHERE h.id = (
       SELECT id FROM public.file_status_history
       WHERE file_id = p_file_id AND to_status = v_pairs.st
       ORDER BY changed_at DESC
       LIMIT 1
     );
  END LOOP;
END $function$;

GRANT EXECUTE ON FUNCTION public.fn_set_file_status_dates(uuid,date,date,date,date,date) TO authenticated;
