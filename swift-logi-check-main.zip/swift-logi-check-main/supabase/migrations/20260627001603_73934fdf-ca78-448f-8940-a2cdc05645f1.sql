ALTER TABLE public.file_budget_fact_lines ADD COLUMN IF NOT EXISTS unit_no text;
CREATE INDEX IF NOT EXISTS file_budget_fact_lines_file_unit_article_idx
  ON public.file_budget_fact_lines (file_id, unit_no, article_id);