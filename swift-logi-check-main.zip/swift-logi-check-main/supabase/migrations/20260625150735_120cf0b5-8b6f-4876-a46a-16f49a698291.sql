
-- 1. Sales persons directory
CREATE TABLE public.sales_persons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL UNIQUE,
  department_id uuid REFERENCES public.departments(id) ON DELETE SET NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.sales_persons TO authenticated;
GRANT ALL ON public.sales_persons TO service_role;

ALTER TABLE public.sales_persons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "sales_persons_select_auth" ON public.sales_persons
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "sales_persons_admin_write" ON public.sales_persons
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'Admin') OR public.has_permission(auth.uid(), 'admin.full'))
  WITH CHECK (public.has_role(auth.uid(), 'Admin') OR public.has_permission(auth.uid(), 'admin.full'));

CREATE TRIGGER sales_persons_updated_at
  BEFORE UPDATE ON public.sales_persons
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 2. Seed from existing sales data
INSERT INTO public.sales_persons (full_name)
SELECT DISTINCT sales_person
FROM public.eqs_ext_sales
WHERE sales_person IS NOT NULL AND length(trim(sales_person)) > 0
ON CONFLICT (full_name) DO NOTHING;

-- 3. Link files to sales_persons
ALTER TABLE public.files
  ADD COLUMN IF NOT EXISTS sales_person_id uuid REFERENCES public.sales_persons(id) ON DELETE SET NULL;

-- 4. Function to change department + regenerate file_number
CREATE OR REPLACE FUNCTION public.fn_change_file_department(
  p_file_id uuid, p_new_department_id uuid
) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_old_dep uuid; v_old_num text; v_year text; v_dep_code text;
  v_seq int; v_lock_key bigint; v_new_num text;
BEGIN
  SELECT department_id, file_number INTO v_old_dep, v_old_num
    FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old_num IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;

  SELECT code INTO v_dep_code FROM public.departments WHERE id = p_new_department_id;
  IF v_dep_code IS NULL THEN RAISE EXCEPTION 'Department has no code'; END IF;

  v_year := to_char(now(), 'YY');
  v_lock_key := hashtextextended('EQ' || v_year, 0);
  PERFORM pg_advisory_xact_lock(v_lock_key);

  SELECT COALESCE(MAX(CAST(substring(file_number FROM '[0-9]{6}$') AS int)), 0) + 1
    INTO v_seq
    FROM public.files
    WHERE file_number LIKE 'EQ' || v_year || '%';

  v_new_num := 'EQ' || v_year || v_dep_code || lpad(v_seq::text, 6, '0');

  UPDATE public.files
    SET department_id = p_new_department_id, file_number = v_new_num
    WHERE id = p_file_id;

  INSERT INTO public.file_audit_log (file_id, action, payload, actor)
  VALUES (p_file_id, 'change_department',
    jsonb_build_object('old_department_id', v_old_dep, 'new_department_id', p_new_department_id,
                       'old_file_number', v_old_num, 'new_file_number', v_new_num),
    auth.uid());

  RETURN v_new_num;
END $$;
