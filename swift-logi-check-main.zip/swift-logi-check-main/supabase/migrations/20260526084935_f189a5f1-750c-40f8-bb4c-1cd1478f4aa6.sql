ALTER TABLE public.checklist_items
ADD COLUMN depends_on_item_id uuid NULL REFERENCES public.checklist_items(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_checklist_items_depends_on
ON public.checklist_items(depends_on_item_id);