-- Extend external finance lines with counterparty + credit-note metadata
ALTER TABLE public.eqs_ext_finance_lines
  ADD COLUMN IF NOT EXISTS finance_direction text,
  ADD COLUMN IF NOT EXISTS finance_type text,
  ADD COLUMN IF NOT EXISTS source_area text,
  ADD COLUMN IF NOT EXISTS party_role text,
  ADD COLUMN IF NOT EXISTS party_accno text,
  ADD COLUMN IF NOT EXISTS party_accname text,
  ADD COLUMN IF NOT EXISTS party_contact text,
  ADD COLUMN IF NOT EXISTS original_inv_no text,
  ADD COLUMN IF NOT EXISTS credit_note_no text;

CREATE INDEX IF NOT EXISTS eqs_ext_finance_lines_unit_no_idx ON public.eqs_ext_finance_lines (unit_no);
CREATE INDEX IF NOT EXISTS eqs_ext_finance_lines_orig_inv_idx ON public.eqs_ext_finance_lines (original_inv_no);
CREATE INDEX IF NOT EXISTS eqs_ext_finance_lines_source_area_idx ON public.eqs_ext_finance_lines (source_area);

-- Track origin of effective dates on unit assignments
ALTER TABLE public.file_unit_assignments
  ADD COLUMN IF NOT EXISTS effective_from_source text,
  ADD COLUMN IF NOT EXISTS effective_to_source text;