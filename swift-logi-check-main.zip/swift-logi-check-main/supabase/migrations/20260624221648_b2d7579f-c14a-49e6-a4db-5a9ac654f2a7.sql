
ALTER TABLE public.eqs_ext_finance_lines        ADD COLUMN IF NOT EXISTS refresh_run_id uuid REFERENCES public.eqs_ext_refresh_runs(id) ON DELETE SET NULL;
ALTER TABLE public.eqs_ext_recent_units         ADD COLUMN IF NOT EXISTS refresh_run_id uuid REFERENCES public.eqs_ext_refresh_runs(id) ON DELETE SET NULL;
ALTER TABLE public.eqs_ext_units                ADD COLUMN IF NOT EXISTS refresh_run_id uuid REFERENCES public.eqs_ext_refresh_runs(id) ON DELETE SET NULL;
ALTER TABLE public.eqs_ext_bookings             ADD COLUMN IF NOT EXISTS refresh_run_id uuid REFERENCES public.eqs_ext_refresh_runs(id) ON DELETE SET NULL;
ALTER TABLE public.eqs_ext_locations_subregions ADD COLUMN IF NOT EXISTS refresh_run_id uuid REFERENCES public.eqs_ext_refresh_runs(id) ON DELETE SET NULL;
ALTER TABLE public.eqs_ext_container_buyers_5y  ADD COLUMN IF NOT EXISTS refresh_run_id uuid REFERENCES public.eqs_ext_refresh_runs(id) ON DELETE SET NULL;
ALTER TABLE public.eqs_ext_rt_charges           ADD COLUMN IF NOT EXISTS refresh_run_id uuid REFERENCES public.eqs_ext_refresh_runs(id) ON DELETE SET NULL;
ALTER TABLE public.eqs_ext_unit_history         ADD COLUMN IF NOT EXISTS refresh_run_id uuid REFERENCES public.eqs_ext_refresh_runs(id) ON DELETE SET NULL;
ALTER TABLE public.eqs_ext_cost_charge_types    ADD COLUMN IF NOT EXISTS refresh_run_id uuid REFERENCES public.eqs_ext_refresh_runs(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_eqs_ext_finance_lines_refresh_run ON public.eqs_ext_finance_lines(refresh_run_id);
