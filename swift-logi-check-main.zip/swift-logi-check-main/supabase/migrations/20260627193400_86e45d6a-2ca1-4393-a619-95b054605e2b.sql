
-- 1) SECURITY DEFINER views → switch to invoker rights
ALTER VIEW public.vw_file_finance_current SET (security_invoker = on);
ALTER VIEW public.vw_file_budget_summary SET (security_invoker = on);

-- 2) Revoke EXECUTE on public-schema functions from anon/public; keep authenticated/service_role
REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA public FROM anon, public;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO authenticated, service_role;

-- 3) Pin search_path on the one function missing it
ALTER FUNCTION public.fn_snapshot_immutable() SET search_path = public;

-- 4) Replace permissive FOR ALL USING(true) WITH CHECK(true) policies with split, signed-in-only writes
DO $do$
DECLARE
  r record;
  v_roles text;
BEGIN
  FOR r IN
    SELECT schemaname, tablename, policyname, roles
    FROM pg_policies
    WHERE schemaname = 'public'
      AND cmd = 'ALL'
      AND qual = 'true'
      AND with_check = 'true'
  LOOP
    v_roles := array_to_string(r.roles, ',');
    EXECUTE format('DROP POLICY %I ON %I.%I', r.policyname, r.schemaname, r.tablename);
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR SELECT TO %s USING (true)',
      r.policyname || ' select', r.schemaname, r.tablename, v_roles);
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR INSERT TO %s WITH CHECK (auth.uid() IS NOT NULL)',
      r.policyname || ' insert', r.schemaname, r.tablename, v_roles);
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR UPDATE TO %s USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL)',
      r.policyname || ' update', r.schemaname, r.tablename, v_roles);
    EXECUTE format(
      'CREATE POLICY %I ON %I.%I FOR DELETE TO %s USING (auth.uid() IS NOT NULL)',
      r.policyname || ' delete', r.schemaname, r.tablename, v_roles);
  END LOOP;
END
$do$;

-- 5) Tighten the lone INSERT-only always-true policy on eqs_booking_exports
DROP POLICY IF EXISTS "eqs_booking_exports insert" ON public.eqs_booking_exports;
CREATE POLICY "eqs_booking_exports insert"
  ON public.eqs_booking_exports
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);
