ALTER TABLE public.files
  ADD COLUMN IF NOT EXISTS origin_country_code text,
  ADD COLUMN IF NOT EXISTS dest_country_code text;
CREATE INDEX IF NOT EXISTS idx_files_origin_country ON public.files(origin_country_code);
CREATE INDEX IF NOT EXISTS idx_files_dest_country ON public.files(dest_country_code);