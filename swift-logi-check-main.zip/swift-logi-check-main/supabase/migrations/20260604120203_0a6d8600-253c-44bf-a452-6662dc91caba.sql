-- Recreate the public view as security_invoker so it respects caller's permissions
DROP VIEW IF EXISTS public.container_extractor_api_keys_public;

-- Replace the deny-all SELECT policy with admin-only access to the base table
DROP POLICY IF EXISTS "No direct select on api keys" ON public.container_extractor_api_keys;
CREATE POLICY "Admins can read api key metadata"
  ON public.container_extractor_api_keys FOR SELECT
  USING (public.is_admin(auth.uid()));

-- Column-level lockdown: even admins cannot read the raw key value through the API
REVOKE SELECT ON public.container_extractor_api_keys FROM authenticated;
GRANT SELECT (id, label, created_at, created_by) ON public.container_extractor_api_keys TO authenticated;

-- Recreate the view with security_invoker so the linter is satisfied
CREATE VIEW public.container_extractor_api_keys_public
WITH (security_invoker=on) AS
SELECT
  id,
  RIGHT(key_value, 4) AS last4,
  LENGTH(key_value) AS key_length,
  label,
  created_at
FROM public.container_extractor_api_keys;

REVOKE ALL ON public.container_extractor_api_keys_public FROM PUBLIC, anon;
GRANT SELECT ON public.container_extractor_api_keys_public TO authenticated;
GRANT ALL ON public.container_extractor_api_keys_public TO service_role;