
-- 1. files: новые колонки для EQS booking
ALTER TABLE public.files
  ADD COLUMN IF NOT EXISTS eqs_booking_state text
    CHECK (eqs_booking_state IN ('awaiting_id','created','failed')),
  ADD COLUMN IF NOT EXISTS eqs_booking_id text,
  ADD COLUMN IF NOT EXISTS eqs_booking_error text,
  ADD COLUMN IF NOT EXISTS eqs_booking_sent_at timestamptz,
  ADD COLUMN IF NOT EXISTS eqs_booking_received_at timestamptz;

-- 2. История экспортов
CREATE TABLE IF NOT EXISTS public.eqs_booking_exports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
  file_number text NOT NULL,
  filename text NOT NULL,
  payload_path text NOT NULL,
  response_filename text,
  response_path text,
  status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','sent','acknowledged','failed')),
  eqs_booking_id text,
  error text,
  payload jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz,
  acknowledged_at timestamptz,
  created_by uuid
);
CREATE INDEX IF NOT EXISTS idx_eqs_booking_exports_file ON public.eqs_booking_exports(file_id);
CREATE INDEX IF NOT EXISTS idx_eqs_booking_exports_status ON public.eqs_booking_exports(status);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.eqs_booking_exports TO authenticated;
GRANT ALL ON public.eqs_booking_exports TO service_role;
ALTER TABLE public.eqs_booking_exports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "eqs_booking_exports read"   ON public.eqs_booking_exports FOR SELECT TO authenticated USING (true);
CREATE POLICY "eqs_booking_exports insert" ON public.eqs_booking_exports FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "eqs_booking_exports update admin" ON public.eqs_booking_exports FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "eqs_booking_exports delete admin" ON public.eqs_booking_exports FOR DELETE TO authenticated
  USING (public.is_admin(auth.uid()));

-- 3. SFTP settings (singleton)
CREATE TABLE IF NOT EXISTS public.eqs_sftp_settings (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  host text,
  port int NOT NULL DEFAULT 22,
  username text,
  outbox_remote_path text,
  processed_remote_path text,
  errors_remote_path text,
  enabled boolean NOT NULL DEFAULT false,
  poll_interval_seconds int NOT NULL DEFAULT 30,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.eqs_sftp_settings TO authenticated;
GRANT ALL ON public.eqs_sftp_settings TO service_role;
ALTER TABLE public.eqs_sftp_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "eqs_sftp_settings read" ON public.eqs_sftp_settings FOR SELECT TO authenticated USING (true);
CREATE POLICY "eqs_sftp_settings write admin" ON public.eqs_sftp_settings FOR ALL TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
INSERT INTO public.eqs_sftp_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- 4. Equipment type map
CREATE TABLE IF NOT EXISTS public.eqs_equipment_type_map (
  iso_code text PRIMARY KEY,
  label text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.eqs_equipment_type_map TO authenticated;
GRANT ALL ON public.eqs_equipment_type_map TO service_role;
ALTER TABLE public.eqs_equipment_type_map ENABLE ROW LEVEL SECURITY;
CREATE POLICY "eqs_equipment_type_map read"  ON public.eqs_equipment_type_map FOR SELECT TO authenticated USING (true);
CREATE POLICY "eqs_equipment_type_map write admin" ON public.eqs_equipment_type_map FOR ALL TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

-- 5. updated_at triggers
DROP TRIGGER IF EXISTS trg_eqs_sftp_settings_updated_at ON public.eqs_sftp_settings;
CREATE TRIGGER trg_eqs_sftp_settings_updated_at
  BEFORE UPDATE ON public.eqs_sftp_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS trg_eqs_equipment_type_map_updated_at ON public.eqs_equipment_type_map;
CREATE TRIGGER trg_eqs_equipment_type_map_updated_at
  BEFORE UPDATE ON public.eqs_equipment_type_map
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
