-- Make file direction optional (UI removes it; existing data preserved)
ALTER TABLE public.files ALTER COLUMN direction DROP NOT NULL;
ALTER TABLE public.files ALTER COLUMN direction SET DEFAULT 'EXPORT'::public.file_direction;

-- Recreate fn_create_file with optional p_direction (defaults to EXPORT)
CREATE OR REPLACE FUNCTION public.fn_create_file(
  p_department_id uuid,
  p_direction public.file_direction DEFAULT 'EXPORT'::public.file_direction,
  p_customer_accno text DEFAULT NULL::text,
  p_customer_name text DEFAULT NULL::text,
  p_origin_subregion text DEFAULT NULL::text,
  p_dest_subregion text DEFAULT NULL::text,
  p_origin_locn text DEFAULT NULL::text,
  p_dest_locn text DEFAULT NULL::text,
  p_planned_departure_date date DEFAULT NULL::date,
  p_planned_arrival_date date DEFAULT NULL::date,
  p_notes text DEFAULT NULL::text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE v_id uuid;
BEGIN
  INSERT INTO public.files (
    direction, department_id, customer_accno, customer_name,
    origin_subregion, dest_subregion, origin_locn, dest_locn,
    planned_departure_date, planned_arrival_date, notes, created_by
  ) VALUES (
    COALESCE(p_direction, 'EXPORT'::public.file_direction), p_department_id, p_customer_accno, p_customer_name,
    p_origin_subregion, p_dest_subregion, p_origin_locn, p_dest_locn,
    p_planned_departure_date, p_planned_arrival_date, p_notes, auth.uid()
  ) RETURNING id INTO v_id;
  INSERT INTO public.file_status_history (file_id, from_status, to_status, changed_by)
  VALUES (v_id, NULL, 'DR', auth.uid());
  RETURN v_id;
END $function$;

-- Index for booking-based grouping
CREATE INDEX IF NOT EXISTS idx_eqs_ext_recent_units_booking_no
  ON public.eqs_ext_recent_units(booking_no);