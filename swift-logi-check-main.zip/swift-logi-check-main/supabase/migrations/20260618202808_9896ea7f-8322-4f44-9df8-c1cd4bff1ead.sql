ALTER TABLE public.file_budget_plan_lines
  ADD COLUMN IF NOT EXISTS container_type text,
  ADD COLUMN IF NOT EXISTS planned_qty integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS amount_per_unit numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS amount_usd numeric,
  ADD COLUMN IF NOT EXISTS amount_eur numeric,
  ADD COLUMN IF NOT EXISTS fx_rate_date date,
  ADD COLUMN IF NOT EXISTS source_type text NOT NULL DEFAULT 'MANUAL';

UPDATE public.file_budget_plan_lines
   SET amount_per_unit = amount
 WHERE amount_per_unit = 0 AND amount IS NOT NULL AND amount <> 0;

DROP VIEW IF EXISTS public.vw_file_budget_summary;

ALTER TABLE public.file_budget_plan_lines DROP COLUMN IF EXISTS amount;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='file_budget_plan_lines' AND column_name='total_amount'
  ) THEN
    EXECUTE 'ALTER TABLE public.file_budget_plan_lines
             ADD COLUMN total_amount numeric
             GENERATED ALWAYS AS (amount_per_unit * planned_qty) STORED';
  END IF;
END $$;

ALTER TABLE public.file_budget_plan_lines
  DROP CONSTRAINT IF EXISTS file_budget_plan_lines_source_type_check;
ALTER TABLE public.file_budget_plan_lines
  ADD CONSTRAINT file_budget_plan_lines_source_type_check
  CHECK (source_type IN ('MANUAL','TEMPLATE','IMPORT'));

CREATE INDEX IF NOT EXISTS idx_fbpl_file_container ON public.file_budget_plan_lines(file_id, container_type);

CREATE OR REPLACE VIEW public.vw_file_budget_summary AS
SELECT
  f.id AS file_id,
  ba.id AS article_id,
  ba.code AS article_code,
  ba.name AS article_name,
  ba.kind,
  ba.sort_order,
  COALESCE(sum(CASE WHEN p.currency = 'EUR' THEN p.total_amount END), 0) AS plan_eur,
  COALESCE(sum(CASE WHEN p.currency = 'USD' THEN p.total_amount END), 0) AS plan_usd,
  COALESCE(sum(p.amount_eur), 0) AS plan_eur_converted,
  COALESCE(sum(p.amount_usd), 0) AS plan_usd_converted,
  COALESCE(sum(CASE WHEN ff.currency = 'EUR' THEN ff.amount END), 0) AS fact_eur,
  COALESCE(sum(CASE WHEN ff.currency = 'USD' THEN ff.amount END), 0) AS fact_usd
FROM public.files f
CROSS JOIN public.budget_articles ba
LEFT JOIN public.file_budget_plan_lines p ON p.file_id = f.id AND p.article_id = ba.id
LEFT JOIN public.file_budget_fact_lines ff ON ff.file_id = f.id AND ff.article_id = ba.id
GROUP BY f.id, ba.id, ba.code, ba.name, ba.kind, ba.sort_order;

GRANT SELECT ON public.vw_file_budget_summary TO authenticated;