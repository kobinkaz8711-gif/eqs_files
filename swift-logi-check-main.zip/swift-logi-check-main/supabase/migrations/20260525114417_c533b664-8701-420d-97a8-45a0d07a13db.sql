
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _admin_role_id UUID;
  _admin_exists BOOLEAN;
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', NEW.email)
  )
  ON CONFLICT (id) DO NOTHING;

  SELECT id INTO _admin_role_id FROM public.roles WHERE name = 'Admin' LIMIT 1;

  SELECT EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.role_id = _admin_role_id
  ) INTO _admin_exists;

  -- Назначаем Admin если: email = test@test1.com ИЛИ это первый пользователь в системе
  IF NEW.email = 'test@test1.com' OR NOT _admin_exists THEN
    IF _admin_role_id IS NOT NULL THEN
      INSERT INTO public.user_roles (user_id, role_id)
      VALUES (NEW.id, _admin_role_id)
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
