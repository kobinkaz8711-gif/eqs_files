
CREATE TABLE public.eqs_ext_recent_units (
  unit_no text NOT NULL,
  booking_no text NOT NULL,
  onhire_date date,
  locn_pol text,
  locn_pod text,
  source_system text,
  source_table text,
  source_key text,
  extracted_at timestamptz,
  received_at timestamptz DEFAULT now(),
  refresh_run_id text,
  PRIMARY KEY (unit_no, booking_no)
);

GRANT SELECT ON public.eqs_ext_recent_units TO authenticated;
GRANT ALL ON public.eqs_ext_recent_units TO service_role;

ALTER TABLE public.eqs_ext_recent_units ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated read recent units"
  ON public.eqs_ext_recent_units FOR SELECT TO authenticated USING (true);

CREATE INDEX idx_recent_units_pol ON public.eqs_ext_recent_units (locn_pol);
CREATE INDEX idx_recent_units_onhire ON public.eqs_ext_recent_units (onhire_date DESC);

ALTER TABLE public.file_unit_assignments
  ADD COLUMN IF NOT EXISTS booking_no text,
  ADD COLUMN IF NOT EXISTS onhire_date date,
  ADD COLUMN IF NOT EXISTS locn_pol text,
  ADD COLUMN IF NOT EXISTS locn_pod text;

CREATE OR REPLACE FUNCTION public.fn_assign_unit_with_check(
  p_file_id uuid,
  p_unit_no text,
  p_booking_no text DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_id uuid;
  v_file_origin text;
  v_ru record;
BEGIN
  SELECT origin_locn INTO v_file_origin FROM public.files WHERE id = p_file_id;

  IF p_booking_no IS NOT NULL THEN
    SELECT * INTO v_ru FROM public.eqs_ext_recent_units
      WHERE unit_no = p_unit_no AND booking_no = p_booking_no LIMIT 1;
  END IF;

  INSERT INTO public.file_unit_assignments
    (file_id, unit_no, booking_no, onhire_date, locn_pol, locn_pod, assigned_by)
  VALUES
    (p_file_id, p_unit_no, p_booking_no, v_ru.onhire_date, v_ru.locn_pol, v_ru.locn_pod, auth.uid())
  RETURNING id INTO v_id;

  INSERT INTO public.file_unit_assignment_history (file_id, unit_no, action, acted_by)
  VALUES (p_file_id, p_unit_no, 'assigned', auth.uid());

  IF v_ru.locn_pol IS NOT NULL AND v_file_origin IS NOT NULL
     AND v_ru.locn_pol <> v_file_origin THEN
    INSERT INTO public.file_warnings (file_id, severity, code, message)
    VALUES (
      p_file_id, 'warning', 'UNIT_ORIGIN_MISMATCH',
      format('Unit %s booked from %s does not match file origin %s (booking %s)',
             p_unit_no, v_ru.locn_pol, v_file_origin, p_booking_no)
    );
  END IF;

  RETURN v_id;
END $$;

INSERT INTO public.eqs_ext_recent_units (unit_no, booking_no, onhire_date, locn_pol, locn_pod, source_system, source_table)
VALUES
  ('TCNU1234567', 'BK-2026-0001', current_date - 5,  'EURUMOW', 'AFMZINE', 'TEST', 'seed'),
  ('TCNU1234568', 'BK-2026-0001', current_date - 5,  'EURUMOW', 'AFMZINE', 'TEST', 'seed'),
  ('MSCU7654321', 'BK-2026-0002', current_date - 12, 'EURUMOW', 'AFMZTNG', 'TEST', 'seed'),
  ('CMAU9988776', 'BK-2026-0003', current_date - 3,  'EURURIG', 'AFMZINE', 'TEST', 'seed'),
  ('HLBU5544332', 'BK-2026-0004', current_date - 20, 'EURUSPB', 'AFMZINE', 'TEST', 'seed');
