-- 1) Replace fx_rate_date with single numeric fx_rate_eur_usd on files
ALTER TABLE public.files
  DROP COLUMN IF EXISTS fx_rate_date,
  ADD COLUMN IF NOT EXISTS fx_rate_eur_usd numeric;

-- Drop redundant fx_rate_date on plan lines (rate is per-file)
ALTER TABLE public.file_budget_plan_lines
  DROP COLUMN IF EXISTS fx_rate_date;

-- 2) Add purchase price columns to eqs_ext_units (per-unit fact)
ALTER TABLE public.eqs_ext_units
  ADD COLUMN IF NOT EXISTS amt_ppb numeric,
  ADD COLUMN IF NOT EXISTS amt_ppl numeric;