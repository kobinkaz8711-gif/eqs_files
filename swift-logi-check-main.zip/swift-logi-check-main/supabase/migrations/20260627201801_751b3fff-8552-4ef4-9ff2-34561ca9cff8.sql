
-- Add scope to budget_articles to separate Sales vs Finance article catalogs
ALTER TABLE public.budget_articles
  ADD COLUMN IF NOT EXISTS scope text NOT NULL DEFAULT 'SALES';

ALTER TABLE public.budget_articles
  DROP CONSTRAINT IF EXISTS budget_articles_scope_check;
ALTER TABLE public.budget_articles
  ADD CONSTRAINT budget_articles_scope_check CHECK (scope IN ('SALES','FINANCE'));

-- Replace global UNIQUE(code) with UNIQUE(scope, code) so Finance can reuse codes
ALTER TABLE public.budget_articles
  DROP CONSTRAINT IF EXISTS budget_articles_code_key;
ALTER TABLE public.budget_articles
  ADD CONSTRAINT budget_articles_scope_code_key UNIQUE (scope, code);

-- Optional finance article on cost/charge mapping
ALTER TABLE public.cost_charge_type_mapping
  ADD COLUMN IF NOT EXISTS finance_article_id uuid NULL
    REFERENCES public.budget_articles(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS cost_charge_type_mapping_finance_article_id_idx
  ON public.cost_charge_type_mapping(finance_article_id);
