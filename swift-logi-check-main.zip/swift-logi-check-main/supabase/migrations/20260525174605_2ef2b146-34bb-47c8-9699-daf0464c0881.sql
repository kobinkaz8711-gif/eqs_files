-- 1. departments
CREATE TABLE public.departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "departments_select_auth" ON public.departments
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "departments_modify_managers" ON public.departments
  FOR ALL TO authenticated
  USING (has_permission(auth.uid(), 'departments.manage'))
  WITH CHECK (has_permission(auth.uid(), 'departments.manage'));

CREATE TRIGGER trg_departments_updated_at
  BEFORE UPDATE ON public.departments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 2. profiles: replace text department with department_id
ALTER TABLE public.profiles DROP COLUMN IF EXISTS department;
ALTER TABLE public.profiles ADD COLUMN department_id uuid REFERENCES public.departments(id) ON DELETE SET NULL;

-- 3. modules
CREATE TABLE public.modules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  route text,
  icon text,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.modules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "modules_select_auth" ON public.modules
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "modules_modify_managers" ON public.modules
  FOR ALL TO authenticated
  USING (has_permission(auth.uid(), 'modules.manage'))
  WITH CHECK (has_permission(auth.uid(), 'modules.manage'));

CREATE TRIGGER trg_modules_updated_at
  BEFORE UPDATE ON public.modules
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 4. module_departments
CREATE TABLE public.module_departments (
  module_id uuid NOT NULL REFERENCES public.modules(id) ON DELETE CASCADE,
  department_id uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (module_id, department_id)
);
ALTER TABLE public.module_departments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "module_departments_select_auth" ON public.module_departments
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "module_departments_modify_managers" ON public.module_departments
  FOR ALL TO authenticated
  USING (has_permission(auth.uid(), 'modules.manage'))
  WITH CHECK (has_permission(auth.uid(), 'modules.manage'));

-- 5. permissions + grant to Admin
INSERT INTO public.permissions (code, description) VALUES
  ('departments.manage', 'Управление отделами'),
  ('modules.manage', 'Управление модулями и их доступами')
ON CONFLICT (code) DO NOTHING;

INSERT INTO public.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM public.roles r
CROSS JOIN public.permissions p
WHERE r.name = 'Admin' AND p.code IN ('departments.manage', 'modules.manage')
ON CONFLICT DO NOTHING;

-- 6. access check function
CREATE OR REPLACE FUNCTION public.user_has_module_access(_user_id uuid, _module_code text)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    has_permission(_user_id, 'admin.full')
    OR EXISTS (
      SELECT 1 FROM public.modules m
      WHERE m.code = _module_code
        AND NOT EXISTS (SELECT 1 FROM public.module_departments md WHERE md.module_id = m.id)
    )
    OR EXISTS (
      SELECT 1
      FROM public.modules m
      JOIN public.module_departments md ON md.module_id = m.id
      JOIN public.profiles p ON p.department_id = md.department_id
      WHERE m.code = _module_code AND p.id = _user_id
    );
$$;

REVOKE EXECUTE ON FUNCTION public.user_has_module_access(uuid, text) FROM anon, public;

-- 7. seed checklist module
INSERT INTO public.modules (code, name, description, route, icon, sort_order)
VALUES ('checklist', 'Настройки модуля', 'Типы перевозок, чек-листы, шаблоны писем', '/settings/module', 'Settings2', 0)
ON CONFLICT (code) DO NOTHING;