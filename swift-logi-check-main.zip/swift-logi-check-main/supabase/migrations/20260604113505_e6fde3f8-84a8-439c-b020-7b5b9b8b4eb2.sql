CREATE TABLE public.container_extractor_api_keys (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key_value TEXT NOT NULL,
  label TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.container_extractor_api_keys TO authenticated;
GRANT ALL ON public.container_extractor_api_keys TO service_role;

ALTER TABLE public.container_extractor_api_keys ENABLE ROW LEVEL SECURITY;

-- Deny direct SELECT — keys must never be read back by clients
CREATE POLICY "No direct select on api keys"
  ON public.container_extractor_api_keys FOR SELECT
  USING (false);

CREATE POLICY "Admins can insert api keys"
  ON public.container_extractor_api_keys FOR INSERT
  WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Admins can delete api keys"
  ON public.container_extractor_api_keys FOR DELETE
  USING (public.is_admin(auth.uid()));

-- Public-safe view: only metadata + last 4 chars, no full key
CREATE VIEW public.container_extractor_api_keys_public
WITH (security_invoker=on) AS
SELECT
  id,
  RIGHT(key_value, 4) AS last4,
  LENGTH(key_value) AS key_length,
  label,
  created_at
FROM public.container_extractor_api_keys;

GRANT SELECT ON public.container_extractor_api_keys_public TO authenticated;