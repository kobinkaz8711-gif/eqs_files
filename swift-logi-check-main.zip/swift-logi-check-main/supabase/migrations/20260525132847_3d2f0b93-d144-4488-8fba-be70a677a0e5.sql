
-- Transport types
CREATE TABLE public.transport_types (
  code TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.checklist_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transport_type_code TEXT NOT NULL UNIQUE REFERENCES public.transport_types(code) ON DELETE CASCADE,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.checklist_sections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id UUID NOT NULL REFERENCES public.checklist_templates(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON public.checklist_sections(template_id);

CREATE TABLE public.checklist_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  section_id UUID NOT NULL REFERENCES public.checklist_sections(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  hint TEXT,
  required BOOLEAN NOT NULL DEFAULT true,
  critical BOOLEAN NOT NULL DEFAULT false,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON public.checklist_items(section_id);

CREATE TYPE public.email_template_kind AS ENUM ('ok', 'missing');

CREATE TABLE public.email_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transport_type_code TEXT REFERENCES public.transport_types(code) ON DELETE CASCADE,
  kind public.email_template_kind NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX email_templates_global_uniq ON public.email_templates(kind) WHERE transport_type_code IS NULL;
CREATE UNIQUE INDEX email_templates_per_type_uniq ON public.email_templates(transport_type_code, kind) WHERE transport_type_code IS NOT NULL;

-- RLS
ALTER TABLE public.transport_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.checklist_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.checklist_sections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.checklist_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tt_select" ON public.transport_types FOR SELECT TO authenticated USING (true);
CREATE POLICY "tt_modify" ON public.transport_types FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'checklist.manage'))
  WITH CHECK (public.has_permission(auth.uid(), 'checklist.manage'));

CREATE POLICY "ct_select" ON public.checklist_templates FOR SELECT TO authenticated USING (true);
CREATE POLICY "ct_modify" ON public.checklist_templates FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'checklist.manage'))
  WITH CHECK (public.has_permission(auth.uid(), 'checklist.manage'));

CREATE POLICY "cs_select" ON public.checklist_sections FOR SELECT TO authenticated USING (true);
CREATE POLICY "cs_modify" ON public.checklist_sections FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'checklist.manage'))
  WITH CHECK (public.has_permission(auth.uid(), 'checklist.manage'));

CREATE POLICY "ci_select" ON public.checklist_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "ci_modify" ON public.checklist_items FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'checklist.manage'))
  WITH CHECK (public.has_permission(auth.uid(), 'checklist.manage'));

CREATE POLICY "et_select" ON public.email_templates FOR SELECT TO authenticated USING (true);
CREATE POLICY "et_modify" ON public.email_templates FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'checklist.manage'))
  WITH CHECK (public.has_permission(auth.uid(), 'checklist.manage'));

-- updated_at triggers
CREATE TRIGGER tt_upd BEFORE UPDATE ON public.transport_types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER ct_upd BEFORE UPDATE ON public.checklist_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER cs_upd BEFORE UPDATE ON public.checklist_sections FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER ci_upd BEFORE UPDATE ON public.checklist_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER et_upd BEFORE UPDATE ON public.email_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed transport types
INSERT INTO public.transport_types (code, label, sort_order) VALUES
  ('FCL', 'FCL — Полный контейнер', 0),
  ('LCL', 'LCL — Сборный груз', 1),
  ('AIR', 'AIR — Авиаперевозка', 2),
  ('ROAD', 'ROAD — Автоперевозка', 3),
  ('RAIL', 'RAIL — Ж/Д перевозка', 4),
  ('SEA', 'SEA — Морская перевозка', 5),
  ('IMPORT', 'IMPORT — Импорт', 6),
  ('EXPORT', 'EXPORT — Экспорт', 7),
  ('DOMESTIC', 'DOMESTIC — Внутренняя перевозка', 8);

-- Seed templates with sections/items
DO $$
DECLARE
  t RECORD;
  tpl_id UUID;
  cargo_id UUID;
  shipper_id UUID;
  cons_id UUID;
  docs_id UUID;
BEGIN
  FOR t IN SELECT code, label FROM public.transport_types LOOP
    INSERT INTO public.checklist_templates (transport_type_code, name)
    VALUES (t.code, t.label) RETURNING id INTO tpl_id;

    INSERT INTO public.checklist_sections (template_id, title, sort_order)
    VALUES (tpl_id, 'Информация о грузе', 0) RETURNING id INTO cargo_id;
    INSERT INTO public.checklist_items (section_id, label, required, critical, sort_order) VALUES
      (cargo_id, 'Вес груза', true, true, 0),
      (cargo_id, 'Описание груза', true, false, 1),
      (cargo_id, 'Габариты груза', true, false, 2),
      (cargo_id, 'Опасный груз (Hazardous)', false, false, 3);

    INSERT INTO public.checklist_sections (template_id, title, sort_order)
    VALUES (tpl_id, 'Информация об отправителе', 1) RETURNING id INTO shipper_id;
    INSERT INTO public.checklist_items (section_id, label, required, critical, sort_order) VALUES
      (shipper_id, 'Shipper (наименование)', true, true, 0),
      (shipper_id, 'Контакт отправителя', true, false, 1),
      (shipper_id, 'Адрес отправителя', true, false, 2);

    INSERT INTO public.checklist_sections (template_id, title, sort_order)
    VALUES (tpl_id, 'Информация о получателе', 2) RETURNING id INTO cons_id;
    INSERT INTO public.checklist_items (section_id, label, required, critical, sort_order) VALUES
      (cons_id, 'Consignee (наименование)', true, true, 0),
      (cons_id, 'Контакт получателя', true, false, 1),
      (cons_id, 'Адрес доставки', true, true, 2);

    INSERT INTO public.checklist_sections (template_id, title, sort_order)
    VALUES (tpl_id, 'Документы', 3) RETURNING id INTO docs_id;
    INSERT INTO public.checklist_items (section_id, label, required, critical, sort_order) VALUES
      (docs_id, 'Commercial Invoice', true, true, 0),
      (docs_id, 'Packing List', true, false, 1),
      (docs_id, 'Договор', true, false, 2);

    IF t.code IN ('FCL', 'LCL', 'SEA') THEN
      INSERT INTO public.checklist_items (section_id, label, required, critical, sort_order)
        VALUES (docs_id, 'Bill of Lading (BL)', true, true, 3);
    ELSIF t.code = 'AIR' THEN
      INSERT INTO public.checklist_items (section_id, label, required, critical, sort_order)
        VALUES (docs_id, 'Air Waybill (AWB)', true, true, 3);
    ELSIF t.code = 'ROAD' THEN
      INSERT INTO public.checklist_items (section_id, label, required, critical, sort_order)
        VALUES (docs_id, 'CMR', true, true, 3);
    ELSIF t.code = 'RAIL' THEN
      INSERT INTO public.checklist_items (section_id, label, required, critical, sort_order)
        VALUES (docs_id, 'SMGS-накладная', true, true, 3);
    ELSIF t.code = 'IMPORT' THEN
      INSERT INTO public.checklist_items (section_id, label, required, critical, sort_order)
        VALUES (docs_id, 'Импортная декларация', true, true, 4);
    ELSIF t.code = 'EXPORT' THEN
      INSERT INTO public.checklist_items (section_id, label, required, critical, sort_order)
        VALUES (docs_id, 'Экспортная декларация', true, true, 4);
    END IF;
  END LOOP;
END $$;

-- Seed global email templates
INSERT INTO public.email_templates (transport_type_code, kind, subject, body) VALUES
  (NULL, 'ok', 'Заявка принята в работу',
'Добрый день.

Заявка проверена и принята в работу.

Спасибо.'),
  (NULL, 'missing', 'Недостаточно данных для обработки заявки',
'Добрый день.

Заявка не может быть принята в работу.

Не хватает следующих данных/документов:
{{missing_list}}

Просьба дополнить информацию и направить повторно.

Спасибо.');

-- Ensure checklist.manage permission exists
INSERT INTO public.permissions (code, description) VALUES
  ('checklist.manage', 'Управление шаблонами и настройками модуля проверки')
ON CONFLICT (code) DO NOTHING;
