DELETE FROM public.container_extractor_api_keys a
USING public.container_extractor_api_keys b
WHERE a.ctid < b.ctid AND a.key_value = b.key_value;

ALTER TABLE public.container_extractor_api_keys
  ADD CONSTRAINT container_extractor_api_keys_key_value_unique UNIQUE (key_value);