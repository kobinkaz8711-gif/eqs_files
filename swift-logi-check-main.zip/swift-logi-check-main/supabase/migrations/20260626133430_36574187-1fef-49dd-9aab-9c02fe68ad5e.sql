
-- Read/write на eqs-outbox и eqs-inbox для authenticated
CREATE POLICY "eqs buckets read"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id IN ('eqs-outbox','eqs-inbox'));

CREATE POLICY "eqs buckets insert"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id IN ('eqs-outbox','eqs-inbox'));

CREATE POLICY "eqs buckets update"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id IN ('eqs-outbox','eqs-inbox'))
  WITH CHECK (bucket_id IN ('eqs-outbox','eqs-inbox'));

CREATE POLICY "eqs buckets delete"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id IN ('eqs-outbox','eqs-inbox'));
