CREATE TABLE public.sales_finance_article_map (
  sales_article_id uuid PRIMARY KEY REFERENCES public.budget_articles(id) ON DELETE CASCADE,
  finance_article_id uuid NOT NULL REFERENCES public.budget_articles(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.sales_finance_article_map TO authenticated;
GRANT ALL ON public.sales_finance_article_map TO service_role;

ALTER TABLE public.sales_finance_article_map ENABLE ROW LEVEL SECURITY;

CREATE POLICY "sfam_select_auth" ON public.sales_finance_article_map
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "sfam_insert_admin" ON public.sales_finance_article_map
  FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'Admin'));
CREATE POLICY "sfam_update_admin" ON public.sales_finance_article_map
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'Admin')) WITH CHECK (public.has_role(auth.uid(),'Admin'));
CREATE POLICY "sfam_delete_admin" ON public.sales_finance_article_map
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'Admin'));

CREATE TRIGGER trg_sfam_updated_at BEFORE UPDATE ON public.sales_finance_article_map
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed from existing cost_charge_type_mapping: most frequent finance per sales
INSERT INTO public.sales_finance_article_map (sales_article_id, finance_article_id)
SELECT sales_article_id, finance_article_id FROM (
  SELECT m.article_id AS sales_article_id,
         m.finance_article_id,
         COUNT(*) AS cnt,
         ROW_NUMBER() OVER (PARTITION BY m.article_id ORDER BY COUNT(*) DESC, m.finance_article_id) AS rn
  FROM public.cost_charge_type_mapping m
  WHERE m.article_id IS NOT NULL AND m.finance_article_id IS NOT NULL
  GROUP BY m.article_id, m.finance_article_id
) t WHERE rn = 1
ON CONFLICT DO NOTHING;