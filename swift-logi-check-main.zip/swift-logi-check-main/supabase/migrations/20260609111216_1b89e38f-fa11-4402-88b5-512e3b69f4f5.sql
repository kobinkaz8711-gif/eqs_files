
-- 1) Revoke column-level SELECT on key_value so it can never be read via Data API
REVOKE SELECT (key_value) ON public.container_extractor_api_keys FROM authenticated;
REVOKE SELECT (key_value) ON public.container_extractor_api_keys FROM anon;

-- 2) Tighten user_roles policies to block privilege escalation
DROP POLICY IF EXISTS user_roles_modify_managers ON public.user_roles;

CREATE POLICY user_roles_insert_managers ON public.user_roles
  FOR INSERT TO authenticated
  WITH CHECK (
    public.has_permission(auth.uid(), 'users.manage')
    AND (
      public.has_permission(auth.uid(), 'admin.full')
      OR NOT EXISTS (
        SELECT 1 FROM public.roles r
        WHERE r.id = user_roles.role_id
          AND (r.is_system = true OR r.name = 'Admin')
      )
    )
  );

CREATE POLICY user_roles_update_managers ON public.user_roles
  FOR UPDATE TO authenticated
  USING (
    public.has_permission(auth.uid(), 'users.manage')
    AND (
      public.has_permission(auth.uid(), 'admin.full')
      OR NOT EXISTS (
        SELECT 1 FROM public.roles r
        WHERE r.id = user_roles.role_id
          AND (r.is_system = true OR r.name = 'Admin')
      )
    )
  )
  WITH CHECK (
    public.has_permission(auth.uid(), 'users.manage')
    AND (
      public.has_permission(auth.uid(), 'admin.full')
      OR NOT EXISTS (
        SELECT 1 FROM public.roles r
        WHERE r.id = user_roles.role_id
          AND (r.is_system = true OR r.name = 'Admin')
      )
    )
  );

CREATE POLICY user_roles_delete_managers ON public.user_roles
  FOR DELETE TO authenticated
  USING (
    public.has_permission(auth.uid(), 'users.manage')
    AND (
      public.has_permission(auth.uid(), 'admin.full')
      OR NOT EXISTS (
        SELECT 1 FROM public.roles r
        WHERE r.id = user_roles.role_id
          AND (r.is_system = true OR r.name = 'Admin')
      )
    )
  );
