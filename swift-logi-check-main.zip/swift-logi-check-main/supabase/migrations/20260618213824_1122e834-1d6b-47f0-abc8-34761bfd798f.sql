
ALTER TABLE public.file_unit_assignments ADD COLUMN IF NOT EXISTS unit_type text;

CREATE OR REPLACE FUNCTION public.fn_assign_unit_with_check(p_file_id uuid, p_unit_no text, p_booking_no text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_id uuid;
  v_file_origin text;
  v_ru record;
  v_unit_type text;
  v_type_ok boolean;
BEGIN
  SELECT origin_locn INTO v_file_origin FROM public.files WHERE id = p_file_id;

  IF p_booking_no IS NOT NULL THEN
    SELECT * INTO v_ru FROM public.eqs_ext_recent_units
      WHERE unit_no = p_unit_no AND booking_no = p_booking_no LIMIT 1;
  END IF;

  SELECT iso_code INTO v_unit_type FROM public.eqs_ext_units WHERE unit_no = p_unit_no LIMIT 1;

  INSERT INTO public.file_unit_assignments
    (file_id, unit_no, booking_no, onhire_date, locn_pol, locn_pod, unit_type, assigned_by)
  VALUES
    (p_file_id, p_unit_no, p_booking_no, v_ru.onhire_date, v_ru.locn_pol, v_ru.locn_pod, v_unit_type, auth.uid())
  RETURNING id INTO v_id;

  INSERT INTO public.file_unit_assignment_history (file_id, unit_no, action, acted_by)
  VALUES (p_file_id, p_unit_no, 'assigned', auth.uid());

  IF v_ru.locn_pol IS NOT NULL AND v_file_origin IS NOT NULL
     AND v_ru.locn_pol <> v_file_origin THEN
    INSERT INTO public.file_warnings (file_id, severity, code, message)
    VALUES (
      p_file_id, 'warning', 'UNIT_ORIGIN_MISMATCH',
      format('Unit %s booked from %s does not match file origin %s (booking %s)',
             p_unit_no, v_ru.locn_pol, v_file_origin, p_booking_no)
    );
  END IF;

  IF v_unit_type IS NOT NULL THEN
    SELECT EXISTS (
      SELECT 1 FROM public.file_container_types
      WHERE file_id = p_file_id AND container_type = v_unit_type
    ) INTO v_type_ok;
    IF NOT v_type_ok AND EXISTS (SELECT 1 FROM public.file_container_types WHERE file_id = p_file_id) THEN
      INSERT INTO public.file_warnings (file_id, severity, code, message)
      VALUES (
        p_file_id, 'warning', 'UNIT_TYPE_MISMATCH',
        format('Unit %s type %s does not match any container type declared in file', p_unit_no, v_unit_type)
      );
    END IF;
  END IF;

  RETURN v_id;
END $function$;
