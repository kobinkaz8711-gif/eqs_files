
-- Storage: restrict eqs-outbox/eqs-inbox to admins
DROP POLICY IF EXISTS "eqs buckets read" ON storage.objects;
DROP POLICY IF EXISTS "eqs buckets insert" ON storage.objects;
DROP POLICY IF EXISTS "eqs buckets update" ON storage.objects;
DROP POLICY IF EXISTS "eqs buckets delete" ON storage.objects;

CREATE POLICY "eqs buckets read" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = ANY (ARRAY['eqs-outbox','eqs-inbox']) AND public.is_admin(auth.uid()));

CREATE POLICY "eqs buckets insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = ANY (ARRAY['eqs-outbox','eqs-inbox']) AND public.is_admin(auth.uid()));

CREATE POLICY "eqs buckets update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = ANY (ARRAY['eqs-outbox','eqs-inbox']) AND public.is_admin(auth.uid()))
  WITH CHECK (bucket_id = ANY (ARRAY['eqs-outbox','eqs-inbox']) AND public.is_admin(auth.uid()));

CREATE POLICY "eqs buckets delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = ANY (ARRAY['eqs-outbox','eqs-inbox']) AND public.is_admin(auth.uid()));

-- Revoke EXECUTE from anon/public on SECURITY DEFINER status mutation functions
REVOKE EXECUTE ON FUNCTION public.fn_open_file(uuid, date) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.fn_confirm_rp(uuid, text, date) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.fn_set_ready_for_cl(uuid, text, date) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.fn_close_file(uuid, text, date) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.fn_cancel_file(uuid, text, date) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.fn_set_file_status_dates(uuid, date, date, date, date, date) FROM anon, PUBLIC;

GRANT EXECUTE ON FUNCTION public.fn_open_file(uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_confirm_rp(uuid, text, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_set_ready_for_cl(uuid, text, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_close_file(uuid, text, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_cancel_file(uuid, text, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fn_set_file_status_dates(uuid, date, date, date, date, date) TO authenticated;
