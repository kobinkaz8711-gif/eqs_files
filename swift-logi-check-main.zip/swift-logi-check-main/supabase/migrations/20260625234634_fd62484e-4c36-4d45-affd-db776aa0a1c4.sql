
CREATE OR REPLACE FUNCTION public.fn_refresh_file_finance_lines(p_file_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_count integer;
BEGIN
  DELETE FROM public.file_finance_lines WHERE file_id = p_file_id;

  WITH ins AS (
    INSERT INTO public.file_finance_lines (
      file_id, unit_no, source_finance_id, source_type, source_code,
      article_id, amount, currency, invoice_no, invoice_date, dte_acct, is_unmapped
    )
    SELECT DISTINCT ON (e.id)
      p_file_id,
      e.unit_no,
      e.id,
      e.source_type,
      e.source_code,
      m.article_id,
      e.amount,
      e.currency,
      e.invoice_no,
      e.invoice_date,
      e.dte_acct,
      (m.article_id IS NULL)
    FROM public.eqs_ext_finance_lines e
    JOIN public.file_unit_assignments fua
      ON fua.unit_no = e.unit_no
     AND fua.file_id = p_file_id
     AND fua.is_active = true
    LEFT JOIN public.cost_charge_type_mapping m
      ON m.source_type = e.source_type
     AND m.source_code = e.source_code
    WHERE
      e.source_code IN ('PURC','RCTP')
      OR (
        COALESCE(e.dte_acct, e.invoice_date::date)
          BETWEEN COALESCE(fua.effective_date_from, '-infinity'::date)
              AND COALESCE(fua.effective_date_to,    'infinity'::date)
      )
    ORDER BY e.id, fua.assigned_at
    RETURNING 1
  )
  SELECT count(*) INTO v_count FROM ins;

  RETURN v_count;
END;
$$;

GRANT EXECUTE ON FUNCTION public.fn_refresh_file_finance_lines(uuid) TO authenticated, service_role;

-- Backfill all non-draft files
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT id FROM public.files WHERE status IN ('OP','RP','RCL','CL') LOOP
    PERFORM public.fn_refresh_file_finance_lines(r.id);
  END LOOP;
END $$;
