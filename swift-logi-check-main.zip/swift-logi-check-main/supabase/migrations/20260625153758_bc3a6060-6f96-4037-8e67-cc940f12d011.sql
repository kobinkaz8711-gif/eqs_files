CREATE OR REPLACE FUNCTION public.fn_change_file_department(p_file_id uuid, p_new_department_id uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_old_dep uuid; v_old_num text; v_year text; v_dep_code text;
  v_seq int; v_lock_key bigint; v_new_num text;
BEGIN
  SELECT department_id, file_number INTO v_old_dep, v_old_num
    FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old_num IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;

  SELECT code INTO v_dep_code FROM public.departments WHERE id = p_new_department_id;
  IF v_dep_code IS NULL THEN RAISE EXCEPTION 'Department has no code'; END IF;

  v_year := to_char(now(), 'YY');
  v_lock_key := hashtextextended('EQ' || v_year, 0);
  PERFORM pg_advisory_xact_lock(v_lock_key);

  SELECT COALESCE(MAX(CAST(substring(file_number FROM '[0-9]{6}$') AS int)), 0) + 1
    INTO v_seq
    FROM public.files
    WHERE file_number LIKE 'EQ' || v_year || '%';

  v_new_num := 'EQ' || v_year || v_dep_code || lpad(v_seq::text, 6, '0');

  UPDATE public.files
    SET department_id = p_new_department_id, file_number = v_new_num
    WHERE id = p_file_id;

  INSERT INTO public.file_audit_log (file_id, action, details, actor_id)
  VALUES (p_file_id, 'change_department',
    jsonb_build_object('old_department_id', v_old_dep, 'new_department_id', p_new_department_id,
                       'old_file_number', v_old_num, 'new_file_number', v_new_num),
    auth.uid());

  RETURN v_new_num;
END $function$;