ALTER TABLE public.eqs_ext_recent_units ADD COLUMN IF NOT EXISTS do_locn TEXT;
ALTER TABLE public.eqs_ext_bookings ADD COLUMN IF NOT EXISTS do_locn TEXT;