CREATE OR REPLACE FUNCTION public.fn_assign_file_number()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_year text;
  v_dep_code text;
  v_seq int;
  v_lock_key bigint;
BEGIN
  IF NEW.file_number IS NOT NULL THEN RETURN NEW; END IF;
  v_year := to_char(now(), 'YY');
  SELECT code INTO v_dep_code FROM public.departments WHERE id = NEW.department_id;
  IF v_dep_code IS NULL THEN
    RAISE EXCEPTION 'Department % has no code', NEW.department_id;
  END IF;
  -- Global sequence within a year across all departments
  v_lock_key := hashtextextended('EQ' || v_year, 0);
  PERFORM pg_advisory_xact_lock(v_lock_key);
  SELECT COALESCE(MAX(
    CAST(substring(file_number FROM '[0-9]{6}$') AS int)
  ), 0) + 1 INTO v_seq
  FROM public.files
  WHERE file_number LIKE 'EQ' || v_year || '%';
  NEW.file_number := 'EQ' || v_year || v_dep_code || lpad(v_seq::text, 6, '0');
  RETURN NEW;
END $function$;

-- Renumber existing 2026 files by created_at order (global sequence)
WITH ordered AS (
  SELECT f.id, f.file_number, d.code AS dep_code,
         ROW_NUMBER() OVER (ORDER BY f.created_at) AS seq
  FROM public.files f
  JOIN public.departments d ON d.id = f.department_id
  WHERE f.file_number LIKE 'EQ26%'
)
UPDATE public.files f
SET file_number = 'EQ26' || o.dep_code || lpad(o.seq::text, 6, '0')
FROM ordered o
WHERE f.id = o.id
  AND f.file_number IS DISTINCT FROM 'EQ26' || o.dep_code || lpad(o.seq::text, 6, '0');