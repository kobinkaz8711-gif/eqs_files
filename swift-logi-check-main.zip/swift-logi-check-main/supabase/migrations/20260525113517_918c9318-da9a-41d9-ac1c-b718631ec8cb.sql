
-- =========================================================
-- TABLES
-- =========================================================

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  position TEXT,
  department TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  is_system BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.user_roles (
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role_id UUID NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, role_id)
);

CREATE TABLE public.role_permissions (
  role_id UUID NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
  permission_id UUID NOT NULL REFERENCES public.permissions(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (role_id, permission_id)
);

-- =========================================================
-- FUNCTIONS
-- =========================================================

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER trg_roles_updated_at
  BEFORE UPDATE ON public.roles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- has_permission: проверяет, есть ли у пользователя право по коду
CREATE OR REPLACE FUNCTION public.has_permission(_user_id UUID, _code TEXT)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles ur
    JOIN public.role_permissions rp ON rp.role_id = ur.role_id
    JOIN public.permissions p ON p.id = rp.permission_id
    WHERE ur.user_id = _user_id
      AND (p.code = _code OR p.code = 'admin.full')
  );
$$;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _name TEXT)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles ur
    JOIN public.roles r ON r.id = ur.role_id
    WHERE ur.user_id = _user_id AND r.name = _name
  );
$$;

CREATE OR REPLACE FUNCTION public.is_admin(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT public.has_role(_user_id, 'Admin');
$$;

-- handle_new_user: создаёт профиль и (для test@test1.com) сразу Admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _admin_role_id UUID;
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', NEW.email)
  )
  ON CONFLICT (id) DO NOTHING;

  IF NEW.email = 'test@test1.com' THEN
    SELECT id INTO _admin_role_id FROM public.roles WHERE name = 'Admin' LIMIT 1;
    IF _admin_role_id IS NOT NULL THEN
      INSERT INTO public.user_roles (user_id, role_id)
      VALUES (NEW.id, _admin_role_id)
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =========================================================
-- RLS
-- =========================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

-- profiles
CREATE POLICY "profiles_select_auth" ON public.profiles
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "profiles_update_self" ON public.profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "profiles_update_managers" ON public.profiles
  FOR UPDATE TO authenticated
  USING (public.has_permission(auth.uid(), 'users.manage'));

CREATE POLICY "profiles_insert_managers" ON public.profiles
  FOR INSERT TO authenticated
  WITH CHECK (public.has_permission(auth.uid(), 'users.manage'));

CREATE POLICY "profiles_delete_managers" ON public.profiles
  FOR DELETE TO authenticated
  USING (public.has_permission(auth.uid(), 'users.manage'));

-- roles
CREATE POLICY "roles_select_auth" ON public.roles
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "roles_modify_managers" ON public.roles
  FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'roles.manage'))
  WITH CHECK (public.has_permission(auth.uid(), 'roles.manage'));

-- permissions
CREATE POLICY "permissions_select_auth" ON public.permissions
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "permissions_modify_admins" ON public.permissions
  FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'admin.full'))
  WITH CHECK (public.has_permission(auth.uid(), 'admin.full'));

-- user_roles
CREATE POLICY "user_roles_select_auth" ON public.user_roles
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "user_roles_modify_managers" ON public.user_roles
  FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'users.manage'))
  WITH CHECK (public.has_permission(auth.uid(), 'users.manage'));

-- role_permissions
CREATE POLICY "role_permissions_select_auth" ON public.role_permissions
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "role_permissions_modify_managers" ON public.role_permissions
  FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'roles.manage'))
  WITH CHECK (public.has_permission(auth.uid(), 'roles.manage'));

-- =========================================================
-- SEED DATA
-- =========================================================

INSERT INTO public.permissions (code, description) VALUES
  ('checklist.read',      'Просмотр чек-листов'),
  ('checklist.validate',  'Проверка заявок через чек-листы'),
  ('checklist.manage',    'Редактирование шаблонов чек-листов'),
  ('users.manage',        'Управление пользователями'),
  ('roles.manage',        'Управление ролями и правами'),
  ('settings.manage',     'Управление системными настройками'),
  ('admin.full',          'Полный административный доступ')
ON CONFLICT (code) DO NOTHING;

INSERT INTO public.roles (name, description, is_system) VALUES
  ('Admin',     'Полный доступ ко всем разделам и настройкам', true),
  ('Logistics', 'Сотрудник отдела логистики: работа с чек-листами', true),
  ('Sales',     'Менеджер по продажам: проверка заявок', true),
  ('Viewer',    'Только просмотр чек-листов', true)
ON CONFLICT (name) DO NOTHING;

-- Маппинг ролей и прав
WITH role_perm_map AS (
  SELECT * FROM (VALUES
    ('Admin',     'admin.full'),
    ('Logistics', 'checklist.read'),
    ('Logistics', 'checklist.validate'),
    ('Logistics', 'checklist.manage'),
    ('Sales',     'checklist.read'),
    ('Sales',     'checklist.validate'),
    ('Viewer',    'checklist.read')
  ) AS t(role_name, perm_code)
)
INSERT INTO public.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM role_perm_map m
JOIN public.roles r ON r.name = m.role_name
JOIN public.permissions p ON p.code = m.perm_code
ON CONFLICT DO NOTHING;
