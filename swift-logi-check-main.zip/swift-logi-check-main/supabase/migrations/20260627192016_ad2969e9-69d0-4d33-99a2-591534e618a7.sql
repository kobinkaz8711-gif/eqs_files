
CREATE OR REPLACE FUNCTION public.fn_revert_file_status(p_file_id uuid, p_notes text DEFAULT NULL)
RETURNS public.file_status
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_old public.file_status;
  v_new public.file_status;
  v_prev public.file_status;
BEGIN
  IF NOT public.has_role(auth.uid(), 'Admin') THEN
    RAISE EXCEPTION 'Only administrators can revert file status';
  END IF;

  SELECT status INTO v_old FROM public.files WHERE id = p_file_id FOR UPDATE;
  IF v_old IS NULL THEN RAISE EXCEPTION 'File not found'; END IF;

  IF v_old = 'DR' THEN
    RAISE EXCEPTION 'File is already in initial status (DR), nothing to revert';
  END IF;

  IF v_old = 'CN' THEN
    SELECT from_status INTO v_prev
      FROM public.file_status_history
      WHERE file_id = p_file_id AND to_status = 'CN'
      ORDER BY changed_at DESC
      LIMIT 1;
    v_new := COALESCE(v_prev, 'DR'::public.file_status);
  ELSIF v_old = 'CL' THEN
    v_new := 'RCL';
  ELSIF v_old = 'RCL' THEN
    v_new := 'RP';
  ELSIF v_old = 'RP' THEN
    v_new := 'OP';
  ELSIF v_old = 'OP' THEN
    v_new := 'DR';
  ELSE
    RAISE EXCEPTION 'Unsupported status %', v_old;
  END IF;

  UPDATE public.files
    SET status = v_new,
        closed_at = CASE WHEN v_old IN ('CL','CN') THEN NULL ELSE closed_at END,
        opened_at = CASE WHEN v_new = 'DR' THEN NULL ELSE opened_at END
  WHERE id = p_file_id;

  INSERT INTO public.file_status_history (file_id, from_status, to_status, notes, changed_by)
  VALUES (p_file_id, v_old, v_new, '[REVERT] ' || COALESCE(p_notes, ''), auth.uid());

  RETURN v_new;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_revert_file_status(uuid, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_revert_file_status(uuid, text) TO authenticated;
