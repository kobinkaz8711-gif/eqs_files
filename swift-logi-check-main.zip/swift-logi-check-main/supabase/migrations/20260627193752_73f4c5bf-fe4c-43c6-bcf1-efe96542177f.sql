
-- 1) eqs_ext_finance_totals & eqs_ext_sales: scope policies to authenticated, not public
DO $do$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT tablename, policyname
    FROM pg_policies
    WHERE schemaname='public'
      AND tablename IN ('eqs_ext_finance_totals','eqs_ext_sales')
      AND roles = '{public}'::name[]
  LOOP
    EXECUTE format('ALTER POLICY %I ON public.%I TO authenticated', r.policyname, r.tablename);
  END LOOP;
END
$do$;

-- 2) eqs_sftp_settings: SELECT admin-only
DROP POLICY IF EXISTS "eqs_sftp_settings read" ON public.eqs_sftp_settings;
CREATE POLICY "eqs_sftp_settings read admin"
  ON public.eqs_sftp_settings
  FOR SELECT
  TO authenticated
  USING (public.is_admin(auth.uid()));

-- 3) reporting_period_control: keep SELECT for authenticated, restrict writes to admins
DROP POLICY IF EXISTS "auth full insert" ON public.reporting_period_control;
DROP POLICY IF EXISTS "auth full update" ON public.reporting_period_control;
DROP POLICY IF EXISTS "auth full delete" ON public.reporting_period_control;
CREATE POLICY "reporting_period_control insert admin"
  ON public.reporting_period_control FOR INSERT TO authenticated
  WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "reporting_period_control update admin"
  ON public.reporting_period_control FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "reporting_period_control delete admin"
  ON public.reporting_period_control FOR DELETE TO authenticated
  USING (public.is_admin(auth.uid()));

-- 4) file_audit_log: keep SELECT for authenticated, restrict INSERT to admins, forbid UPDATE/DELETE
DROP POLICY IF EXISTS "auth full insert" ON public.file_audit_log;
DROP POLICY IF EXISTS "auth full update" ON public.file_audit_log;
DROP POLICY IF EXISTS "auth full delete" ON public.file_audit_log;
CREATE POLICY "file_audit_log insert admin"
  ON public.file_audit_log FOR INSERT TO authenticated
  WITH CHECK (public.is_admin(auth.uid()));
-- No UPDATE/DELETE policies = denied for all non-service roles.
