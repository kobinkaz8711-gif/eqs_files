// Minimal FTP client for Deno edge runtime.
// Implements: connect, login, TYPE I, PASV, STOR, LIST, RETR, DELE, QUIT.
// No FTPS (TLS shim unreliable in this runtime). Passive mode only.

const enc = new TextEncoder();
const dec = new TextDecoder();

export class FtpError extends Error {
  code: number;
  constructor(code: number, message: string) {
    super(`FTP ${code}: ${message}`);
    this.code = code;
  }
}

export class FtpClient {
  private ctrl!: Deno.TcpConn;
  private buf = "";
  private host = "";
  verbose = false;

  private log(...args: unknown[]) {
    if (this.verbose) console.log("[ftp]", ...args);
  }

  async connect(host: string, port = 21, timeoutMs = 15_000) {
    this.host = host;
    const p = Deno.connect({ hostname: host, port }) as Promise<Deno.TcpConn>;
    this.ctrl = await withTimeout(p, timeoutMs, `connect ${host}:${port}`);
    const greet = await this.readReply();
    if (greet.code !== 220) throw new FtpError(greet.code, greet.text);
  }

  async login(user: string, password: string) {
    let r = await this.cmd(`USER ${user}`);
    if (r.code === 331) r = await this.cmd(`PASS ${password}`);
    if (r.code !== 230 && r.code !== 202) {
      throw new FtpError(r.code, r.text);
    }
    await this.cmd("TYPE I", [200]);
  }

  async pasv(): Promise<Deno.TcpConn> {
    const r = await this.cmd("PASV", [227]);
    const m = r.text.match(/(\d+),(\d+),(\d+),(\d+),(\d+),(\d+)/);
    if (!m) throw new FtpError(227, `bad PASV response: ${r.text}`);
    const ip = `${m[1]}.${m[2]}.${m[3]}.${m[4]}`;
    const port = (parseInt(m[5]) << 8) + parseInt(m[6]);
    // Some servers behind NAT return internal IP — fall back to control host.
    const target = ip.startsWith("10.") || ip.startsWith("192.168.") || ip.startsWith("172.")
      ? this.host
      : ip;
    return await withTimeout(
      Deno.connect({ hostname: target, port }) as Promise<Deno.TcpConn>,
      15_000,
      `pasv connect ${target}:${port}`,
    );
  }

  async stor(remotePath: string, data: Uint8Array) {
    const data_conn = await this.pasv();
    try {
      const r1 = await this.cmd(`STOR ${remotePath}`, [125, 150]);
      this.log("STOR opened", r1.text);
      await writeAll(data_conn, data);
      data_conn.close();
      const r2 = await this.readReply();
      if (r2.code !== 226 && r2.code !== 250) {
        throw new FtpError(r2.code, r2.text);
      }
    } catch (e) {
      try { data_conn.close(); } catch {}
      throw e;
    }
  }

  async retr(remotePath: string): Promise<Uint8Array> {
    const data_conn = await this.pasv();
    try {
      await this.cmd(`RETR ${remotePath}`, [125, 150]);
      const chunks: Uint8Array[] = [];
      const tmp = new Uint8Array(64 * 1024);
      while (true) {
        const n = await data_conn.read(tmp);
        if (n === null) break;
        chunks.push(tmp.slice(0, n));
      }
      data_conn.close();
      const r = await this.readReply();
      if (r.code !== 226 && r.code !== 250) throw new FtpError(r.code, r.text);
      let total = 0;
      for (const c of chunks) total += c.length;
      const out = new Uint8Array(total);
      let off = 0;
      for (const c of chunks) { out.set(c, off); off += c.length; }
      return out;
    } catch (e) {
      try { data_conn.close(); } catch {}
      throw e;
    }
  }

  async list(remotePath: string): Promise<string[]> {
    const data_conn = await this.pasv();
    try {
      await this.cmd(`LIST ${remotePath}`, [125, 150]);
      const chunks: Uint8Array[] = [];
      const tmp = new Uint8Array(8192);
      while (true) {
        const n = await data_conn.read(tmp);
        if (n === null) break;
        chunks.push(tmp.slice(0, n));
      }
      data_conn.close();
      const r = await this.readReply();
      if (r.code !== 226 && r.code !== 250) throw new FtpError(r.code, r.text);
      let total = 0;
      for (const c of chunks) total += c.length;
      const out = new Uint8Array(total);
      let off = 0;
      for (const c of chunks) { out.set(c, off); off += c.length; }
      const text = dec.decode(out);
      return text.split(/\r?\n/).filter((l) => l.trim().length > 0);
    } catch (e) {
      try { data_conn.close(); } catch {}
      throw e;
    }
  }

  async dele(remotePath: string) {
    await this.cmd(`DELE ${remotePath}`, [250, 200]);
  }

  async quit() {
    try { await this.cmd("QUIT"); } catch {}
    try { this.ctrl.close(); } catch {}
  }

  close() {
    try { this.ctrl.close(); } catch {}
  }

  private async cmd(
    line: string,
    expect?: number[],
  ): Promise<{ code: number; text: string }> {
    this.log(">", line);
    await writeAll(this.ctrl, enc.encode(line + "\r\n"));
    const r = await this.readReply();
    this.log("<", r.code, r.text);
    if (expect && !expect.includes(r.code)) {
      throw new FtpError(r.code, r.text);
    }
    return r;
  }

  private async readReply(): Promise<{ code: number; text: string }> {
    // FTP reply: "ccc text\r\n" or multi-line "ccc-...\r\nccc text\r\n"
    const tmp = new Uint8Array(4096);
    while (true) {
      const idx = this.findReplyEnd();
      if (idx) {
        const block = this.buf.slice(0, idx.end);
        this.buf = this.buf.slice(idx.end);
        return { code: idx.code, text: block.trim() };
      }
      const n = await withTimeout(
        this.ctrl.read(tmp),
        30_000,
        "read FTP reply",
      );
      if (n === null) throw new Error("control connection closed");
      this.buf += dec.decode(tmp.subarray(0, n));
    }
  }

  private findReplyEnd(): { code: number; end: number } | null {
    // Look for a line that starts with "DDD " (space, not dash) followed by CRLF.
    const lines = this.buf.split("\r\n");
    let consumed = 0;
    let code = 0;
    for (let i = 0; i < lines.length - 1; i++) {
      const line = lines[i];
      consumed += line.length + 2;
      const m = line.match(/^(\d{3})([ -])/);
      if (m && m[2] === " ") {
        code = parseInt(m[1]);
        return { code, end: consumed };
      }
    }
    return null;
  }
}

async function writeAll(conn: Deno.TcpConn, data: Uint8Array) {
  let off = 0;
  while (off < data.length) {
    const n = await conn.write(data.subarray(off));
    off += n;
  }
}

function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return Promise.race([
    p,
    new Promise<T>((_, rej) =>
      setTimeout(() => rej(new Error(`timeout ${ms}ms: ${label}`)), ms)
    ),
  ]);
}
