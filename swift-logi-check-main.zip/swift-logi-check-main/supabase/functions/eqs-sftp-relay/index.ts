// Supabase Edge Function: eqs-sftp-relay (FTP transport)
// Runs every minute via pg_cron.
// 1. Upload pending xlsx from Storage bucket "eqs-outbox" → FTP outbox_remote_path
// 2. Scan processed_remote_path → save to "eqs-inbox", update booking ID
// 3. Scan errors_remote_path → mark failed
//
// Env vars: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, EQS_SFTP_PASSWORD

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { FtpClient } from "./ftp.ts";


const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const FTP_PASSWORD = Deno.env.get("EQS_SFTP_PASSWORD") ?? "";

interface FtpSettings {
  host: string | null;
  port: number;
  username: string | null;
  outbox_remote_path: string | null;
  processed_remote_path: string | null;
  errors_remote_path: string | null;
  incomplete_remote_path: string | null;
  enabled: boolean;
  use_tls: boolean;
}

function jsonResp(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

function extractBookingId(filename: string, prefix: string): string | null {
  if (!filename.startsWith(prefix)) return null;
  const rest = filename.slice(prefix.length).replace(/\.xlsx$/i, "");
  if (rest.startsWith("_") && rest.length > 1) return rest.slice(1);
  return null;
}

function parseLsName(line: string): string | null {
  // Unix `ls -l`: "drwxr-xr-x 1 owner group  size Mon DD HH:MM name"
  // Take everything after the 8th whitespace-separated field.
  const parts = line.split(/\s+/);
  if (parts.length < 9) return null;
  return parts.slice(8).join(" ");
}


Deno.serve(async (req) => {
  if (req.method !== "POST" && req.method !== "GET") {
    return jsonResp({ error: "method not allowed" }, 405);
  }

  const supabase = createClient(SUPABASE_URL, SERVICE_ROLE, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: settings, error: sErr } = await supabase
    .from("eqs_sftp_settings")
    .select("*")
    .eq("id", 1)
    .maybeSingle<FtpSettings>();
  if (sErr) return jsonResp({ error: sErr.message }, 500);
  if (!settings || !settings.enabled) {
    return jsonResp({ ok: true, skipped: "disabled" });
  }
  if (!settings.host || !settings.username || !FTP_PASSWORD) {
    return jsonResp({ ok: false, error: "incomplete ftp config" }, 400);
  }

  // ── Diagnostic mode: raw TCP probe ────────────────────────────
  const url = new URL(req.url);
  if (url.searchParams.get("diag") === "1") {
    const diag: any = {
      host: settings.host,
      port: settings.port ?? 21,
      connected: false,
      bytes_read: 0,
      banner: null,
      error: null,
      remote_ip: null,
      egress_ip: null,
    };
    try {
      const ipRes = await fetch("https://api.ipify.org?format=json");
      diag.egress_ip = (await ipRes.json()).ip;
    } catch (e) { diag.egress_ip_error = String(e); }

    let conn: Deno.TcpConn | null = null;
    try {
      const connectP = Deno.connect({
        hostname: settings.host,
        port: settings.port ?? 21,
      }) as Promise<Deno.TcpConn>;
      conn = await Promise.race([
        connectP,
        new Promise<never>((_, rej) =>
          setTimeout(() => rej(new Error("connect timeout 10s")), 10_000),
        ),
      ]);
      diag.connected = true;
      try {
        diag.remote_ip = (conn.remoteAddr as Deno.NetAddr).hostname;
      } catch {}

      const buf = new Uint8Array(1024);
      const n = await Promise.race([
        conn.read(buf),
        new Promise<null>((res) => setTimeout(() => res(null), 10_000)),
      ]);
      if (n === null) {
        diag.error = "no banner within 10s (socket open, server silent)";
      } else if (n === 0) {
        diag.error = "server closed connection without sending banner";
      } else {
        diag.bytes_read = n;
        diag.banner = new TextDecoder().decode(buf.subarray(0, n));
      }
    } catch (e) {
      diag.error = String(e);
    } finally {
      try { conn?.close(); } catch {}
    }
    return jsonResp(diag);
  }

  // ── Diagnostic LIST: show what's on the FTP right now ─────────
  if (url.searchParams.get("diag") === "ls") {
    const ls: any = { folders: {} };
    const c = new FtpClient();
    try {
      await c.connect(settings.host, settings.port ?? 21);
      await c.login(settings.username, FTP_PASSWORD);
      for (const [key, path] of [
        ["outbox", settings.outbox_remote_path],
        ["processed", settings.processed_remote_path],
        ["errors", settings.errors_remote_path],
        ["incomplete", settings.incomplete_remote_path],
      ] as const) {
        if (!path) { ls.folders[key] = { path: null, files: [] }; continue; }
        try {
          const lines = await c.list(path);
          ls.folders[key] = { path, lines };
        } catch (e) {
          ls.folders[key] = { path, error: String(e) };
        }
      }
    } catch (e) {
      ls.error = String(e);
    } finally {
      try { await c.quit(); } catch {}
    }
    return jsonResp(ls);
  }




  const client = new FtpClient();
  const result: any = { uploaded: 0, processed: 0, incomplete: 0, errors: 0, details: [] };

  try {
    await client.connect(settings.host, settings.port ?? 21);
    await client.login(settings.username, FTP_PASSWORD);

    // 1. Upload pending
    if (settings.outbox_remote_path) {
      const { data: pending } = await supabase
        .from("eqs_booking_exports")
        .select("id,filename,payload_path")
        .eq("status", "pending")
        .order("created_at", { ascending: true })
        .limit(50);

      for (const exp of pending ?? []) {
        try {
          const { data: blob, error: dlErr } = await supabase.storage
            .from("eqs-outbox")
            .download(exp.payload_path);
          if (dlErr || !blob) throw new Error(dlErr?.message ?? "download failed");
          const buf = new Uint8Array(await blob.arrayBuffer());
          const remote = `${settings.outbox_remote_path.replace(/\/$/, "")}/${exp.filename}`;
          await client.stor(remote, buf);
          await supabase
            .from("eqs_booking_exports")
            .update({ status: "sent", sent_at: new Date().toISOString() })
            .eq("id", exp.id);
          result.uploaded++;
          result.details.push({ uploaded: exp.filename });
        } catch (e) {
          result.details.push({ upload_failed: exp.filename, error: String(e) });
        }
      }
    }

    // Map sent exports by filename prefix
    const { data: sentExports } = await supabase
      .from("eqs_booking_exports")
      .select("id,file_id,file_number,filename,payload_path")
      .in("status", ["sent", "acknowledged", "incomplete"]);
    const prefixToExport = new Map<string, any>();
    for (const e of sentExports ?? []) {
      const prefix = e.filename.replace(/\.xlsx$/i, "");
      prefixToExport.set(prefix, e);
    }

    // 2. Scan processed
    if (settings.processed_remote_path) {
      let lines: string[] = [];
      try { lines = await client.list(settings.processed_remote_path); } catch (e) {
        result.details.push({ list_processed_failed: String(e) });
      }
      for (const line of lines) {
        const name = parseLsName(line);
        if (!name || !name.toLowerCase().endsWith(".xlsx")) continue;
        let matchedExp: any = null;
        let bookingId: string | null = null;
        for (const [prefix, exp] of prefixToExport.entries()) {
          const bid = extractBookingId(name, prefix);
          if (bid) { matchedExp = exp; bookingId = bid; break; }
        }
        if (!matchedExp) continue;
        try {
          const remotePath = `${settings.processed_remote_path.replace(/\/$/, "")}/${name}`;
          const buf = await client.retr(remotePath);
          const inboxPath = `${matchedExp.file_number}/${name}`;
          await supabase.storage
            .from("eqs-inbox")
            .upload(inboxPath, buf, {
              contentType:
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
              upsert: true,
            });
          await supabase
            .from("eqs_booking_exports")
            .update({
              status: "acknowledged",
              response_filename: name,
              response_path: inboxPath,
              eqs_booking_id: bookingId,
              acknowledged_at: new Date().toISOString(),
            })
            .eq("id", matchedExp.id);
          await supabase
            .from("files")
            .update({
              eqs_booking_state: "created",
              eqs_booking_id: bookingId,
              eqs_booking_received_at: new Date().toISOString(),
              eqs_booking_error: null,
            })
            .eq("id", matchedExp.file_id);
          if (bookingId) {
            await supabase.rpc("fn_assign_booking", {
              p_file_id: matchedExp.file_id,
              p_booking_no: bookingId,
              p_source: "eqs",
            });
          }
          try { await client.dele(remotePath); } catch {}
          result.processed++;
          result.details.push({ processed: name, booking_id: bookingId });
        } catch (e) {
          result.details.push({ process_failed: name, error: String(e) });
        }
      }
    }

    // 3. Scan errors
    if (settings.errors_remote_path) {
      let lines: string[] = [];
      try { lines = await client.list(settings.errors_remote_path); } catch {}
      for (const line of lines) {
        const name = parseLsName(line);
        if (!name || !name.toLowerCase().endsWith(".xlsx")) continue;
        let matchedExp: any = null;
        for (const [prefix, exp] of prefixToExport.entries()) {
          if (name.startsWith(prefix)) { matchedExp = exp; break; }
        }
        if (!matchedExp) continue;
        try {
          const remotePath = `${settings.errors_remote_path.replace(/\/$/, "")}/${name}`;
          const buf = await client.retr(remotePath);
          const inboxPath = `${matchedExp.file_number}/${name}`;
          await supabase.storage
            .from("eqs-inbox")
            .upload(inboxPath, buf, {
              contentType:
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
              upsert: true,
            });
          await supabase
            .from("eqs_booking_exports")
            .update({
              status: "failed",
              response_filename: name,
              response_path: inboxPath,
              error: "EQS returned error file",
              acknowledged_at: new Date().toISOString(),
            })
            .eq("id", matchedExp.id);
          await supabase
            .from("files")
            .update({
              eqs_booking_state: "failed",
              eqs_booking_error: name,
              eqs_booking_received_at: new Date().toISOString(),
            })
            .eq("id", matchedExp.file_id);
          try { await client.dele(remotePath); } catch {}
          result.errors++;
          result.details.push({ error_file: name });
        } catch (e) {
          result.details.push({ error_process_failed: name, error: String(e) });
        }
      }
    }

    // 4. Scan incomplete
    if (settings.incomplete_remote_path) {
      let lines: string[] = [];
      try { lines = await client.list(settings.incomplete_remote_path); } catch (e) {
        result.details.push({ list_incomplete_failed: String(e) });
      }
      for (const line of lines) {
        const name = parseLsName(line);
        if (!name || !name.toLowerCase().endsWith(".xlsx")) continue;
        let matchedExp: any = null;
        let bookingId: string | null = null;
        for (const [prefix, exp] of prefixToExport.entries()) {
          const bid = extractBookingId(name, prefix);
          if (bid) { matchedExp = exp; bookingId = bid; break; }
        }
        if (!matchedExp) continue;
        try {
          const remotePath = `${settings.incomplete_remote_path.replace(/\/$/, "")}/${name}`;
          const buf = await client.retr(remotePath);
          const inboxPath = `${matchedExp.file_number}/${name}`;
          await supabase.storage
            .from("eqs-inbox")
            .upload(inboxPath, buf, {
              contentType:
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
              upsert: true,
            });
          await supabase
            .from("eqs_booking_exports")
            .update({
              status: "incomplete",
              response_filename: name,
              response_path: inboxPath,
              eqs_booking_id: bookingId,
              acknowledged_at: new Date().toISOString(),
            })
            .eq("id", matchedExp.id);
          await supabase
            .from("files")
            .update({
              eqs_booking_state: "incomplete",
              eqs_booking_id: bookingId,
              eqs_booking_received_at: new Date().toISOString(),
              eqs_booking_error: null,
            })
            .eq("id", matchedExp.file_id);
          if (bookingId) {
            await supabase.rpc("fn_assign_booking", {
              p_file_id: matchedExp.file_id,
              p_booking_no: bookingId,
              p_source: "eqs",
            });
          }
          try { await client.dele(remotePath); } catch {}
          result.incomplete++;
          result.details.push({ incomplete: name, booking_id: bookingId });
        } catch (e) {
          result.details.push({ incomplete_process_failed: name, error: String(e) });
        }
      }
    }
  } catch (e) {
    try { client.close(); } catch {}
    return jsonResp({ ok: false, error: String(e), partial: result }, 500);
  } finally {
    try { await client.quit(); } catch {}
  }

  return jsonResp({ ok: true, ...result });
});

